
using Microsoft.AspNetCore.Mvc;
[ApiController]
[Route("api/[controller]")]
public class IclipsController:ControllerBase{
private readonly IclipsService _service;
public IclipsController(IclipsService s){_service=s;}

[HttpPost("Send_Email")]
public async Task<IActionResult> Send_Email(string pCompanyID, string pRecipients, string pSubject, string pBody, string pAttachment)
{
    var r = await _service.Send_Email(pCompanyID, pRecipients, pSubject, pBody, pAttachment);
    return Ok(r);
}
[HttpPost("Get_Policy_Setup")]
public async Task<IActionResult> Get_Policy_Setup(string pCompanyID, string ptable, string pPolicyid, string pskey1)
{
    var r = await _service.Get_Policy_Setup(pCompanyID, ptable, pPolicyid, pskey1);
    return Ok(r);
}
[HttpPost("GetSingleValueICLIPS")]
public async Task<IActionResult> GetSingleValueICLIPS(string pCompanyID, string ptable, string pskey1)
{
    var r = await _service.GetSingleValueICLIPS(pCompanyID, ptable, pskey1);
    return Ok(r);
}
[HttpPost("GetSingleValue")]
public async Task<IActionResult> GetSingleValue(string pCompanyID, string ptable, string pskey1)
{
    var r = await _service.GetSingleValue(pCompanyID, ptable, pskey1);
    return Ok(r);
}
[HttpPost("GetProductTypeSetupValue")]
public async Task<IActionResult> GetProductTypeSetupValue(string pCompanyID, string pProductType, string pSetupName)
{
    var r = await _service.GetProductTypeSetupValue(pCompanyID, pProductType, pSetupName);
    return Ok(r);
}
[HttpPost("GetComboList")]
public async Task<IActionResult> GetComboList(string pCompanyID, string ptable, string ptype, string pcate)
{
    var r = await _service.GetComboList(pCompanyID, ptable, ptype, pcate);
    return Ok(r);
}
[HttpPost("GetSearchList")]
public async Task<IActionResult> GetSearchList(string pCompanyID, string pListType, string pCriteria)
{
    var r = await _service.GetSearchList(pCompanyID, pListType, pCriteria);
    return Ok(r);
}
[HttpPost("GetSearchListByCriteria")]
public async Task<IActionResult> GetSearchListByCriteria(string pCompanyID, string pListType, string pCriteria)
{
    var r = await _service.GetSearchListByCriteria(pCompanyID, pListType, pCriteria);
    return Ok(r);
}
[HttpPost("GetPolicy")]
public async Task<IActionResult> GetPolicy(string pCompanyID, string pPolicyID)
{
    var r = await _service.GetPolicy(pCompanyID, pPolicyID);
    return Ok(r);
}
[HttpPost("SaveClient")]
public async Task<IActionResult> SaveClient(string pmode)
{
    var r = await _service.SaveClient(pmode);
    return Ok(r);
}
[HttpPost("GetClient")]
public async Task<IActionResult> GetClient(string pclientid)
{
    var r = await _service.GetClient(pclientid);
    return Ok(r);
}
[HttpPost("SaveAgent")]
public async Task<IActionResult> SaveAgent(string pmode)
{
    var r = await _service.SaveAgent(pmode);
    return Ok(r);
}
[HttpPost("GetAgent")]
public async Task<IActionResult> GetAgent(string pCompanyID, string pPolicyID, string pAgentID)
{
    var r = await _service.GetAgent(pCompanyID, pPolicyID, pAgentID);
    return Ok(r);
}
[HttpPost("GetBranch")]
public async Task<IActionResult> GetBranch(string pCompanyID, string pPolicyID, string pBranchID)
{
    var r = await _service.GetBranch(pCompanyID, pPolicyID, pBranchID);
    return Ok(r);
}
[HttpPost("IsExistAgent")]
public async Task<IActionResult> IsExistAgent(string pCompanyID, string pPolicyID, string pAgentID)
{
    var r = await _service.IsExistAgent(pCompanyID, pPolicyID, pAgentID);
    return Ok(r);
}
[HttpPost("GetPackageCoverageList")]
public async Task<IActionResult> GetPackageCoverageList(string pCompanyID, string pPackageID, string pMemberID)
{
    var r = await _service.GetPackageCoverageList(pCompanyID, pPackageID, pMemberID);
    return Ok(r);
}
[HttpPost("GetQuestionerList")]
public async Task<IActionResult> GetQuestionerList(string pCompanyID, string pProductType, string pMemberID)
{
    var r = await _service.GetQuestionerList(pCompanyID, pProductType, pMemberID);
    return Ok(r);
}
[HttpPost("GetCertificateList")]
public async Task<IActionResult> GetCertificateList(string pCompanyID, string pCriteria)
{
    var r = await _service.GetCertificateList(pCompanyID, pCriteria);
    return Ok(r);
}
[HttpPost("GetCertificateListForClaim")]
public async Task<IActionResult> GetCertificateListForClaim(string pCompanyID, string pCriteria)
{
    var r = await _service.GetCertificateListForClaim(pCompanyID, pCriteria);
    return Ok(r);
}
[HttpPost("GetCertificateListForSurrender")]
public async Task<IActionResult> GetCertificateListForSurrender(string pCompanyID, string pCriteria)
{
    var r = await _service.GetCertificateListForSurrender(pCompanyID, pCriteria);
    return Ok(r);
}
[HttpPost("GetCertificateHeader")]
public async Task<IActionResult> GetCertificateHeader(string pCompanyID, string pMemberID)
{
    var r = await _service.GetCertificateHeader(pCompanyID, pMemberID);
    return Ok(r);
}
[HttpPost("GetCertificate")]
public async Task<IActionResult> GetCertificate(string pCompanyID, string pMemberID)
{
    var r = await _service.GetCertificate(pCompanyID, pMemberID);
    return Ok(r);
}
[HttpPost("GetCertificate_Beneficiary")]
public async Task<IActionResult> GetCertificate_Beneficiary(string pCompanyID, string pPolicyID, string pCertificateID)
{
    var r = await _service.GetCertificate_Beneficiary(pCompanyID, pPolicyID, pCertificateID);
    return Ok(r);
}
[HttpPost("GetCertificate_Coverage")]
public async Task<IActionResult> GetCertificate_Coverage(string pCompanyID, string pPolicyID, string pCertificateID)
{
    var r = await _service.GetCertificate_Coverage(pCompanyID, pPolicyID, pCertificateID);
    return Ok(r);
}
[HttpPost("GetCertificate_PreviousPolicy")]
public async Task<IActionResult> GetCertificate_PreviousPolicy(string pCompanyID, string pPolicyID, string pCertificateID)
{
    var r = await _service.GetCertificate_PreviousPolicy(pCompanyID, pPolicyID, pCertificateID);
    return Ok(r);
}
[HttpPost("GetHealthList")]
public async Task<IActionResult> GetHealthList(string pCompanyID, string pListType, string pProductID, string pPolicyID, string pMemberID)
{
    var r = await _service.GetHealthList(pCompanyID, pListType, pProductID, pPolicyID, pMemberID);
    return Ok(r);
}
[HttpPost("GetInsuredAge")]
public async Task<IActionResult> GetInsuredAge(string pCompanyID, string pPlanID, string pDOB, string pAppRecDt)
{
    var r = await _service.GetInsuredAge(pCompanyID, pPlanID, pDOB, pAppRecDt);
    return Ok(r);
}
[HttpPost("GetMaturityDate")]
public async Task<IActionResult> GetMaturityDate(string pCompanyID, string pPolicyID, string pStartDate, string pDuration)
{
    var r = await _service.GetMaturityDate(pCompanyID, pPolicyID, pStartDate, pDuration);
    return Ok(r);
}
[HttpPost("SaveCertificate")]
public async Task<IActionResult> SaveCertificate(string pCertificate, string pBeneficiary, string pHealthQ, string pHealthH)
{
    var r = await _service.SaveCertificate(pCertificate, pBeneficiary, pHealthQ, pHealthH);
    return Ok(r);
}
[HttpPost("SaveNewCertificate")]
public async Task<IActionResult> SaveNewCertificate(string pUseExistingInsuredID, string pUseExistingDebiturID, string oagt, string loben, string loque, string locov, string loPolH, string loPolC, string lodoc, string pMode)
{
    var r = await _service.SaveNewCertificate(pUseExistingInsuredID, pUseExistingDebiturID, oagt, loben, loque, locov, loPolH, loPolC, lodoc, pMode);
    return Ok(r);
}
[HttpPost("SaveCertificate")]
public async Task<IActionResult> SaveCertificate(string pUseExistingInsuredID, string pUseExistingDebiturID, string poins, string podeb, string oagt, string loben, string loque, string locov, string loPolH, string loPolC, string lodoc, string pMode)
{
    var r = await _service.SaveCertificate(pUseExistingInsuredID, pUseExistingDebiturID, poins, podeb, oagt, loben, loque, locov, loPolH, loPolC, lodoc, pMode);
    return Ok(r);
}
[HttpPost("SaveCertificate")]
public async Task<IActionResult> SaveCertificate(string pUseExistingInsuredID, string pUseExistingDebiturID, string poins, string podeb, string oagt, string loben, string loque)
{
    var r = await _service.SaveCertificate(pUseExistingInsuredID, pUseExistingDebiturID, poins, podeb, oagt, loben, loque);
    return Ok(r);
}
[HttpPost("ValidateCertificate")]
public async Task<IActionResult> ValidateCertificate(string pMemberID, string pProcessBy)
{
    var r = await _service.ValidateCertificate(pMemberID, pProcessBy);
    return Ok(r);
}
[HttpPost("ApproveCertificate")]
public async Task<IActionResult> ApproveCertificate(string pMemberID, string pProcessBy)
{
    var r = await _service.ApproveCertificate(pMemberID, pProcessBy);
    return Ok(r);
}
[HttpPost("IssueCertificate")]
public async Task<IActionResult> IssueCertificate(string pMemberID, string pProcessBy)
{
    var r = await _service.IssueCertificate(pMemberID, pProcessBy);
    return Ok(r);
}
[HttpPost("GetCertificate_Agent")]
public async Task<IActionResult> GetCertificate_Agent(string pCompanyID, string pPolicyID, string pMemberID)
{
    var r = await _service.GetCertificate_Agent(pCompanyID, pPolicyID, pMemberID);
    return Ok(r);
}
[HttpPost("GetCertificate_PrePolicy")]
public async Task<IActionResult> GetCertificate_PrePolicy(string pMemberID, string pInsuredID, string pType)
{
    var r = await _service.GetCertificate_PrePolicy(pMemberID, pInsuredID, pType);
    return Ok(r);
}
[HttpPost("SavePrePolicy")]
public async Task<IActionResult> SavePrePolicy(string loPrePol)
{
    var r = await _service.SavePrePolicy(loPrePol);
    return Ok(r);
}
[HttpPost("UpdatePolicySAR")]
public async Task<IActionResult> UpdatePolicySAR(string pMemberID, string pProcessBy)
{
    var r = await _service.UpdatePolicySAR(pMemberID, pProcessBy);
    return Ok(r);
}
[HttpPost("GetDocumentList")]
public async Task<IActionResult> GetDocumentList(string pCompanyID, string pProductType, string pMemberID)
{
    var r = await _service.GetDocumentList(pCompanyID, pProductType, pMemberID);
    return Ok(r);
}
[HttpPost("GetDocumentListOf")]
public async Task<IActionResult> GetDocumentListOf(string pCompanyID, string pProductType, string pMemberID)
{
    var r = await _service.GetDocumentListOf(pCompanyID, pProductType, pMemberID);
    return Ok(r);
}
[HttpPost("GetBeneficiaryList")]
public async Task<IActionResult> GetBeneficiaryList(string pMemberID)
{
    var r = await _service.GetBeneficiaryList(pMemberID);
    return Ok(r);
}
[HttpPost("GetPrePolicy")]
public async Task<IActionResult> GetPrePolicy(string pMemberID)
{
    var r = await _service.GetPrePolicy(pMemberID);
    return Ok(r);
}
[HttpPost("GetPreClaim")]
public async Task<IActionResult> GetPreClaim(string pMemberID)
{
    var r = await _service.GetPreClaim(pMemberID);
    return Ok(r);
}
[HttpPost("GetCertificate_Letters")]
public async Task<IActionResult> GetCertificate_Letters(string pMemberID)
{
    var r = await _service.GetCertificate_Letters(pMemberID);
    return Ok(r);
}
[HttpPost("GetPolicyInfo")]
public async Task<IActionResult> GetPolicyInfo(string pCompanyID, string pListType, string pPolicyID)
{
    var r = await _service.GetPolicyInfo(pCompanyID, pListType, pPolicyID);
    return Ok(r);
}
[HttpPost("GetPlanInfo")]
public async Task<IActionResult> GetPlanInfo(string pCompanyID, string pListType, string pPlanID)
{
    var r = await _service.GetPlanInfo(pCompanyID, pListType, pPlanID);
    return Ok(r);
}
[HttpPost("GetPackagePlan")]
public async Task<IActionResult> GetPackagePlan(string pCompanyID, string pPackageID)
{
    var r = await _service.GetPackagePlan(pCompanyID, pPackageID);
    return Ok(r);
}
[HttpPost("GetClientList")]
public async Task<IActionResult> GetClientList(string pCompanyID, string pListType, string pCriteria)
{
    var r = await _service.GetClientList(pCompanyID, pListType, pCriteria);
    return Ok(r);
}
[HttpPost("GetClientInfo")]
public async Task<IActionResult> GetClientInfo(string pCompanyID, string pClientID)
{
    var r = await _service.GetClientInfo(pCompanyID, pClientID);
    return Ok(r);
}
[HttpPost("GetUnderwritingList")]
public async Task<IActionResult> GetUnderwritingList(string pCompanyID, string pCriteria)
{
    var r = await _service.GetUnderwritingList(pCompanyID, pCriteria);
    return Ok(r);
}
[HttpPost("GetUnderwriting")]
public async Task<IActionResult> GetUnderwriting(string pUnderwritingID)
{
    var r = await _service.GetUnderwriting(pUnderwritingID);
    return Ok(r);
}
[HttpPost("GetUnderwritingsar")]
public async Task<IActionResult> GetUnderwritingsar(string pUnderwritingID)
{
    var r = await _service.GetUnderwritingsar(pUnderwritingID);
    return Ok(r);
}
[HttpPost("GetUnderwriting_Remark")]
public async Task<IActionResult> GetUnderwriting_Remark(string pUnderwritingID)
{
    var r = await _service.GetUnderwriting_Remark(pUnderwritingID);
    return Ok(r);
}
[HttpPost("GetUnderwriting_History")]
public async Task<IActionResult> GetUnderwriting_History(string pUnderwritingID)
{
    var r = await _service.GetUnderwriting_History(pUnderwritingID);
    return Ok(r);
}
[HttpPost("GetUnderwriting_Previous")]
public async Task<IActionResult> GetUnderwriting_Previous(string pUnderwritingID)
{
    var r = await _service.GetUnderwriting_Previous(pUnderwritingID);
    return Ok(r);
}
[HttpPost("GetUnderwriting_RequirementMedical")]
public async Task<IActionResult> GetUnderwriting_RequirementMedical(string pUnderwritingID)
{
    var r = await _service.GetUnderwriting_RequirementMedical(pUnderwritingID);
    return Ok(r);
}
[HttpPost("GetUnderwriting_RequirementFinancial")]
public async Task<IActionResult> GetUnderwriting_RequirementFinancial(string pUnderwritingID)
{
    var r = await _service.GetUnderwriting_RequirementFinancial(pUnderwritingID);
    return Ok(r);
}
[HttpPost("GetUnderwriting_Coverage")]
public async Task<IActionResult> GetUnderwriting_Coverage(string pUnderwritingID)
{
    var r = await _service.GetUnderwriting_Coverage(pUnderwritingID);
    return Ok(r);
}
[HttpPost("GetUnderwriting_PreviousPolicy")]
public async Task<IActionResult> GetUnderwriting_PreviousPolicy(string pUnderwritingID, string pClientID, string pMemberID)
{
    var r = await _service.GetUnderwriting_PreviousPolicy(pUnderwritingID, pClientID, pMemberID);
    return Ok(r);
}
[HttpPost("Add_Underwriting_Remark")]
public async Task<IActionResult> Add_Underwriting_Remark(string pmode, string pUnderwritingID, string pRemarkDate, string pRemarkType, string pRemark, string pprocessby)
{
    var r = await _service.Add_Underwriting_Remark(pmode, pUnderwritingID, pRemarkDate, pRemarkType, pRemark, pprocessby);
    return Ok(r);
}
[HttpPost("GetUnderwriting_Letters")]
public async Task<IActionResult> GetUnderwriting_Letters(string pUnderwritingID)
{
    var r = await _service.GetUnderwriting_Letters(pUnderwritingID);
    return Ok(r);
}
[HttpPost("GetUnderwriting_Letters_Info")]
public async Task<IActionResult> GetUnderwriting_Letters_Info(string pUnderwritingID)
{
    var r = await _service.GetUnderwriting_Letters_Info(pUnderwritingID);
    return Ok(r);
}
[HttpPost("DeleteUnderwritingRequirement")]
public async Task<IActionResult> DeleteUnderwritingRequirement(string pUnderwritingRequirementID)
{
    var r = await _service.DeleteUnderwritingRequirement(pUnderwritingRequirementID);
    return Ok(r);
}
[HttpPost("WaiveUnderwritingRequirement")]
public async Task<IActionResult> WaiveUnderwritingRequirement(string pUnderwritingRequirementID)
{
    var r = await _service.WaiveUnderwritingRequirement(pUnderwritingRequirementID);
    return Ok(r);
}
[HttpPost("SaveUnderwritingRequirement")]
public async Task<IActionResult> SaveUnderwritingRequirement(string pmode, string oreq, string pProcessBy)
{
    var r = await _service.SaveUnderwritingRequirement(pmode, oreq, pProcessBy);
    return Ok(r);
}
[HttpPost("SaveUnderwriting")]
public async Task<IActionResult> SaveUnderwriting(string pmode, string pouw, string loreq, string locov, string lopol, string pprocesssby)
{
    var r = await _service.SaveUnderwriting(pmode, pouw, loreq, locov, lopol, pprocesssby);
    return Ok(r);
}
[HttpPost("StartUnderwritingReview")]
public async Task<IActionResult> StartUnderwritingReview(string pUnderwritingID, string pReviewDate, string pUnderwriterID, string pRemark, string pprocesssby)
{
    var r = await _service.StartUnderwritingReview(pUnderwritingID, pReviewDate, pUnderwriterID, pRemark, pprocesssby);
    return Ok(r);
}
[HttpPost("SetUnderwritingDecision")]
public async Task<IActionResult> SetUnderwritingDecision(string pUnderwritingID, string pDecisionDate, string pUnderwritingDecision, string pExclusionType, string pReasonForExclusion, string pRemark, string pReadyForApproval, string pExtraMortalita, string pExtraMortalitaType, string pprocesssby)
{
    var r = await _service.SetUnderwritingDecision(pUnderwritingID, pDecisionDate, pUnderwritingDecision, pExclusionType, pReasonForExclusion, pRemark, pReadyForApproval, pExtraMortalita, pExtraMortalitaType, pprocesssby);
    return Ok(r);
}
[HttpPost("ApproveUnderwriting")]
public async Task<IActionResult> ApproveUnderwriting(string pUnderwritingID, string pApproveDate, string pRemark, string pprocesssby)
{
    var r = await _service.ApproveUnderwriting(pUnderwritingID, pApproveDate, pRemark, pprocesssby);
    return Ok(r);
}
[HttpPost("ReverseUnderwriting")]
public async Task<IActionResult> ReverseUnderwriting(string pUnderwritingID, string pRemark, string pprocesssby)
{
    var r = await _service.ReverseUnderwriting(pUnderwritingID, pRemark, pprocesssby);
    return Ok(r);
}
[HttpPost("CancelUnderwriting")]
public async Task<IActionResult> CancelUnderwriting(string pUnderwritingID, string pRemark, string pprocesssby)
{
    var r = await _service.CancelUnderwriting(pUnderwritingID, pRemark, pprocesssby);
    return Ok(r);
}
[HttpPost("RollbackUnderwriting")]
public async Task<IActionResult> RollbackUnderwriting(string pUnderwritingID, string pRemark, string pprocesssby)
{
    var r = await _service.RollbackUnderwriting(pUnderwritingID, pRemark, pprocesssby);
    return Ok(r);
}
[HttpPost("ResetUnderwriting")]
public async Task<IActionResult> ResetUnderwriting(string pUnderwritingID, string pRemark, string pprocesssby)
{
    var r = await _service.ResetUnderwriting(pUnderwritingID, pRemark, pprocesssby);
    return Ok(r);
}
[HttpPost("GetCodeList")]
public async Task<IActionResult> GetCodeList(string pCompanyID, string pCodeType)
{
    var r = await _service.GetCodeList(pCompanyID, pCodeType);
    return Ok(r);
}
[HttpPost("GetCode")]
public async Task<IActionResult> GetCode(string pCompanyID, string pCodeType, string pCodeID)
{
    var r = await _service.GetCode(pCompanyID, pCodeType, pCodeID);
    return Ok(r);
}
[HttpPost("SaveCode")]
public async Task<IActionResult> SaveCode(string pmode, string pCode, string pprocesssby)
{
    var r = await _service.SaveCode(pmode, pCode, pprocesssby);
    return Ok(r);
}
[HttpPost("DeleteCode")]
public async Task<IActionResult> DeleteCode(string pCompanyID, string pCodeType, string pCodeID, string pprocesssby)
{
    var r = await _service.DeleteCode(pCompanyID, pCodeType, pCodeID, pprocesssby);
    return Ok(r);
}
[HttpPost("IsExistCode")]
public async Task<IActionResult> IsExistCode(string pCompanyID, string pCodeType, string pCodeID, string pCodeName)
{
    var r = await _service.IsExistCode(pCompanyID, pCodeType, pCodeID, pCodeName);
    return Ok(r);
}
[HttpPost("GetParameterSettingList")]
public async Task<IActionResult> GetParameterSettingList(string pCompanyID, string pcategory)
{
    var r = await _service.GetParameterSettingList(pCompanyID, pcategory);
    return Ok(r);
}
[HttpPost("GetParameterSettingList")]
public async Task<IActionResult> GetParameterSettingList(string pCompanyID, string pcategory, string pPage, string pPageSize)
{
    var r = await _service.GetParameterSettingList(pCompanyID, pcategory, pPage, pPageSize);
    return Ok(r);
}
[HttpPost("GetParameterSetting")]
public async Task<IActionResult> GetParameterSetting(string pCompanyID, string pParameterID)
{
    var r = await _service.GetParameterSetting(pCompanyID, pParameterID);
    return Ok(r);
}
[HttpPost("SaveParameterSetting")]
public async Task<IActionResult> SaveParameterSetting(string pmode, string poset, string pProcessBy)
{
    var r = await _service.SaveParameterSetting(pmode, poset, pProcessBy);
    return Ok(r);
}
[HttpPost("GetProcessList")]
public async Task<IActionResult> GetProcessList(string pCompanyID, string pStartDate, string pEndDate, string pProcessType, string pPolicyID, string pType)
{
    var r = await _service.GetProcessList(pCompanyID, pStartDate, pEndDate, pProcessType, pPolicyID, pType);
    return Ok(r);
}
[HttpPost("GetProcessFileList")]
public async Task<IActionResult> GetProcessFileList(string pCompanyID, string pPolicyID, string pProcessType, string pProcessID, string pProcessDate, string pCurrencyID)
{
    var r = await _service.GetProcessFileList(pCompanyID, pPolicyID, pProcessType, pProcessID, pProcessDate, pCurrencyID);
    return Ok(r);
}
[HttpPost("GetListFile")]
public async Task<IActionResult> GetListFile(string pCompanyID, string ptable, string pPolicy, string pProcessType, string pCurrency)
{
    var r = await _service.GetListFile(pCompanyID, ptable, pPolicy, pProcessType, pCurrency);
    return Ok(r);
}
[HttpPost("IsValidTransaction")]
public async Task<IActionResult> IsValidTransaction(string pany)
{
    var r = await _service.IsValidTransaction(pany);
    return Ok(r);
}
[HttpPost("Update_payment")]
public async Task<IActionResult> Update_payment(string pProcessID, string pProcessBy)
{
    var r = await _service.Update_payment(pProcessID, pProcessBy);
    return Ok(r);
}
[HttpPost("Run_Process")]
public async Task<IActionResult> Run_Process(string pProc, string loProcList)
{
    var r = await _service.Run_Process(pProc, loProcList);
    return Ok(r);
}
[HttpPost("Get_Process")]
public async Task<IActionResult> Get_Process(string pCompanyID, string pProcessID)
{
    var r = await _service.Get_Process(pCompanyID, pProcessID);
    return Ok(r);
}
[HttpPost("Get_Process_detail")]
public async Task<IActionResult> Get_Process_detail(string pCompanyID, string pProcessID, string pFileID, string pProcessType, string pProcessDateStart, string pProcessDateEnd, string pCurrencyID)
{
    var r = await _service.Get_Process_detail(pCompanyID, pProcessID, pFileID, pProcessType, pProcessDateStart, pProcessDateEnd, pCurrencyID);
    return Ok(r);
}
[HttpPost("Process_Approve")]
public async Task<IActionResult> Process_Approve(string pCompanyID, string pProcessID, string pProcessType, string pProcessBy)
{
    var r = await _service.Process_Approve(pCompanyID, pProcessID, pProcessType, pProcessBy);
    return Ok(r);
}
[HttpPost("Process_Rollback")]
public async Task<IActionResult> Process_Rollback(string pCompanyID, string pProcessID, string pProcessType, string pProcessBy)
{
    var r = await _service.Process_Rollback(pCompanyID, pProcessID, pProcessType, pProcessBy);
    return Ok(r);
}
[HttpPost("Process_Cancel")]
public async Task<IActionResult> Process_Cancel(string pProcessID, string pProcessBy)
{
    var r = await _service.Process_Cancel(pProcessID, pProcessBy);
    return Ok(r);
}
[HttpPost("ProcessTask")]
public async Task<IActionResult> ProcessTask(string pCompanyID, string pMemberID, string pTaskID, string pProcessBy, string pTaskParameter)
{
    var r = await _service.ProcessTask(pCompanyID, pMemberID, pTaskID, pProcessBy, pTaskParameter);
    return Ok(r);
}
[HttpPost("SetTempProcess")]
public async Task<IActionResult> SetTempProcess(string pTempID, string pTransType, string loCert, string pProcessBy)
{
    var r = await _service.SetTempProcess(pTempID, pTransType, loCert, pProcessBy);
    return Ok(r);
}
[HttpPost("GetTempProcess")]
public async Task<IActionResult> GetTempProcess(string pTempID)
{
    var r = await _service.GetTempProcess(pTempID);
    return Ok(r);
}
[HttpPost("GetCertificate_History")]
public async Task<IActionResult> GetCertificate_History(string pMemberID)
{
    var r = await _service.GetCertificate_History(pMemberID);
    return Ok(r);
}
[HttpPost("GetControlSetup")]
public async Task<IActionResult> GetControlSetup(string pCompanyID, string pCriteria)
{
    var r = await _service.GetControlSetup(pCompanyID, pCriteria);
    return Ok(r);
}
[HttpPost("GetSettingValue")]
public async Task<IActionResult> GetSettingValue(string pCompanyID, string pParameterID)
{
    var r = await _service.GetSettingValue(pCompanyID, pParameterID);
    return Ok(r);
}
[HttpPost("BMICalculation")]
public async Task<IActionResult> BMICalculation(string pWeight, string pHeight, string pProductType)
{
    var r = await _service.BMICalculation(pWeight, pHeight, pProductType);
    return Ok(r);
}
[HttpPost("FACalculation")]
public async Task<IActionResult> FACalculation(string pComanyID, string pProductType, string pCalcType, string pParamValue)
{
    var r = await _service.FACalculation(pComanyID, pProductType, pCalcType, pParamValue);
    return Ok(r);
}
[HttpPost("GetSurrenderAmount")]
public async Task<IActionResult> GetSurrenderAmount(string pCompanyID, string pParamValue)
{
    var r = await _service.GetSurrenderAmount(pCompanyID, pParamValue);
    return Ok(r);
}
[HttpPost("GetReport")]
public async Task<IActionResult> GetReport(string pCompanyID, string pReportID)
{
    var r = await _service.GetReport(pCompanyID, pReportID);
    return Ok(r);
}
[HttpPost("GetDetailEmail")]
public async Task<IActionResult> GetDetailEmail(string pCompanyID, string sCertID, string sReportType)
{
    var r = await _service.GetDetailEmail(pCompanyID, sCertID, sReportType);
    return Ok(r);
}
[HttpPost("GetReport_Criteria")]
public async Task<IActionResult> GetReport_Criteria(string pCompanyID, string pReportID)
{
    var r = await _service.GetReport_Criteria(pCompanyID, pReportID);
    return Ok(r);
}
[HttpPost("GetReport_Additional_Info")]
public async Task<IActionResult> GetReport_Additional_Info(string pCompanyID, string pReportID)
{
    var r = await _service.GetReport_Additional_Info(pCompanyID, pReportID);
    return Ok(r);
}
[HttpPost("GetReportDataSource")]
public async Task<IActionResult> GetReportDataSource(string pReportID, string pCompanyID, string oany)
{
    var r = await _service.GetReportDataSource(pReportID, pCompanyID, oany);
    return Ok(r);
}
[HttpPost("GetReportDataSource")]
public async Task<IActionResult> GetReportDataSource(string pReportID, string pReportID1, string pCompanyID, string oany)
{
    var r = await _service.GetReportDataSource(pReportID, pReportID1, pCompanyID, oany);
    return Ok(r);
}
[HttpPost("GetReportTitle")]
public async Task<IActionResult> GetReportTitle(string pReportID, string pCompanyID, string oany)
{
    var r = await _service.GetReportTitle(pReportID, pCompanyID, oany);
    return Ok(r);
}
[HttpPost("SaveReport_Info")]
public async Task<IActionResult> SaveReport_Info(string pmode, string loinfo, string pprocesssby)
{
    var r = await _service.SaveReport_Info(pmode, loinfo, pprocesssby);
    return Ok(r);
}
[HttpPost("DeleteReport_Info")]
public async Task<IActionResult> DeleteReport_Info(string pTransReportID)
{
    var r = await _service.DeleteReport_Info(pTransReportID);
    return Ok(r);
}
[HttpPost("GetClaimList")]
public async Task<IActionResult> GetClaimList(string pCompanyID, string pCriteria)
{
    var r = await _service.GetClaimList(pCompanyID, pCriteria);
    return Ok(r);
}
[HttpPost("GetNewClaimInfo")]
public async Task<IActionResult> GetNewClaimInfo(string pCompanyID, string pMemberID, string pProcessBy)
{
    var r = await _service.GetNewClaimInfo(pCompanyID, pMemberID, pProcessBy);
    return Ok(r);
}
[HttpPost("GetClaimCoverageInfo")]
public async Task<IActionResult> GetClaimCoverageInfo(string pMemberID, string pPlanID, string pIncuredDate)
{
    var r = await _service.GetClaimCoverageInfo(pMemberID, pPlanID, pIncuredDate);
    return Ok(r);
}
[HttpPost("GetClaim")]
public async Task<IActionResult> GetClaim(string pClaimID)
{
    var r = await _service.GetClaim(pClaimID);
    return Ok(r);
}
[HttpPost("GetClaim_Payment")]
public async Task<IActionResult> GetClaim_Payment(string pClaimID)
{
    var r = await _service.GetClaim_Payment(pClaimID);
    return Ok(r);
}
[HttpPost("GetClaim_Remark")]
public async Task<IActionResult> GetClaim_Remark(string pClaimID)
{
    var r = await _service.GetClaim_Remark(pClaimID);
    return Ok(r);
}
[HttpPost("GetClaim_History")]
public async Task<IActionResult> GetClaim_History(string pClaimID)
{
    var r = await _service.GetClaim_History(pClaimID);
    return Ok(r);
}
[HttpPost("GetClaim_PendingInvoice")]
public async Task<IActionResult> GetClaim_PendingInvoice(string pMemberID)
{
    var r = await _service.GetClaim_PendingInvoice(pMemberID);
    return Ok(r);
}
[HttpPost("GetClaim_PaidInvoice")]
public async Task<IActionResult> GetClaim_PaidInvoice(string pMemberID)
{
    var r = await _service.GetClaim_PaidInvoice(pMemberID);
    return Ok(r);
}
[HttpPost("Add_Claim_Remark")]
public async Task<IActionResult> Add_Claim_Remark(string pmode, string pClaimID, string pRemarkDate, string pRemarkType, string pRemark, string pprocessby)
{
    var r = await _service.Add_Claim_Remark(pmode, pClaimID, pRemarkDate, pRemarkType, pRemark, pprocessby);
    return Ok(r);
}
[HttpPost("SaveClaim")]
public async Task<IActionResult> SaveClaim(string pmode, string pprocesssby)
{
    var r = await _service.SaveClaim(pmode, pprocesssby);
    return Ok(r);
}
[HttpPost("ApproveClaim")]
public async Task<IActionResult> ApproveClaim(string pClaimID, string pApproveDate, string pRemark, string pprocesssby)
{
    var r = await _service.ApproveClaim(pClaimID, pApproveDate, pRemark, pprocesssby);
    return Ok(r);
}
[HttpPost("CloseClaim")]
public async Task<IActionResult> CloseClaim(string pClaimID, string pCloseDate, string pRemark, string pprocesssby)
{
    var r = await _service.CloseClaim(pClaimID, pCloseDate, pRemark, pprocesssby);
    return Ok(r);
}
[HttpPost("RejectClaim")]
public async Task<IActionResult> RejectClaim(string pClaimID, string pRejectDate, string pRemark, string pprocesssby)
{
    var r = await _service.RejectClaim(pClaimID, pRejectDate, pRemark, pprocesssby);
    return Ok(r);
}
[HttpPost("ReverseClaim")]
public async Task<IActionResult> ReverseClaim(string pClaimID, string pReverseDate, string pRemark, string pprocesssby)
{
    var r = await _service.ReverseClaim(pClaimID, pReverseDate, pRemark, pprocesssby);
    return Ok(r);
}
[HttpPost("CancelClaim")]
public async Task<IActionResult> CancelClaim(string pClaimID, string pCancelDate, string pRemark, string pprocesssby)
{
    var r = await _service.CancelClaim(pClaimID, pCancelDate, pRemark, pprocesssby);
    return Ok(r);
}
[HttpPost("GetPaymentToBeneficiary")]
public async Task<IActionResult> GetPaymentToBeneficiary(string pCompanyID, string ptable, string pPolicyID, string pBenefitType, string pCertificateID, string pPaymentToBank)
{
    var r = await _service.GetPaymentToBeneficiary(pCompanyID, ptable, pPolicyID, pBenefitType, pCertificateID, pPaymentToBank);
    return Ok(r);
}
[HttpPost("GetCalculateClaim")]
public async Task<IActionResult> GetCalculateClaim(string pCompanyID, string ptable, string pPolicyID, string pPlanID, string pClaimType, string pProductType, string pMemberID, string pPaymentToBank, string pIncuredDt, string pProcessBy)
{
    var r = await _service.GetCalculateClaim(pCompanyID, ptable, pPolicyID, pPlanID, pClaimType, pProductType, pMemberID, pPaymentToBank, pIncuredDt, pProcessBy);
    return Ok(r);
}
[HttpPost("GetSurrenderList")]
public async Task<IActionResult> GetSurrenderList(string pCompanyID, string pCriteria)
{
    var r = await _service.GetSurrenderList(pCompanyID, pCriteria);
    return Ok(r);
}
[HttpPost("GetNewSurrenderInfo")]
public async Task<IActionResult> GetNewSurrenderInfo(string pCompanyID, string pMemberID, string pProcessBy)
{
    var r = await _service.GetNewSurrenderInfo(pCompanyID, pMemberID, pProcessBy);
    return Ok(r);
}
[HttpPost("GetSurrender")]
public async Task<IActionResult> GetSurrender(string pSurrenderID)
{
    var r = await _service.GetSurrender(pSurrenderID);
    return Ok(r);
}
[HttpPost("GetRefundPremium")]
public async Task<IActionResult> GetRefundPremium(string pCompanyID, string pProductID, string pSurrenderDate, string pSurrenderTYpe, string pMemberID, string pValueOthers)
{
    var r = await _service.GetRefundPremium(pCompanyID, pProductID, pSurrenderDate, pSurrenderTYpe, pMemberID, pValueOthers);
    return Ok(r);
}
[HttpPost("SaveSurrender")]
public async Task<IActionResult> SaveSurrender(string pmode, string pprocesssby)
{
    var r = await _service.SaveSurrender(pmode, pprocesssby);
    return Ok(r);
}
[HttpPost("ApproveSurrender")]
public async Task<IActionResult> ApproveSurrender(string pSurrenderID, string pApproveDate, string pRemark, string pprocesssby)
{
    var r = await _service.ApproveSurrender(pSurrenderID, pApproveDate, pRemark, pprocesssby);
    return Ok(r);
}
[HttpPost("ValidateUploadFileNew")]
public async Task<IActionResult> ValidateUploadFileNew(string pCompanyID, string pPolicyID, string pFileID, string pFileName, string pOriFileName, string pProcessBy)
{
    var r = await _service.ValidateUploadFileNew(pCompanyID, pPolicyID, pFileID, pFileName, pOriFileName, pProcessBy);
    return Ok(r);
}
[HttpPost("getUploadSchema")]
public async Task<IActionResult> getUploadSchema(string pCompanyID, string pPolicyID, string pFileID)
{
    var r = await _service.getUploadSchema(pCompanyID, pPolicyID, pFileID);
    return Ok(r);
}
[HttpPost("UploadFile")]
public async Task<IActionResult> UploadFile(string pCompanyID, string pPolicyID, string pCriteria)
{
    var r = await _service.UploadFile(pCompanyID, pPolicyID, pCriteria);
    return Ok(r);
}
[HttpPost("GetBillInfo")]
public async Task<IActionResult> GetBillInfo(string pCompanyID, string pPolicyID, string pInvoiceNo)
{
    var r = await _service.GetBillInfo(pCompanyID, pPolicyID, pInvoiceNo);
    return Ok(r);
}
[HttpPost("GetListBillDetail")]
public async Task<IActionResult> GetListBillDetail(string pCompanyID, string pPolicyID, string pInvoiceNo)
{
    var r = await _service.GetListBillDetail(pCompanyID, pPolicyID, pInvoiceNo);
    return Ok(r);
}
}