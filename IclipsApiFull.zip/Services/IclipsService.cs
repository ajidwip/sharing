using System.Data; using System.Data.SqlClient; public class IclipsService { private readonly string _connectionString="YOUR_CONNECTION";
public async Task<string> Send_Email(string pCompanyID, string pRecipients, string pSubject, string pBody, string pAttachment)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_send_email", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pRecipients", pRecipients);
cmd.Parameters.AddWithValue("@pSubject", pSubject);
cmd.Parameters.AddWithValue("@pBody", pBody);
cmd.Parameters.AddWithValue("@pAttachment", pAttachment);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> Get_Policy_Setup(string pCompanyID, string ptable, string pPolicyid, string pskey1)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@ptable", ptable);
cmd.Parameters.AddWithValue("@pPolicyid", pPolicyid);
cmd.Parameters.AddWithValue("@pskey1", pskey1);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetSingleValueICLIPS(string pCompanyID, string ptable, string pskey1)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@ptable", ptable);
cmd.Parameters.AddWithValue("@pskey1", pskey1);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetSingleValue(string pCompanyID, string ptable, string pskey1)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@ptable", ptable);
cmd.Parameters.AddWithValue("@pskey1", pskey1);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetProductTypeSetupValue(string pCompanyID, string pProductType, string pSetupName)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pProductType", pProductType);
cmd.Parameters.AddWithValue("@pSetupName", pSetupName);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetComboList(string pCompanyID, string ptable, string ptype, string pcate)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@ptable", ptable);
cmd.Parameters.AddWithValue("@ptype", ptype);
cmd.Parameters.AddWithValue("@pcate", pcate);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetSearchList(string pCompanyID, string pListType, string pCriteria)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetSearchList", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pListType", pListType);
cmd.Parameters.AddWithValue("@pCriteria", pCriteria);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetSearchListByCriteria(string pCompanyID, string pListType, string pCriteria)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetSearchListByCriteria", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pListType", pListType);
cmd.Parameters.AddWithValue("@pCriteria", pCriteria);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetPolicy(string pCompanyID, string pPolicyID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> SaveClient(string pmode)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("SaveClient", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pmode", pmode);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetClient(string pclientid)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetClient", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pclientid", pclientid);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> SaveAgent(string pmode)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("SaveAgent", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pmode", pmode);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetAgent(string pCompanyID, string pPolicyID, string pAgentID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
cmd.Parameters.AddWithValue("@pAgentID", pAgentID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetBranch(string pCompanyID, string pPolicyID, string pBranchID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
cmd.Parameters.AddWithValue("@pBranchID", pBranchID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> IsExistAgent(string pCompanyID, string pPolicyID, string pAgentID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
cmd.Parameters.AddWithValue("@pAgentID", pAgentID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetPackageCoverageList(string pCompanyID, string pPackageID, string pMemberID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetPackageCoverageList", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pPackageID", pPackageID);
cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetQuestionerList(string pCompanyID, string pProductType, string pMemberID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetQuestionerList", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pProductType", pProductType);
cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetCertificateList(string pCompanyID, string pCriteria)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetCertificateList", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pCriteria", pCriteria);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetCertificateListForClaim(string pCompanyID, string pCriteria)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetCertificateListForClaim", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pCriteria", pCriteria);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetCertificateListForSurrender(string pCompanyID, string pCriteria)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetCertificateListForSurrender", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pCriteria", pCriteria);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetCertificateHeader(string pCompanyID, string pMemberID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetCertificate(string pCompanyID, string pMemberID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetCertificate_Beneficiary(string pCompanyID, string pPolicyID, string pCertificateID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetCertificate_Beneficiary", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
cmd.Parameters.AddWithValue("@pCertificateID", pCertificateID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetCertificate_Coverage(string pCompanyID, string pPolicyID, string pCertificateID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetCertificate_Coverage", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
cmd.Parameters.AddWithValue("@pCertificateID", pCertificateID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetCertificate_PreviousPolicy(string pCompanyID, string pPolicyID, string pCertificateID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetCertificate_PreviousPolicy", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
cmd.Parameters.AddWithValue("@pCertificateID", pCertificateID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetHealthList(string pCompanyID, string pListType, string pProductID, string pPolicyID, string pMemberID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetHealthList", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pListType", pListType);
cmd.Parameters.AddWithValue("@pProductID", pProductID);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetInsuredAge(string pCompanyID, string pPlanID, string pDOB, string pAppRecDt)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_age", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pPlanID", pPlanID);
cmd.Parameters.AddWithValue("@pDOB", pDOB);
cmd.Parameters.AddWithValue("@pAppRecDt", pAppRecDt);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetMaturityDate(string pCompanyID, string pPolicyID, string pStartDate, string pDuration)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_calc_duration", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
cmd.Parameters.AddWithValue("@pStartDate", pStartDate);
cmd.Parameters.AddWithValue("@pDuration", pDuration);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> SaveCertificate(string pCertificate, string pBeneficiary, string pHealthQ, string pHealthH)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_save_certificate", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCertificate", pCertificate);
cmd.Parameters.AddWithValue("@pBeneficiary", pBeneficiary);
cmd.Parameters.AddWithValue("@pHealthQ", pHealthQ);
cmd.Parameters.AddWithValue("@pHealthH", pHealthH);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> SaveNewCertificate(string pUseExistingInsuredID, string pUseExistingDebiturID, string oagt, string loben, string loque, string locov, string loPolH, string loPolC, string lodoc, string pMode)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("SaveNewCertificate", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUseExistingInsuredID", pUseExistingInsuredID);
cmd.Parameters.AddWithValue("@pUseExistingDebiturID", pUseExistingDebiturID);
cmd.Parameters.AddWithValue("@oagt", oagt);
cmd.Parameters.AddWithValue("@loben", loben);
cmd.Parameters.AddWithValue("@loque", loque);
cmd.Parameters.AddWithValue("@locov", locov);
cmd.Parameters.AddWithValue("@loPolH", loPolH);
cmd.Parameters.AddWithValue("@loPolC", loPolC);
cmd.Parameters.AddWithValue("@lodoc", lodoc);
cmd.Parameters.AddWithValue("@pMode", pMode);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> SaveCertificate(string pUseExistingInsuredID, string pUseExistingDebiturID, string poins, string podeb, string oagt, string loben, string loque, string locov, string loPolH, string loPolC, string lodoc, string pMode)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("SaveCertificate", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUseExistingInsuredID", pUseExistingInsuredID);
cmd.Parameters.AddWithValue("@pUseExistingDebiturID", pUseExistingDebiturID);
cmd.Parameters.AddWithValue("@poins", poins);
cmd.Parameters.AddWithValue("@podeb", podeb);
cmd.Parameters.AddWithValue("@oagt", oagt);
cmd.Parameters.AddWithValue("@loben", loben);
cmd.Parameters.AddWithValue("@loque", loque);
cmd.Parameters.AddWithValue("@locov", locov);
cmd.Parameters.AddWithValue("@loPolH", loPolH);
cmd.Parameters.AddWithValue("@loPolC", loPolC);
cmd.Parameters.AddWithValue("@lodoc", lodoc);
cmd.Parameters.AddWithValue("@pMode", pMode);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> SaveCertificate(string pUseExistingInsuredID, string pUseExistingDebiturID, string poins, string podeb, string oagt, string loben, string loque)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("SaveCertificate", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUseExistingInsuredID", pUseExistingInsuredID);
cmd.Parameters.AddWithValue("@pUseExistingDebiturID", pUseExistingDebiturID);
cmd.Parameters.AddWithValue("@poins", poins);
cmd.Parameters.AddWithValue("@podeb", podeb);
cmd.Parameters.AddWithValue("@oagt", oagt);
cmd.Parameters.AddWithValue("@loben", loben);
cmd.Parameters.AddWithValue("@loque", loque);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> ValidateCertificate(string pMemberID, string pProcessBy)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_validate_certificate", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
cmd.Parameters.AddWithValue("@pProcessBy", pProcessBy);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> ApproveCertificate(string pMemberID, string pProcessBy)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_approve_certificate", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
cmd.Parameters.AddWithValue("@pProcessBy", pProcessBy);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> IssueCertificate(string pMemberID, string pProcessBy)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_issue_certificate", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
cmd.Parameters.AddWithValue("@pProcessBy", pProcessBy);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetCertificate_Agent(string pCompanyID, string pPolicyID, string pMemberID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetCertificate_PrePolicy(string pMemberID, string pInsuredID, string pType)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetCertificate_PrePolicy", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
cmd.Parameters.AddWithValue("@pInsuredID", pInsuredID);
cmd.Parameters.AddWithValue("@pType", pType);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> SavePrePolicy(string loPrePol)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("SavePrePolicy", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@loPrePol", loPrePol);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> UpdatePolicySAR(string pMemberID, string pProcessBy)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("UpdatePolicySAR", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
cmd.Parameters.AddWithValue("@pProcessBy", pProcessBy);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetDocumentList(string pCompanyID, string pProductType, string pMemberID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetDocumentList", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pProductType", pProductType);
cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetDocumentListOf(string pCompanyID, string pProductType, string pMemberID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pProductType", pProductType);
cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetBeneficiaryList(string pMemberID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetBeneficiaryList", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetPrePolicy(string pMemberID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetPrePolicy", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetPreClaim(string pMemberID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetPreClaim", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetCertificate_Letters(string pMemberID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetCertificate_Letters", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetPolicyInfo(string pCompanyID, string pListType, string pPolicyID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pListType", pListType);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetPlanInfo(string pCompanyID, string pListType, string pPlanID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pListType", pListType);
cmd.Parameters.AddWithValue("@pPlanID", pPlanID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetPackagePlan(string pCompanyID, string pPackageID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pPackageID", pPackageID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetClientList(string pCompanyID, string pListType, string pCriteria)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetClientList", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pListType", pListType);
cmd.Parameters.AddWithValue("@pCriteria", pCriteria);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetClientInfo(string pCompanyID, string pClientID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pClientID", pClientID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetUnderwritingList(string pCompanyID, string pCriteria)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetUnderwritingList", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pCriteria", pCriteria);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetUnderwriting(string pUnderwritingID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingID", pUnderwritingID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetUnderwritingsar(string pUnderwritingID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingID", pUnderwritingID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetUnderwriting_Remark(string pUnderwritingID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetUnderwriting_Remark", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingID", pUnderwritingID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetUnderwriting_History(string pUnderwritingID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetUnderwriting_History", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingID", pUnderwritingID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetUnderwriting_Previous(string pUnderwritingID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetUnderwriting_Previous", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingID", pUnderwritingID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetUnderwriting_RequirementMedical(string pUnderwritingID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetUnderwriting_RequirementMedical", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingID", pUnderwritingID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetUnderwriting_RequirementFinancial(string pUnderwritingID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetUnderwriting_RequirementFinancial", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingID", pUnderwritingID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetUnderwriting_Coverage(string pUnderwritingID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetUnderwriting_Coverage", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingID", pUnderwritingID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetUnderwriting_PreviousPolicy(string pUnderwritingID, string pClientID, string pMemberID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetUnderwriting_PreviousPolicy", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingID", pUnderwritingID);
cmd.Parameters.AddWithValue("@pClientID", pClientID);
cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> Add_Underwriting_Remark(string pmode, string pUnderwritingID, string pRemarkDate, string pRemarkType, string pRemark, string pprocessby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("Add_Underwriting_Remark", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pmode", pmode);
cmd.Parameters.AddWithValue("@pUnderwritingID", pUnderwritingID);
cmd.Parameters.AddWithValue("@pRemarkDate", pRemarkDate);
cmd.Parameters.AddWithValue("@pRemarkType", pRemarkType);
cmd.Parameters.AddWithValue("@pRemark", pRemark);
cmd.Parameters.AddWithValue("@pprocessby", pprocessby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetUnderwriting_Letters(string pUnderwritingID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetUnderwriting_Letters", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingID", pUnderwritingID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetUnderwriting_Letters_Info(string pUnderwritingID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetUnderwriting_Letters_Info", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingID", pUnderwritingID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> DeleteUnderwritingRequirement(string pUnderwritingRequirementID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("DeleteUnderwritingRequirement", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingRequirementID", pUnderwritingRequirementID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> WaiveUnderwritingRequirement(string pUnderwritingRequirementID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("WaiveUnderwritingRequirement", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingRequirementID", pUnderwritingRequirementID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> SaveUnderwritingRequirement(string pmode, string oreq, string pProcessBy)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("SaveUnderwritingRequirement", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pmode", pmode);
cmd.Parameters.AddWithValue("@oreq", oreq);
cmd.Parameters.AddWithValue("@pProcessBy", pProcessBy);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> SaveUnderwriting(string pmode, string pouw, string loreq, string locov, string lopol, string pprocesssby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("SaveUnderwriting", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pmode", pmode);
cmd.Parameters.AddWithValue("@pouw", pouw);
cmd.Parameters.AddWithValue("@loreq", loreq);
cmd.Parameters.AddWithValue("@locov", locov);
cmd.Parameters.AddWithValue("@lopol", lopol);
cmd.Parameters.AddWithValue("@pprocesssby", pprocesssby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> StartUnderwritingReview(string pUnderwritingID, string pReviewDate, string pUnderwriterID, string pRemark, string pprocesssby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("StartUnderwritingReview", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingID", pUnderwritingID);
cmd.Parameters.AddWithValue("@pReviewDate", pReviewDate);
cmd.Parameters.AddWithValue("@pUnderwriterID", pUnderwriterID);
cmd.Parameters.AddWithValue("@pRemark", pRemark);
cmd.Parameters.AddWithValue("@pprocesssby", pprocesssby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> SetUnderwritingDecision(string pUnderwritingID, string pDecisionDate, string pUnderwritingDecision, string pExclusionType, string pReasonForExclusion, string pRemark, string pReadyForApproval, string pExtraMortalita, string pExtraMortalitaType, string pprocesssby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("SetUnderwritingDecision", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingID", pUnderwritingID);
cmd.Parameters.AddWithValue("@pDecisionDate", pDecisionDate);
cmd.Parameters.AddWithValue("@pUnderwritingDecision", pUnderwritingDecision);
cmd.Parameters.AddWithValue("@pExclusionType", pExclusionType);
cmd.Parameters.AddWithValue("@pReasonForExclusion", pReasonForExclusion);
cmd.Parameters.AddWithValue("@pRemark", pRemark);
cmd.Parameters.AddWithValue("@pReadyForApproval", pReadyForApproval);
cmd.Parameters.AddWithValue("@pExtraMortalita", pExtraMortalita);
cmd.Parameters.AddWithValue("@pExtraMortalitaType", pExtraMortalitaType);
cmd.Parameters.AddWithValue("@pprocesssby", pprocesssby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> ApproveUnderwriting(string pUnderwritingID, string pApproveDate, string pRemark, string pprocesssby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("ApproveUnderwriting", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingID", pUnderwritingID);
cmd.Parameters.AddWithValue("@pApproveDate", pApproveDate);
cmd.Parameters.AddWithValue("@pRemark", pRemark);
cmd.Parameters.AddWithValue("@pprocesssby", pprocesssby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> ReverseUnderwriting(string pUnderwritingID, string pRemark, string pprocesssby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("ReverseUnderwriting", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingID", pUnderwritingID);
cmd.Parameters.AddWithValue("@pRemark", pRemark);
cmd.Parameters.AddWithValue("@pprocesssby", pprocesssby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> CancelUnderwriting(string pUnderwritingID, string pRemark, string pprocesssby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("CancelUnderwriting", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingID", pUnderwritingID);
cmd.Parameters.AddWithValue("@pRemark", pRemark);
cmd.Parameters.AddWithValue("@pprocesssby", pprocesssby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> RollbackUnderwriting(string pUnderwritingID, string pRemark, string pprocesssby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("RollbackUnderwriting", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingID", pUnderwritingID);
cmd.Parameters.AddWithValue("@pRemark", pRemark);
cmd.Parameters.AddWithValue("@pprocesssby", pprocesssby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> ResetUnderwriting(string pUnderwritingID, string pRemark, string pprocesssby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("ResetUnderwriting", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pUnderwritingID", pUnderwritingID);
cmd.Parameters.AddWithValue("@pRemark", pRemark);
cmd.Parameters.AddWithValue("@pprocesssby", pprocesssby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetCodeList(string pCompanyID, string pCodeType)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetCodeList", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pCodeType", pCodeType);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetCode(string pCompanyID, string pCodeType, string pCodeID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pCodeType", pCodeType);
cmd.Parameters.AddWithValue("@pCodeID", pCodeID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> SaveCode(string pmode, string pCode, string pprocesssby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("SaveCode", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pmode", pmode);
cmd.Parameters.AddWithValue("@pCode", pCode);
cmd.Parameters.AddWithValue("@pprocesssby", pprocesssby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> DeleteCode(string pCompanyID, string pCodeType, string pCodeID, string pprocesssby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("DeleteCode", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pCodeType", pCodeType);
cmd.Parameters.AddWithValue("@pCodeID", pCodeID);
cmd.Parameters.AddWithValue("@pprocesssby", pprocesssby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> IsExistCode(string pCompanyID, string pCodeType, string pCodeID, string pCodeName)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pCodeType", pCodeType);
cmd.Parameters.AddWithValue("@pCodeID", pCodeID);
cmd.Parameters.AddWithValue("@pCodeName", pCodeName);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetParameterSettingList(string pCompanyID, string pcategory)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetParameterSettingList", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pcategory", pcategory);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetParameterSettingList(string pCompanyID, string pcategory, string pPage, string pPageSize)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pcategory", pcategory);
cmd.Parameters.AddWithValue("@pPage", pPage);
cmd.Parameters.AddWithValue("@pPageSize", pPageSize);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetParameterSetting(string pCompanyID, string pParameterID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pParameterID", pParameterID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> SaveParameterSetting(string pmode, string poset, string pProcessBy)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("SaveParameterSetting", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pmode", pmode);
cmd.Parameters.AddWithValue("@poset", poset);
cmd.Parameters.AddWithValue("@pProcessBy", pProcessBy);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetProcessList(string pCompanyID, string pStartDate, string pEndDate, string pProcessType, string pPolicyID, string pType)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pStartDate", pStartDate);
cmd.Parameters.AddWithValue("@pEndDate", pEndDate);
cmd.Parameters.AddWithValue("@pProcessType", pProcessType);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
cmd.Parameters.AddWithValue("@pType", pType);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetProcessFileList(string pCompanyID, string pPolicyID, string pProcessType, string pProcessID, string pProcessDate, string pCurrencyID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
cmd.Parameters.AddWithValue("@pProcessType", pProcessType);
cmd.Parameters.AddWithValue("@pProcessID", pProcessID);
cmd.Parameters.AddWithValue("@pProcessDate", pProcessDate);
cmd.Parameters.AddWithValue("@pCurrencyID", pCurrencyID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetListFile(string pCompanyID, string ptable, string pPolicy, string pProcessType, string pCurrency)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@ptable", ptable);
cmd.Parameters.AddWithValue("@pPolicy", pPolicy);
cmd.Parameters.AddWithValue("@pProcessType", pProcessType);
cmd.Parameters.AddWithValue("@pCurrency", pCurrency);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> IsValidTransaction(string pany)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_is_valid_transaction", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pany", pany);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> Update_payment(string pProcessID, string pProcessBy)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_update_tpayment", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pProcessID", pProcessID);
cmd.Parameters.AddWithValue("@pProcessBy", pProcessBy);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> Run_Process(string pProc, string loProcList)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_process_run", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pProc", pProc);
cmd.Parameters.AddWithValue("@loProcList", loProcList);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> Get_Process(string pCompanyID, string pProcessID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pProcessID", pProcessID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> Get_Process_detail(string pCompanyID, string pProcessID, string pFileID, string pProcessType, string pProcessDateStart, string pProcessDateEnd, string pCurrencyID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pProcessID", pProcessID);
cmd.Parameters.AddWithValue("@pFileID", pFileID);
cmd.Parameters.AddWithValue("@pProcessType", pProcessType);
cmd.Parameters.AddWithValue("@pProcessDateStart", pProcessDateStart);
cmd.Parameters.AddWithValue("@pProcessDateEnd", pProcessDateEnd);
cmd.Parameters.AddWithValue("@pCurrencyID", pCurrencyID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> Process_Approve(string pCompanyID, string pProcessID, string pProcessType, string pProcessBy)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_process_approve", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pProcessID", pProcessID);
cmd.Parameters.AddWithValue("@pProcessType", pProcessType);
cmd.Parameters.AddWithValue("@pProcessBy", pProcessBy);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> Process_Rollback(string pCompanyID, string pProcessID, string pProcessType, string pProcessBy)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_process_Rollback", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pProcessID", pProcessID);
cmd.Parameters.AddWithValue("@pProcessType", pProcessType);
cmd.Parameters.AddWithValue("@pProcessBy", pProcessBy);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> Process_Cancel(string pProcessID, string pProcessBy)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("Process_Cancel", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pProcessID", pProcessID);
cmd.Parameters.AddWithValue("@pProcessBy", pProcessBy);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> ProcessTask(string pCompanyID, string pMemberID, string pTaskID, string pProcessBy, string pTaskParameter)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_process_task", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
cmd.Parameters.AddWithValue("@pTaskID", pTaskID);
cmd.Parameters.AddWithValue("@pProcessBy", pProcessBy);
cmd.Parameters.AddWithValue("@pTaskParameter", pTaskParameter);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> SetTempProcess(string pTempID, string pTransType, string loCert, string pProcessBy)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("SetTempProcess", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pTempID", pTempID);
cmd.Parameters.AddWithValue("@pTransType", pTransType);
cmd.Parameters.AddWithValue("@loCert", loCert);
cmd.Parameters.AddWithValue("@pProcessBy", pProcessBy);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetTempProcess(string pTempID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_temp_transaction", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pTempID", pTempID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetCertificate_History(string pMemberID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetCertificate_History", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetControlSetup(string pCompanyID, string pCriteria)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pCriteria", pCriteria);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetSettingValue(string pCompanyID, string pParameterID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pParameterID", pParameterID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> BMICalculation(string pWeight, string pHeight, string pProductType)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_calc_BMI", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pWeight", pWeight);
cmd.Parameters.AddWithValue("@pHeight", pHeight);
cmd.Parameters.AddWithValue("@pProductType", pProductType);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> FACalculation(string pComanyID, string pProductType, string pCalcType, string pParamValue)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_calculation", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pComanyID", pComanyID);
cmd.Parameters.AddWithValue("@pProductType", pProductType);
cmd.Parameters.AddWithValue("@pCalcType", pCalcType);
cmd.Parameters.AddWithValue("@pParamValue", pParamValue);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetSurrenderAmount(string pCompanyID, string pParamValue)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pParamValue", pParamValue);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetReport(string pCompanyID, string pReportID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pReportID", pReportID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetDetailEmail(string pCompanyID, string sCertID, string sReportType)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@sCertID", sCertID);
cmd.Parameters.AddWithValue("@sReportType", sReportType);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetReport_Criteria(string pCompanyID, string pReportID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pReportID", pReportID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetReport_Additional_Info(string pCompanyID, string pReportID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pReportID", pReportID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetReportDataSource(string pReportID, string pCompanyID, string oany)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetReportDataSource", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pReportID", pReportID);
cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@oany", oany);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetReportDataSource(string pReportID, string pReportID1, string pCompanyID, string oany)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetReportDataSource", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pReportID", pReportID);
cmd.Parameters.AddWithValue("@pReportID1", pReportID1);
cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@oany", oany);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetReportTitle(string pReportID, string pCompanyID, string oany)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pReportID", pReportID);
cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@oany", oany);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> SaveReport_Info(string pmode, string loinfo, string pprocesssby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("SaveReport_Info", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pmode", pmode);
cmd.Parameters.AddWithValue("@loinfo", loinfo);
cmd.Parameters.AddWithValue("@pprocesssby", pprocesssby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> DeleteReport_Info(string pTransReportID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("DeleteReport_Info", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pTransReportID", pTransReportID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetClaimList(string pCompanyID, string pCriteria)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetClaimList", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pCriteria", pCriteria);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetNewClaimInfo(string pCompanyID, string pMemberID, string pProcessBy)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
cmd.Parameters.AddWithValue("@pProcessBy", pProcessBy);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetClaimCoverageInfo(string pMemberID, string pPlanID, string pIncuredDate)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
cmd.Parameters.AddWithValue("@pPlanID", pPlanID);
cmd.Parameters.AddWithValue("@pIncuredDate", pIncuredDate);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetClaim(string pClaimID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pClaimID", pClaimID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetClaim_Payment(string pClaimID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetClaim_Payment", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pClaimID", pClaimID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetClaim_Remark(string pClaimID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetClaim_Remark", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pClaimID", pClaimID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetClaim_History(string pClaimID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetClaim_History", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pClaimID", pClaimID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetClaim_PendingInvoice(string pMemberID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetClaim_PendingInvoice", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetClaim_PaidInvoice(string pMemberID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetClaim_PaidInvoice", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> Add_Claim_Remark(string pmode, string pClaimID, string pRemarkDate, string pRemarkType, string pRemark, string pprocessby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("Add_Claim_Remark", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pmode", pmode);
cmd.Parameters.AddWithValue("@pClaimID", pClaimID);
cmd.Parameters.AddWithValue("@pRemarkDate", pRemarkDate);
cmd.Parameters.AddWithValue("@pRemarkType", pRemarkType);
cmd.Parameters.AddWithValue("@pRemark", pRemark);
cmd.Parameters.AddWithValue("@pprocessby", pprocessby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> SaveClaim(string pmode, string pprocesssby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("SaveClaim", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pmode", pmode);
cmd.Parameters.AddWithValue("@pprocesssby", pprocesssby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> ApproveClaim(string pClaimID, string pApproveDate, string pRemark, string pprocesssby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("ApproveClaim", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pClaimID", pClaimID);
cmd.Parameters.AddWithValue("@pApproveDate", pApproveDate);
cmd.Parameters.AddWithValue("@pRemark", pRemark);
cmd.Parameters.AddWithValue("@pprocesssby", pprocesssby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> CloseClaim(string pClaimID, string pCloseDate, string pRemark, string pprocesssby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("CloseClaim", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pClaimID", pClaimID);
cmd.Parameters.AddWithValue("@pCloseDate", pCloseDate);
cmd.Parameters.AddWithValue("@pRemark", pRemark);
cmd.Parameters.AddWithValue("@pprocesssby", pprocesssby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> RejectClaim(string pClaimID, string pRejectDate, string pRemark, string pprocesssby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("RejectClaim", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pClaimID", pClaimID);
cmd.Parameters.AddWithValue("@pRejectDate", pRejectDate);
cmd.Parameters.AddWithValue("@pRemark", pRemark);
cmd.Parameters.AddWithValue("@pprocesssby", pprocesssby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> ReverseClaim(string pClaimID, string pReverseDate, string pRemark, string pprocesssby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("ReverseClaim", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pClaimID", pClaimID);
cmd.Parameters.AddWithValue("@pReverseDate", pReverseDate);
cmd.Parameters.AddWithValue("@pRemark", pRemark);
cmd.Parameters.AddWithValue("@pprocesssby", pprocesssby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> CancelClaim(string pClaimID, string pCancelDate, string pRemark, string pprocesssby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("CancelClaim", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pClaimID", pClaimID);
cmd.Parameters.AddWithValue("@pCancelDate", pCancelDate);
cmd.Parameters.AddWithValue("@pRemark", pRemark);
cmd.Parameters.AddWithValue("@pprocesssby", pprocesssby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetPaymentToBeneficiary(string pCompanyID, string ptable, string pPolicyID, string pBenefitType, string pCertificateID, string pPaymentToBank)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_calculation_Payment", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@ptable", ptable);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
cmd.Parameters.AddWithValue("@pBenefitType", pBenefitType);
cmd.Parameters.AddWithValue("@pCertificateID", pCertificateID);
cmd.Parameters.AddWithValue("@pPaymentToBank", pPaymentToBank);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetCalculateClaim(string pCompanyID, string ptable, string pPolicyID, string pPlanID, string pClaimType, string pProductType, string pMemberID, string pPaymentToBank, string pIncuredDt, string pProcessBy)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_calculate_claim", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@ptable", ptable);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
cmd.Parameters.AddWithValue("@pPlanID", pPlanID);
cmd.Parameters.AddWithValue("@pClaimType", pClaimType);
cmd.Parameters.AddWithValue("@pProductType", pProductType);
cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
cmd.Parameters.AddWithValue("@pPaymentToBank", pPaymentToBank);
cmd.Parameters.AddWithValue("@pIncuredDt", pIncuredDt);
cmd.Parameters.AddWithValue("@pProcessBy", pProcessBy);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetSurrenderList(string pCompanyID, string pCriteria)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("GetSurrenderList", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pCriteria", pCriteria);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetNewSurrenderInfo(string pCompanyID, string pMemberID, string pProcessBy)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
cmd.Parameters.AddWithValue("@pProcessBy", pProcessBy);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetSurrender(string pSurrenderID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pSurrenderID", pSurrenderID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetRefundPremium(string pCompanyID, string pProductID, string pSurrenderDate, string pSurrenderTYpe, string pMemberID, string pValueOthers)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_calculate_surrender", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pProductID", pProductID);
cmd.Parameters.AddWithValue("@pSurrenderDate", pSurrenderDate);
cmd.Parameters.AddWithValue("@pSurrenderTYpe", pSurrenderTYpe);
cmd.Parameters.AddWithValue("@pMemberID", pMemberID);
cmd.Parameters.AddWithValue("@pValueOthers", pValueOthers);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> SaveSurrender(string pmode, string pprocesssby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("SaveSurrender", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pmode", pmode);
cmd.Parameters.AddWithValue("@pprocesssby", pprocesssby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> ApproveSurrender(string pSurrenderID, string pApproveDate, string pRemark, string pprocesssby)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("ApproveSurrender", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pSurrenderID", pSurrenderID);
cmd.Parameters.AddWithValue("@pApproveDate", pApproveDate);
cmd.Parameters.AddWithValue("@pRemark", pRemark);
cmd.Parameters.AddWithValue("@pprocesssby", pprocesssby);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> ValidateUploadFileNew(string pCompanyID, string pPolicyID, string pFileID, string pFileName, string pOriFileName, string pProcessBy)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("ValidateUploadFileNew", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
cmd.Parameters.AddWithValue("@pFileID", pFileID);
cmd.Parameters.AddWithValue("@pFileName", pFileName);
cmd.Parameters.AddWithValue("@pOriFileName", pOriFileName);
cmd.Parameters.AddWithValue("@pProcessBy", pProcessBy);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> getUploadSchema(string pCompanyID, string pPolicyID, string pFileID)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("getUploadSchema", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
cmd.Parameters.AddWithValue("@pFileID", pFileID);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> UploadFile(string pCompanyID, string pPolicyID, string pCriteria)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_Upload_Certificate", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
cmd.Parameters.AddWithValue("@pCriteria", pCriteria);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetBillInfo(string pCompanyID, string pPolicyID, string pInvoiceNo)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
cmd.Parameters.AddWithValue("@pInvoiceNo", pInvoiceNo);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}


public async Task<string> GetListBillDetail(string pCompanyID, string pPolicyID, string pInvoiceNo)
{
    string result = "";
    using(SqlConnection conn = new SqlConnection(_connectionString))
    using(SqlCommand cmd = new SqlCommand("usp_get_records", conn))
    {
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pCompanyID", pCompanyID);
cmd.Parameters.AddWithValue("@pPolicyID", pPolicyID);
cmd.Parameters.AddWithValue("@pInvoiceNo", pInvoiceNo);
        await conn.OpenAsync();
        using(SqlDataReader rdr = await cmd.ExecuteReaderAsync())
        {
            if(await rdr.ReadAsync())
            {
                result = rdr[0].ToString();
            }
        }
    }
    return result;
}
}