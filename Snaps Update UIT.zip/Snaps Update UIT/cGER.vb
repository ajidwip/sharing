﻿Namespace snaps.api.models

    'Created        :   RS
    'Updated        :   RW
    'Updated Date   : 6 June 2018
    'Desc           : SAVE Data GER Car Summary

    Public Class cGER
        'Public Property CompanyID As String
        'Public Property FormNum As String
        'Public Property GERType As String
        'Public Property MainFormNum As String
        'Public Property Currency As String
        'Public Property ExchangeRate As Double
        'Public Property FromDept As String
        'Public Property AdvanceFormNum As String
        'Public Property TransactionCode As String
        'Public Property PolRelated As Boolean
        'Public Property PolicyNum As String
        'Public Property UserID As String
        'Public Property Budgeted As Boolean
        'Public Property PONumber As String

        'Created        :   RS
        'Updated        :   Rs
        'Updated Date   :   18 September 2018
        'Desc           :   SAVE Data BULK new
        Public Property DetEx As String
        Public Property PayCat As String
        Public Property bulkID As Int32
        Public Property bulkFlagValue As String
        Public Property tempResult As String
        Public Property tempResult2 As String
        Public Property cBulkData As List(Of cBulkData)

        Public Property CompanyID As String
        Public Property FormNum As String
        Public Property GERType As String
        Public Property MainFormNum As String
        Public Property FormType As String
        Public Property Currency As String
        Public Property ExchangeRate As Double
        Public Property FromDept As String
        Public Property AdvanceFormNum As String
        Public Property CreateDt As Date
        Public Property CheckedDt As Date
        Public Property ApprovedDt As Date
        Public Property TransactionCode As String
        Public Property BankName As String
        Public Property BankAccNumber As String
        Public Property PolRelated As Boolean
        Public Property PolicyNum As String
        Public Property Budgeted As Boolean
        Public Property PONumber As String
        Public Property AppNumber As String

        Public Property Subject As String
        Public Property PaidBy As String
        Public Property Taxable As Boolean
        Public Property BeneficiaryName As String
        Public Property BeneficiaryBankCode As String
        Public Property BeneficiaryBankAccount As String
        Public Property BeneficiaryBankBranch As String
        Public Property BeneficiaryBankCity As String
        Public Property BeneficiaryEmail As String
        Public Property BeneficiaryAccountCurrency As String
        Public Property BeneficiaryTypeCd As String
        Public Property BeneficiaryTypeNm As String
        Public Property BeneficiaryResidentStatusCd As String
        Public Property BeneficiaryResidentStatusNm As String
        Public Property BeneficiaryTranTypeCd As String
        Public Property BeneficiaryTranTypeNm As String
        Public Property BeneficiaryTranFacilityTypeCd As String
        Public Property BeneficiaryTranFacilityTypeNm As String

        Public Property UserID As String
        Public Property CreateBy As String
        Public Property CheckedBy As String
        Public Property ApprovedBy As String
        Public Property TotalAmount As String
        Public Property AdvanceAmount As String
        Public Property DueAmount As String
        Public Property TaxAmount As String
        Public Property NettAmount As String
        Public Property ProcessType As String
        Public Property FormStatus As String
        Public Property FormLocation As String
        Public Property PoNum As String
        Public Property sBenID As String
        Public Property BeneficiaryResidenStatusNm As String
        Public Property TaxSubsidy As String
        Public Property ToGenerate As String
        Public Property GenerateRemark As String
        Public Property Journalized As String
        Public Property ToApprovedByTax As String

        Public Property FormNumNew As String

        'Travel Header
        Public Property travelDateFrom As DateTime
        Public Property travelDateUntil As DateTime
        Public Property travelDateRange As Integer

        Public Property travelTotalIDRAmount As String

        Public Property travelCreditCardOAmount As String
        Public Property travelCreditCardOCurr As String
        Public Property travelCreditCardExchangeRate As String
        Public Property travelCreditCardIDRAmount As String

        Public Property travelPaidInCashOAmount As String
        Public Property travelPaidInCashOCurr As String
        Public Property travelPaidInCashExchangeRate As String
        Public Property travelPaidInCashIDRAmount As String

        Public Property travelPrePaidOAmount As String
        Public Property travelPrePaidOCurr As String
        Public Property travelPrePaidExchangeRate As String
        Public Property travelPrePaidIDRAmount As String

        Public Property travelCashAdvanceNum As String

        Public Property travelCashAdvanceOAmount As String
        Public Property travelCashAdvanceOCurr As String
        Public Property travelCashAdvanceExchangeRate As String
        Public Property travelCashAdvanceIDRAmount As String

        Public Property travelDueAmountTravel As String

        Public Property travelTravellerName As String
        Public Property travelDepartment As String
        Public Property travelTripDestination As String
        Public Property travelTripPurpose As String
        Public Property travelTravellerPosition As String

        'Enter Header
        Public Property enterTotalIDRAmount As String
        Public Property enterTotalDueAmount As String

        Public Property listTravelDetail As List(Of travelDetailData)
        Public Property listEnterDetail As List(Of entertainmentGER_List_Model)
        Public Property listGERApproval As List(Of GERApproval)

        Public Property PayeeDOB As String
        Public Property ListNoID As String
        Public Property travelTransport As String
        Public Property travelMillage As String

        Public Property listrptRepor As List(Of rptReport)

    End Class

    Public Class GERApproval
        Public Property FormNum As String
        Public Property IsTax As String
        Public Property FileLocation As String
    End Class

    Public Class travelDetailData

        Public Property typeOfExpenses As String
        Public Property typeOfExpensesCode As String
        Public Property originalAmount As String
        Public Property idrAmount As String
        Public Property originalCurr As String
        Public Property exchangeRate As String
        Public Property nomor As String
        Public Property seqNum As String


    End Class

    Public Class cGERDetailResult

        Public Property cGERDetail As List(Of cSubGERDetail)
        Public Property cGERHistory As List(Of cGERHistory)
        Public Property result As String
        Public Property message As String


    End Class

    Public Class rptReport
        Public Property CompanyId As String
        Public Property TMPNum As String
        Public Property VoucherNum As String
        Public Property CodeVoucher As String
        Public Property PaidDate As DateTime
        Public Property Formnum As String
    End Class

    Public Class cSubGERDetail

        Public Property CompanyID As String
        Public Property FormNum As String
        Public Property GERType As String
        Public Property MainFormNum As String
        Public Property Currency As String
        Public Property ExchangeRate As Double
        Public Property FromDept As String
        Public Property AdvanceFormNum As String
        Public Property TransactionCode As String
        Public Property PolRelated As Boolean
        Public Property PolicyNum As String
        Public Property Budgeted As Boolean
        Public Property PONumber As String
        Public Property AppNumber As String

        Public Property Subject As String
        Public Property PaidBy As String
        Public Property Taxable As String
        Public Property BeneficiaryName As String
        Public Property BeneficiaryBankName As String

        Public Property BeneficiaryBankCode As String
        Public Property BeneficiaryBankAccount As String
        Public Property BeneficiaryBankBranch As String
        Public Property BeneficiaryBankCity As String
        Public Property BeneficiaryEmail As String
        Public Property BeneficiaryAccountCurrency As String
        Public Property BeneficiaryTypeCd As String
        Public Property BeneficiaryTypeNm As String
        Public Property BeneficiaryResidentStatusCd As String
        Public Property BeneficiaryResidentStatusNm As String
        Public Property BeneficiaryTranTypeCd As String
        Public Property BeneficiaryTranTypeNm As String
        Public Property BeneficiaryTranFacilityTypeCd As String
        Public Property BeneficiaryTranFacilityTypeNm As String

        Public Property SLFIBankAccountNum As String
        Public Property SLFIBankCode As String
        Public Property SLFIBankName As String

        Public Property RejectType As String
        Public Property RejectReason As String

        Public Property CreateDt As String
        Public Property CheckedDt As String
        Public Property ApprovedDt As String

        Public Property TotalAmount As String
        Public Property AdvanceAmount As String
        Public Property DueAmount As String
        Public Property TaxAmount As String
        Public Property NettAmount As String

        Public Property FormStatus As String
        Public Property FormLocation As String

        Public Property Description As String
        Public Property Journalized As String

        Public Property CreateBy As String
        Public Property CheckedBy As String
        Public Property ApprovedBy As String

        Public Property codeTypeTransaction As String
        Public Property paymentCategory As String
        Public Property PayeeDOB As String
        Public Property ListNoID As String

    End Class

    Public Class cSubGER

        Public Property pCompanyID As String
        Public Property pFormNum As String
        Public Property pUploadID As String

    End Class

    Public Class cBulkParam

        Public Property BulkID As Int32

    End Class

    Public Class cBulkData

        Public Property UID As String
        Public Property PolicyNo As String
        Public Property BName As String
        Public Property BCode As String
        Public Property AccountNo As String
        Public Property OAmmount As String
        Public Property TransKey As String

    End Class

    Public Class cBulkDataParam

        Public Property cBulkData As List(Of cBulkData)

    End Class

    ' Update Ronald 29 May Start
    Public Class cRejectedList
        Public Property cRejectedDetail As List(Of cRejectedDetail)
        Public Property result As String
        Public Property message As String
        Public Property totalRows As String
    End Class
    Public Class cRejectedDetail

        Public Property CompanyID As String
        Public Property FormNum As String
        Public Property Dept As String
        Public Property RejectDate As String
        Public Property RejectReason As String
        Public Property RejectBy As String
        Public Property RejectType As String
        Public Property CopiedTo As String
        Public Property UpdateBy As String
        Public Property PolRelated As String



    End Class
    ' Update Ronald 29 May End

    'Created : RS
    'Date    : 4 September 2018
    'Desc    : Get Data Policy List GER

    Public Class policyListParameter

        Public Property PageNum As Integer
        Public Property PageSize As Integer
        Public Property sortParam As List(Of sortParam)
        Public Property Search As String
        Public Property sType As String
        Public Property companyID As String

    End Class

    Public Class sortParam

        Public Property column As String
        Public Property dir As String

    End Class

    Public Class policyListResult

        Public Property policyList As List(Of policyListDetail)
        Public Property TotalRows As Integer
        Public Property TotalFilter As Integer
        Public Property Result As String
        Public Property Message As String

    End Class

    Public Class policyListDetail

        Public Property policyNumber As String
        Public Property totalAmount As String
        Public Property paidAmount As String
        Public Property remainingAmount As String

    End Class

    'Created : RS
    'Date    : 4 September 2018
    'Desc    : Get Beneficiary List GER

    Public Class beneficiaryListParameter

        Public Property PageNum As Integer
        Public Property PageSize As Integer
        Public Property sortParam As List(Of sortParam)
        Public Property Search As String
        Public Property sType As String
        Public Property companyID As String

    End Class

    Public Class beneficiaryListResult

        Public Property beneficiaryList As List(Of ListGERBeneficiaryDetail)
        Public Property TotalRows As Integer
        Public Property TotalFilter As Integer
        Public Property Result As String
        Public Property Message As String

    End Class

    'Created : RS
    'Date    : 17 September 2018
    'Desc    : Get car Filter List GER

    Public Class carFilterListParameter

        Public Property PageNum As Integer
        Public Property PageSize As Integer
        Public Property sortParam As List(Of sortParam)
        Public Property Search As String
        Public Property sType As String
        Public Property companyID As String

    End Class

    Public Class carFilterListResult

        Public Property carFilterList As List(Of carFilterListDetail)
        Public Property TotalRows As Integer
        Public Property TotalFilter As Integer
        Public Property Result As String
        Public Property Message As String

    End Class

    Public Class carFilterListDetail

        Public Property carNumber As String
        Public Property totalAmount As String
        Public Property paidAmount As String

    End Class

    'Created : RS
    'Date    : 24 September 2018
    'Desc    : Get GER Policy Bulk Detail

    Public Class gerPolicyBulkDetailParameter

        Public Property PageNum As Integer
        Public Property PageSize As Integer
        Public Property sortParam As List(Of sortParam)
        Public Property Search As String
        Public Property formNum As String
        Public Property companyID As String

    End Class

    Public Class gerPolicyBulkDetailResult

        Public Property gerPolicyBulkDetailList As List(Of gerPolicyBulkDetailSub)
        Public Property TotalRows As Integer
        Public Property TotalFilter As Integer
        Public Property Result As String
        Public Property Message As String

    End Class

    Public Class gerPolicyBulkDetailSub

        Public Property subGER As String
        Public Property mainGER As String
        Public Property policyNum As String
        Public Property beneficiaryName As String
        Public Property beneficiary_Bank_Name As String
        Public Property beneficiary_Bank_Account As String
        Public Property totalAmount As String

    End Class

End Namespace
