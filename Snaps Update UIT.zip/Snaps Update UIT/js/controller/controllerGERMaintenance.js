/**
 * GER Maintenance - controller
 * Contains Controller for Maintenance GER
 * Roby S - 5 June 2018
 */


function gerMaintenanceCtrl (transService,$scope, $timeout, commonService, $uibModal, transGERService, toaster, 
	DTOptionsBuilder, DTColumnDefBuilder, $filter, localStorageService, bsLoadingOverlayService,SweetAlert, $filter,APISettings,$http, $compile,DTColumnBuilder) {
	var vm = this;
	vm.message = '';
	vm.codeCostCenter = '';
	vm.codeSegCode = '';

	vm.dob = undefined;
	var startDateTravelTemp = undefined;
	var endDateTravelTemp = undefined;

	var startDateEnterTemp = undefined;
	$scope.isDisabled = true;
	$scope.isTOE = true;
	$scope.isOtherR = true;
	//$scope.isINH = false;

	vm.modifiedOn = modifiedOn;
	vm.modifiedOff = modifiedOff;
	vm.refreshGERMaintenance = refreshGERMaintenance;

	vm.ListNoID = [];
	vm.ListNoID2 = [];
	$scope.noidModel =  [];
	$scope.dataExcel = [];
	$scope.bulkFileInput = undefined;

	$scope.isPolNum = false;
	$scope.isCerNum = false;
	$scope.disMTF = true;

	vm.polNumDisable = true;
	vm.budgetValue = 'YES';
	$scope.testModel = {};
	$scope.getTotalEntOrigAmount = 0;
	vm.entDetails = [];
	$scope.test = [{
		'codeID' : '1',
		'descriptionID' : '-'
	}, {
		'codeID' : '2',
		'descriptionID' : 'Tabbaru'
	}, {
		'codeID' : '3',
		'descriptionID' : 'Ujro'
	}];

	$scope.ListNoIDP = [];
	
	$scope.testModel = '0'

	if (localStorageService.get('CO_ID_VALUE') == 'SYA') {
		$scope.disFlag = false;
	}
	else {
		$scope.disFlag = false;
	}

	$scope.changesmillage = function () {
		if (vm.travelDetails2Add.trsTravel=='PSLCAR' || vm.travelDetails2Add.trsTravel=='SHTBUS'){
				 $scope.isDisabled = false;
				 
			}else{
				 $scope.isDisabled = true;
				 vm.travelDetails2Add.travelMillage=0;
			}
		   }
	
	$scope.DoBack = function() {

		$scope.backData = localStorageService.get('valueBack');

		if($scope.backData != null && $scope.backData != undefined) {

			if($scope.backData.page == 'gerlist') {

				if ($scope.backData != null && $scope.backData != undefined)
				{

				$scope.backData.isBack = true;
				localStorageService.set('valueBack', $scope.backData);
				window.location.href = "index.html#/list/GER";

				}
				else
				{

					window.location.href = "index.html#/list/GER";


				}
			}
			else if($scope.backData.page == 'rejectlist') {
				$scope.backData.isBack = true;
				localStorageService.set('valueBack', $scope.backData);
				window.location.href = "index.html#/list/rejected";
			}

			

		}
		else
		{
			window.location.href = "index.html#/list/GER";
		}
	}

	$("#transactionType_DESC").keydown(false);

	refreshGERMaintenance();

	function modifiedOn()
	{
		bsLoadingOverlayService.start({
			referenceId: 'overLay_GERMaintenance'
		});

		commonService.GetElementVal({formNumber:localStorageService.get('GERNO_MAINTEN'),companyid:localStorageService.get('CO_ID_VALUE'),Status2:$scope.formStatusCurrent,Status:$scope.formStatusCurrent,Rules:localStorageService.get('ROLESGER_MAINTEN'),RType:'DISABL'}).then(function (results) {

			if(results.elementText != null && results.elementText != '')
			{
				toaster.pop({ type: 'error', body: results.elementText, toasterId: 20 });
			}
			else
			{
				vm.ElementValList = results;

				$timeout(function(){
					$scope.$apply(function() {
						
							vm.ElementValList.elementComboList.forEach(function (h) {

								$('#' + h['attributeTag']).selectpicker('refresh'); 
					
							});

						});
				});

			}

			bsLoadingOverlayService.stop({
		        referenceId: 'overLay_GERMaintenance'
		    });

		}, function (error) {
			toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
		});
		$scope.disMTF = false;
	}

	function modifiedOff()
	{

		commonService.GetElementVal({formNumber:localStorageService.get('GERNO_MAINTEN'),companyid:localStorageService.get('CO_ID_VALUE'),Status2:$scope.formStatusCurrent,Status:'MOFF',Rules:localStorageService.get('ROLESGER_MAINTEN'),RType:'DISABL'}).then(function (results) {

			vm.ElementValList = results;
			$scope.reportVal = {
				trv: results.elementValueList.geR_TRVL_TAB_DSB,
				ent: results.elementValueList.geR_ENT_TAB_DSB
			};

			$timeout(function(){
					$scope.$apply(function() {
						
						vm.ElementValList.elementComboList.forEach(function (h) {

							$('#' + h['attributeTag']).selectpicker('refresh'); 
				
						});

					});
			});
			
			//$scope.editBeneficiaryName = false;
			tabEditOff();
	
		}, function (error) {
			toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
		});

		$scope.dobDis = true;
		$scope.disMTF = true;

	}

	$scope.reloadBulkFile1 = function (fAttach) {
                
		var resultbase64,resultFileName,resultFileNameType;
		$scope.bulkFileInput1 = fAttach;
		var filetypes = fAttach[0].filetype.split("/");
		resultbase64 = fAttach[0].base64;
		resultFileName = fAttach[0].filename;
		resultFileNameType = filetypes[1];
		var workbook = XLSX.read(resultbase64, {type: 'base64'});
		
		var data = XLSX.utils.sheet_to_json( workbook.Sheets[workbook.SheetNames[0]]);
		$scope.dataExcel = data;
		 $timeout( function(){
				  
				}, 1000);
		var tempData = $scope.dataExcel;
		$scope.bulkExcelCollection = [];
		if(tempData != undefined && tempData.length != 0)
		{
				var dtx = 0
				tempData.forEach(function (h) {
						// if (h['TransKey'] != undefined || h['Transkey'] != '' ) {
						//         gerTypeTemp = 'M';
						// }
						let ic1 = h['Nomor Rekening'].includes("-");
						if (ic1 == true)
						{
							$scope.bulkExcelCollection = [];
							toaster.pop({ type: 'error', body: 'account number must not contain "-"', toasterId: 20 });
							dtx = 1
							return;
						}

						if (dtx == 1)
						{
							$scope.bulkExcelCollection = [];
						}
						else
						{
							$scope.bulkExcelCollection.push({
								NomorGER:h['Nomor GER'],
								NomorRekening:h['Nomor Rekening'],
								NamaPemilikRekening:h['Nama Pemilik Rekening'],
								Bank:h['Bank'],
								Currency:h['Currency'],
								Amount:h['Amount'],
								Keterangan:h['Keterangan'],
								Email:h['Email']}
							);	
						}
				});
		}
		
};
$scope.clearDataExcel = function () {

		$scope.dataExcel = [];
		$scope.bulkFileInput = undefined;
};


	function tabEditOff()
	{
		$scope.showhide1(true);
		$scope.showhide2(true);
		$scope.showhide3(true);
	}

	function refreshGERMaintenance()
	{

		if(localStorageService.get('GERNO_MAINTEN') != '0')
		{
			bsLoadingOverlayService.start({
				referenceId: 'overLay_GERMaintenance'
			});

			transGERService.gerDetailMaster({"skey1":localStorageService.get('GERNO_MAINTEN'),"companyid":localStorageService.get('CO_ID_VALUE')}).then(function (results) {

				$scope.formStatusCurrent =results.cGERDetail[0].formStatus;
				$scope.dob = results.cGERDetail[0].payeeDOB;
				
				commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_Subject'}).then(function (results1) {

					$scope.subjectList = results1.comboValueList;

					commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_PaidBy'}).then(function (results2) {

						$scope.paidByList = results2.comboValueList;

						commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_Bank',OthersKey1:results.cGERDetail[0].currency}).then(function (results3) {

							$scope.bankList = results3.comboValueList;

							commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_Beneficiary_Bank'}).then(function (results4) {

								$scope.beneficiaryBankList = results4.comboValueList;

								commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_beneficiarytype'}).then(function (results5) {

									$scope.benTypeList = results5.comboValueList;

									commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_Bank_Account',OthersKey1:results.cGERDetail[0].slfiBankCode, 
									OthersKey2:results.cGERDetail[0].currency}).then(function (results6) {

										$scope.bankAccNumberList = results6.comboValueList;

										commonService.getComboValue({ companyid: localStorageService.get('CO_ID_VALUE'), OthersKey1: 'ITAPP', TypeCombo: 'Combo_currency_new_ger' }).then(function (results7) {

											$scope.accCurrencyList = results7.comboValueList;

											commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_beneficiarytransactiontype'}).then(function (results8) {

												$scope.btransactionTypeList = results8.comboValueList;

												commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_all_code',OthersKey1:'BNFRECST'}).then(function (results9) {
													
													commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'combo_ListNoId',OthersKey1:localStorageService.get('USERID_VALUE')}).then(function (resultsx) {
														debugger;
														$scope.ListNoIDP = resultsx.comboValueList;
														
														$timeout(function(){
															$scope.$apply(function() {
																	$('#listNoId').selectpicker('refresh'); 
															});
														});

														
													}, function (error) {
														toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
													});

													commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'get_ListNoID',OthersKey1:results.cGERDetail[0].formNum}).then(function (resultsi) {
														debugger;
														resultsi.comboValueList;
														vm.ListNoID = [];
														for (var i = 0; i < resultsi.comboValueList.length; i++) {
															vm.ListNoID.push({
																listNoId: resultsi.comboValueList[i].descriptionID,
																amount: resultsi.comboValueList[i].others2,
																companyid: localStorageService.get('CO_ID_VALUE'),
																FormNum : $scope.fnumberModelHeader,
																ID: resultsi.comboValueList[i].others3});
														}
														CalculateTotal();

														// vm.ListNoID.push({
														// 	listNoId: results.comboValueList[0].codeID,
														// 	amount: results.comboValueList[0].others1,
														// 	companyid: localStorageService.get('CO_ID_VALUE'),
														// 	FormNum : $scope.fnumberModelHeader});
														// 	CalculateTotal();
														
														

														
													}, function (error) {
														toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
													});

													$scope.beneResidentList = results9.comboValueList;

													$scope.departModelHeader = results.cGERDetail[0].fromDept;

														if(results.cGERDetail[0].budgeted == true)
														{
															$scope.budgetModelHeader = 'yes';
														}
														else
														{
															$scope.budgetModelHeader = 'no';
														}

														$scope.fnumberModelHeader = results.cGERDetail[0].formNum;
														$scope.currencyModelHeader = results.cGERDetail[0].currency;
														$scope.transTypeModelHeader = results.cGERDetail[0].transactionCode;
														$scope.exRateModelHeader = results.cGERDetail[0].exchangeRate;
														$scope.policyNumberHeader = results.cGERDetail[0].policyNum;
														$scope.gerStatusModelHeader = results.cGERDetail[0].formStatus;
														$scope.cashAdModelHeader = results.cGERDetail[0].advanceFormNum;
														$scope.poNumbModelHeader = results.cGERDetail[0].poNumber;
														$scope.appNumbModelHeader = results.cGERDetail[0].appNumber;

														if ($scope.transTypeModelHeader == "CPDEAC" && localStorageService.get('CO_ID_VALUE') == "SLF")
														{
															$scope.isPolNum = false;
															$scope.isCerNum = true;
														}

														if ($scope.transTypeModelHeader == "GRPDEAC" && localStorageService.get('CO_ID_VALUE') == "SLF")
														{
															$scope.isPolNum = false;
															$scope.isCerNum = true;
														}

														if ($scope.transTypeModelHeader == "GRPDEACI" && localStorageService.get('CO_ID_VALUE') == "SLF")
														{
															$scope.isPolNum = false;
															$scope.isCerNum = true;
														}

														if ($scope.transTypeModelHeader == "GRPHI" && localStorageService.get('CO_ID_VALUE') == "SLF")
														{
															$scope.isPolNum = true;
															$scope.isCerNum = false;
														}

														if ($scope.transTypeModelHeader == "GRPSURR" && localStorageService.get('CO_ID_VALUE') == "SLF")
														{
															$scope.isPolNum = false;
															$scope.isCerNum = true;
														}

														if ($scope.transTypeModelHeader == "CPDEAC" && localStorageService.get('CO_ID_VALUE') == "SYA")
														{
															$scope.isPolNum = false;
															$scope.isCerNum = true;
														}

														if ($scope.transTypeModelHeader == "GRPDEAC" && localStorageService.get('CO_ID_VALUE') == "SYA")
														{
															$scope.isPolNum = false;
															$scope.isCerNum = true;
														}

														if ($scope.transTypeModelHeader == "GRPDEACI" && localStorageService.get('CO_ID_VALUE') == "SYA")
														{
															$scope.isPolNum = false;
															$scope.isCerNum = true;
														}

														if ($scope.transTypeModelHeader == "GRPSURR" && localStorageService.get('CO_ID_VALUE') == "SYA")
														{
															$scope.isPolNum = false;
															$scope.isCerNum = true;
														}

														if ($scope.transTypeModelHeader == "HISYAR" && localStorageService.get('CO_ID_VALUE') == "SYA")
														{
															$scope.isPolNum = true;
															$scope.isCerNum = false;
														}
														
														if ($scope.transTypeModelHeader == 'INH') {
															$scope.isINH = false;
														}
														else {
															$scope.isINH = true;
														}

														$scope.subjectModel = results.cGERDetail[0].subject;
														$scope.paidModel = results.cGERDetail[0].paidBy;
														$scope.bankModel = results.cGERDetail[0].slfiBankCode;
														$scope.bankAccModel = results.cGERDetail[0].slfiBankAccountNum;
														
														$scope.benTypeModel = results.cGERDetail[0].beneficiaryTypeCd;
														vm.beneficiaryName_Value = results.cGERDetail[0].beneficiaryName;

														$scope.benBankModel = results.cGERDetail[0].beneficiaryBankCode;
														$scope.benBankAccModel = results.cGERDetail[0].beneficiaryBankAccount;
														$scope.benBranchModel = results.cGERDetail[0].beneficiaryBankBranch;
														$scope.benTransTypeModel = results.cGERDetail[0].beneficiaryTranTypeCd;
														$scope.benresidentModel = results.cGERDetail[0].beneficiaryResidentStatusCd;
														$scope.bencurrencyModel = results.cGERDetail[0].beneficiaryAccountCurrency;
														$scope.bencityModel = results.cGERDetail[0].beneficiaryBankCity;
														$scope.benEmailModel = results.cGERDetail[0].beneficiaryEmail;
														$scope.rejectReason = results.cGERDetail[0].rejectReason;

														$scope.totalAmount = results.cGERDetail[0].totalAmount;
														$scope.advanceAmount = results.cGERDetail[0].advanceAmount;
														$scope.dueAmount = results.cGERDetail[0].dueAmount;
														$scope.taxAmount = results.cGERDetail[0].taxAmount;
														$scope.nettAmount = results.cGERDetail[0].nettAmount;
														$scope.convertednettAmount = results.cGERDetail[0].nettAmount;
														$scope.polRelated = results.cGERDetail[0].polRelated;
														$scope.payCatModel = results.cGERDetail[0].paymentCategory;
														$scope.dobDis = true;
														

														vm.listHistory = results.cGERHistory;

														$scope.globalCodeTypeTransaction = results.cGERDetail[0].codeTypeTransaction;

														tabGERDetail();

														if($scope.globalCodeTypeTransaction == 'TRAVLE')
														{
															tabGERTravel();
														}
														else if($scope.globalCodeTypeTransaction == 'ENTREE')
														{
															tabGEREntertainment();
														}

														commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'PaymentCategory'}).then(function (res) {
															debugger;
															$scope.payCatList = res.comboValueList;
															$timeout(function(){
																$scope.$apply(function() {
																		$('#payCatCombo').selectpicker('refresh'); 
																});
														});

														}, function (error) {
															toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
														});

														modifiedOff();

														bsLoadingOverlayService.stop({
															referenceId: 'overLay_GERMaintenance'
														});
														

												}, function (error) {
													toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
												});

												
										
											}, function (error) {
												toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
											});							
											
									
										}, function (error) {
											toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
										});

										
								
									}, function (error) {
										toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
									});
									
							
								}, function (error) {
									toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
								});
						
							}, function (error) {
								toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
							});
							
					
						}, function (error) {
							toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
						});
						
				
					}, function (error) {
						toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
					});
					
			
				}, function (error) {
					toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
				});

			}, function (error) {
				toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
			});

		}

	}

	$scope.tabGERApproval = function() {

		//Update Ronald 5 Start
		transGERService.listApprover({
		    "paramtype": "List_GER_Approver", "ProcessBy": localStorageService.get('USERID_VALUE'), "skey1": localStorageService.get('GERNO_MAINTEN'), "skey2": "", "skey3": "", "skey4": "*"
        , "skey5": "", "skey6": "", "skey7": "", "companyid": localStorageService.get('CO_ID_VALUE'), "pagesize": "10000", "pageno": "1"
		}).then(function (results) {

		    vm.listApprover = results.cGERApprover;
		    bsLoadingOverlayService.stop({
		        referenceId: 'listGerOverLay'
		    });

		}, function (error) {
		    toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
		});
		// Update Ronald 5 end

	}

	$scope.tabGERPolicyDetail = function() {

		//Update Ronald 5 Start
		transGERService.listPolicydetail({
		    "paramtype": "List_GER_Policydetail", "ProcessBy": localStorageService.get('USERID_VALUE'), "skey1": localStorageService.get('GERNO_MAINTEN'), "skey2": "", "skey3": "", "skey4": "*"
        , "skey5": "", "skey6": "", "skey7": "", "companyid": localStorageService.get('CO_ID_VALUE'), "pagesize": "10000", "pageno": "1"
		}).then(function (results) {

		    vm.listPolicydetail = results.cGERPolicydetail;
		    bsLoadingOverlayService.stop({
		        referenceId: 'listGerOverLay'
		    });

		}, function (error) {
		    toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
		});
	    // Update Ronald 5 end

	}

	// $scope.tabGERHistory = function() {

	// 	 //Update Ronald 5 Start
	// 	 transGERService.listHistory({
	// 	    "paramtype": "List_GER_History", "ProcessBy": localStorageService.get('USERID_VALUE'), "skey1": localStorageService.get('GERNO_MAINTEN'), "skey2": "", "skey3": "", "skey4": "*"
    //     , "skey5": "", "skey6": "", "skey7": "", "companyid": localStorageService.get('CO_ID_VALUE'), "pagesize": "10000", "pageno": "1"
	// 	}).then(function (results) {

	// 	    vm.listHistory = results.cGERHistory;
	// 	    bsLoadingOverlayService.stop({
	// 	        referenceId: 'listGerOverLay'
	// 	    });

	// 	}, function (error) {
	// 	    toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
	// 	});
	//     // Update Ronald 5 end

	// }

	//Update Ronald 5 Start
	function tabGERDetail() {
		
		bsLoadingOverlayService.start({
			referenceId: 'gerMaintenance_tabDetailOverlay'
		});

		transGERService.listDescription({
			"paramtype": "List_GER_Description", "ProcessBy": localStorageService.get('USERID_VALUE'), "skey1": localStorageService.get('GERNO_MAINTEN'), "skey2": "", "skey3": "", "skey4": "*"
		, "skey5": "", "skey6": "", "skey7": "", "companyid": localStorageService.get('CO_ID_VALUE'), "pagesize": "10000", "pageno": "1"
		}).then(function (results) {

			vm.listDescription = results.cGERDescription;
			
			// $scope.getTotal = function(){
			// 	var total = 0;
			// 	for(var i = 0; i < vm.listDescription.length; i++){
			// 		var item = vm.listDescription[i];
			// 		total += (item.originalAmount*1);
			// 	}
			// return total;
			// };

			CalculateGERDetail();

			bsLoadingOverlayService.stop({
				referenceId: 'gerMaintenance_tabDetailOverlay'
			});
		}, function (error) {
			toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
		});
	
	}
	// Update Ronald 5 end

	$scope.tabGERAttachment = function() {

		transGERService.getGERAttachment({companyid:localStorageService.get('CO_ID_VALUE'),paramtype:'List_Attachment',skey1:localStorageService.get('GERNO_MAINTEN')}).then(function (results) {

			vm.attList = results.cGERAttachment;		
	
		}, function (error) {
			toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
		});

	};

	function addAtts() {
		// vm.attList.push(angular.copy(vm.att2Add));
		// vm.att2Add = att2Add(vm.att2Add.no + 1);

		var resultbase64,resultFileName,resultFileNameType;

		if(angular.isUndefined(vm.att2Add.attachFile) || vm.att2Add.attachFile == '')
		{

			toaster.pop({ type: 'error', body: "Please upload the File!!", toasterId: 20 });
			resultbase64 = '';
			resultFileName = '';
			resultFileNameType = '';

		}
		else
		{
			var filetypes = vm.att2Add.attachFile[0].filetype.split("/");
			resultbase64 = vm.att2Add.attachFile[0].base64;
			resultFileName = vm.att2Add.attachFile[0].filename;
			resultFileNameType = filetypes[1];

			var resultFileName2 = resultFileName.split(".");
			var resultFileNameType=resultFileName.split('.').pop().toLowerCase();

			if(resultFileNameType != 'xlsx' && resultFileNameType != 'xls'  && resultFileNameType != 'pdf' )
			{
				toaster.pop({ type: 'error', body: "Only PDF , XLSX, XLS , DOC, DOCX File!!", toasterId: 20 });
				return;
			}
			

			transGERService.createGERAttachment({companyid:localStorageService.get('CO_ID_VALUE'),FileData:resultbase64,Table:'NEW',FormNum:localStorageService.get('GERNO_MAINTEN')
			,FileName:resultFileName2[0],AttachmentType:resultFileNameType}).then(function (results) {
	
				transGERService.getGERAttachment({companyid:localStorageService.get('CO_ID_VALUE'),paramtype:'List_Attachment',skey1:localStorageService.get('GERNO_MAINTEN')}).then(function (results) {

					vm.attList = results.cGERAttachment;		
					vm.att2Add.attachFile = '';
			
				}, function (error) {
					toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
				});	
		
			}, function (error) {
				toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
			});

		}

	}


	//roby bank change

	$scope.bankChange = function() {

		commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_Bank_Account',OthersKey1:$scope.bankModel, 
		OthersKey2:$scope.currencyModelHeader}).then(function (results) {

			$scope.bankAccNumberList = results.comboValueList;

			$timeout(function(){
				$scope.$apply(function() {
					$('#bankAccNumberCombo').selectpicker('refresh'); 
				});
			});

		}, function(error){

		});

	}

	vm.CTdtOptions = DTOptionsBuilder.newOptions().withPaginationType('full_numbers')
	.withOption('rowCallback', $scope.rowCallbackCT).withOption('responsive', true);

	vm.ACdtOptions = DTOptionsBuilder.newOptions().withPaginationType('full_numbers')
	.withOption('rowCallback', $scope.rowCallbackAC).withOption('responsive', true);
	
	vm.SCdtOptions = DTOptionsBuilder.newOptions().withPaginationType('full_numbers')
	.withOption('rowCallback', $scope.rowCallbackAC).withOption('responsive', true);

	vm.GDdtOptions = DTOptionsBuilder.newOptions().withPaginationType('full_numbers')
	.withOption('responsive', true);

	vm.GDLNOptions = DTOptionsBuilder.newOptions().withPaginationType('full_numbers')
	.withOption('responsive', true);

    vm.GDdtColumnDefs = [
        DTColumnDefBuilder.newColumnDef(0).notSortable(),
        DTColumnDefBuilder.newColumnDef(1).notSortable(),
        DTColumnDefBuilder.newColumnDef(2).notSortable(),
		DTColumnDefBuilder.newColumnDef(3).notSortable(),
		DTColumnDefBuilder.newColumnDef(4).notSortable(),
        DTColumnDefBuilder.newColumnDef(5).notSortable(),
		DTColumnDefBuilder.newColumnDef(6).notSortable()
	];

	vm.ATTdtOptions = DTOptionsBuilder.newOptions().withPaginationType('full_numbers')
	.withOption('responsive', true);

	vm.HSdtOptions = DTOptionsBuilder.newOptions().withPaginationType('full_numbers')
	.withOption('responsive', true);

	vm.policyDetaildtOptions = DTOptionsBuilder.newOptions().withPaginationType('full_numbers')
	.withOption('responsive', true);

	vm.APVdtOptions = DTOptionsBuilder.newOptions().withPaginationType('full_numbers')
	.withOption('responsive', true);

	
	$scope.selectChargeTo = function(item) {
		debugger;
		vm.messageChargeTo = item.others1;
		vm.codeCostCenter = item.codeID;
		angular.element('input#chargeTo').removeClass("ng-pristine ng-untouched ng-empty").addClass("ng-touched ng-not-empty ng-dirty ng-valid-parse");
		angular.element('#ctFormGroup').removeClass("is-empty");
		$scope.editChargeTo=false;
	};
	
	$scope.selectSegCode = function(item) {
		debugger;
		vm.messageSegCode = item.descriptionID;
		vm.codeSegCode = item.codeID;
		vm.SegCodeDesc = item.codeID +' - '+item.descriptionID;
		angular.element('input#segCode').removeClass("ng-pristine ng-untouched ng-empty").addClass("ng-touched ng-not-empty ng-dirty ng-valid-parse");
		angular.element('#scFormGroup').removeClass("is-empty");
		$scope.editSegCode=false;
	};
	
	$scope.selectAccountCode = function(item) {
        vm.messageAccountCode = item.codeID;
		angular.element('input#accountCode').removeClass("ng-pristine ng-untouched ng-empty").addClass("ng-touched ng-not-empty ng-dirty ng-valid-parse");
		angular.element('#acFormGroup').removeClass("is-empty");
		$scope.editAccountCode=false;

		$scope.adpro = [];
                if (item.codeID == '5500003401' || item.codeID == '5500003400') {
                        if(item.codeID == '5500003401') {
                                $scope.adpro = [{
                                        codeID : 'Jasa Desain',
                                        descriptionID : 'Jasa Desain'
                                },{
                                        codeID : 'Jasa Media Audio Visual',
                                        descriptionID : 'Jasa Media Audio Visual'
                                },{
                                        codeID : 'Jasa Media Cetak',
                                        descriptionID : 'Jasa Media Cetak'
                                },{
                                        codeID : 'Jasa Tenaga Ahli',
                                        descriptionID : 'Jasa Tenaga Ahli'
                                },{
                                        codeID : 'Pembelian Barang Promosi',
                                        descriptionID : 'Pembelian Barang Promosi'
                                },{
                                        codeID : 'Pengenalan Produk Asuransi',
                                        descriptionID : 'Pengenalan Produk Asuransi'
                                },{
                                        codeID : 'Sponsorship',
                                        descriptionID : 'Sponsorship'
                                },{
                                        codeID : 'Lain - Lain',
                                        descriptionID : 'Lain - Lain'
                                }];
                                // $scope.adpro = [{
                                //                 codeID : '1',
                                //                 descriptionID : 'Jasa Desain'
                                //         },{
                                //                 codeID : '2',
                                //                 descriptionID : 'Jasa Media Audio Visual'
                                //         },{
                                //                 codeID : '3',
                                //                 descriptionID : 'Jasa Media Cetak'
                                //         },{
                                //                 codeID : '4',
                                //                 descriptionID : 'Jasa Tenaga Ahli'
                                //         },{
                                //                 codeID : '5',
                                //                 descriptionID : 'Pembelian Barang Promosi'
                                //         },{
                                //                 codeID : '6',
                                //                 descriptionID : 'Pengenalan Produk Asuransi'
                                //         },{
                                //                 codeID : '7',
                                //                 descriptionID : 'Sponsorship'
                                //         },{
                                //                 codeID : '8',
                                //                 descriptionID : 'Lain - Lain'
                                //         }];
                        }
                        else if (item.codeID == '5500003400') {
                                $scope.adpro = [{
                                        codeID : 'Pemasangan Papan Reklame',
                                        descriptionID : 'Pemasangan Papan Reklame'
                                },{
                                        codeID : 'Perizinan dan Pajak Papan Reklame',
                                        descriptionID : 'Perizinan dan Pajak Papan Reklame'
                                },{
                                        codeID : 'Pemasangan Iklan',
                                        descriptionID : 'Pemasangan Iklan'
                                },{
                                        codeID : 'Pemasangan Logo Perusahaan',
                                        descriptionID : 'Pemasangan Logo Perusahaan'
                                },{
                                        codeID : 'Lain - Lain',
                                        descriptionID : 'Lain - Lain'
                                }];
                                // $scope.adpro = [{
                                //         codeID : '1',
                                //         descriptionID : 'Pemasangan Papan Reklame'
                                // },{
                                //         codeID : '2',
                                //         descriptionID : 'Perizinan dan Pajak Papan Reklame'
                                // },{
                                //         codeID : '3',
                                //         descriptionID : 'Pemasangan Iklan'
                                // },{
                                //         codeID : '4',
                                //         descriptionID : 'Pemasangan Logo Perusahaan'
                                // },{
                                //         codeID : '5',
                                //         descriptionID : 'Lain - Lain'
                                // }];
                        }
                        else {
                                $scope.adpro = [];
                        }
                }
                $timeout(function(){
                        $scope.$apply(function() {
                                        $('#combo_adpro').selectpicker('refresh');
                        });
                });
	};
	
	
	$scope.rowCallbackCT = function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
        angular.element('td:not(:first-child)', nRow).unbind('click');
        angular.element('td:not(:first-child)', nRow).bind('click', function() {
            $scope.$apply(function() {
                $scope.selectChargeTo(aData);
            });
        });
        return nRow;
	};
	
	$scope.rowCallbackAC = function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
        angular.element('td:not(:first-child)', nRow).unbind('click');
        angular.element('td:not(:first-child)', nRow).bind('click', function() {
			$scope.editAccountCode = false;
            $scope.$apply(function() {
                $scope.selectAccountCode(aData);
            });
        });
        return nRow;
	};
	
	
    vm.details2Add = $scope.details2Add;
	vm.att2Add = att2Add();
    vm.addDetails = $scope.addDetails;
	vm.addAtts = addAtts;

	vm.removeDetails = removeDetails;
	vm.viewAtts = viewAtts;
	vm.removeAtts = removeAtts;
	vm.attName =  $scope.filename;
	
    $scope.details2Add = function() {
        return {
            detailNumber: '',
            description: '',
			originalAmount: '',
            costCenter: '',
			accountCodeAC: '',
			certificateNo:'',
			policyNo:''
        };
	};

	/*
	custom Function Max
	RS - 4 June 2018
	RS - 2 July 2018
	RS - 19 July 2018
	*/
	
	$scope.DoMakeSure = function(sTitle) {
		if (sTitle == "Government Official")
		{
			SweetAlert.swal("Warning", "Make sure you choose the correct title", "warning");
		}
	}

	function customMinimum(arrayValue,fieldName)
	{

		if(arrayValue == undefined)
		{
			return 0;
		}

		var arrayLength = arrayValue.length, tempResult = 0, finalResult = 0;

		if (arrayLength == 1)
		{
			return arrayValue[0][fieldName];
		}
		else{

			for(arrayKey1 = 0 ; arrayKey1 < arrayLength ; arrayKey1++)
			{
				for(arrayKey2 = 1 + arrayKey1 ; arrayKey2 < arrayLength ; arrayKey2++)
				{
					if(parseInt(arrayValue[arrayKey1][fieldName]) > parseInt(arrayValue[arrayKey2][fieldName]))
					{
						tempResult = arrayValue[arrayKey1][fieldName];
					}
					else
					{
						tempResult = arrayValue[arrayKey2][fieldName];
					}

					if(parseInt(tempResult) > parseInt(finalResult))
					{
						finalResult = tempResult;
					}
					
				}

			};
		}

		return finalResult;

	}

	$scope.changeTest = function(param) {
		$scope.testModel = param;
	}

	$scope.addDetails = function() {

		if(vm.details2Add.description == undefined || vm.details2Add.description == '')
		{
			toaster.pop({ type: 'error', body: 'Description detail must filled !', toasterId: 20 });
			return;
		}

		if (vm.details2Add.originalAmount > '0') {
			if (vm.messageAccountCode == undefined || vm.messageAccountCode == '') {

				toaster.pop({ type: 'error', body: 'Account Code must filled !', toasterId: 20 });
				return;
			}



			if ($scope.policyNumberHeader == null || $scope.policyNumberHeader == undefined || $scope.policyNumberHeader == "" || $scope.policyNumberHeader == 0) {


				if (vm.messageChargeTo == undefined || vm.messageChargeTo == '') {
					toaster.pop({ type: 'error', body: 'Charge To must filled !', toasterId: 20 });
					return;
				}


			}




		}






		if (($scope.transTypeModelHeader == 'GRPSURR' || $scope.transTypeModelHeader == 'GRPVRM') && localStorageService.get('CO_ID_VALUE') == 'SYA') {
			if ($scope.testModel == '0' || $scope.testModel == '1') {
				toaster.pop({ type: 'error', body: 'Select option Tabbaru & Ujro must filled !', toasterId: 20 });
				return;
			}

		}

		if (vm.messageAccountCode =='5500003400' || vm.messageAccountCode == '5500003401') {
			if($scope.adproSelect == 'Lain - Lain') {
					toaster.pop({ type: 'error', body: 'Reason must filled !', toasterId: 20 });
					return;
			}
		}
		if($scope.isPolNum == true && vm.details2Add.PolicyNo == undefined) {
				toaster.pop({ type: 'error', body: 'Policy Number must filled !', toasterId: 20 });
				return;
		}
		if($scope.isCerNum == true && vm.details2Add.certificateNo == undefined) {
				toaster.pop({ type: 'error', body: 'Certificate Number must filled !', toasterId: 20 });
				return;
		}

		if(vm.details2Add.originalAmount == undefined || vm.details2Add.description == '')
		{
			vm.details2Add.originalAmount = 0;
		}

		var lastSeqNum = 0;


		if(vm.listDescription == undefined || vm.listDescription == null || vm.listDescription.length == 0)
		{
			vm.listDescription = [];
		}
		else
		{
			lastSeqNum = parseFloat(customMinimum(vm.listDescription,'seqNum')) + 1;
		}

		if($scope.isPolNum == true && (vm.details2Add.PolicyNo == undefined || vm.details2Add.PolicyNo == "")) {
			toaster.pop({ type: 'error', body: 'Policy Number must filled !', toasterId: 20 });
			return;
		}

		if($scope.isCerNum == true && (vm.details2Add.certificateNo == undefined || vm.details2Add.certificateNo == "")) {
			toaster.pop({ type: 'error', body: 'Certificate Number must filled !', toasterId: 20 });
			return;
		}
		
		vm.listDescription.push({
		coa : vm.messageAccountCode,
		coa_updated : vm.messageAccountCode,
		companyID : localStorageService.get('CO_ID_VALUE'),
		codeCostCenter : vm.codeCostCenter,
		costCenter : vm.messageChargeTo,
		description : vm.details2Add.description,
		formNum : localStorageService.get('GERNO_MAINTEN'),
		nomor : vm.details2Add.detailNumber,
		originalAmount : vm.details2Add.originalAmount,
		seqNum : lastSeqNum,
		isSyaFlag : $scope.testModel,
		segCode : vm.codeSegCode,
		certificateNo : vm.details2Add.certificateNo,
		policyNo : vm.details2Add.PolicyNo});

		CalculateGERDetail();

		vm.messageAccountCode = '';
		vm.messageChargeTo = '';
		vm.codeCostCenter = '';
		vm.codeSegCode = '';
		vm.SegCodeDesc ='';
		vm.details2Add.description = '';
		vm.details2Add.detailNumber = '';
		vm.details2Add.originalAmount = '';
		$scope.testModel = '0';
		$scope.editChargeTo = false;
		$scope.editAccountCode = false;
		vm.details2Add.certificateNo = '';
		vm.details2Add.PolicyNo = '';

		//console.log(vm.details2Add);
	};

	$scope.changeListNoId = function(itemx){
		$scope.ListNoI_temp = itemx;
	}

	
	$scope.addListNo = function(listt) {
		// $scope.listNoModel = listt;
		// $scope.noidModel.push({
		// 	listNoId : $scope.listNoModel,
		// 	FormNum : $scope.fnumberModelHeader,
		// 	companyid: localStorageService.get('CO_ID_VALUE')
		// });
		commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'ListNoId_detail',OthersKey1:$scope.ListNoI_temp}).then(function (results) {
			debugger;
			//$scope.ListNoIDC = results.comboValueList;

			vm.ListNoID.push({
				listNoId: results.comboValueList[0].codeID,
				amount: results.comboValueList[0].others1,
				companyid: localStorageService.get('CO_ID_VALUE'),
				FormNum : $scope.fnumberModelHeader,
				ID:results.comboValueList[0].others2 });
				CalculateTotal();

				$scope.listNoModel = '';
			
			// for (var i = 0; i < results.comboValueList.length; i++) {
			// 	vm.ListNoID.push({
			// 		ListNo: results.comboValueList[i].codeID,
			// 		PolicyID: results.comboValueList[i].others1,
			// 		amount: results.comboValueList[i].others2,
			// 		curr: results.comboValueList[i].others3,
			// 		systemTreatyNumber: results.comboValueList[i].others4,
			// 		reinsCo:results.comboValueList[i].others5,
			// 		planCode: results.comboValueList[i].others6});
			// 		CalculateTotal(results.comboValueList[i].others2,);
			// }

			

		// 	vm.ListNoID2 = vm.ListNoID.reduce(function(r, a) {
		// 		r[a.ListNo] = r[a.ListNo] || [];
		// 		r[a.ListNo].push(a);
		// 		return r;
		// 	  }, Object.create(null));

			// transGERService.listnoidDt({
			// 	"skey2": $scope.listNoModel
			// }).then(function (results) {
			// 	debugger;
			// 	results;
				
			// }, function (error) {
			// 	toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
			// });

			// results.comboValueList.forEach(function(value){
			// 	var gig = $scope.listNoModel;
			// 	vm.ListNoID.push({
			// 	ListNo: value.codeID,
			// 	PolicyID: value.others1,
			// 	amount: value.others2});
			// });
			
			
		}, function (error) {
			toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
		});
	}

	$scope.totalAmountList = 0;

	function CalculateTotal() {
		$scope.totalAmountList = 0;
		vm.ListNoID.forEach(function(value) {
			// if  ($scope.tempAmount == 0)
			// {
				$scope.totalAmountList = parseFloat($scope.totalAmountList) + parseFloat(value.amount);
			// }parse
			// else {
			// 	$scope.totalAmount = $scope.tempAmount + value.amount
			// }
			

		});
	}

	function CalculateGERDetail()
	{
		if($scope.formStatusCurrent == 'NEW')
		{

			$scope.totalAmount = 0;
			$scope.dueAmount = 0;
			$scope.nettAmount = 0;
			$scope.convertednettAmount = 0;

			vm.listDescription.forEach(function(value) {

				$scope.totalAmount = value.originalAmount == null  ? parseFloat($scope.totalAmount) + 0 : value.originalAmount == '' ? parseFloat($scope.totalAmount) + 0 : parseFloat($scope.totalAmount) + parseFloat(value.originalAmount);

			});

			$scope.dueAmount = $scope.advanceAmount == null  ? parseFloat($scope.totalAmount) - 0 : $scope.advanceAmount == '' ? 
			parseFloat($scope.totalAmount) - 0 : parseFloat($scope.totalAmount) - parseFloat($scope.advanceAmount);

			$scope.tempTotalPrePaidCreditCard = $scope.totalPrePaidCreditCard == null ? 0 : $scope.totalPrePaidCreditCard == '' ? 0 : isNaN($scope.totalPrePaidCreditCard) ? 0 : parseFloat($scope.totalPrePaidCreditCard);
			$scope.tempTotalPrePaidExpenses = $scope.totalPrePaidExpenses == null ? 0 : $scope.totalPrePaidExpenses == '' ? 0 : isNaN($scope.totalPrePaidExpenses) ? 0 : parseFloat($scope.totalPrePaidExpenses);

			$scope.dueAmount = parseFloat($scope.dueAmount)
			- parseFloat($scope.tempTotalPrePaidCreditCard)
			- parseFloat($scope.tempTotalPrePaidExpenses);

			//$scope.nettAmount = $scope.taxAmount == null  ? parseFloat($scope.dueAmount) - 0 : $scope.taxAmount == '' ? parseFloat($scope.dueAmount) - 0 : parseFloat($scope.dueAmount) - parseFloat($scope.taxAmount);
			$scope.nettAmount = $scope.dueAmount;
			//$scope.convertednettAmount = $scope.taxAmount == null  ? (parseFloat($scope.exRateModelHeader)*parseFloat($scope.dueAmount)) - 0 : $scope.taxAmount == '' ? (parseFloat($scope.exRateModelHeader)*parseFloat($scope.dueAmount)) - 0 : (parseFloat($scope.exRateModelHeader)*parseFloat($scope.dueAmount)) - parseFloat($scope.taxAmount);
			$scope.convertednettAmount = (parseFloat($scope.exRateModelHeader)*parseFloat($scope.dueAmount));

		}
		else
		{
			$scope.convertednettAmount = parseFloat($scope.nettAmount) * parseFloat($scope.exRateModelHeader);
		}

	}
	
	function att2Add(no) {
        return {
            no: no,
            attName: '',
            remarks: ''
        };
    }
    
    // function modifyDetails(index) {
    //     vm.details.splice(index, 1, angular.copy(vm.details2Add));
    //     vm.details2Add = details2Add(vm.details2Add.no + 1);
	// }
	
    function removeDetails(index) {
		vm.listDescription.splice(index, 1);
		CalculateGERDetail();
	}

	$scope.removeListNo = function(index) {
		vm.ListNoID.splice(index, 1);
		CalculateTotal();
	}
	
	function removeAtts(index,seqNum) {

		transGERService.deleteGERAttachment({companyid:localStorageService.get('CO_ID_VALUE'),formNum:localStorageService.get('GERNO_MAINTEN')
		,SeqNum:seqNum}).then(function (results) {

		},function (error) {
			toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
		});	

        vm.attList.splice(index, 1);
	}
	

	function viewAtts(seqNum) {



		transGERService.getGERAttachmentFile({companyid:localStorageService.get('CO_ID_VALUE'),skey1:localStorageService.get('GERNO_MAINTEN')
		,skey2:seqNum}).then(function (results) {

			if(results.message != 'SUCCESS')
			{
				toaster.pop({ type: 'error', body: results.result, toasterId: 20 });
			}else
			{
				var sliceSize = 512;

				var byteCharacters = atob(results.bfile64);
				var byteArrays = [];

				for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
					var slice = byteCharacters.slice(offset, offset + sliceSize);

					var byteNumbers = new Array(slice.length);
					for (var i = 0; i < slice.length; i++) {
					byteNumbers[i] = slice.charCodeAt(i);
					}

					var byteArray = new Uint8Array(byteNumbers);

					byteArrays.push(byteArray);
				}

				var blob = new Blob(byteArrays, {type: results.mmType});

				if (window.navigator && window.navigator.msSaveOrOpenBlob) {
					window.navigator.msSaveOrOpenBlob(blob);
				}
				else {
					var fileURL = URL.createObjectURL(blob);
					window.open(fileURL, "EPrescription");
				}
	
			}

			
		
		}, function (error) {
			toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
		});	
		

		

    }

	
	$scope.toggleTransactionType = function () {
		$scope.edit = !$scope.edit;

	};

	$scope.toggleChargeTo = function () {
		$scope.editChargeTo = !$scope.editChargeTo;
	};

	$scope.toggleListNoID = function () {
		$scope.editLisNoID = !$scope.editLisNoID;
	};
	
	$scope.toggleSegCode = function () {
		$scope.editSegCode = !$scope.editSegCode;
	};

	$scope.toggleAccountCode = function () {
		$scope.editAccountCode = !$scope.editAccountCode;
	};

	$scope.openGERDetailEditModal = function (
		flagDisableEdit,
		parameterCompany,
		parameterFormNo,
		indexFilter,
		parameterNo,
		parameterDescription,
		parametercostCenter,
		parameterCOA,
		parameterAmount,
		parameterisSyaFlag,
		parameterSegCode,
		parameterCertificateNo,
		parameterPolicyNo) {

		$scope.tempEditGERDetail_globalCodeTypeTransaction =	$scope.globalCodeTypeTransaction
		$scope.tempEditGERDetail_Company = parameterCompany;
		$scope.tempEditGERDetail_FormNo = parameterFormNo;
		$scope.tempEditGERDetail_indexFilter = indexFilter;
		$scope.tempEditGERDetail_No = parameterNo;
		$scope.tempEditGERDetail_Description = parameterDescription;
		$scope.tempEditGERDetail_CostCenter = parametercostCenter;
		$scope.tempEditGERDetail_COA = parameterCOA;
		$scope.tempEditGERDetail_Amount = parameterAmount;
		$scope.tempEditGERDetail_flagDisableEdit = flagDisableEdit;
		$scope.tempEditGERDetail_isSyaFlag = parameterisSyaFlag;
		$scope.tempEditGERDetail_SegCode = parameterSegCode;
		$scope.tempEditGERDetail_CertificateNo = parameterCertificateNo;
		$scope.tempEditGERDetail_PolicyNo = parameterPolicyNo;

		var modalInstance = $uibModal.open({
			templateUrl: 'views/GERDetailEditModal.html',
			scope: $scope,
			size: 'lg',
			controller: 'GERDetailEditModalCtrl as GERDetailEditModalObject',
			windowClass: 'app-modal-window',
			resolve: {
                loadPlugin: function ($ocLazyLoad) {
                    return $ocLazyLoad.load([
                        {
                            name: 'snaps',
                            files: ['js/controllers/controllerGERDetailEditModal.js']
                        },
                        {
                            name: 'dynamicNumber',
                            files: ['js/plugins/angular-dynamic-number/dynamic-number.min.js']
                        }
                    ]);
                }
				}
		});

		modalInstance.result.then(function(resultVariable) {
			//vm.listDescription.splice(index, indexFilter, angular.copy(resultVariable));
			vm.listDescription[indexFilter] = resultVariable;
			CalculateGERDetail();
		});
	};

	/*

	Name	: RS
	Date	: 5 September 2018
	Change	: Beneficiary Name

	*/

	$scope.openBeneficiaryListViewModal = function () {

		$scope.tempOpenBeneficiary = $scope.departModelHeader;

		var modalInstance = $uibModal.open({
			templateUrl: 'views/beneficiaryListView.html',
			scope: $scope,
			//windowClass: 'customBeneficiaryModal',
			size: 'lg',
			controller: 'GERBeneficiaryListViewModalCtrl as GERBeneficiaryListViewModalObject',
			resolve: {
                loadPlugin: function ($ocLazyLoad) {
                    return $ocLazyLoad.load([
                        {
                            name: 'snaps',
                            files: ['js/controllers/controllerGERBeneficiaryListView.js']
                        },
						{
                            insertBefore: '#loadBefore',
                            files: ['js/bootstrap/bootstrap-select.js']
                        }
                    ]);
                }
				}
		});

		modalInstance.result.then(function(resultVariable) {
			
			vm.beneficiaryName_Value = resultVariable.beneficiaryName;

			$scope.benBranchModel = resultVariable.beneficiary_Bank_Branch;
			$scope.benTypeModel = resultVariable.beneficiaryTypeCode;
			$scope.benBankModel = resultVariable.beneficiaryBankCode;
			$scope.benBankAccModel = resultVariable.beneficiary_Bank_Account;
			$scope.benTransTypeModel = resultVariable.beneficiaryTranTypeCode;

			$scope.benresidentModel = resultVariable.beneficiaryResidenStatusCode;
			$scope.bencityModel = resultVariable.beneficiary_Bank_City;
			$scope.benEmailModel = resultVariable.beneficiary_Email;

		});

	};


	$scope.openPrintModal = function () {

		if(vm.listDescription.length == 0)
		{
            toaster.pop({ type: 'error', body: 'Minimum GER has 1 detail !', toasterId: 20 });
			return;
		}

		if($scope.subjectModel == undefined || $scope.subjectModel == '')
		{
            toaster.pop({ type: 'error', body: 'please pick Subject !', toasterId: 20 });
			return;
		}

		if($scope.paidModel == undefined || $scope.paidModel == '')
		{
            toaster.pop({ type: 'error', body: 'please pick Paid By !', toasterId: 20 });
			return;
		}

		if(vm.beneficiaryName_Value == undefined || vm.beneficiaryName_Value == '')
		{
            toaster.pop({ type: 'error', body: 'please pick Beneficiary Name !', toasterId: 20 });
			return;
		}

		if($scope.benTypeModel == undefined || $scope.benTypeModel == '')
		{
            toaster.pop({ type: 'error', body: 'please Beneficiary Type !', toasterId: 20 });
			return;
		}

		if($scope.benBankModel == undefined || $scope.benBankModel == '')
		{
            toaster.pop({ type: 'error', body: 'please pick Beneficiary Bank !', toasterId: 20 });
			return;
		}

		if($scope.benBankModel == undefined || $scope.benBankModel == '')
		{
            toaster.pop({ type: 'error', body: 'please pick Beneficiary Bank !', toasterId: 20 });
			return;
		}

		if($scope.benBankAccModel == undefined || $scope.benBankAccModel == '')
		{
            toaster.pop({ type: 'error', body: 'please fill Beneficiary Bank Acc. Number !', toasterId: 20 });
			return;
		}

		if($scope.benTransTypeModel == undefined || $scope.benTransTypeModel == '')
		{
            toaster.pop({ type: 'error', body: 'please pick Transaction Type !', toasterId: 20 });
			return;
		}
		
		if($scope.benresidentModel == undefined || $scope.benresidentModel == '')
		{
            toaster.pop({ type: 'error', body: 'please pick Resident Status !', toasterId: 20 });
			return;
		}

		SweetAlert.swal({
			title: "Print GER",
			text: "Do you want Print ?",
			type: "warning",
			showCancelButton: true,
			confirmButtonColor: "#DD6B55",
			confirmButtonText: "Yes",
			cancelButtonText: "No",
			closeOnConfirm: true,
			closeOnCancel: false,
			showLoaderOnConfirm: true },
		function (isConfirm) {

			if (isConfirm) {

				transGERService.checkPrintFunction({companyid:localStorageService.get('CO_ID_VALUE'),skey1:localStorageService.get('GERNO_MAINTEN'),skey2:localStorageService.get('USERID_VALUE')}).then(function (results) {

					if(results.returnValue == 'NOT')
					{
						toaster.pop({ type: 'error', body: results.returnDescription, toasterId: 20 });
						return;
					}

					refreshGERMaintenance();

					// var modalInstance = $uibModal.open({
					// 	templateUrl: 'views/printModal.html',
					// 	size: 'lg',
					// 	controller: 'printModalCtrl as printModalObject',
					// 	resolve: {
					// 		loadPlugin: function ($ocLazyLoad) {
					// 			return $ocLazyLoad.load([
					// 				{
					// 					name: 'snaps',
					// 					files: ['js/controllers/controllerPrintModal.js']
					// 				}
					// 			]);
					// 		}
					// 		}
					// });

					$scope.paramRPT = "skey1=" + $scope.fnumberModelHeader + "&Companyid=" + localStorageService.get('CO_ID_VALUE');

					if($scope.reportVal.ent == false) {
						var dt = {
							"companyId": localStorageService.get('CO_ID_VALUE'),
							"skey1" : "GERLetter",
							"skey2": $scope.paramRPT,
							"skey3": $scope.fnumberModelHeader,
							"userid":localStorageService.get('USERID_VALUE')
						}

						$scope.dt1 = {
							"companyId": localStorageService.get('CO_ID_VALUE'),
							"skey1" : "EntertainmentLetter",
							"skey2": $scope.paramRPT,
							"skey3": $scope.fnumberModelHeader,
							"userid":localStorageService.get('USERID_VALUE')
						}

						//GetGenerateReport1(dt);
						transGERService.generateReport(dt).then(function(results) {
							debugger;
							results;
							var sliceSize = 512;
				
							var byteCharacters = atob(results.genReportDetail[0].imageByte);
							var byteArrays = [];
				
							for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
								var slice = byteCharacters.slice(offset, offset + sliceSize);
				
								var byteNumbers = new Array(slice.length);
								for (var i = 0; i < slice.length; i++) {
								byteNumbers[i] = slice.charCodeAt(i);
								}
				
								var byteArray = new Uint8Array(byteNumbers);
				
								byteArrays.push(byteArray);
							}
				
							var blob = new Blob(byteArrays, {type: results.genReportDetail[0].mmType});
				
							if (window.navigator && window.navigator.msSaveOrOpenBlob) {
								window.navigator.msSaveOrOpenBlob(blob);
							}
							else {
								var fileURL = URL.createObjectURL(blob);
								window.open(fileURL, "_blank");
								// var fileURL = URL.createObjectURL(blob);
								// window.open(results.genReportDetail[0].imageByte);
							}
							$scope.GetGenerateReport2($scope.dt1);
						});
						//GetGenerateReport(dt1);
					}
					else if($scope.reportVal.trv == false) {
						var dt = {
							"companyId": localStorageService.get('CO_ID_VALUE'),
							"skey1" : "TravelLetter",
							"skey2": $scope.paramRPT,
							"skey3": $scope.fnumberModelHeader,
							"userid":localStorageService.get('USERID_VALUE')
						}
						GetGenerateReport1(dt);
					}
					else {
						var dt = {
							"companyId": localStorageService.get('CO_ID_VALUE'),
							"skey1" : "GERLetter",
							"skey2": $scope.paramRPT,
							"skey3": $scope.fnumberModelHeader,
							"userid":localStorageService.get('USERID_VALUE')
						}
						GetGenerateReport1(dt);
					}

					// if($scope.policyBulk.length > 0 ) {
					// 	var dt3 = {
					// 		"companyId": localStorageService.get('CO_ID_VALUE'),
					// 		"skey1" : "SubGERDetail",
					// 		"skey2": paramRPT,
					// 		"skey3": $scope.fnumberModelHeader,
					// 		"userid":localStorageService.get('USERID_VALUE')
					// 	}
					// 	GetGenerateReport(dt3);
					// }
				}, function (error) {
					SweetAlert.swal("Failed", "Cancel Print", "error");
					toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
				});

			} 
			else {
				swal("Cancel", "Cancel Print", "error");
			}

		});
		
	};

	$scope.changeListNoID =  function(item) {
		if ($scope.nettAmount == 0) {
			toaster.pop({ type: 'error', body: 'please fill GER Detail !', toasterId: 20 });
			$scope.listNoID = "";
			return;
		}
		else {
			var ddt = {
				"skey1": item
			};
			transGERService.getSumListNoID(ddt).then(function(results) {
				if (results == 0)
				{
					toaster.pop({ type: 'error', body: 'List No ID not found !', toasterId: 20 });
					return;
				}
				else {
					if (results != $scope.nettAmount || $scope.nettAmount != results) {
						toaster.pop({ type: 'error', body: 'Please check net amount, amount GER Det not equal with amount List No iD  !', toasterId: 20 });
						$scope.listNoID = "";
						return;
					}
				}
			});
		}
	}

	function GetGenerateReport1(params) {
		transGERService.generateReport(params).then(function(results) {
			debugger;
			results;
			var sliceSize = 512;

			var byteCharacters = atob(results.genReportDetail[0].imageByte);
			var byteArrays = [];

			for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
				var slice = byteCharacters.slice(offset, offset + sliceSize);

				var byteNumbers = new Array(slice.length);
				for (var i = 0; i < slice.length; i++) {
				byteNumbers[i] = slice.charCodeAt(i);
				}

				var byteArray = new Uint8Array(byteNumbers);

				byteArrays.push(byteArray);
			}

			var blob = new Blob(byteArrays, {type: results.genReportDetail[0].mmType});

			if (window.navigator && window.navigator.msSaveOrOpenBlob) {
				window.navigator.msSaveOrOpenBlob(blob);
			}
			else {
				var fileURL = URL.createObjectURL(blob);
				window.open(fileURL, "_blank");
				// var fileURL = URL.createObjectURL(blob);
				// window.open(results.genReportDetail[0].imageByte);
			}

			if($scope.policyBulk.length > 0 ) {
				var dt3 = {
					"companyId": localStorageService.get('CO_ID_VALUE'),
					"skey1" : "SubGERDetail",
					"skey2": $scope.paramRPT,
					"skey3": $scope.fnumberModelHeader,
					"userid":localStorageService.get('USERID_VALUE')
				}
				$scope.GetGenerateReport3(dt3);
			}
		});
	};

	$scope.GetGenerateReport2 = function(params) {
		transGERService.generateReport(params).then(function(results) {
			debugger;
			results;
			var sliceSize = 512;

			var byteCharacters = atob(results.genReportDetail[0].imageByte);
			var byteArrays = [];

			for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
				var slice = byteCharacters.slice(offset, offset + sliceSize);

				var byteNumbers = new Array(slice.length);
				for (var i = 0; i < slice.length; i++) {
				byteNumbers[i] = slice.charCodeAt(i);
				}

				var byteArray = new Uint8Array(byteNumbers);

				byteArrays.push(byteArray);
			}

			var blob = new Blob(byteArrays, {type: results.genReportDetail[0].mmType});

			if (window.navigator && window.navigator.msSaveOrOpenBlob) {
				window.navigator.msSaveOrOpenBlob(blob);
			}
			else {
				var fileURL = URL.createObjectURL(blob);
				window.open(fileURL, "_blank");
				// var fileURL = URL.createObjectURL(blob);
				// window.open(results.genReportDetail[0].imageByte);
			}

			if($scope.policyBulk.length > 0 ) {
				var dt3 = {
					"companyId": localStorageService.get('CO_ID_VALUE'),
					"skey1" : "SubGERDetail",
					"skey2": $scope.paramRPT,
					"skey3": $scope.fnumberModelHeader,
					"userid":localStorageService.get('USERID_VALUE')
				}
				$scope.GetGenerateReport3(dt3);
			}
		});
	};

	$scope.GetGenerateReport3 = function(params) {
		transGERService.generateReport(params).then(function(results) {
			debugger;
			results;
			var sliceSize = 512;

			var byteCharacters = atob(results.genReportDetail[0].imageByte);
			var byteArrays = [];

			for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
				var slice = byteCharacters.slice(offset, offset + sliceSize);

				var byteNumbers = new Array(slice.length);
				for (var i = 0; i < slice.length; i++) {
				byteNumbers[i] = slice.charCodeAt(i);
				}

				var byteArray = new Uint8Array(byteNumbers);

				byteArrays.push(byteArray);
			}

			var blob = new Blob(byteArrays, {type: results.genReportDetail[0].mmType});

			if (window.navigator && window.navigator.msSaveOrOpenBlob) {
				window.navigator.msSaveOrOpenBlob(blob);
			}
			else {
				var fileURL = URL.createObjectURL(blob);
				window.open(fileURL, "_blank");
				// var fileURL = URL.createObjectURL(blob);
				// window.open(results.genReportDetail[0].imageByte);
			}
		});
	};

	$scope.total= 0;
	var data = '';
		for (var i = 0; i < data.length; i++) {
		$scope.total= $scope.total + data[i].originalAmount;
	   } 

	$scope.saveGER = function () {

		if(vm.listDescription.length == 0)
		{
            toaster.pop({ type: 'error', body: 'Minimum GER has 1 detail !', toasterId: 20 });
			return;
		}

		CalculateGERDetail();

		//-----------AJI---------------//
		if($scope.travelDetails2Add.trsTravel == undefined || $scope.travelDetails2Add.trsTravel == '')
		{
            toaster.pop({ type: 'error', body: 'Transport Mode Cannot Be Blank', toasterId: 20 });
			return;
		}

		if($scope.travelDetails2Add.travelMillage == undefined || $scope.travelDetails2Add.travelMillage == '')
		{
            toaster.pop({ type: 'error', body: 'Mileage Cannot Be Blank', toasterId: 20 });
			return;
		}
		//---------------------------------//

		if($scope.subjectModel == undefined || $scope.subjectModel == '')
		{
            toaster.pop({ type: 'error', body: 'please pick Subject !', toasterId: 20 });
			return;
		}

		if($scope.paidModel == undefined || $scope.paidModel == '')
		{
            toaster.pop({ type: 'error', body: 'please pick Paid By !', toasterId: 20 });
			return;
		}

		if(vm.beneficiaryName_Value == undefined || vm.beneficiaryName_Value == '')
		{
            toaster.pop({ type: 'error', body: 'please pick Beneficiary Name !', toasterId: 20 });
			return;
		}

		if($scope.benTypeModel == undefined || $scope.benTypeModel == '')
		{
            toaster.pop({ type: 'error', body: 'please Beneficiary Type !', toasterId: 20 });
			return;
		}

		if($scope.benBankModel == undefined || $scope.benBankModel == '')
		{
            toaster.pop({ type: 'error', body: 'please pick Beneficiary Bank !', toasterId: 20 });
			return;
		}

		if($scope.benBankModel == undefined || $scope.benBankModel == '')
		{
            toaster.pop({ type: 'error', body: 'please pick Beneficiary Bank !', toasterId: 20 });
			return;
		}

		if($scope.benBankAccModel == undefined || $scope.benBankAccModel == '')
		{
            toaster.pop({ type: 'error', body: 'please fill Beneficiary Bank Acc. Number !', toasterId: 20 });
			return;
		}

		if($scope.benTransTypeModel == undefined || $scope.benTransTypeModel == '')
		{
            toaster.pop({ type: 'error', body: 'please pick Transaction Type !', toasterId: 20 });
			return;
		}
		
		if($scope.benresidentModel == undefined || $scope.benresidentModel == '')
		{
            toaster.pop({ type: 'error', body: 'please pick Resident Status !', toasterId: 20 });
			return;
		}

		if($scope.payCatModel == undefined || $scope.payCatModel == '') {
			toaster.pop({ type: 'error', body: 'please pick Payment Category !', toasterId: 20 });
			return;
		}

		if($scope.transTypeModelHeader == 'MTF' && $scope.bulkFileInput1 == null && $scope.gerStatusModelHeader == 'NEW')
		{
				toaster.pop({ type: 'error', body: 'Please upload excel format !', toasterId: 20 });
				return;
		}

		if($scope.polRelated == true && ($filter('date')($scope.dob._d, 'yyyy-MM-dd') == undefined || $filter('date')($scope.dob._d, 'yyyy-MM-dd') == ''))
		{
			if ($scope.dob == undefined || $scope.dob == '') {
				toaster.pop({ type: 'error', body: 'please filled peye BOD !', toasterId: 20 });
				return;
			}
		}
		
		if($scope.polRelated == true && $scope.benBranchModel == '')
		{
			toaster.pop({ type: 'error', body: 'please filled Bank Branch !', toasterId: 20 });
			return;
		}


		if($scope.globalCodeTypeTransaction == 'TRAVLE')
		{

			if(vm.travelDetails.length == 0)
			{
				toaster.pop({ type: 'error', body: 'Minimum Travel detail has 1 transaction !', toasterId: 20 });
				return;
			}

			CalculateTravelGERDetail();

			if(vm.travelDetails2Add.travellerName == undefined || vm.travelDetails2Add.travellerName == '')
			{
				toaster.pop({ type: 'error', body: 'please filled Traveller Name !', toasterId: 20 });
				return;
			}

			if(startDateTravelTemp == undefined  || endDateTravelTemp == undefined || startDateTravelTemp == ''  || endDateTravelTemp == '' )
			{
				toaster.pop({ type: 'error', body: 'please pick Travel Date !', toasterId: 20 });
				return;
			}
			
			if(vm.travelDetails2Add.deptTravel == undefined || vm.travelDetails2Add.deptTravel == '')
			{
				toaster.pop({ type: 'error', body: 'please pick Department Travel !', toasterId: 20 });
				return;
			}

			if(vm.travelDetails2Add.destination == undefined || vm.travelDetails2Add.destination == '')
			{
				toaster.pop({ type: 'error', body: 'please filled Destination !', toasterId: 20 });
				return;
			}

			if(vm.travelDetails2Add.purpose == undefined || vm.travelDetails2Add.purpose == '')
			{
				toaster.pop({ type: 'error', body: 'please filled Purpose !', toasterId: 20 });
				return;
			}


		}
		else if($scope.globalCodeTypeTransaction == 'ENTREE')
		{
			if(vm.entDetails.length == 0)
			{
				toaster.pop({ type: 'error', body: 'Minimum Entertaiment detail has 1 transaction !', toasterId: 20 });
				return;
			}
		}
		
		
		if($scope.globalCodeTypeTransaction == 'POLICY')
		{
			var dataFill = 0;

			vm.listDescription.forEach(function(value) {

				if(value.coa != '' && value.coa != undefined)
				{
					dataFill++;
				}
	
			});

			if(dataFill == 0)
			{
				toaster.pop({ type: 'error', body: 'Minimum Account Code has 1 !', toasterId: 20 });
				return;
			}
		}
		else
		{
			var dataFill = 0,dataFill2 = 0;

			vm.listDescription.forEach(function(value) {

				if(value.coa != '' && value.coa != undefined)
				{
					dataFill++;
				}

				if(value.costCenter != '' && value.costCenter != undefined)
				{
					dataFill2++;
				}
	
			});

			if(dataFill == 0 || dataFill2 == 0)
			{
				toaster.pop({ type: 'error', body: 'Minimum Account Code and Charge To has 1 !', toasterId: 20 });
				return;
			}
		}

		SweetAlert.swal({
			title: "Save Data",
			text: "Do you want Save ?",
			type: "warning",
			showCancelButton: true,
			confirmButtonColor: "#DD6B55",
			confirmButtonText: "Yes",
			cancelButtonText: "No",
			closeOnConfirm: false,
			closeOnCancel: false,
			showLoaderOnConfirm: true },
		function (isConfirm) {
			if (isConfirm) {

				if(($scope.nettAmount <= 0 || $scope.convertednettAmount <= '0') && $scope.paidModel != 'Zero Payment')
				{
					toaster.pop({ type: 'error', body: 'Paid method can only Zero Payment !', toasterId: 20 });
					return;
				}
				else if(($scope.nettAmount > 0 || $scope.convertednettAmount > '0') && $scope.paidModel == 'Zero Payment')
				{
					toaster.pop({ type: 'error', body: 'Paid method cannot Zero Payment !', toasterId: 20 });
					return;
				}

				var data = {

					'subject': $scope.subjectModel,
					'paidBy' : $scope.paidModel,
					'BankName' : $scope.bankModel,
					'bankAccNumber' : $scope.bankAccModel,
					'beneficiaryName' : vm.beneficiaryName_Value,
					'beneficiaryTypeCd' : $scope.benTypeModel,
					'beneficiaryBankCode' : $scope.benBankModel,
					'beneficiaryBankAccount' : $scope.benBankAccModel,
					'beneficiaryBankBranch' : $scope.benBranchModel,
					'beneficiaryTranTypeCd' : $scope.benTransTypeModel,
					'beneficiaryAccountCurrency' : $scope.bencurrencyModel,
					'beneficiaryResidentStatusCd' : $scope.benresidentModel,
					'beneficiaryBankCity': $scope.bencityModel,
					'beneficiaryEmail': $scope.benEmailModel,
					'companyID':localStorageService.get('CO_ID_VALUE'),
					'processType': 'M',
					'formNum': $scope.fnumberModelHeader,
					'taxAmount': $scope.taxAmount == null  ? 0 : $scope.taxAmount == '' ? 0 : $scope.taxAmount,
					'nettAmount': $scope.nettAmount,
					'totalAmount':$scope.totalAmount,
					'advanceAmount':$scope.advanceAmount,
					'dueAmount': $scope.dueAmount,

					'travelDateFrom':$filter('date')(startDateTravelTemp, 'yyyy-MM-dd'),
					'travelDateUntil':$filter('date')(endDateTravelTemp, 'yyyy-MM-dd'),
					'travelTotalIDRAmount':$scope.totalTravelAmount,

					'travelCreditCardOAmount':vm.travelDetails2Add.prePaidCreditCard,
					'travelCreditCardOCurr':vm.travelDetails2Add.currencyTravel_CreditCard,
					'travelCreditCardExchangeRate':vm.travelDetails2Add.exchangeRateCreditCard,
					'travelCreditCardIDRAmount':$scope.totalPrePaidCreditCard,

					'travelPaidInCashOAmount':0,
					'travelPaidInCashOCurr':'IDR',
					'travelPaidInCashExchangeRate':1,
					'travelPaidInCashIDRAmount':0,

					'travelPrePaidOAmount':vm.travelDetails2Add.prePaidExpenses,
					'travelPrePaidOCurr':vm.travelDetails2Add.currencyTravel_PrePaidExpenses,
					'travelPrePaidExchangeRate':vm.travelDetails2Add.exchangeRatePrePaidExpenses,
					'travelPrePaidIDRAmount':$scope.totalPrePaidExpenses,

					'travelCashAdvanceNum':$scope.cashAdModelHeader == null ? '' : $scope.cashAdModelHeader,

					'travelCashAdvanceOAmount':$scope.advanceAmount,
					'travelCashAdvanceOCurr':'IDR',
					'travelCashAdvanceExchangeRate':'1',
					'travelCashAdvanceIDRAmount':$scope.advanceAmount,

					'travelDueAmountTravel':$scope.totalTravelAmount,

					'travelTravellerName':vm.travelDetails2Add.travellerName,
					'travelDepartment':vm.travelDetails2Add.deptTravel,
					'travelTripDestination':vm.travelDetails2Add.destination,
					'travelTripPurpose':vm.travelDetails2Add.purpose,
					'travelTransport': vm.travelDetails2Add.trsTravel,
					'travelMillage': vm.travelDetails2Add.travelMillage,
					'travelTravellerPosition':'',

					'enterTotalIDRAmount':$scope.getTotalEntOrigAmount(),
					'enterTotalDueAmount':$scope.dueFromEntertainment,

					'listTravelDetail': vm.travelDetails,
					'listEnterDetail': vm.entDetails,
					'payCat' : $scope.payCatModel,
					'payeeDOB' : $filter('date')($scope.dob._d, 'yyyy-MM-dd')

					
				}
				console.log(data);
		
				bsLoadingOverlayService.start({
					referenceId: 'overLay_GERMaintenance'
				});
		

				transGERService.checkBeneAffliationName({sKey1:vm.beneficiaryName_Value}).then(function(results){

					if(results.returnValue != '') {

						bsLoadingOverlayService.stop({
							referenceId: 'overLay_GERMaintenance'
						});
		
						SweetAlert.swal("Failed", "Cancel to Save", "error");
						toaster.pop({ type: 'error', body: results.returnDescription, toasterId: 20 });
						
						
					}
					else
					{
						transGERService.saveGERCARSummary(data).then(function(results){
							if(results.message == 'SUCCESS') {

								if ($scope.transTypeModelHeader == 'REINS') {
									transGERService.bulkListNoId({bulkListNoId : vm.ListNoID}).then(function(resultsListNoId) {

									}, function(error){
										//SweetAlert.swal("Failed", "Cancel to Save", "error");
										toaster.pop({ type: 'error', body: 'save list no id failed', toasterId: 20 });
									});
					
								}

								if($scope.transTypeModelHeader == 'MTF')
								{
									transGERService.SaveGERMTFDetail({formNum: $scope.fnumberModelHeader, userID : localStorageService.get('USERID_VALUE') ,companyID :localStorageService.get('CO_ID_VALUE'), bulkGERMTFDetail : $scope.bulkExcelCollection}).then(function(resultsListNoId) {
									}, function(error){
											//SweetAlert.swal("Failed", "Cancel to Save", "error");
											toaster.pop({ type: 'error', body: 'save list no id failed', toasterId: 20 });
									});
								}

								transGERService.gerDetailInsertBulk({bulkGERDetailData:vm.listDescription}).then(function (results3) {
				
				
									bsLoadingOverlayService.stop({
										referenceId: 'overLay_GERMaintenance'
									});
				
									refreshGERMaintenance();
									modifiedOff()
				
									swal("Success", "Save has been complete.", "success");
				
				
								}, function (error) {
									SweetAlert.swal("Failed", "Cancel to Save", "error");
									toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
								});
								
							}
							else
							{
								bsLoadingOverlayService.stop({
									referenceId: 'overLay_GERMaintenance'
								});
		
								SweetAlert.swal("Failed", "Cancel to Save", "error");
								toaster.pop({ type: 'error', body: results.invalidMessage, toasterId: 20 });
							}
							
							
						}, function (error){
							SweetAlert.swal("Failed", "Cancel to Save", "error");
							toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
						})
					}
					
				}, function (error){
					SweetAlert.swal("Failed", "Cancel to Save", "error");
					toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
				})


				//---
			

			} 
			else {
				swal("Cancel", "Cancel Save", "error");
			}
		});


		//------------

		

	};

	$scope.sendBankBookClick = function () {

		SweetAlert.swal({
			title: "Save Data",
			text: "Do you want Send Bank Book ?",
			type: "warning",
			showCancelButton: true,
			confirmButtonColor: "#DD6B55",
			confirmButtonText: "Yes",
			cancelButtonText: "No",
			closeOnConfirm: false,
			closeOnCancel: false,
			showLoaderOnConfirm: true },
		function (isConfirm) {
			if (isConfirm) {

				if ($scope.currencyModelHeader == "CAD" || $scope.currencyModelHeader == "HKD" || $scope.currencyModelHeader == "SGD") {
					$scope.currencyModelHeader = "USD";
				}
				
				var params = {
					companyid: localStorageService.get('CO_ID_VALUE'),
					paramtype: "SinglePayment",
					skey1: localStorageService.get('GERNO_MAINTEN'),
					skey2: $scope.bankModel,
					skey3: $scope.bankAccModel,
					skey4: $scope.currencyModelHeader,
					userid: localStorageService.get('USERID_VALUE'),
				}

				transService.processInternetBanking(params).then(function(results) {

					if(results.invalidMessage != "ERROR") {

						refreshGERMaintenance();
						SweetAlert.swal("Success", results.invalidMessage, "success");

					}
					else {

						SweetAlert.swal("Error", results.invalidMessage, "error");

					}

				}, function (error){
					SweetAlert.swal("Failed", "Cancel to Send Bank Book", "error");
					toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
				})

			

			} 
			else {
				swal("Cancel", "Cancel Send Bank Book", "error");
			}
		});


		//------------

		

	};

	$scope.showhide1 = function (flagOpen) {
		var ibox = angular.element(document).find('div.ibox.i1');
		var icon = angular.element(document).find('i.tg'); 

		if(flagOpen == true && icon[0].className == 'fa tg fa-plus')
		{
			return;
		}

		var content = angular.element(document).find('div.ibox-content.c1');
		content.slideToggle(200);
		// Toggle icon from up to down
		icon.toggleClass('fa-library_books').toggleClass('fa-plus');
		ibox.toggleClass('').toggleClass('border-bottom');
		$scope.timeout = function() {
			ibox.resize();
			ibox.find('[id^=map-]').resize();
		};

		commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_ChargeTo',OthersKey1:localStorageService.get('USERID_VALUE')}).then(function (results) {

			vm.CTList = results.comboValueList;
			
		}, function (error) {
			toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
		});
		
		commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_SegCode',OthersKey1:localStorageService.get('USERID_VALUE')}).then(function (results) {

			vm.SCList = results.comboValueList;
			
		}, function (error) {
			toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
		});

		commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_Account_Code',OthersKey1:localStorageService.get('GERNO_MAINTEN')}).then(function (results) {

			vm.ACList = results.comboValueList;
			
		}, function (error) {
			toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
		});
		
	};


	/* ==================start travel tab controller========================== */

	vm.TraveldtOptions = 
	DTOptionsBuilder
	.newOptions()
	.withPaginationType('full_numbers')
	.withOption('responsive', true)
	.withOption('searching', false).withOption('info', false);
	
	vm.TraveldtColumnDefs = [
		DTColumnDefBuilder.newColumnDef(0).notSortable(),
		DTColumnDefBuilder.newColumnDef(1).notSortable(),
		DTColumnDefBuilder.newColumnDef(2).notSortable(),
		DTColumnDefBuilder.newColumnDef(3).notSortable(),
		DTColumnDefBuilder.newColumnDef(4).notSortable(),
		DTColumnDefBuilder.newColumnDef(5).notSortable(),
		DTColumnDefBuilder.newColumnDef(6).notSortable(),
		DTColumnDefBuilder.newColumnDef(7).notSortable()
	];

	$scope.travelDetails2Add = function(no, typeOfExpenses, travelExpOriginalAmount, originalCurrency, travelExchangeRate) {
        return {

			travellerName:travellerName,
			deptTravel:deptTravel,
			trsTravel: trsTravel,
			travelMillage:travelMillage,
			destination:destination,
			purpose:purpose,

            no: no,
            typeOfExpenses: typeOfExpenses,
            travelExpOriginalAmount: travelExpOriginalAmount,
			originalCurrency: originalCurrency,
			travelExchangeRate: travelExchangeRate,
			
			typeExpenseTravel:typeExpenseTravel,
			currencyTravel:currencyTravel,
			originalCurrency:originalCurrency,

			prePaidCreditCard:prePaidCreditCard,
			prePaidExpenses:prePaidExpenses,
			currencyTravel_CreditCard:currencyTravel_CreditCard,
			currencyTravel_CashAdvance:currencyTravel_CashAdvance,
			currencyTravel_PrePaidExpenses:currencyTravel_PrePaidExpenses,
			exchangeRateCreditCard:exchangeRateCreditCard,
			exchangeRatePrePaidExpenses:exchangeRatePrePaidExpenses,
			exchangeRateCashAdvance:exchangeRateCashAdvance,
			exchangeValueAdvanceAmount:exchangeValueAdvanceAmount
        };
	};

	vm.CalculateTravelGERDetail = CalculateTravelGERDetail;
	vm.travelDetails = [];
	vm.travelDetails2Add = $scope.travelDetails2Add;
	vm.addTravelDetails = $scope.addTravelDetails;

	vm.removeTravelDetails = removeTravelDetails;

	function CalculateTravelGERDetail() {
		
		$scope.totalTravelAmount = 0;

		vm.travelDetails.forEach(function(value) {

			$scope.totalTravelAmount = parseFloat($scope.totalTravelAmount) + parseFloat(value.idrAmount);

		});

		if(vm.listDescription != undefined)
		{
			vm.listDescription[0]["originalAmount"] = 0;
			vm.listDescription[0]["originalAmount"] = parseFloat($scope.totalTravelAmount);
		}

		var tempPrePaidCreditCard = vm.travelDetails2Add.prePaidCreditCard == null ? 0 : vm.travelDetails2Add.prePaidCreditCard == '' ? 0 : isNaN(vm.travelDetails2Add.prePaidCreditCard) ? 0 : vm.travelDetails2Add.prePaidCreditCard;
		var tempPrePaidExpenses = vm.travelDetails2Add.prePaidExpenses == null ? 0 : vm.travelDetails2Add.prePaidExpenses == '' ? 0 : isNaN(vm.travelDetails2Add.prePaidExpenses) ? 0 : vm.travelDetails2Add.prePaidExpenses;

		var tempExchangeRateCreditCard = vm.travelDetails2Add.exchangeRateCreditCard == null ? 1 : vm.travelDetails2Add.exchangeRateCreditCard == '' ? 1 : isNaN(vm.travelDetails2Add.exchangeRateCreditCard) ? 1 : vm.travelDetails2Add.exchangeRateCreditCard;
		var tempExchangeRatePrePaidExpenses = vm.travelDetails2Add.exchangeRatePrePaidExpenses == null ? 1 : vm.travelDetails2Add.exchangeRatePrePaidExpenses == '' ? 1 : isNaN(vm.travelDetails2Add.exchangeRatePrePaidExpenses) ? 1 : vm.travelDetails2Add.exchangeRatePrePaidExpenses;

		$scope.totalPrePaidCreditCard = parseFloat(tempPrePaidCreditCard) * parseFloat(tempExchangeRateCreditCard);
		$scope.totalPrePaidExpenses = parseFloat(tempPrePaidExpenses) * parseFloat(tempExchangeRatePrePaidExpenses);

		$scope.totalTravelAmount = $scope.totalTravelAmount == null ? 0 : $scope.totalTravelAmount == '' ? 0 : isNaN($scope.totalTravelAmount) ? 0 : $scope.totalTravelAmount;

		$scope.totalTravelAmount = parseFloat($scope.totalTravelAmount) - 
		parseFloat($scope.totalPrePaidCreditCard) -
		parseFloat($scope.advanceAmount) - 
		parseFloat($scope.totalPrePaidExpenses);

		if(vm.listDescription != undefined)
		{
			CalculateGERDetail();
		}

	};

	function tabGERTravel() {

		$timeout(function(){
			$scope.$apply(function() {
				
				$('input[name="dateRange"]').daterangepicker({
					autoUpdateInput: false,
					locale: {
						cancelLabel: 'Clear',
						format: 'DD-MMM-YYYY'
					}
	
				},function(start, end, label) {
					//console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
					startDateTravelTemp = start.format('DD-MMM-YYYY');
					endDateTravelTemp = end.format('DD-MMM-YYYY');
				  }
			
				);
			
				$('input[name="dateRange"]').on('apply.daterangepicker', function(ev, picker) {
					$(this).val(picker.startDate.format('DD-MMM-YYYY') + ' - ' + picker.endDate.format('DD-MMM-YYYY'));
				});
			
				$('input[name="dateRange"]').on('cancel.daterangepicker', function(ev, picker) {
					$(this).val('');
					startDateTravelTemp = undefined;
					endDateTravelTemp = undefined;
				});
	
	
			
			});
		});

		$scope.totalTravelAmount = 0;
		vm.travelDetails2Add.exchangeValueAdvanceAmount = 0;
		vm.travelDetails2Add.exchangeRateCashAdvance = 1;

		vm.travelDetails2Add.prePaidExpenses = 0;
		vm.travelDetails2Add.prePaidCreditCard = 0;

		vm.travelDetails2Add.exchangeRateCreditCard = 1;
		vm.travelDetails2Add.exchangeRatePrePaidExpenses = 1;

		$scope.totalPrePaidCreditCard = 0;
		$scope.totalPrePaidExpenses = 0;

		transGERService.getTravelGERDetail({companyid:localStorageService.get('CO_ID_VALUE'),gerNo:localStorageService.get('GERNO_MAINTEN')}).then(function (results) {
	
			commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_department_travel'}).then(function (results1) {

				$scope.deptEditGER = results1.comboValueList;

				commonService.getComboValue({ companyid: localStorageService.get('CO_ID_VALUE'), TypeCombo: 'Combo_all_code',OthersKey1: 'TRANMODE' }).then(function (results10) {
					$scope.typeExpenseListTravell = results10.comboValueList;
				}, function (error) {
				});

				commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_all_code',OthersKey1:'EXPTP'}).then(function (results2) {

					$scope.typeExpenseListTravel = results2.comboValueList;

					vm.travelDetails2Add.travellerName = results.travellerName;

					if(results.dateFrom != undefined && results.dateFrom != '' && results.dateUntil != undefined && results.dateUntil != '')
					{

						$timeout(function(){
							$scope.$apply(function() {

								startDateTravelTemp = results.dateFrom;
								endDateTravelTemp = results.dateUntil;
								
								$('input[name="dateRange"]').daterangepicker({
									startDate: results.dateFrom, endDate: results.dateUntil,
									locale: {
										cancelLabel: 'Clear',
										format: 'DD-MMM-YYYY'
									}
					
								},function(start, end, label) {
									console.log("A new date selection was made: " + start.format('DD-MMM-YYYY') + ' to ' + end.format('DD-MMM-YYYY'));
									startDateTravelTemp = start.format('DD-MMM-YYYY');
									endDateTravelTemp = end.format('DD-MMM-YYYY');
								  }
							
								);
							
								$('input[name="dateRange"]').on('apply.daterangepicker', function(ev, picker) {
									$(this).val(picker.startDate.format('DD-MMM-YYYY') + ' - ' + picker.endDate.format('DD-MMM-YYYY'));
								});
							
								$('input[name="dateRange"]').on('cancel.daterangepicker', function(ev, picker) {
									$(this).val('');
									startDateTravelTemp = undefined;
									endDateTravelTemp = undefined;
								});
					
							
							});
						});

					}
					

					vm.travelDetails2Add.deptTravel = results.department;
					vm.travelDetails2Add.trsTravel = results.travelTransport;
					vm.travelDetails2Add.travelMillage = results.travelMillage;
					vm.travelDetails2Add.destination = results.tripDestination;
					vm.travelDetails2Add.purpose = results.tripPurpose;

					vm.travelDetails = results.listTravelGER;	

					vm.travelDetails2Add.prePaidCreditCard = results.creditCardOriginalAmount == null ? 0 : parseFloat(results.creditCardOriginalAmount);
					$scope.globalCurrencyTravel_CreditCard = results.creditCardOriginalCurrency;
					vm.travelDetails2Add.exchangeRateCreditCard = results.creditCardExchangeRate == null ? 1 : parseFloat(results.creditCardExchangeRate);
					$scope.totalPrePaidCreditCard = results.creditCardAmount == null ? 0 : parseFloat(results.creditCardAmount);
					
					vm.travelDetails2Add.exchangeValueAdvanceAmount = parseFloat($scope.advanceAmount);
					
					vm.travelDetails2Add.prePaidExpenses = results.prepaidOriginalAmount == null ? 0 : parseFloat(results.prepaidOriginalAmount);
					$scope.globalCurrencyTravel_PrePaidExpenses = results.prepaidOriginalCurrency;
					vm.travelDetails2Add.exchangeRatePrePaidExpenses = results.prepaidExchangeRate == null ? 1 : parseFloat(results.prepaidExchangeRate);
					$scope.totalPrePaidExpenses = results.prepaidAmount == null ? 0 : parseFloat(results.prepaidAmount);

					if (vm.travelDetails2Add.trsTravel == 'PSLCAR') {
						$scope.isDisabled = false;
					}

					$scope.getListCurrencyTravel();
					
					CalculateTravelGERDetail();
	
					$timeout(function(){
						$scope.$apply(function() {
							$('#comboTypeExpense').selectpicker('refresh'); 
							$('#deptTravel').selectpicker('refresh'); 
						});
					});
	
					
				}, function(error){
	
				});

			}, function(error){

			});

				
	
		}, function (error) {
			toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
		});
	
	};

	$scope.getListCurrencyTravel = function() {

		commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_currency_new_ger',OthersKey1:vm.travelDetails2Add.deptTravel}).then(function (results3) {

			$scope.currencyRateTravelList = results3.comboValueList;

			vm.travelDetails2Add.currencyTravel_CashAdvance = "IDR";
			vm.travelDetails2Add.currencyTravel_CreditCard = $scope.globalCurrencyTravel_CreditCard == null ? 'IDR' : $scope.globalCurrencyTravel_CreditCard == '' ? 'IDR' : $scope.globalCurrencyTravel_CreditCard;
			vm.travelDetails2Add.currencyTravel_PrePaidExpenses = $scope.globalCurrencyTravel_PrePaidExpenses == null ? 'IDR' : $scope.globalCurrencyTravel_PrePaidExpenses == '' ? 'IDR' : $scope.globalCurrencyTravel_PrePaidExpenses;
			

			$timeout(function(){
				$scope.$apply(function() {
					$('#currencyTravel').selectpicker('refresh'); 
					$('#currencyTravel_CreditCard').selectpicker('refresh'); 
					$('#currencyTravel_CashAdvance').selectpicker('refresh'); 
					$('#currencyTravel_PrePaidExpenses').selectpicker('refresh'); 
				});
			});

		}, function(error){
		
		});


	};
	  

	$scope.addTravelDetails = function() {

		if(vm.travelDetails2Add.typeExpenseTravel == undefined || vm.travelDetails2Add.typeExpenseTravel == '')
		{
            toaster.pop({ type: 'error', body: 'please pick Type Expenses !', toasterId: 20 });
			return;
		}

		if(vm.travelDetails2Add.currencyTravel == undefined || vm.travelDetails2Add.currencyTravel == '')
		{
            toaster.pop({ type: 'error', body: 'please pick Currency Travel !', toasterId: 20 });
			return;
		}

		var expensesFlag = false;

		vm.travelDetails.forEach(function(value) {

			if(value.typeOfExpenses == vm.travelDetails2Add.typeExpenseTravel)
			{
				expensesFlag = true;
				return true;
			}

		});

		if(expensesFlag)
		{
			toaster.pop({ type: 'error', body: "That Expenses already Exists !", toasterId: 20 });
			return;
		}

		var lastSeqNum = 0;
		
		if(vm.travelDetails == undefined || vm.travelDetails == null || vm.travelDetails.length == 0)
		{
			vm.travelDetails = [];
		}
		else
		{
			lastSeqNum = parseFloat(customMinimum(vm.travelDetails,'seqNum')) + 1;
		}
		
		var lastNomor = parseFloat(customMinimum(vm.travelDetails, 'nomor')) + 1;
		var tempTravelExpOriginalAmount = vm.travelDetails2Add.travelExpOriginalAmount == null ? 0 : vm.travelDetails2Add.travelExpOriginalAmount == '' ? 0 : isNaN(vm.travelDetails2Add.travelExpOriginalAmount) ? 0 : vm.travelDetails2Add.travelExpOriginalAmount;
		var tempExchangeRateTravel = vm.travelDetails2Add.exchangeRateTravel == null ? 1 : vm.travelDetails2Add.exchangeRateTravel == '' ? 1 : isNaN(vm.travelDetails2Add.exchangeRateTravel) ? 1 : vm.travelDetails2Add.exchangeRateTravel;

		vm.travelDetails.push({
		typeOfExpenses : vm.travelDetails2Add.typeExpenseTravel,
		typeOfExpensesCode : vm.travelDetails2Add.typeExpenseTravel,
		originalAmount : tempTravelExpOriginalAmount,
		idrAmount : parseFloat(tempTravelExpOriginalAmount) * parseFloat(tempExchangeRateTravel),
		originalCurr : vm.travelDetails2Add.currencyTravel,
		exchangeRate: tempExchangeRateTravel,
		nomor : lastNomor,
		seqNum : lastSeqNum});

		CalculateTravelGERDetail();

		vm.travelDetails2Add.typeExpenseTravel = '';
		vm.travelDetails2Add.currencyTravel = '';
		vm.travelDetails2Add.exchangeRateTravel = '';
		vm.travelDetails2Add.travelExpOriginalAmount = '';

		//console.log(vm.details2Add);

	};

	$scope.openGERTravelDetailEditModal = function (
		indexFilter,
		parameterExchangeRate,
		parameterOriginalAmount,
		parameterOriginalCurrency,
		parameterTypeOfExpenses,
		parameterNomor) {

		$scope.tempEditGERTravelDetail_parameterExchangeRate = parameterExchangeRate;
		$scope.tempEditGERTravelDetail_parameterOriginalAmount = parameterOriginalAmount;
		$scope.tempEditGERTravelDetail_indexFilter = indexFilter;
		$scope.tempEditGERTravelDetail_parameterOriginalCurrency = parameterOriginalCurrency;
		$scope.tempEditGERTravelDetail_parameterTypeOfExpenses = parameterTypeOfExpenses;
		$scope.tempEditGERTravelDetail_parameterNomor = parameterNomor;

		var modalInstance = $uibModal.open({
			templateUrl: 'views/GERTravelDetailEditModal.html',
			scope: $scope,
			size: 'lg',
			controller: 'GERTravelDetailEditModalCtrl as GERTravelDetailEditModalObject',
			resolve: {
                loadPlugin: function ($ocLazyLoad) {
                    return $ocLazyLoad.load([
                        {
                            name: 'snaps',
                            files: ['js/controllers/controllerGERTravelDetailEditModal.js']
                        },
                        {
                            name: 'dynamicNumber',
                            files: ['js/plugins/angular-dynamic-number/dynamic-number.min.js']
                        }
                    ]);
                }
				}
		});

		modalInstance.result.then(function(resultVariable) {
			vm.travelDetails[indexFilter] = resultVariable;
			CalculateTravelGERDetail();
		});
	};
	
    function removeTravelDetails(index) {
		vm.travelDetails.splice(index, 1);

		var arrayLength = vm.travelDetails.length

		var lastNomor  = 1;

		for(arrayKey = 0 ; arrayKey < arrayLength ; arrayKey++)
		{
			vm.travelDetails[arrayKey].nomor = lastNomor;
			lastNomor = lastNomor + 1;
		}

		CalculateTravelGERDetail();
	}
	
	$scope.getTotalTravelExpense = function(){
		var total = 0;
		for(var i = 0; i < vm.travelDetails.length; i++){
			var item = vm.travelDetails[i];
			total += (item.travelExpOriginalAmount*item.travelExchangeRate*1);
		}
	return total;
	};	
	
	$scope.otherReason = function(param) {
		if (param == "Lain - Lain") {
			$scope.isOtherR = false;
			//vm.entDetails2Add.reason = param + ' (' + $scope.mReason + ')';
		}
		else {
			$scope.isOtherR = true;
		}
		$scope.full_Reason =  param;
	}

	$scope.otherTOE = function(param) {
		if (param == "Lain - Lain") {
			$scope.isTOE = false;
			//vm.entDetails2Add.typeOfEntertainment = param + ' (' + $scope.mtypeOfEntertainment + ')';
		}
		else {
			$scope.isTOE = true;
		}
		$scope.full_toe = param;
	}

	$scope.changeTOE = function(param) {
		$scope.desc_TOE = param;
		if (vm.entDetails2Add.typeOfEntertainment == 'Lain - Lain') {
			$scope.full_toe = vm.entDetails2Add.typeOfEntertainment + ' (' + param + ')';
		}
		else {
			$scope.full_toe = vm.entDetails2Add.typeOfEntertainment;
		}
		
	}

	$scope.changeReason = function(param) {
		$scope.desc_Reason = param;
		if (vm.entDetails2Add.reason == 'Lain - Lain') {
			$scope.full_Reason = vm.entDetails2Add.reason + ' (' + param + ')';
		}
		else {
			$scope.full_Reason = vm.entDetails2Add.reason;
		}
		
	}

	$scope.showhide2 = function (flagOpen) {
		var ibox = angular.element(document).find('div.ibox.i2');
		var icon = angular.element(document).find('i.tg2'); 

		if(flagOpen == true && icon[0].className == 'fa tg2 fa-plus')
		{
			return;
		}

		var content = angular.element(document).find('div.ibox-content.c2');
		content.slideToggle(200);
		// Toggle icon from up to down
		icon.toggleClass('fa-library_books').toggleClass('fa-plus');
		ibox.toggleClass('').toggleClass('border-bottom');
		$scope.timeout = function() {
			ibox.resize();
			ibox.find('[id^=map-]').resize();
		};

		vm.travelDetails2Add.typeExpenseTravel = '';
		vm.travelDetails2Add.currencyTravel = '';
		vm.travelDetails2Add.exchangeRateTravel = '';
		vm.travelDetails2Add.travelExpOriginalAmount = '';
	};
	
/* ==================end travel tab controller========================== */

/* ==================start entertainment tab controller========================== */

vm.EntdtOptions = DTOptionsBuilder.newOptions().withPaginationType('full_numbers')
.withOption('responsive', true).withOption('searching', false)
.withOption('info', false);

vm.EntdtColumnDefs = [
	DTColumnDefBuilder.newColumnDef(0).notSortable(),
	DTColumnDefBuilder.newColumnDef(1).notSortable(),
	DTColumnDefBuilder.newColumnDef(2).notSortable(),
	DTColumnDefBuilder.newColumnDef(3).notSortable(),
	DTColumnDefBuilder.newColumnDef(4).notSortable(),
	DTColumnDefBuilder.newColumnDef(5),
	DTColumnDefBuilder.newColumnDef(6).notSortable(),
	DTColumnDefBuilder.newColumnDef(7).notSortable(),
	DTColumnDefBuilder.newColumnDef(8).notSortable(),
	DTColumnDefBuilder.newColumnDef(9),
	DTColumnDefBuilder.newColumnDef(10).notSortable(),
	DTColumnDefBuilder.newColumnDef(11),
	DTColumnDefBuilder.newColumnDef(12),
	DTColumnDefBuilder.newColumnDef(13).notSortable()
];

$scope.entDetails2Add = function(no, receiver, providedName, companyName, title, 
	placeOfInvoice, typeOfCompany, typeOfEntertainment, reason, fullAddress, entOriginalAmount,dateRangEnter) {
	return {
		no: no,
		receiver: receiver,
		providedName: providedName,
		dateRangEnter:dateRangEnter,
		companyName: companyName,
		title: title,
		placeOfInvoice: placeOfInvoice,
		typeOfCompany: typeOfCompany,
		typeOfEntertainment: typeOfEntertainment,
		reason: reason,
		fullAddress: fullAddress,
		entOriginalAmount: entOriginalAmount
	};
};


vm.entDetails2Add = $scope.entDetails2Add;

vm.addEntDetails = $scope.addEntDetails;
vm.removeEntDetails = removeEntDetails;



function tabGEREntertainment() {

	$timeout(function(){
		$scope.$apply(function() {
			
			$('input[name="dateRangeEnter"]').daterangepicker({
				singleDatePicker: true,
				autoUpdateInput: false,
				locale: {
					format: 'DD-MMM-YYYY'
				}

			},function(start, label) {
				//console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
				startDateEnterTemp = start.format('DD-MMM-YYYY');
			  }
		
			);
		
			$('input[name="dateRangeEnter"]').on('apply.daterangepicker', function(ev, picker) {
				$(this).val(picker.startDate.format('DD-MMM-YYYY'));
			});
		
			$('input[name="dateRangeEnter"]').on('cancel.daterangepicker', function(ev, picker) {
				$(this).val('');
				startDateEnterTemp = undefined;
			});


		
		});
	});



	transGERService.getEntertainmentGERDetail({companyid:localStorageService.get('CO_ID_VALUE'),gerNo:localStorageService.get('GERNO_MAINTEN')}).then(function (results) {

		vm.entDetails = results.listEntertainmentGER;		
		$scope.titleEntertainmentList = results.comboTitleEntertainment;
		$scope.typeOfCompanyList = results.comboTypeCompany;
		$scope.typeOfEntertainment2 = results.comboTypeOfEntertaiment;
		$scope.comboReason = results.comboReason;

		$timeout(function(){
			$scope.$apply(function() {
				$('#titleEntertainment').selectpicker('refresh'); 
				$('#typeOfCompany').selectpicker('refresh'); 
			});
		});

	}, function (error) {
		toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
	});

};
    
	$scope.addEntDetails = function() {

		if(startDateEnterTemp== undefined || startDateEnterTemp == '')
		{
			toaster.pop({ type: 'error', body: 'please pick Entertaiment Date !', toasterId: 20 });
			return;
		}

		if(vm.entDetails2Add.receiver == undefined || vm.entDetails2Add.receiver == '')
		{
            toaster.pop({ type: 'error', body: 'please filled Receiver Entertaiment !', toasterId: 20 });
			return;
		}

		if(vm.entDetails2Add.providedName == undefined || vm.entDetails2Add.providedName == '')
		{
            toaster.pop({ type: 'error', body: 'please filled Provided Name Entertaiment !', toasterId: 20 });
			return;
		}

		if(vm.entDetails2Add.companyName == undefined || vm.entDetails2Add.companyName == '')
		{
            toaster.pop({ type: 'error', body: 'please filled Company Name !', toasterId: 20 });
			return;
		}

		if(vm.entDetails2Add.title == undefined || vm.entDetails2Add.title == '')
		{
            toaster.pop({ type: 'error', body: 'please pick Title Entertaiment !', toasterId: 20 });
			return;
		}

		if(vm.entDetails2Add.placeOfInvoice == undefined || vm.entDetails2Add.placeOfInvoice == '')
		{
            toaster.pop({ type: 'error', body: 'please filled Place of Invoice Entertaiment !', toasterId: 20 });
			return;
		}

		if(vm.entDetails2Add.typeOfCompany == undefined || vm.entDetails2Add.typeOfCompany == '')
		{
            toaster.pop({ type: 'error', body: 'please pick Type of Company Entertaiment !', toasterId: 20 });
			return;
		}

		if(vm.entDetails2Add.typeOfEntertainment == undefined || vm.entDetails2Add.typeOfEntertainment == '')
		{
            toaster.pop({ type: 'error', body: 'please filled Type of Entertainment !', toasterId: 20 });
			return;
		}

		if(vm.entDetails2Add.fullAddress == undefined || vm.entDetails2Add.fullAddress == '')
		{
            toaster.pop({ type: 'error', body: 'please filled Full Address !', toasterId: 20 });
			return;
		}

		if(vm.entDetails2Add.entOriginalAmount == undefined || vm.entDetails2Add.entOriginalAmount == '')
		{
            toaster.pop({ type: 'error', body: 'please filled Ent. Original Amount !', toasterId: 20 });
			return;
		}

	
		
		var lastSeqNum = 0;
		
		if(vm.entDetails == undefined || vm.entDetails == null || vm.entDetails.length == 0)
		{
			vm.entDetails = [];
		}
		else
		{
			lastSeqNum = parseFloat(customMinimum(vm.entDetails,'seqNum')) + 1;
		}
		
		var lastNomor = parseFloat(customMinimum(vm.entDetails, 'nomor')) + 1;
		var tempEntOriginalAmount = vm.entDetails2Add.entOriginalAmount == null ? 0 : vm.entDetails2Add.entOriginalAmount == '' ? 0 : vm.entDetails2Add.entOriginalAmount;

		vm.entDetails.push({
		companyNm : vm.entDetails2Add.companyName,
		//entertainmentType:vm.entDetails2Add.typeOfEntertainment,
		entertainmentTypeDesc: $scope.desc_TOE,
		entertainmentType:$scope.full_toe,
		entrDate: $filter('date')(startDateEnterTemp, 'dd-MMM-yyyy'),
		idrAmount:vm.entDetails2Add.entOriginalAmount,
		nomor:lastNomor,
		personNm: vm.entDetails2Add.receiver,
		place:vm.entDetails2Add.placeOfInvoice,
		providedNm:vm.entDetails2Add.providedName,
		//reason:vm.entDetails2Add.reason,
		reasonDesc: $scope.desc_Reason,
		reason:$scope.full_Reason,
		seqNum:lastSeqNum,
		title:vm.entDetails2Add.title,
		typeOfCompany:vm.entDetails2Add.typeOfCompany,
		fullAddress:vm.entDetails2Add.fullAddress

		});

		$timeout(function(){
			$scope.$apply(function() {
				
				$('input[name="dateRangeEnter"]').val('');
				startDateEnterTemp = undefined;

			
			});
		});

		vm.entDetails2Add.receiver = '';
		vm.entDetails2Add.providedName = '';
		vm.entDetails2Add.companyName = '';

		vm.entDetails2Add.title = '';
		vm.entDetails2Add.placeOfInvoice = '';
		vm.entDetails2Add.typeOfCompany = '';
		vm.entDetails2Add.typeOfEntertainment = '';

		vm.entDetails2Add.reason = '';
		vm.entDetails2Add.fullAddress = '';
		vm.entDetails2Add.entOriginalAmount = '';
		
		$scope.mReason = '';
		$scope.mtypeOfEntertainment = '';

		$scope.isTOE = true;
		$scope.isOtherR = true;


	};
	
	function modifyEntDetails(index) {
        vm.entDetails.splice(index, 1, angular.copy(vm.entDetails2Add));
        vm.entDetails2Add = entDetails2Add(vm.entDetails2Add.no + 1);
	}
	
	function removeEntDetails(index) {
		vm.entDetails.splice(index, 1);

		var arrayLength = vm.entDetails.length

		var lastNomor  = 1;

		for(arrayKey = 0 ; arrayKey < arrayLength ; arrayKey++)
		{
			vm.entDetails[arrayKey].nomor = lastNomor;
			lastNomor = lastNomor + 1;
		}


	}
	
	$scope.getTotalEntOrigAmount = function(){
		
		var totalEnt = 0;

		if($scope.globalCodeTypeTransaction == 'ENTREE')
		{
		
			vm.entDetails.forEach(function(value) {

				totalEnt = parseFloat(totalEnt) + parseFloat(value.idrAmount);

			});

			$scope.dueFromEntertainment = parseFloat(totalEnt) - parseFloat($scope.advanceAmount);

			if(vm.listDescription != undefined)
			{
				vm.listDescription[0]["originalAmount"] = totalEnt;
				CalculateGERDetail();
			}

		}

		return totalEnt;
		
	};	

	$scope.showhide3 = function (flagOpen) {
		var ibox = angular.element(document).find('div.ibox.i3');
		var icon = angular.element(document).find('i.tg3'); 

		if(flagOpen == true && icon[0].className == 'fa tg3 fa-plus')
		{
			return;
		}

		var content = angular.element(document).find('div.ibox-content.c3');
		content.slideToggle(200);
		// Toggle icon from up to down
		icon.toggleClass('fa-library_books').toggleClass('fa-plus');
		ibox.toggleClass('').toggleClass('border-bottom');
		$scope.timeout = function() {
			ibox.resize();
			ibox.find('[id^=map-]').resize();
		};

		$timeout(function(){
			$scope.$apply(function() {
				
				$('input[name="dateRangeEnter"]').val('');
				startDateEnterTemp = undefined;

			
			});
		});

		vm.entDetails2Add.receiver = '';
		vm.entDetails2Add.providedName = '';
		vm.entDetails2Add.companyName = '';

		vm.entDetails2Add.title = '';
		vm.entDetails2Add.placeOfInvoice = '';
		vm.entDetails2Add.typeOfCompany = '';
		vm.entDetails2Add.typeOfEntertainment = '';

		vm.entDetails2Add.reason = '';
		vm.entDetails2Add.fullAddress = '';
		vm.entDetails2Add.entOriginalAmount = '';
	};

	$scope.showhide4 = function(isOpen) {
		var ibox = angular.element(document).find('div.ibox.i1');
		var icon = angular.element(document).find('i.tg'); 

		if(isOpen == true && icon[0].className == 'fa tg fa-plus')
		{
			return;
		}

		var content = angular.element(document).find('div.ibox-content.c1');
		content.slideToggle(200);
		// Toggle icon from up to down
		icon.toggleClass('fa-library_books').toggleClass('fa-plus');
		ibox.toggleClass('').toggleClass('border-bottom');
		$scope.timeout = function() {
			ibox.resize();
			ibox.find('[id^=map-]').resize();
		};

		// commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'combo_ListNoId',OthersKey1:localStorageService.get('USERID_VALUE')}).then(function (results) {

		// 	vm.ListNoID = results.comboValueList;
			
		// }, function (error) {
		// 	toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
		// });

	}

	$scope.openGEREntreDetailEditModal = function (
		indexFilter,
		parameterNomor,
		parameterEntrDate,
		parameterProvidedNm,
		parameterPersonNm,
		parameterTitle,
		parameterCompanyNm,
		parameterTypeOfCompany,
		parameterEntertainmentType,
		parameterReason,
		parameterPlace,
		parameterFullAddress,
		parameterIDRAmount,
		parameterReasonDesc,
		parameterEnterDesc) {

		/*

		$index,item.entrDate,item.providedNm,item.personNm,
		item.title,item.companyNm,item.typeOfCompany,item.entertainmentType,item.reason,item.place,item.fullAddress,item.idrAmount
		*/

		$scope.tempEditGEREntreDetail_indexFilter = indexFilter;
		$scope.tempEditGEREntreDetail_parameterNomor = parameterNomor;
		$scope.tempEditGEREntreDetail_parameterEntrDate = parameterEntrDate;
		$scope.tempEditGEREntreDetail_parameterProvidedNm = parameterProvidedNm;
		$scope.tempEditGEREntreDetail_parameterPersonNm = parameterPersonNm;
		$scope.tempEditGEREntreDetail_parameterTitle = parameterTitle;
		$scope.tempEditGEREntreDetail_parameterCompanyNm = parameterCompanyNm;
		$scope.tempEditGEREntreDetail_parameterTypeOfCompany = parameterTypeOfCompany;
		$scope.tempEditGEREntreDetail_parameterEntertainmentType = parameterEntertainmentType;
		$scope.tempEditGEREntreDetail_parameterReason = parameterReason;
		$scope.tempEditGEREntreDetail_parameterReasonDesc = parameterReasonDesc;
		$scope.tempEditGEREntreDetail_parameterEnterDesc = parameterEnterDesc;
		$scope.tempEditGEREntreDetail_parameterPlace = parameterPlace;
		$scope.tempEditGEREntreDetail_parameterFullAddress = parameterFullAddress;
		$scope.tempEditGEREntreDetail_parameterIDRAmount = parameterIDRAmount;

		var modalInstance = $uibModal.open({
			templateUrl: 'views/GEREntreDetailEditModal.html',
			scope: $scope,
			size: 'lg',
			controller: 'GEREntreDetailEditModalCtrl as GEREntreDetailEditModalObject',
			resolve: {
                loadPlugin: function ($ocLazyLoad) {
                    return $ocLazyLoad.load([
                        {
                            name: 'snaps',
                            files: ['js/controllers/controllerGEREntreDetailEditModal.js']
                        },
                        {
                            name: 'dynamicNumber',
                            files: ['js/plugins/angular-dynamic-number/dynamic-number.min.js']
                        },
						{
                            files: ['js/plugins/jsDatepicker/daterangepicker.js']
						}
						,
						{
                            files: ['css/plugins/jsDatepicker/daterangepicker.css']
                        }
                    ]);
                }
				}
		});

		modalInstance.result.then(function(resultVariable) {
			vm.entDetails[indexFilter] = resultVariable;
		});
	};
	
/* ==================end entertainment tab controller========================== */

	// bsLoadingOverlayService.start({
	// 	referenceId: 'overLay_GERMaintenance'
	// });

	commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_transaction_Code',OthersKey1:localStorageService.get('DEPT_VALUE')}).then(function (results) {

		vm.TTList = results.comboValueList;
		
	}, function (error) {
		toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
	});
	
	commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_department_new_ger',OthersKey1:localStorageService.get('USERID_VALUE'),OthersKey2:'UPREP'}).then(function (results) {

		$scope.department = results.comboValueList;
		$timeout(function(){
			$scope.$apply();
        	$('#department').selectpicker('refresh'); 
		}
		);

		commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_CashAdvance',OthersKey1:localStorageService.get('DEPT_VALUE')}).then(function (results) {

			$scope.cashAdvanceNumber = results.comboValueList;
			$timeout(function(){
				$scope.$apply();
				$('#cashAdvanceNumber').selectpicker('refresh'); 
			}
			);

			commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_Policy',OthersKey1:'S1',OthersKey2:'RP'}).then(function (results) {

				$scope.policyNumber = results.comboValueList;
				$timeout(function(){
					$scope.$apply();
					$('#policyNumber').selectpicker('refresh'); 

					

					// bsLoadingOverlayService.stop({
					// 	referenceId: 'overLay_GERMaintenance'
					// });
				}
				);
				
		
				}, function (error) {
					toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
				});
				
		
			}, function (error) {
				toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
			});
			
	
		}, function (error) {
			toaster.pop({ type: 'error', body: error.error_description, toasterId: 20 });
		});
	

		/*
		Name 	: RS
		Date	: 26 September 2018
		Detail	: Function to Reject

		*/

		$scope.openRejectModal = function () {

			$scope.typeFormParameter = 'GER';

			var modalInstance = $uibModal.open({
				templateUrl: 'views/modalRejectForm.html',
				scope: $scope,
				size: 'lg',
				controller: 'modalRejectFormCtrl as modalRejectFormObject',
				resolve: {
					loadPlugin: function ($ocLazyLoad) {
						return $ocLazyLoad.load([
							{
								name: 'snaps',
								files: ['js/controllers/controllerModalRejectForm.js']
							},
							{
								files: ['js/plugins/sweetalert/sweetalert.min.js', 'css/plugins/sweetalert/sweetalert.css']
							},
							{
								name: 'oitozero.ngSweetAlert',
								files: ['js/plugins/sweetalert/angular-sweetalert.min.js']
							}
						]);
					}
					}
			});
	
			modalInstance.result.then(function(resultFlag) {

				if(resultFlag)
				{
					refreshGERMaintenance();
				}

			});
			
		};

	/*
		Name 	: RS
		Date	: 24 September 2018
		Detail	: Function to reload Policy Detail Bulk

	*/

	vm.dtInstance = {};
    
    $scope.dtColumns = [

		DTColumnBuilder.newColumn('mainGER').withTitle('Main GER No'),
		DTColumnBuilder.newColumn('subGER').withTitle('Sub GER No'),
		DTColumnBuilder.newColumn('policyNum').withTitle('Policy No'),
        DTColumnBuilder.newColumn('beneficiaryName').withTitle('Beneficiary Name'),
        DTColumnBuilder.newColumn('beneficiary_Bank_Name').withTitle('Beneficiary Bank'),
		DTColumnBuilder.newColumn('beneficiary_Bank_Account').withTitle('Ben. Bank Account'),
		
        DTColumnBuilder.newColumn('totalAmount').withTitle('Total Amount'),
        
    ];

    function createdRow(row, data, dataIndex) {
        $compile(angular.element(row).contents())($scope);
    }

    var ajaxCallback = function(data, callback, settings) {

                var serviceBase = APISettings.apiServiceBaseUri;

                $http.post(serviceBase + 'api/Trans/getPolicyBulkDetailListView', {PageNum:data.start,PageSize:data.length,Search:data.search.value,sortParam:data.order,companyID:localStorageService.get('CO_ID_VALUE'),formNum:localStorageService.get('GERNO_MAINTEN')} , { headers: { 'Content-Type': 'application/json' } }).success(function (results) {
            
                callback({
                        recordsTotal: results.totalRows,
                        recordsFiltered: results.totalFilter,
                        data: results.gerPolicyBulkDetailList
                    });
$scope.policyBulk = results.gerPolicyBulkDetailList;
                
            })
            .error(function (error, status) {
                toaster.error(error.error_description);
            });

        };

    $scope.dtOptions = DTOptionsBuilder
        .newOptions()
        .withOption('ajax', ajaxCallback)
        .withDataProp('data') // tried data aswell
        .withOption('processing', true)
        .withOption('serverSide', true)
        .withOption('paging', true)
        .withOption('stateSave', false)
        .withOption('lengthMenu', [10, 20, 50, 100 ])
        .withDisplayLength(10)
        .withPaginationType('full_numbers')
        .withOption('createdRow', createdRow)
        .withOption('responsive', true);

    


}

angular
    .module('snaps')
	.controller('gerMaintenanceCtrl', gerMaintenanceCtrl);

	