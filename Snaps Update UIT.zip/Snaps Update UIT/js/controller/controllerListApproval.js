function listApprovalCtrl(DTOptionsBuilder, DTColumnBuilder, DTColumnDefBuilder, transService, $http, $compile, $scope, $resource, $filter, $uibModal, localStorageService, commonService,$timeout, transService, Broadcaster) {
	var vm = this;
	var userId = localStorageService.get('USERID_VALUE');
	var userName = localStorageService.get('USERNM_VALUE');
	$scope.formLoc = userId +' - '+userName;
	$scope.listAppr = [];

	$scope.$on('return', function() {
		if (Broadcaster.data != null) {
			var item = Broadcaster.data;
			var inv = $filter('filter')($scope.listAppTableData, {formNum: item.FormNum}, true)[0];
			var p = item.data.split("#"); 
			inv.selectApprover = p[1];
			inv.codeApprover = p[0];
		}
	});

	
	$scope.$on('rejectOk', function() {
		// if (Broadcaster.data == null) {
			$scope.search();
		// }
	});


	commonService.getComboValue({ companyid: localStorageService.get('CO_ID_VALUE'), TypeCombo: 'TRXTYPEAPPR', OthersKey1: localStorageService.get('USERID_VALUE') }).then(function (results) {
		$scope.listTransType = results.comboValueList;
		if($scope.listTransType.length != 0) {
			$scope.listTransType.unshift({codeID:'0', descriptionID:'All Data', others1: '', others2:'', others3:'', others4:'',others5:''});
			$scope.transType = '0';
		}
        
        $timeout(function () {
	        $scope.$apply();
	        $('#transType').selectpicker('refresh');

	    }
		);
	}, function (error) {
		// toaster.error(error.error_description);
		window.location.href = "index.html#/login?menu=approval";
    });
	
	//vm.rowSelected = '';
    //vm.selected = {};
 	$scope.selected = {};
    vm.selectAll = false;
	
	// vm.listAppTableData = $resource('/json/listApproval.json').query();
	
	// $scope.listAppData = ["All", "Other"];
	$scope.listNextApprover = ["TAX", "Dcsdfg Adfgj"];
	//$scope.formLoc = "CA257 - Zdfssf Vxasfdgsf";
	
	
	//$scope.hideResultGrid = false;

	$scope.search = function () {
		//$scope.hideResultGrid = true;
		transService.getListApproval({ companyid: localStorageService.get('CO_ID_VALUE'),  skey1: localStorageService.get('USERID_VALUE'), skey2: $scope.transType == 0 ? '' : $scope.transType }).then(function(results) {
			$scope.listAppTableData = results.cListApprovalDetail;
			$scope.listAppr = $scope.listAppTableData;

			angular.forEach($scope.listAppr, function(dt) {
				dt.selected = false;
			});
		})
	};
	$scope.filterDisable = function () {
	    if ($scope.transType == undefined) {
	        return true;
	    }
	    else {
	        return false;
	    }
	};

	$scope.checkedApp = function (item) {
        //$scope.selectedGERNum = $filter('filter')($scope.appVal.listAppTableData, { checked: true });
		console.log('Test Checkbox');
		console.log(item);
		var dt = $filter('filter')($scope.listAppr, { formNum : item.formNum}, true);
		if(dt[0].selected == true) {
			dt[0].selected = false;
		}
		else if(dt[0].selected == false){
			dt[0].selected = true;
		}
    };
	$scope.appVal = {
    	listAppTableData: []
	};
	$scope.checkAll = function(checked) {
		if($scope.appVal.listAppTableData.length == 0 || checked) {
			$scope.appVal.listAppTableData = $scope.listAppTableData.map(function(item) { 
				var dt = $filter('filter')($scope.listAppr, { formNum : item.formNum}, true);
				if(dt[0].selected == true) {
					dt[0].selected = false;
				}
				else if(dt[0].selected == false){
					dt[0].selected = true;
				}
				return item.formNum; 
			});
		}
		else if (angular.element('#SelectAllRow').hasClass('ng-not-empty')) {
		$scope.appVal.listAppTableData = [];
		}
		else if($scope.appVal.listAppTableData.length >= 1) {
		$scope.appVal.listAppTableData = $scope.listAppTableData.map(function(item) { 
			var dt = $filter('filter')($scope.listAppr, { formNum : item.formNum}, true);
			if(dt[0].selected == true) {
				dt[0].selected = false;
			}
			else if(dt[0].selected == false){
				dt[0].selected = true;
			}
			return item.formNum; 
		});
		}
	};
	$scope.openRejectModal = function () {
		var dataReject = {
			companyId : localStorageService.get('CO_ID_VALUE'),
			userId : localStorageService.get('USERID_VALUE'),
			rejectReason : '',
			cListApprovalDetail : $filter('filter')($scope.listAppr, { selected : true}, true),
			appr: 0
		}
		console.log(dataReject);

		Broadcaster.broadcast('rejectModal', dataReject);

		var modalInstance = $uibModal.open({
			templateUrl: 'views/modalApprovalReject.html',
			size: 'md',
			controller: ModalRejectCtrlList
		});
	};
	$scope.editNextAppModal = function (codeAppr,selectappr, nxtAppr, trxCd, budgeted, dept, formNum) {
		var data = {
			CodeAppr : codeAppr+'#'+selectappr,
			NextAppr : nxtAppr,
			TrxCd : trxCd,
			Budgeted : budgeted,
			Department : dept,
			FormNum : formNum
		}

		Broadcaster.broadcast("dataEditApp", data);
		var modalInstance = $uibModal.open({
			templateUrl: 'views/modalEditNextApprover.html',
			size: 'md',
			controller: ModalInstanceCtrl
		});
	};
	$scope.viewFormDetail = function (item) {
//		Broadcaster.broadcast("GERNO", item);
		localStorageService.set('ListDetail', item);
		window.location.href = "index.html#/list/Approval/ApprovalDetail";
	};
	
	vm.listAppdtOptions = DTOptionsBuilder.newOptions()
        .withOption('responsive', false)
        .withOption('paging', true)
		.withOption('filter', false)
		.withOption('lengthchange', false);
        
	
	/*vm.listAppdtOptions = DTOptionsBuilder.newOptions()
        .withOption('scrollY', false)
        .withOption('scrollX', '100%')
        .withOption('scrollCollapse', false)
        .withOption('paging', true)
        .withFixedColumns({
            leftColumns: 2
        });*/
	
	vm.dtColumnDefs = [
        DTColumnDefBuilder.newColumnDef(0).notSortable(),
        DTColumnDefBuilder.newColumnDef(1),
        DTColumnDefBuilder.newColumnDef(2).notSortable(),
		DTColumnDefBuilder.newColumnDef(3).notSortable(),
        DTColumnDefBuilder.newColumnDef(4).notSortable(),
        DTColumnDefBuilder.newColumnDef(5),
		DTColumnDefBuilder.newColumnDef(6).notSortable(),
        DTColumnDefBuilder.newColumnDef(7).notSortable(),
        DTColumnDefBuilder.newColumnDef(8).notSortable(),
		DTColumnDefBuilder.newColumnDef(9).notSortable(),
        DTColumnDefBuilder.newColumnDef(10).notSortable(),
        DTColumnDefBuilder.newColumnDef(11).notSortable(),
		DTColumnDefBuilder.newColumnDef(12).notSortable(),
        DTColumnDefBuilder.newColumnDef(13).notSortable(),
        DTColumnDefBuilder.newColumnDef(14).notSortable(),
		DTColumnDefBuilder.newColumnDef(15).notSortable(),
        DTColumnDefBuilder.newColumnDef(16).notSortable(),
        DTColumnDefBuilder.newColumnDef(17).notSortable()
		// DTColumnDefBuilder.newColumnDef(18).notSortable()
    ];
	$scope.editAppr = {
		approver: 3
	};
	
	$scope.showAppr = function() {
		var selected = $filter('filter')($scope.listApprover, {value: $scope.editAppr.approver});
		return ($scope.editAppr.approver && selected.length) ? selected[0].text : 'Not set';
	};
	/* ==================start detail========================== */
	vm.details = $resource('/json/detailListGER.json').query();
	vm.apv = $resource('/json/listAPV.json').query();
	vm.detailFormNumdtOptions = DTOptionsBuilder.newOptions().withPaginationType('simple').withOption('responsive', true);
	vm.detailFormNumdtColumnDefs = [
        DTColumnDefBuilder.newColumnDef(0).notSortable(),
        DTColumnDefBuilder.newColumnDef(1),
        DTColumnDefBuilder.newColumnDef(2),
		DTColumnDefBuilder.newColumnDef(3),
		DTColumnDefBuilder.newColumnDef(4),
        DTColumnDefBuilder.newColumnDef(5).notSortable()
    ];
	$scope.getTotal = function(){
		var total = 0;
		for(var i = 0; i < vm.details.length; i++){
			var item = vm.details[i];
			total += (item.originalAmount*1);
		}
	return total;
	};
	$scope.checkboxModel = {value : 'YES'};
	/* ==================end detail========================== */
    $scope.ok = function () {
        $uibModalInstance.close();
    };

    $scope.cancel = function () {
		$uibModalInstance.dismiss('cancel');
	};

	$scope.DoApprove = function () {
		$scope.isProcessing = true; 

		var dataApprove = {
			companyId : localStorageService.get('CO_ID_VALUE'),
			userId : localStorageService.get('USERID_VALUE'),
			cListApprovalDetail : $filter('filter')($scope.listAppr, { selected : true}, true)
		}
		console.log(dataApprove);

		transService.approve(dataApprove).then(function(results) {
			results;
			$scope.isProcessing = false;
			$scope.search();
		}, function (error) {
			// 3. Jangan lupa set false juga jika terjadi error
			$scope.isProcessing = false;
		});
	}
}

function ModalInstanceCtrl ($scope, $uibModalInstance, Broadcaster, commonService, localStorageService, $timeout ) {
	$scope.params = Broadcaster.data;

	commonService.getComboValue({
		companyid: localStorageService.get('CO_ID_VALUE'), TypeCombo: 'Combo_next_approver', OthersKey1: $scope.params.Department
		, OthersKey2: $scope.params.TrxCd, OthersKey3: $scope.params.Budgeted == true ? 1 : 0 , OthersKey4: $scope.params.NextAppr//, OthersKey5: 0
	}).then(function (results) {

		if(results.comboValueList.length == 0) {
			$scope.approver = ''
			$scope.ListApprover = [{
				codeID : "",
				descriptionID : "",
				others1 : "",
				others2 : "",
				others3 : "",
				others4 : "",
				others5 : ""
			}];
		}
		else {
			$scope.apprName = $scope.params.CodeAppr;
			$scope.listApprover = results.comboValueList;
		}
		
		$timeout(function () {
			$scope.$apply();
			$('#appr').selectpicker('refresh');

		}
		);

	}, function (error) {
		toaster.error(error.error_description);
	});
	// $scope.listApprover = ["Abcd Efghij","Defg Hijklmn","Zklmnop Qrstu"];
    $scope.ok = function () {
		$uibModalInstance.close();
		var data = {
			FormNum : $scope.params.FormNum,
			data : $scope.apprName
		}
		Broadcaster.broadcast("return", data);
    };

    $scope.cancel = function () {
		$uibModalInstance.dismiss('cancel');
	};

}

function ModalRejectCtrlList ($scope, $uibModalInstance, Broadcaster, commonService, localStorageService, $timeout, transService ) {
	$scope.params = Broadcaster.data;

	
	// $scope.listApprover = ["Abcd Efghij","Defg Hijklmn","Zklmnop Qrstu"];
    $scope.ok = function () {
		if($scope.rejectR == undefined || $scope.rejectR == '') {
			toaster.error('Please fill Reject Reason');
		}
		else {
			//Broadcaster.broadcast("return", data);
			$scope.params.rejectReason = $scope.rejectR;
			transService.denyall($scope.params).then(function(results) {
				results;
				if($scope.params.appr == 1) {
					history.go(-1);
				}
				else {
					Broadcaster.broadcast("rejectOk", null);
				}
			});
			$uibModalInstance.close();
		}
    };

    $scope.cancel = function () {
		$uibModalInstance.dismiss('cancel');
	};

}
angular
    .module('snaps')
	.controller('listApprovalCtrl', listApprovalCtrl)
	.controller('ModalInstanceCtrl', ModalInstanceCtrl)
	.controller('ModalRejectCtrlList', ModalRejectCtrlList);

//function javaScriptCall(){
////angular.element(document.getElementById('divID')).scope().TestAngularMethod();
//
//	alert ('item checked');		
//}