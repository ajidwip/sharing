/**
 * New GER - controller
 * Contains Controller for Create NEW GER
 * Roby S - 5 June 2018
 */


function newGERCtrl ($rootScope,$q,APISettings,$scope, $timeout, commonService, $uibModal, transGERService, toaster, $resource, 
	DTOptionsBuilder, DTColumnDefBuilder, DTColumnBuilder, $filter, $http, localStorageService, bsLoadingOverlayService,SweetAlert) {

	var vm = this;
	vm.message = '';
	vm.reloadChangeTransactionCode = reloadChangeTransactionCode;

	var gerTypeTemp = 'S';


	vm.polNumDisable = true;
	vm.budgetValue = 'YES';

	$scope.dept = '';
	$scope.currency_option = '';
	vm.message_DESC = '';
	vm.cashAdvanceNumberSelect = '';
	$scope.dataChecked = false;
	$scope.bulkChecked = null;
	$scope.currencyRateDisabled = true;
	$scope.exchangeRateModel = '';
	$scope.policyNumberSelect = '';
	$scope.poNumber = '';
	$scope.clearDataExcel;
	$scope.detailExpenses = ''; 
	$scope.detExDisabled = true;

	vm.TTdtOptions = DTOptionsBuilder.newOptions().withPaginationType('full_numbers').withOption('rowCallback', $scope.rowCallback).withOption('bLengthChange', false).withOption('responsive', true);

	vm.TTdtColumnDefs = [
        DTColumnDefBuilder.newColumnDef(0).notSortable(),
        DTColumnDefBuilder.newColumnDef(1).notSortable(),
        DTColumnDefBuilder.newColumnDef(2).notSortable(),
		DTColumnDefBuilder.newColumnDef(3).notSortable(),
		DTColumnDefBuilder.newColumnDef(4).notSortable(),
		DTColumnDefBuilder.newColumnDef(5).notSortable()
	];

	commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'PaymentCategory'}).then(function (res) {
		//debugger;
		$scope.payCatList = res.comboValueList;
		$timeout(function(){
			$scope.$apply(function() {
					$('#payCatCombo').selectpicker('refresh'); 
			});
		});
	});
	//-----------------------AJI-----------------//
	commonService.getComboValue({ companyid: localStorageService.get('CO_ID_VALUE'), TypeCombo: 'DetailExpenses' }).then(function (res) {
		//debugger;
		$scope.DetExList = res.comboValueList;
		$timeout(function () {
			$scope.$apply(function () {
				$('#detailExpensesCombo').selectpicker('refresh');
			});
		});
	});
	//----------------------------------------//
	$("#transactionType_DESC").keydown(false);
		
	$scope.someClickHandler = function(item) {
		vm.message_DESC = item.descriptionID;
		vm.message_CODE = item.codeID;
		vm.message_POL = item.others1;
		if(item.others3 == 'YES') 
		{
			$scope.dataChecked = true;
			$scope.bulkChecked = null;
		}
		else if(item.others3 == 'NO')
		{
			$scope.dataChecked = false;
			$scope.bulkChecked = null;

			$scope.dataExcel = [];
			$scope.bulkFileInput = undefined;
		}

		if(vm.message_POL == 'NPOL')
		{
			vm.polNumDisable = true;
			vm.policyNumber_NoValue = '';

			$scope.cashAdvanceDisabled = false;
			$timeout(function(){
				$scope.$apply();
				$('#cashAdvanceNumber').selectpicker('refresh'); 
			}
			);

			
		}
		else
		{
			vm.polNumDisable = false;
		}

		$timeout(function(){
			$scope.$apply();
			$('#policyNumber').selectpicker('refresh'); 
		}
		);
		
		$scope.edit = false;
    };


	$scope.toggleTransactionType = function () {
		$scope.edit = !$scope.edit;

	};


	$scope.checkBulk = function (check) {
		
		if (check == '1') {
			gerTypeTemp = 'M';
			vm.policyNumber_NoValue = '';
			vm.polNumDisable = true;

			$scope.currency_option = 'IDR';
			NewGERCurrencyEXRate_Change();
			$scope.currencyComboDisabled = true;
			
			$timeout(function(){
				$scope.$apply();
				$('#currency').selectpicker('refresh'); 
			}
			);

		} else {
			gerTypeTemp = 'S';
			vm.polNumDisable = false;

			$scope.currencyComboDisabled = false;
			$timeout(function(){
				$scope.$apply();
				$('#currency').selectpicker('refresh'); 
			}
			);
		}

		$scope.dataExcel = [];
		$scope.bulkFileInput = undefined;

	};

	$scope.reloadBulkFile = function () {
    
		var resultbase64,resultFileName,resultFileNameType;

		var filetypes = $scope.bulkFileInput[0].filetype.split("/");
		resultbase64 = $scope.bulkFileInput[0].base64;
		resultFileName = $scope.bulkFileInput[0].filename;
		resultFileNameType = filetypes[1];

		var workbook = XLSX.read(resultbase64, {type: 'base64'});
		
		var data = XLSX.utils.sheet_to_json( workbook.Sheets[workbook.SheetNames[0]]);


		$scope.dataExcel = data;

		 $timeout( function(){

			   
			}, 1000);

		
	};

	$scope.clearDataExcel = function () {
    
		$scope.dataExcel = [];
		$scope.bulkFileInput = undefined;

	};

	$scope.saveNewGER = function () {
		if($scope.dept == undefined || $scope.dept == '')
		{
			toaster.pop({ type: 'error', body: 'please pick Department !', toasterId: 55 });
			return;
		}

		if($scope.currency_option == undefined || $scope.currency_option == '')
		{
			toaster.pop({ type: 'error', body: 'please pick Currency !', toasterId: 55 });
			return;
		}

		if($scope.exchangeRateModel == undefined || $scope.exchangeRateModel == '')
		{
			toaster.pop({ type: 'error', body: 'please fill Exchange Rate !', toasterId: 55 });
			return;
		}

		if(vm.message_DESC == undefined || vm.message_DESC == '')
		{
			toaster.pop({ type: 'error', body: 'please pick Transaction Type !', toasterId: 55 });
			return;
		}

		if($scope.bulkChecked == true && $scope.bulkFileInput == null)
		{
			toaster.pop({ type: 'error', body: 'please upload the bulk file !', toasterId: 55 });
			return;
		}

		if($scope.bulkChecked != true && $scope.bulkFileInput == null && vm.message_POL != 'NPOL' && (vm.policyNumber_NoValue == '' || vm.policyNumber_NoValue == undefined))
		{
			toaster.pop({ type: 'error', body: 'please pick Policy Number !', toasterId: 55 });
			return;
		}
		
		if($scope.payCatModel == undefined || $scope.payCatModel == '') {
			toaster.pop({ type: 'error', body: 'please pick Payment Category !', toasterId: 55 });
			return;
		}
		//----------AJI-----------//
		if ($scope.payCatModel == 'EX' && $scope.detailExpenses == '') {
			toaster.pop({ type: 'error', body: 'please pick Detail Expenses !', toasterId: 55 });
			return;
		}
		//------------------//

		if($scope.poNumber != null && $scope.poNumber != '' && $scope.poNumber != undefined)
		{
			transGERService.checkApplicationNumber({CompanyID:localStorageService.get('CO_ID_VALUE')
					,skey1:$scope.poNumber}).then(function (results) {

						if(results.resultFlag)
						{
							toaster.pop({ type: 'error', body: results.result, toasterId: 55 });
							SweetAlert.swal("Failed", "Cancel to Save", "error");
							return;
						}

			}, function (error) {
				toaster.pop({ type: 'error', body: error.error_description, toasterId: 55 });
			});

		}

		SweetAlert.swal({
				title: "Save Data",
				text: "Do you want Save ?",
				type: "warning",
				showCancelButton: true,
				confirmButtonColor: "#DD6B55",
				confirmButtonText: "Yes",
				cancelButtonText: "No",
				closeOnConfirm: false,
				closeOnCancel: false,
				showLoaderOnConfirm: true },
			function (isConfirm) {
				if (isConfirm) {

					var budgetedTemp;

					if(vm.budgetValue == 'YES')
					{
						budgetedTemp = true;
					}
					else{
						budgetedTemp = 	false;
					}

					var tempData = $scope.dataExcel;
					var bulkExcelCollection = [];

					if(tempData != undefined && tempData.length != 0)
					{
					
						tempData.forEach(function (h) {

							if (h['TransKey'] != undefined || h['Transkey'] != '' ) {
								gerTypeTemp = 'M';
							}

							bulkExcelCollection.push({
									UID:0,
									PolicyNo:h['Policy Number'],
									BName:h['Beneficiary Name'],
									BCode:h['Beneficiary Bank Code'],
									AccountNo:h['Account number'],
									OAmmount:h['Original amount'],
									TransKey:h['TransKey']}
							);

						});

					}


					transGERService.createGER2({CompanyID:localStorageService.get('CO_ID_VALUE')
					,GERType:gerTypeTemp == 'E' ? 'M' : gerTypeTemp,Currency:$scope.currency_option
					,ExchangeRate:$scope.exchangeRateModel,FromDept:$scope.dept
					,AdvanceFormNum:vm.cashAdvanceNumberSelect,TransactionCode:vm.message_CODE
					,PolRelated:vm.message_POL == "NPOL" ? false : true
					,PolicyNum:vm.policyNumber_NoValue,UserID:localStorageService.get('USERID_VALUE'),Budgeted:budgetedTemp,PONumber:$scope.poNumber
						, bulkFlagValue: gerTypeTemp, cBulkData: bulkExcelCollection, PayCat: $scope.payCatModel, DetEx: $scope.detailExpenses, AppNumber: $scope.appNumber
					}
					).then(function (results) {

						var tempVal1;
						var tempVal2;
						tempVal1 = results.returnValue;
						localStorageService.set('GERNO_MAINTEN', tempVal1);
						localStorageService.set('ROLESGER_MAINTEN', 'UPREP');

						if (results.message == "SUCCESS")
						{
							swal("Success", "Save has been complete.", "success");
							window.location.href = "index.html#/master/germaintenance";
						}
						else{
							SweetAlert.swal("Failed", "Cancel to Save", "error");
							toaster.pop({ type: 'error', body: results.result, toasterId: 55 });
						}

						

						// if (gerTypeTemp == 'M')
						// {

							// transGERService.createIDBulk().then(function (results2) {

							// 	tempVal2 = results2.returnValue;

							// 	var tempData = $scope.dataExcel;
							// 	var serviceBase = APISettings.apiServiceBaseUri;

							// 	var chain = $q.when();
							// 	var bulkExcelCollection = [];
								
							// 	tempData.forEach(function (h) {

							// 		bulkExcelCollection.push({
							// 				UID:tempVal2,
							// 				PolicyNo:h['Policy Number'],
							// 				BName:h['Beneficiary Name'],
							// 				BCode:h['Beneficiary Bank Code'],
							// 				AccountNo:h['Account number'],
							// 				OAmmount:h['Original amount']}
							// 		);


							// 	});

							// 	transGERService.insertBulkNewGER({cBulkData:bulkExcelCollection}).then(function (results3) {

							// 		transGERService.createSubGER({pCompanyID:localStorageService.get('CO_ID_VALUE'),pFormNum:tempVal1,pUploadID:tempVal2}).then(function (results4) {

							// 			swal("Success", "Save has been complete.", "success");
							// 			window.location.href = "index.html#/master/germaintenance";

					
							// 		}, function (error) {
							// 			SweetAlert.swal("Failed", "Cancel to Save", "error");
							// 			toaster.pop({ type: 'error', body: error.error_description, toasterId: 55 });
							// 		});

				
							// 	}, function (error) {
							// 		SweetAlert.swal("Failed", "Cancel to Save", "error");
							// 		toaster.pop({ type: 'error', body: error.error_description, toasterId: 55 });
							// 	});


							// }, function (error) {
							// 	SweetAlert.swal("Failed", "Cancel to Save", "error");
							// 	toaster.pop({ type: 'error', body: error.error_description, toasterId: 55 });
							// });

						// }
						// else
						// {
						// 	swal("Success", "Save has been complete.", "success");
						// 	window.location.href = "index.html#/master/germaintenance";
						// }

					}, function (error) {
						SweetAlert.swal("Failed", "Cancel to Save", "error");
						toaster.pop({ type: 'error', body: error.error_description, toasterId: 55 });
					});

				

			} 
			else {
				swal("Cancel", "Cancel Save", "error");
			}
		});

	};

	
	bsLoadingOverlayService.start({
		referenceId: 'newGEROverLay'
	});

	function reloadChangeTransactionCode() {

			commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_transaction_Code',OthersKey1:$scope.dept}).then(function (results) {

				vm.TTList = results.comboValueList;
				
			}, function (error) {
				toaster.pop({ type: 'error', body: error.error_description, toasterId: 55 });
			});

	}
	
	commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_department_new_ger',OthersKey1:localStorageService.get('USERID_VALUE'),OthersKey2:'UPREP'}).then(function (results) {

		$scope.department = results.comboValueList;
		$timeout(function(){
			$scope.$apply();
        	$('#department').selectpicker('refresh'); 
		}
		);

		commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_CashAdvance',OthersKey1:localStorageService.get('DEPT_VALUE')}).then(function (results) {

			$scope.cashAdvanceNumber = results.comboValueList;
			$scope.cashAdvanceDisabled = true;
			$timeout(function(){
				$scope.$apply();
				$('#cashAdvanceNumber').selectpicker('refresh'); 
			}
			);

			commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_Policy',OthersKey1:'S1',OthersKey2:'RP'}).then(function (results) {

				$scope.policyNumber = results.comboValueList;
				$timeout(function(){
					$scope.$apply();
					$('#policyNumber').selectpicker('refresh'); 

					

					bsLoadingOverlayService.stop({
						referenceId: 'newGEROverLay'
					});
				}
				);
				
		
				}, function (error) {
					toaster.pop({ type: 'error', body: error.error_description, toasterId: 55 });
				});
				
		
			}, function (error) {
				toaster.pop({ type: 'error', body: error.error_description, toasterId: 55 });
			});
			
	
		}, function (error) {
			toaster.pop({ type: 'error', body: error.error_description, toasterId: 55 });
		});
	
	vm.NewGERCurrency_Change = NewGERCurrency_Change;
	vm.NewGERCurrencyEXRate_Change = NewGERCurrencyEXRate_Change;

	function NewGERCurrency_Change()
	{
		commonService.getComboValue({companyid:localStorageService.get('CO_ID_VALUE'),TypeCombo:'Combo_currency_new_ger',OthersKey1:$scope.dept}).then(function (results) {

			$scope.currency = results.comboValueList;
			$timeout(function(){
				$scope.$apply();
				$('#currency').selectpicker('refresh'); 
			}
			);
	
		}, function (error) {
			toaster.pop({ type: 'error', body: error.error_description, toasterId: 55 });
		});
	}

	function NewGERCurrencyEXRate_Change()
	{
		if($scope.currency_option == 'IDR')
		{
			$scope.exchangeRateModel = '1';
			$scope.currencyRateDisabled = true;
		}
		else
		{
			$scope.exchangeRateModel = '1';
			$scope.currencyRateDisabled = false;
		}
		
	}

	$scope.openPolicyNoListViewModal = function () {

		var modalInstance = $uibModal.open({
			templateUrl: 'views/policyNumberListView.html',
			scope: $scope,
			size: 'lg',
			controller: 'GERPolicyListViewModalCtrl as GERPolicyListViewModalObject',
			resolve: {
                loadPlugin: function ($ocLazyLoad) {
                    return $ocLazyLoad.load([
                        {
                            name: 'snaps',
                            files: ['js/controllers/controllerGERPolicyListView.js']
                        },
						{
                            insertBefore: '#loadBefore',
                            files: ['js/bootstrap/bootstrap-select.js']
                        }
                    ]);
                }
				}
		});

		modalInstance.result.then(function(policy) {
			vm.policyNumber_NoValue = policy;
		});

	};

	$scope.openCARFilteristViewModal = function () {

		$scope.newGER_tempOpenDept = $scope.dept;

		var modalInstance = $uibModal.open({
			templateUrl: 'views/carFilterListView.html',
			scope: $scope,
			size: 'lg',
			controller: 'CARFilterComboListViewModalCtrl as CARFilterComboListViewModalObject',
			resolve: {
                loadPlugin: function ($ocLazyLoad) {
                    return $ocLazyLoad.load([
                        {
                            name: 'snaps',
                            files: ['js/controllers/controllerCARFilterListView.js']
                        },
						{
                            insertBefore: '#loadBefore',
                            files: ['js/bootstrap/bootstrap-select.js']
                        }
                    ]);
                }
				}
		});

		modalInstance.result.then(function(carNo) {
			vm.cashAdvanceNumberSelect = carNo;
		});

	};

	//--------------------AJI-------------------//
	$('#detailExpensesCombo').on('changed.bs.select', function (e, clickedIndex, isSelected, previousValue) {
		$scope.detailExpenses = $(this).val();
		$scope.$apply();
	});

	$scope.onPayCatChange = function () {
		if ($scope.payCatModel === 'EX') {
			$scope.detExDisabled = false;
		} else {
			$scope.detExDisabled = true;
			$scope.detailExpenses = ''; // Reset nilai jika bukan EX
		}

		$timeout(function () {
			$('#detailExpensesCombo').selectpicker('refresh');
		});
	};
	//---------------------------------------------//

}


angular
    .module('snaps')
	.controller('newGERCtrl', newGERCtrl);

	