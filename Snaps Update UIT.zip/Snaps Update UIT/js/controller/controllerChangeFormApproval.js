// (function(){
//     'use strict';
// changeFormApprovalCtrl.$inject = ['$uibModalInstance'];
    function changeFormApprovalCtrl($scope, DTColumnDefBuilder,DTOptionsBuilder, toaster, commonService, $timeout, localStorageService, transService, $filter, $uibModal, Broadcaster, SweetAlert) {
        var vm = this;
		
		$scope.checkVisble = true;
        $scope.btnVisble = true; 
        $scope.currApp = '';
        $scope.dept = '';
        $scope.listdepartment = [];
		
		vm.TTdtOptions = DTOptionsBuilder.newOptions().withPaginationType('full_numbers').withOption('rowCallback', $scope.rowCallback).withOption('bLengthChange', false).withOption('responsive', true);
		vm.dtOptionsBen = DTOptionsBuilder.newOptions().withOption('responsive', true).withOption('bPaginate', false).withOption('bFilter', false).withOption('bInfo', false).withOption('bProcessing', true);
		
		
		vm.TTdtColumnDefs = [
			DTColumnDefBuilder.newColumnDef(0).notSortable(),
			DTColumnDefBuilder.newColumnDef(1).notSortable(),
			DTColumnDefBuilder.newColumnDef(2).notSortable(),
			DTColumnDefBuilder.newColumnDef(3).notSortable(),
			DTColumnDefBuilder.newColumnDef(4).notSortable(),
			DTColumnDefBuilder.newColumnDef(5).notSortable()
		];
		
        commonService.getComboValue({ companyid: localStorageService.get('CO_ID_VALUE'), TypeCombo: 'Combo_current_apprv' }).then(function (results) {
            $scope.currAppList = results.comboValueList;

            $timeout(function () {
                $scope.$apply();
                $('#currApproval').selectpicker('refresh');
            }
            );
            $scope.statusTypeM = 'BNKTOABT';
        }, function (error) {
            toaster.error(error.error_description);
        });

        commonService.getComboValue({ companyid: localStorageService.get('CO_ID_VALUE'), TypeCombo: 'Combo_search_APR', OthersKey1: localStorageService.get('USERID_VALUE') }).then(function (results) {

            $scope.listsearch = results.comboValueList;
    
            $timeout(function () {
                $scope.$apply();
                $('#searchby').selectpicker('refresh');
    
            }
            );
    
    
        }, function (error) {
            toaster.error(error.error_description);
        });

        //--------------AJI-----------/
        $scope.DoChangeDepartment = function(item) {
            commonService.getComboValue({ companyid: localStorageService.get('CO_ID_VALUE'), TypeCombo: 'Combo_dept_current_apprv', OthersKey1: item }).then(function (results) {
                $scope.listdepartment = results.comboValueList;
                $scope.message_DESC = "";
                $scope.btnVisble = false;
                //$scope.listdepartment.unshift({codeID:'0', descriptionID:'All Department', others1: '', others2:'', others3:'', others4:'',others5:''});
        
                $timeout(function () {
                    $scope.$apply();
                    $('#dept').selectpicker('refresh');
                }
                );
                //$scope.DoFilter(); 
            }, function (error) {
                toaster.error(error.error_description);
            });
        }
        $scope.changeSearchValue = function(value) {
            $scope.searchValue = value;
            
            // UPDATE: Lakukan filter otomatis jika value diisi (misal min 3 karakter) 
            // atau jika value dihapus (kosong)
            if(value.length >= 3 || value.length == 0) {
                $scope.DoFilter();
            }
        }
        //--------------------------//

        $scope.DoChangeTranType = function(item) {
            commonService.getComboValue({ companyid: localStorageService.get('CO_ID_VALUE'), TypeCombo: 'Combo_transaction_Code', OthersKey1: item, OthersKey2:'GERCARCOMBOAPP'}).then(function (results) {
                $scope.TTList = results.comboValueList;
        
            }, function (error) {
                toaster.error(error.error_description);
            });
        }

        // function reloadChangeTransCode() {
        //     commonService.getComboValue({ companyid: localStorageService.get('CO_ID_VALUE'), TypeCombo: 'Combo_transaction_Code', OthersKey1: $scope.deptCode }).then(function (results) {
        //         vm.TTList = results.comboValueList;
        
        //     }, function (error) {
        //         toaster.error(error.error_description);
        //     });
        // }

        $scope.toggleTransactionType = function() {
            $scope.edit = !$scope.edit;
        }

        $scope.DoSelectTranType = function(item) {
            $scope.message_DESC = item.descriptionID;
            $scope.message_CODE = item.codeID;
            $scope.message_POL = item.others1;

            if (item.others3 == 'YES') {
                $scope.dataChecked = true;
            }
            else if (item.others3 == 'NO') {
                $scope.dataChecked = false;
            }
            $scope.edit = false;
            $scope.btnVisble = false;
        }
        //-------------AJI-------------//
        $scope.DoFilter = function() {
            if (!$scope.currApp) {
                return; 
            }

            var dt1 = ($scope.date && $scope.date.startDate) ? $filter('date')($scope.date.startDate._d, 'yyyy-MM-dd') : undefined;
            var dt2 = ($scope.date && $scope.date.endDate) ? $filter('date')($scope.date.endDate._d, 'yyyy-MM-dd') : undefined;

            var data = {
                companyid: localStorageService.get('CO_ID_VALUE'),
                skey1: $scope.currApp,
                skey2: $scope.dept || "", // Jika dept kosong, kirim string kosong
                skey3: $scope.message_CODE || "", // UPDATE: Sekarang boleh kosong (Transaction Type)
                skey4: $scope.searchFilter || "",
                skey5: $scope.searchValue || "",
                skey6: dt1,
                skey7: dt2
            };

            // Tampilkan loading overlay jika ada
            transService.getListSendToNewApprover(data).then(function(results) {
                $scope.changeformapprovallist = results.cSendToNewApproverDetail;
                $scope.checkVisble = false;
            }, function(error) {
                // Jangan tampilkan error jika hanya karena data memang belum ditemukan saat mengetik
                console.log(error.error_description);
            });
        }
        //-----------------------//

        $scope.DoChangeTime  = function(item) {
            var i = item;
        
        }

        $scope.DoEdit = function(item) {
            Broadcaster.broadcast('sendListItem', item);
            var modalInstance = $uibModal.open({
            	templateUrl: 'views/modalChangeFormApproval.html',
            	size: 'lg',
            	controller: 'modalChangeFormApprovalCtrl',
            	resolve: {
            		loadPlugin: function ($ocLazyLoad) {
            			return $ocLazyLoad.load([
            				{
            					name: 'snaps',
            					files: ['js/controllers/controllerModalChangeFormApproval.js']
                            },
                            {
                                name: 'snaps',
                                files: ['js/services/service.js']
                            }
            			]);
            		}
            		}
            });
        }

        $scope.$on('newAppr', function() {
            if (Broadcaster.data != null) {
                var item = Broadcaster.data;
                var inv = $filter('filter')($scope.changeformapprovallist, {formNum: $scope.listItem.formNum}, true)[0];
                inv.newApproval = item.newApproval;
                inv.ChangeReason = item.ChangeReason;
            }
        });

        $scope.DoSendToNewApproval = function() {
            $scope.SendNew = [];
            $scope.New = "";
            angular.forEach($scope.changeformapprovallist, function(item) {
                if(item.newApproval != '') {
                    $scope.SendNew.push(item.formNum+"|"+item.location+"|"+item.newApproval+"|"+item.ChangeReason)
                    $scope.New = $scope.SendNew.join("|");
                }
            });

            if($scope.New == "") {
                toaster.error("Select New Approval");
            }
            else {
                var dta = {
                    companyid: localStorageService.get('CO_ID_VALUE'),
                    paramtype: "ChangesApproval",
                    skey1: $scope.New,
                    userid: localStorageService.get('USERID_VALUE')
                }
                transService.sendNewApprover(dta).then(function(results) {
                    if(results.invalidMessage == "Berhasil") {
                        $scope.DoFilter();
                        SweetAlert.swal("Success", "Process Change Approval has been complete.", "success");
                    }
                }, function(error) {
                    toaster.error(error.error_description);
                });
                console.log($scope.New);
            }
        }
    }

    angular
        .module('snaps')
        .controller('changeFormApprovalCtrl', changeFormApprovalCtrl)
// })