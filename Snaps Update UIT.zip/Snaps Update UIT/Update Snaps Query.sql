------UR1-------

CREATE TABLE #TDCode (
    CompanyID VARCHAR(10),
    CodeType VARCHAR(50),
    CodeID VARCHAR(50),
    CodeName VARCHAR(50),
    CodeCategory VARCHAR(50),
    CodeSequence VARCHAR(50),
    IsSystemCode VARCHAR(50),
);

INSERT #TDCode
SELECT '*','BNKNAME','MANDIRIIN','Mandiri In House',null,'8','1'
UNION
SELECT '*','BNKNAME','MANDIRIDC','Mandiri Domestic',null,'8','1'
UNION
SELECT '*','BNKNAME','MANDIRIIN1','Mandiri In House 1M',null,'8','1'
UNION
SELECT '*','BNKNAME','MANDIRIDC1','Mandiri Domestic 1M',null,'8','1'
UNION
SELECT '*','BNKNAME','MANDIRIUSIN','Mandiri USD In House',null,'8','1'
UNION
SELECT '*','BNKNAME','MANDIRIUSDC','Mandiri USD Domestic',null,'8','1'

INSERT INTO [tdcode] (CompanyID, CodeType, CodeID, CodeName, CodeCategory, CodeSequence, IsSystemCode) 
SELECT CompanyID, CodeType, CodeID, CodeName, CodeCategory, CodeSequence,IsSystemCode FROM #TDCode


DROP TABLE #TDCode

-----------UR4---------------
ALTER TABLE fb_ger_info
ADD DetailExpenses VARCHAR(255) DEFAULT NULL;

INSERT INTO tcode
SELECT 'CSL','DTLEX','SH','Special Handling','',1,1,'',GETDATE(),'adm',GETDATE(),'adm'
UNION
SELECT 'CSL','DTLEX','DP','Direct Purchase','',2,1,'',GETDATE(),'adm',GETDATE(),'adm'
UNION
SELECT 'CSL','DTLEX','RE','Reimbursement','',3,1,'',GETDATE(),'adm',GETDATE(),'adm'
UNION
SELECT 'SLF','DTLEX','SH','Special Handling','',1,1,'',GETDATE(),'adm',GETDATE(),'adm'
UNION
SELECT 'SLF','DTLEX','DP','Direct Purchase','',2,1,'',GETDATE(),'adm',GETDATE(),'adm'
UNION
SELECT 'SLF','DTLEX','RE','Reimbursement','',3,1,'',GETDATE(),'adm',GETDATE(),'adm'


ALTER TABLE fb_report_bycreatedate_temp
ADD DetailExpenses VARCHAR(255) DEFAULT NULL;