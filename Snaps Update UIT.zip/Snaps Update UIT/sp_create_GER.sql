-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
/*
	DECLARE @FormNum CHAR(9)
	EXEC sp_create_GER 
		@CompanyID='SLF',
		@FormNum=@FormNum OUT,
		@GERType='M',
		@MainFormNum='',
		@Currency='IDR',
		@ExchangeRate=1,
		@FromDept='CLM',
		@AdvanceFormNum='',
		@TransactionCode='PAY',
		@PolRelated=1,
		@PolicyNum='1123232',
		@UserID='F722'
		
	SELECT * FROM fb_ger_info WHERE FormNum=@FormNum

*/
-- =============================================
ALTER PROCEDURE [dbo].[sp_create_GER]
	@CompanyID			VARCHAR(3),
	@FormNum			CHAR(9) OUT,
	@GERType			VARCHAR(1),
	@MainFormNum		CHAR(9)='',
	@Currency			VARCHAR(3),
	@ExchangeRate		FLOAT=1,
	@FromDept			VARCHAR(10),
	@AdvanceFormNum		VARCHAR(9)='',
	@TransactionCode	VARCHAR(8),
	@PolRelated			BIT,
	@PolicyNum			CHAR(9),
	@UserID				VARCHAR(15),
	@Budgeted			BIT,
	@PONumber			VARCHAR(50),
	@ToGenerate bit=1,
	@Journalized bit=1,
	@ToApprovedByTax bit=1,
	@PayCat varchar(10) = null,
	@DetEx varchar(50) = null,
	@AppNum varchar(15) =null
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Taxable	BIT
	DECLARE @flagTransType varchar(100)
	Declare @AdvanceAmount float



	SELECT	@FormNum=dbo.fGetNextGERNo(@CompanyID, 1)

	SELECT	@Taxable=IsTaxable 
	FROM	fb_TransactionType
	WHERE	CompanyID=@CompanyID AND Code=@TransactionCode

	IF @AdvanceFormNum <> ''
		BEGIN
			
			SELECT @AdvanceAmount=DueAmount FROM fb_ger_info WHERE FormNum=@AdvanceFormNum

		END

	select @PolRelated=CASE WHEN Category='POL' THEN 1 ELSE 0 END
	FROM fb_TransactionType WHERE COMPANYID=@CompanyID AND CODE=@TransactionCode

	INSERT INTO 
		fb_ger_info
		(CompanyID, FormNum, GERType, MainFormNum, Curr, ExchangeRate, 
		 FormType, FromDept, AdvanceFormNum,AdvanceAmount, TransactionCode, FormStatus, PolRelated, PolicyNum,Budgeted,[PONum],BeneficiaryAccountCurrency,ToGenerate,Taxable,FormLocation,
		 CreateDt, CreateBy, PaymentCategory, DetailExpenses, [ApplicationNo])
	SELECT
		@CompanyID, @FormNum, @GerType, @FormNum, @Currency, @ExchangeRate, 
		'GER', @FromDept, @AdvanceFormNum,@AdvanceAmount, @TransactionCode, 'NEW', @PolRelated, @PolicyNum,@Budgeted,@PONumber,@Currency,@ToGenerate,@Taxable,@UserID,
		GETDATE(), @UserID, @PayCat, @DetEx, @AppNum
		
	select @flagTransType=CASE WHEN codeID = 'TRAVEL' then 'TRAVLE' WHEN codeID ='ENTERTAINMENT' then 'ENTREE' ELSE 'OTHER'  END
			from vlist_codeTransaction a right join fb_ger_info b on a.codeType=b.TransactionCode where b.FormNum=@FormNum

	IF @flagTransType = 'TRAVLE'
		BEGIN
			
			insert into fb_GER_detail_info
			select @CompanyID,@FormNum,'0','1','Travel Expense summary. For details, please see document attachment','','','0','','',1, '', '', '', '', NULL, NULL


		END
	ELSE IF @flagTransType = 'ENTREE'
		BEGIN

			insert into fb_GER_detail_info
			select @CompanyID,@FormNum,'0','1','Entertainment expense summary. For details, Please see document attachment','','','0','','',1,'', '', '', '', NULL, NULL

		END

	EXEC usp_process_transactionLog @Companyid, 1,@FormNum,'',@UserID
		
	SELECT @FormNum
END
