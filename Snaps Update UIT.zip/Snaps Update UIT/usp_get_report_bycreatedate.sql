  
  
  
  
--VPMARCOM  
-- =============================================  
-- Author:  <Author,,Name>  
-- Create date: <Create Date,,>  
-- Description: <Description,,>  
/*  
  
  EXEC usp_get_report_bycreatedate   
  @CompanyID='SLF',    
  @skey1='CSD',      
  @skey2='GER',   
  @skey3='ABT',   
  @skey4='CASHIER',  
  @dkey1='2021-10-01',   
  @dkey2='2021-10-19',  
  @USERID='F544'  
  
  
  
*/  
-- =============================================  
  
ALTER PROCEDURE [dbo].[usp_get_report_bycreatedate]   
 @Companyid VARCHAR(5),  
 @skey1  VARCHAR(255) = NULL,--Department  
 @skey2  VARCHAR(255) = NULL,--Form Type  
 @skey3  VARCHAR(255) = NULL,--Form Status  
 @skey4  VARCHAR(255) = NULL,--Roles  
 @dkey1  DATETIME = NULL,  
 @dkey2  DATETIME = NULL,  
 @userid  VARCHAR(5) =NULL  
  
AS  
BEGIN  
  
 DECLARE @stmt   VARCHAR(MAX),  
   @stmt1   VARCHAR(MAX),  
   @AddSelect  VARCHAR(MAX),  
   @AddJoin  VARCHAR(MAX),  
   @AddWhere  VARCHAR(MAX),  
   @TotalRows  INT  
  
  
  
if @skey2='GER'  
  
BEGIN  
  
delete test7  
insert into test7 values (getdate(),'@Companyid',@Companyid)  
insert into test7 values (getdate(),'@skey1',@skey1)  
insert into test7 values (getdate(),'@skey2',@skey2)  
insert into test7 values (getdate(),'@skey3',@skey3)  
insert into test7 values (getdate(),'@skey4',@skey4)  
insert into test7 values (getdate(),'@dkey1',convert(varchar(max),@dkey1,112))  
insert into test7 values (getdate(),'@dkey2',convert(varchar(max),@dkey2,112))  
  
   SELECT @stmt  = 'insert into  fb_report_bycreatedate_temp '+  
   'Select A.Companyid,A.Curr, A.FormType, A.FormNum, A.AdvanceFormNum AS GCSettlementNumber, C.FormStatus as CFormStatus, A.FormStatus as AFormStatus, D.TransferedDt as DTransferredDt, '+  
   'A.CreateDt, A.CreateBy, A.FromDept, A.BeneficiaryName, E.BankName AS BeneficiaryBankName, A.BeneficiaryBankAccount, ISNULL(A.TotalAmount,0) as TotalAmount, ISNULL(A.AdvanceAmount,0) as AdvanceAmount, ISNULL(A.DueAmount,0) as DueAmount, ISNULL(A.TaxAmo
unt,0) as TaxAmount, ISNULL(A.NettAmount,0) as NettAmount, B.VoucherNum , A.TransactionCode, B.TransferedDt as BTransferredDt, '+   
   --'A.PolicyNum,A.ApplicationNo , F.Description FROM fb_ger_info A '+   
   'A.PolicyNum,A.ApplicationNo, SUBSTRING((SELECT '' '' + CAST(z.[Description] as VARCHAR(max)) FROM fb_ger_detail_info z WHERE z.[Description] <> '''' AND z.CompanyId = A.CompanyId AND z.Formnum = A.Formnum order by z.SeqNum asc for xml path('''')),1,10
00)  as [Description], Null as [MainGerNumber], A.PONum as PRNumber, f.codename as PaymentCategory, g.codename as DetailExpenses, ISNULL(A.NettAmount,0)*A.[ExchangeRate] as ConvertedNettAmount FROM fb_ger_info A '+   
   'LEFT JOIN fb_payment_info B ON A.FormNum = B.FormNum and a.companyid=b.companyid '+   
   'LEFT JOIN fb_GER_info C ON C.FormNum = A.AdvanceFormNum and a.companyid=c.companyid '+   
   'LEFT JOIN fb_payment_info D ON A.AdvanceFormNum = D.FormNum and a.companyid=d.companyid '+   
   'LEFT JOIN fb_ListOfBeneficiaryBank E ON A.BeneficiaryBankCode=E.Code and a.companyid=e.companyid '+   
   'LEFT JOIN tcode f ON a.companyid = f.companyid and f.codeid = a.[PaymentCategory] and f.codetype = ''PyCat'''+   
   'LEFT JOIN tcode g ON a.companyid = g.companyid and g.codeid = a.[DetailExpenses] and g.codetype = ''DetEx'''+   
   'Where A.FORMNUM=A.MAINFORMNUM AND (convert(varchar(10),A.CreateDt,121)>='''+convert(varchar(10),@dkey1,121)+ ''' and convert(varchar(10),A.CreateDt,121)<='''+convert(varchar(10),@dkey2,121)+''') AND A.FormType =''' +@skey2+''' AND A.CompanyID='''+@Companyid+''' '    
   --'LEFT JOIN (select formnum,Description, CompanyID, SeqNum from fb_ger_detail_info where Description <>'''')F '+  
   --'ON A.FormNum=F.FormNum AND A.CompanyID=F.CompanyID Where A.FORMNUM=A.MAINFORMNUM AND (convert(varchar(10),A.CreateDt,121)>='''+convert(varchar(10),@dkey1,121)+ ''' and convert(varchar(10),A.CreateDt,121)<='''+convert(varchar(10),@dkey2,121)+''') ANDA.FormType =''' +@skey2+''' AND A.CompanyID='''+@Companyid+''' '    
   --'ON A.FormNum=F.FormNum AND A.CompanyID=F.CompanyID Where (A.CreateDt>='''+convert(varchar(10),@dkey1,121)+ ''' and A.CreateDt<='''+convert(varchar(10),@dkey2,121)+''') AND A.FormStatus='''+@skey3+''' AND A.FormType =''' +@skey2+''' AND F.CompanyID='''+@Companyid+''' '    
   ,  
   @stmt1  = 'INSERT INTO tid(TotalRows) SELECT COUNT(1) FROM vlist_ger_all ',  
   @AddSelect = '',   
   @AddJoin = '',   
   @AddWhere = ''   
  
END  
ELSE IF @skey2 ='CAR'  
  
begin   
  
   SELECT @stmt  = 'insert into  fb_report_bycreatedate_temp '+  
      'Select A.Companyid,a.CURR, a.FormType, a.FormNum, X.formnum AS GCSettlementNumber, '+  
      'X.REfStatus as CFormStatus, a.FormStatus as AFormStatus, fb_Payment_Info.TransferedDt as DTransferredDt, '+  
      'a.CreateDt, a.CreateBy, a.FromDept, a.BeneficiaryName, fb_ListOfBeneficiaryBank.BankName AS BeneficiaryBankName, a.BeneficiaryBankAccount, ISNULL(a.TotalAmount,0) as TotalAmount, ISNULL(a.AdvanceAmount,0) as AdvanceAmount, ISNULL(a.DueAmount,0) as 
DueAmount, ISNULL(a.TaxAmount,0) as TaxAmount, ISNULL(a.NettAmount,0) as NettAmount, fb_Payment_Info.VoucherNum , a.TransactionCode, fb_Payment_Info.TransferedDt as BTransferredDt, '+   
      --'a.PolicyNum,a.ApplicationNo , F.Description '+  
      'a.PolicyNum,a.ApplicationNo , SUBSTRING((SELECT '' '' + CAST(z.[Description] as VARCHAR(max)) FROM fb_ger_detail_info z WHERE z.[Description] <> '''' AND z.CompanyId = A.CompanyId AND z.Formnum = A.Formnum order by z.SeqNum asc for xml path('''')),
1,800)  as [Description], Null as [MainGerNumber], A.PONum as PRNumber, NULL as PaymentCategory, ISNULL(A.NettAmount,0)*A.[ExchangeRate] as ConvertedNettAmount '+  
      'FROM            dbo.fb_ger_info a LEFT OUTER JOIN '+  
      'dbo.fb_Payment_Info ON a.CompanyID = dbo.fb_Payment_Info.CompanyID AND '+  
      'a.FormNum = dbo.fb_Payment_Info.FormNum LEFT OUTER JOIN '+  
      'dbo.fb_ListOfBeneficiaryBank ON a.CompanyID = dbo.fb_ListOfBeneficiaryBank.CompanyID AND '+  
      'a.BeneficiaryBankCode = dbo.fb_ListOfBeneficiaryBank.Code LEFT OUTER JOIN '+  
      'dbo.fb_GER_Reject_Info ON a.FormNum = dbo.fb_GER_Reject_Info.FormNum AND a.CompanyID = dbo.fb_GER_Reject_Info.CompanyID LEFT OUTER JOIN '+  
      '(SELECT        FormNum, AdvanceFormNum, FormStatus as REfStatus '+  
      'FROM            dbo.fb_ger_info AS fb_ger_info_1 '+  
      'WHERE        (AdvanceFormNum <> '''') AND (FormStatus <> ''REJ'')) AS X ON a.FormNum = X.AdvanceFormNum '+  
      --'LEFT JOIN (select formnum,Description, CompanyID, SeqNum from fb_ger_detail_info where seqnum=0)F  '+  
      --'ON a.FormNum=F.FormNum AND a.CompanyID=F.CompanyID '+  
      'Where (a.FormType = ''CAR'')  and (A.CreateDt>='''+convert(varchar(10),@dkey1,121)+ ''' and A.CreateDt<='''+convert(varchar(10),@dkey2,121)+''')  AND A.FormType =''' +@skey2+''' AND A.CompanyID='''+@Companyid+''' '    
--      'WHERE        (a.FormType = ''CAR'') AND (A.CompanyID='''+@Companyid+''') '   
  
  
  
  
   --'Select A.Curr, A.FormType, A.FormNum, A.AdvanceFormNum AS GCSettlementNumber, C.FormStatus as CFormStatus, A.FormStatus as AFormStatus, D.TransferedDt as DTransferredDt, '+  
   --'A.CreateDt, A.CreateBy, A.FromDept, A.BeneficiaryName, E.BankName AS BeneficiaryBankName, A.BeneficiaryBankAccount, ISNULL(A.TotalAmount,0) as TotalAmount, ISNULL(A.AdvanceAmount,0) as AdvanceAmount, ISNULL(A.DueAmount,0) as DueAmount, ISNULL(A.TaxAmount,0) as TaxAmount, ISNULL(A.NettAmount,0) as NettAmount, B.VoucherNum , A.TransactionCode, B.TransferedDt as BTransferredDt, '+   
   --'A.PolicyNum,A.ApplicationNo , F.Description FROM fb_ger_info A '+   
   --'LEFT JOIN fb_payment_info B ON A.FormNum = B.FormNum and a.companyid=b.companyid '+   
   --'LEFT JOIN fb_GER_info C ON C.FormNum = A.AdvanceFormNum and a.companyid=c.companyid '+   
   --'LEFT JOIN fb_payment_info D ON A.AdvanceFormNum = D.FormNum and a.companyid=d.companyid '+   
   --'LEFT JOIN fb_ListOfBeneficiaryBank E ON A.BeneficiaryBankCode=E.Code and a.companyid=e.companyid '+   
   --'LEFT JOIN (select formnum,Description, CompanyID, SeqNum from fb_ger_detail_info where Description <>'''')F '+  
   --'ON A.FormNum=F.FormNum AND A.CompanyID=F.CompanyID Where (convert(varchar(10),A.CreateDt,121)>='''+convert(varchar(10),@dkey1,121)+ ''' and convert(varchar(10),A.CreateDt,121)<='''+convert(varchar(10),@dkey2,121)+''') AND A.FormType =''' +@skey2+'''AND A.CompanyID='''+@Companyid+''' '    
   --'ON A.FormNum=F.FormNum AND A.CompanyID=F.CompanyID Where (A.CreateDt>='''+convert(varchar(10),@dkey1,121)+ ''' and A.CreateDt<='''+convert(varchar(10),@dkey2,121)+''') AND A.FormStatus='''+@skey3+''' AND A.FormType =''' +@skey2+''' AND F.CompanyID='''+@Companyid+''' '    
   ,  
   @stmt1  = 'INSERT INTO tid(TotalRows) SELECT COUNT(1) FROM vlist_car_all ',  
   @AddSelect = '',   
   @AddJoin = '',   
   @AddWhere = ''   
end  
  
ELSE IF @skey2='GBULK'  
BEGIN  
   SELECT @stmt  = 'insert into  fb_report_bycreatedate_temp Select A.Companyid,A.Curr, A.FormType, A.FormNum, A.AdvanceFormNum AS GCSettlementNumber, C.FormStatus as CFormStatus, A.FormStatus as AFormStatus, D.TransferedDt as DTransferredDt, '+  
   'A.CreateDt, A.CreateBy, A.FromDept, A.BeneficiaryName, E.BankName AS BeneficiaryBankName, A.BeneficiaryBankAccount, ISNULL(A.TotalAmount,0) as TotalAmount, ISNULL(A.AdvanceAmount,0) as AdvanceAmount, ISNULL(A.DueAmount,0) as DueAmount, ISNULL(A.TaxAmo
unt,0) as TaxAmount, ISNULL(A.NettAmount,0) as NettAmount, B.VoucherNum , A.TransactionCode, B.TransferedDt as BTransferredDt, '+   
   'A.PolicyNum,A.ApplicationNo , SUBSTRING((SELECT '' '' + CAST(z.[Description] as VARCHAR(max)) FROM fb_ger_detail_info z WHERE z.[Description] <> '''' AND z.CompanyId = A.CompanyId AND z.Formnum = A.Formnum order by z.SeqNum asc for xml path('''')),1,8
00)  as [Description], A.MainFormnum as [MainGerNumber], A.PONum as PRNumber, f.codename as PaymentCategory, ISNULL(A.NettAmount,0)*A.[ExchangeRate] as ConvertedNettAmount FROM fb_ger_info A '+   
   'LEFT JOIN (select VoucherNum,TransferedDt, a.FormNum, a.MainFormNum,a.CompanyID from fb_ger_info a left outer join fb_payment_info b on a.FormNum=b.FormNum and a.CompanyID=b.CompanyID) B ON A.mainformnum = B.FormNum and a.companyid=b.companyid '+   
   'LEFT JOIN fb_GER_info C ON C.FormNum = A.AdvanceFormNum and a.companyid=c.companyid '+   
   'LEFT JOIN fb_payment_info D ON A.AdvanceFormNum = D.FormNum and a.companyid=d.companyid '+   
   'LEFT JOIN fb_ListOfBeneficiaryBank E ON A.BeneficiaryBankCode=E.Code and a.companyid=e.companyid '+   
   'LEFT JOIN tcode f ON a.companyid = f.companyid and f.codeid = a.[PaymentCategory] and f.codetype = ''PyCat'''+   
   --'LEFT JOIN (select formnum,Description, CompanyID, SeqNum from fb_ger_detail_info where Description <>'''')F '+  
   'Where A.FORMNUM<>A.MAINFORMNUM AND (convert(varchar(10),A.CreateDt,121)>='''+CONVERT(VARCHAR(10),@dkey1,121)+ ''' and convert(varchar(10),A.CreateDt,121)<='''+CONVERT(VARCHAR(10),@dkey2,121)+''') AND A.FormType =''GER'' AND A.CompanyID='''+@Companyid+
''' '    
   --'ON A.FormNum=F.FormNum AND A.CompanyID=F.CompanyID Where (A.CreateDt>='''+convert(varchar(10),@dkey1,121)+ ''' and A.CreateDt<='''+convert(varchar(10),@dkey2,121)+''') AND A.FormStatus='''+@skey3+''' AND A.FormType =''' +@skey2+''' AND F.CompanyID='''+@Companyid+''' '    
   ,  
   @stmt1  = 'INSERT INTO tid(TotalRows) SELECT COUNT(1) FROM vlist_ger_all ',  
   @AddSelect = '',   
   @AddJoin = '',   
   @AddWhere = ''   
END  
  
    
 IF CHARINDEX('*',@skey3) <> 1  
 BEGIN  
  SET @AddWhere = @AddWhere + 'AND A.FormStatus=''' + @skey3 + ''''  
 END  
    
 --DEPARTMENT  
 IF CHARINDEX('*',@skey1) <> 1  
  begin   
  
  PRINT 'MASUK SINI'  
    --When departement combo box have value   
    SET @AddWhere = @AddWhere + ' AND A.Fromdept = ''' + @skey1 + ''' '  
      
  
    IF @skey4='CC'  
    begin  
    SET @AddWhere = @AddWhere + ' AND a.CompanyID+a.fromDept IN (SELECT DISTINCT a.companyid+(a.deptcode) as Codeid from fb_Dept_TransactionType A  
       inner join fb_transactiontype b  
       on a.transactiontypecode= b.code and a.companyid=b.companyid inner join fb_department c  
       on a.deptcode=c.code and a.companyid=c.companyid  
       where b.category=''POL'' and a.companyid=@Companyid) '  
    end  
    ELSE IF @skey4 NOT IN ('ACC','CASHIER','TAX','TAX_ALL')  
    BEGIN  
    --PRINT 'MASUK CHECK SKEY7'  
    SET @AddWhere = @AddWhere + ' AND a.CompanyID+a.fromDept IN (SELECT CompanyID+DeptCode FROM fb_user_department WHERE CompanyID='''  + @companyid + ''' AND UserID=''' + @userid + '''' + ')  '  
      
    END  
  END  
 ELSE  
  BEGIN  
  --List all department can access by user  
     
      
   IF @skey4  IN ('TAX','CASHIER','AUDIT','TAX_ALL','ACC')  
   BEGIN  
    INSERT INTO ROLES  
    select distinct (a.deptcode)   
    from fb_user_department a inner join fb_department b  
    on a.deptcode=b.code and a.CompanyID = b.CompanyID where a.deptcode   
    not in (select code from fb_costcenter_distribution_info) AND A.CompanyID=@Companyid  
  
   END  
   ELSE IF @skey4='UPREP'  
   BEGIN  
     IF EXISTS(SELECT deptcode FROM fb_user_dept_from WHERE userid=@userid and CompanyID = @Companyid)  
     BEGIN  
      INSERT INTO ROLES  
      SELECT a.deptcode   
      FROM fb_user_dept_from a  
      INNER JOIN fb_department b ON a.deptcode=b.code AND a.CompanyID = b.CompanyID WHERE a.UserID=@userid AND a.CompanyID=@Companyid  
          
  
     END  
     ELSE  
     BEGIN  
      INSERT INTO ROLES  
      SELECT a.deptid   
      FROM fb_user_info a   
      INNER JOIN fb_department b  
      ON a.deptid=b.code AND a.CompanyID = b.CompanyID WHERE a.UserId=@userid AND a.CompanyID=@Companyid  
     END  
   END  
   ELSE IF @skey4='CC'  
   BEGIN  
     INSERT INTO ROLES  
     SELECT DISTINCT(a.deptcode)        
     FROM fb_Dept_TransactionType A  
     INNER JOIN fb_transactiontype b  
     ON a.transactiontypecode= b.code AND a.CompanyID = b.CompanyID INNER JOIN fb_department c  
     ON a.deptcode=c.code AND a.companyid = c.companyid  
     WHERE b.category='POL' AND a.CompanyID=@Companyid  
   END  
   ELSE IF @skey4 = 'VWONLY'  
   BEGIN  
    --INSERT INTO #ROLES  
    --SELECT DeptCode  
    --FROM fb_usersegrole_detail   
    --WHERE CompanyID = @companyid AND UserID = @userid AND IsActive = 1  
    INSERT INTO ROLES  
    select [DeptCode] from [fb_usersegrole_detail] where [UserID]=@userid and CompanyID = @companyid  
   END  
     
   SET @AddWhere = @AddWhere + ' AND a.fromDept in  (select codeid from ROLES) '  
  
 END  
  
 IF @AddWhere<>''  
 SET @stmt = @stmt+@AddWhere  
   
 PRINT 'STATEMENTNNYA : '+@stmt  
  
   
 INSERT INTO test7 VALUES (GETDATE(), @skey2,'@skey2')  
 INSERT INTO test7 VALUES (GETDATE(), @stmt, 'bycreatedate')  
 EXEC(@stmt)  
  
  SELECT Curr, FormType, FormNum, GCSettlementNumber,  CFormStatus, AFormStatus,  DTransferredDt, CreateDt, CreateBy, FromDept, BeneficiaryName, BeneficiaryBankName, BeneficiaryBankAccount, TotalAmount, AdvanceAmount, DueAmount, TaxAmount, NettAmount, VoucherNum , TransactionCode, BTransferredDt,    
  PolicyNum,ApplicationNo , Description, MainGerNumber, PRNumber, PaymentCategory, DetailExpenses, ConvertedNettAmount  
  FROM fb_report_bycreatedate_temp WHERE companyid=@Companyid   
  
    TRUNCATE TABLE ROLES  
  TRUNCATE TABLE fb_report_bycreatedate_temp  
  
  
END  
  
  
  