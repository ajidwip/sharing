﻿Imports Snaps.model
Imports Snaps.dal
Imports Snaps.com
Imports System.DirectoryServices
Imports Snaps.model.snaps.api.models
Imports System.IO
Imports System.Data.SqlClient
Imports System.Security.Cryptography
Imports System.Text
Imports System.Text.RegularExpressions
Imports Snaps.sec

Namespace snaps.api.snapsbll
    Public Class snapsbiz

#Region "Variables"
        Dim ores As cResult
        Dim sretval As String
        Dim ssql As String
        Dim rdr As IDataReader
        Dim oprm As cParams
        Private key() As Byte = {}
        Private IV() As Byte = {&H12, &H34, &H56, &H78, &H90, &HAB, &HCD, &HEF}
        Dim CompanyId As String
#End Region

#Region "Private Functions"
        Private Function GetValue(ByVal odal As SQLAccess, ByVal pparam As cParams) As String
            Dim rdr As IDataReader
            Dim sResultValue As String = ""
            Try
                rdr = odal.ExecuteDataReader("sp_get", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, comlib.GetText(pparam.paramtype)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pparam.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pparam.skey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pparam.skey3)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pparam.skey4)),
                        odal.CreateParameter("@skey5", SqlDbType.VarChar, comlib.GetText(pparam.skey5)),
                        odal.CreateParameter("@skey6", SqlDbType.VarChar, comlib.GetText(pparam.skey6)),
                        odal.CreateParameter("@skey7", SqlDbType.VarChar, comlib.GetText(pparam.skey7)),
                        odal.CreateParameter("@skey8", SqlDbType.VarChar, comlib.GetText(pparam.skey8)),
                        odal.CreateParameter("@skey9", SqlDbType.VarChar, comlib.GetText(pparam.skey9)),
                        odal.CreateParameter("@skey10", SqlDbType.VarChar, comlib.GetText(pparam.skey10)),
                        odal.CreateParameter("@ikey1", SqlDbType.Int, comlib.GetInteger(pparam.ikey1)),
                        odal.CreateParameter("@ikey2", SqlDbType.Int, comlib.GetInteger(pparam.ikey2)),
                        odal.CreateParameter("@ikey3", SqlDbType.Int, comlib.GetInteger(pparam.ikey3)),
                        odal.CreateParameter("@ikey4", SqlDbType.Int, comlib.GetInteger(pparam.ikey4)),
                        odal.CreateParameter("@ikey5", SqlDbType.Int, comlib.GetInteger(pparam.ikey5)),
                        odal.CreateParameter("@fkey1", SqlDbType.Float, comlib.GetDouble(pparam.fkey1)),
                        odal.CreateParameter("@fkey2", SqlDbType.Float, comlib.GetDouble(pparam.fkey2)),
                        odal.CreateParameter("@fkey3", SqlDbType.Float, comlib.GetDouble(pparam.fkey3)),
                        odal.CreateParameter("@fkey4", SqlDbType.Float, comlib.GetDouble(pparam.fkey4)),
                        odal.CreateParameter("@fkey5", SqlDbType.Float, comlib.GetDouble(pparam.fkey5)),
                        odal.CreateParameter("@dkey1", SqlDbType.DateTime, comlib.CToDate(pparam.dkey1)),
                        odal.CreateParameter("@dkey2", SqlDbType.DateTime, comlib.CToDate(pparam.dkey2)),
                        odal.CreateParameter("@dkey3", SqlDbType.DateTime, comlib.CToDate(pparam.dkey3)),
                        odal.CreateParameter("@dkey4", SqlDbType.DateTime, comlib.CToDate(pparam.dkey4)),
                        odal.CreateParameter("@dkey5", SqlDbType.DateTime, comlib.CToDate(pparam.dkey5)))
                If rdr.Read Then
                    sResultValue = comlib.GetText(rdr("ReturnValue"))
                End If
            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pparam = Nothing
            End Try
            Return sResultValue
        End Function
        Private Function GetRows(odal As SQLAccess, pparam As cParams) As IDataReader
            Try
                If comlib.IsNumericBlank(pparam.pageno) Then
                    pparam.pageno = 1
                    pparam.pagesize = 15
                End If
                rdr = odal.ExecuteDataReader("sp_get", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, comlib.GetText(pparam.paramtype)),
                        odal.CreateParameter("@pageno", SqlDbType.Int, comlib.GetInteger(pparam.pageno)),
                        odal.CreateParameter("@PageSize", SqlDbType.Int, comlib.GetInteger(pparam.pagesize)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pparam.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pparam.skey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pparam.skey3)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pparam.skey4)),
                        odal.CreateParameter("@skey5", SqlDbType.VarChar, comlib.GetText(pparam.skey5)),
                        odal.CreateParameter("@skey6", SqlDbType.VarChar, comlib.GetText(pparam.skey6)),
                        odal.CreateParameter("@skey7", SqlDbType.VarChar, comlib.GetText(pparam.skey7)),
                        odal.CreateParameter("@skey8", SqlDbType.VarChar, comlib.GetText(pparam.skey8)),
                        odal.CreateParameter("@skey9", SqlDbType.VarChar, comlib.GetText(pparam.skey9)),
                        odal.CreateParameter("@skey10", SqlDbType.VarChar, comlib.GetText(pparam.skey10)),
                        odal.CreateParameter("@ikey1", SqlDbType.Int, comlib.GetInteger(pparam.ikey1)),
                        odal.CreateParameter("@ikey2", SqlDbType.Int, comlib.GetInteger(pparam.ikey2)),
                        odal.CreateParameter("@ikey3", SqlDbType.Int, comlib.GetInteger(pparam.ikey3)),
                        odal.CreateParameter("@ikey4", SqlDbType.Int, comlib.GetInteger(pparam.ikey4)),
                        odal.CreateParameter("@ikey5", SqlDbType.Int, comlib.GetInteger(pparam.ikey5)),
                        odal.CreateParameter("@fkey1", SqlDbType.Float, comlib.GetDouble(pparam.fkey1)),
                        odal.CreateParameter("@fkey2", SqlDbType.Float, comlib.GetDouble(pparam.fkey2)),
                        odal.CreateParameter("@fkey3", SqlDbType.Float, comlib.GetDouble(pparam.fkey3)),
                        odal.CreateParameter("@fkey4", SqlDbType.Float, comlib.GetDouble(pparam.fkey4)),
                        odal.CreateParameter("@fkey5", SqlDbType.Float, comlib.GetDouble(pparam.fkey5)),
                        odal.CreateParameter("@dkey1", SqlDbType.DateTime, comlib.CToDate(pparam.dkey1)),
                        odal.CreateParameter("@dkey2", SqlDbType.DateTime, comlib.CToDate(pparam.dkey2)),
                        odal.CreateParameter("@dkey3", SqlDbType.DateTime, comlib.CToDate(pparam.dkey3)),
                        odal.CreateParameter("@dkey4", SqlDbType.DateTime, comlib.CToDate(pparam.dkey4)),
                        odal.CreateParameter("@dkey5", SqlDbType.DateTime, comlib.CToDate(pparam.dkey5)))
            Catch ex As Exception
                Throw ex
            End Try
            Return rdr
        End Function
        Private Sub GetDataTable(odal As SQLAccess, pparam As cParams, ByRef odt As DataTable)
            Try
                If comlib.IsNumericBlank(pparam.pageno) Then
                    pparam.pageno = 1
                    pparam.pagesize = 50
                End If
                odal.FillDataTable(odt, True, CommandType.StoredProcedure, "sp_get",
                                   odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                                   odal.CreateParameter("@table", SqlDbType.VarChar, comlib.GetText(pparam.paramtype)),
                                   odal.CreateParameter("@pageno", SqlDbType.Int, comlib.GetInteger(pparam.pageno)),
                                   odal.CreateParameter("@PageSize", SqlDbType.Int, comlib.GetInteger(pparam.pagesize)),
                                   odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pparam.skey1)),
                                   odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pparam.skey2)),
                                   odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pparam.skey3)),
                                   odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pparam.skey4)),
                                   odal.CreateParameter("@skey5", SqlDbType.VarChar, comlib.GetText(pparam.skey5)),
                                   odal.CreateParameter("@skey6", SqlDbType.VarChar, comlib.GetText(pparam.skey6)),
                                   odal.CreateParameter("@skey7", SqlDbType.VarChar, comlib.GetText(pparam.skey7)),
                                   odal.CreateParameter("@skey8", SqlDbType.VarChar, comlib.GetText(pparam.skey8)),
                                   odal.CreateParameter("@skey9", SqlDbType.VarChar, comlib.GetText(pparam.skey9)),
                                   odal.CreateParameter("@skey10", SqlDbType.VarChar, comlib.GetText(pparam.skey10)),
                                   odal.CreateParameter("@ikey1", SqlDbType.Int, comlib.GetInteger(pparam.ikey1)),
                                   odal.CreateParameter("@ikey2", SqlDbType.Int, comlib.GetInteger(pparam.ikey2)),
                                   odal.CreateParameter("@ikey3", SqlDbType.Int, comlib.GetInteger(pparam.ikey3)),
                                   odal.CreateParameter("@ikey4", SqlDbType.Int, comlib.GetInteger(pparam.ikey4)),
                                   odal.CreateParameter("@ikey5", SqlDbType.Int, comlib.GetInteger(pparam.ikey5)),
                                   odal.CreateParameter("@fkey1", SqlDbType.Float, comlib.GetDouble(pparam.fkey1)),
                                   odal.CreateParameter("@fkey2", SqlDbType.Float, comlib.GetDouble(pparam.fkey2)),
                                   odal.CreateParameter("@fkey3", SqlDbType.Float, comlib.GetDouble(pparam.fkey3)),
                                   odal.CreateParameter("@fkey4", SqlDbType.Float, comlib.GetDouble(pparam.fkey4)),
                                   odal.CreateParameter("@fkey5", SqlDbType.Float, comlib.GetDouble(pparam.fkey5)),
                                   odal.CreateParameter("@dkey1", SqlDbType.DateTime, comlib.CToDate(pparam.dkey1)),
                                   odal.CreateParameter("@dkey2", SqlDbType.DateTime, comlib.CToDate(pparam.dkey2)),
                                   odal.CreateParameter("@dkey3", SqlDbType.DateTime, comlib.CToDate(pparam.dkey3)),
                                   odal.CreateParameter("@dkey4", SqlDbType.DateTime, comlib.CToDate(pparam.dkey4)),
                                   odal.CreateParameter("@dkey5", SqlDbType.DateTime, comlib.CToDate(pparam.dkey5)))
            Catch ex As Exception
                Throw ex
            End Try
        End Sub
        Private Function IsValid(odal As SQLAccess, pparam As cParams) As String
            Dim rdr As IDataReader
            Dim sResultValue As String = ""
            Try
                If comlib.IsNumericBlank(pparam.pageno) Then
                    pparam.pageno = 1
                    pparam.pagesize = 50
                End If

                rdr = odal.ExecuteDataReader("sp_val", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                        odal.CreateParameter("@TaskType", SqlDbType.VarChar, comlib.GetText(pparam.paramtype)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pparam.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pparam.skey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pparam.skey3)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pparam.skey4)),
                        odal.CreateParameter("@skey5", SqlDbType.VarChar, comlib.GetText(pparam.skey5)),
                        odal.CreateParameter("@skey6", SqlDbType.VarChar, comlib.GetText(pparam.skey6)),
                        odal.CreateParameter("@skey7", SqlDbType.VarChar, comlib.GetText(pparam.skey7)),
                        odal.CreateParameter("@skey8", SqlDbType.VarChar, comlib.GetText(pparam.skey8)),
                        odal.CreateParameter("@skey9", SqlDbType.VarChar, comlib.GetText(pparam.skey9)),
                        odal.CreateParameter("@skey10", SqlDbType.VarChar, comlib.GetText(pparam.skey10)),
                        odal.CreateParameter("@ikey1", SqlDbType.Int, comlib.GetInteger(pparam.ikey1)),
                        odal.CreateParameter("@ikey2", SqlDbType.Int, comlib.GetInteger(pparam.ikey2)),
                        odal.CreateParameter("@ikey3", SqlDbType.Int, comlib.GetInteger(pparam.ikey3)),
                        odal.CreateParameter("@ikey4", SqlDbType.Int, comlib.GetInteger(pparam.ikey4)),
                        odal.CreateParameter("@ikey5", SqlDbType.Int, comlib.GetInteger(pparam.ikey5)),
                        odal.CreateParameter("@fkey1", SqlDbType.Float, comlib.GetDouble(pparam.fkey1)),
                        odal.CreateParameter("@fkey2", SqlDbType.Float, comlib.GetDouble(pparam.fkey2)),
                        odal.CreateParameter("@fkey3", SqlDbType.Float, comlib.GetDouble(pparam.fkey3)),
                        odal.CreateParameter("@fkey4", SqlDbType.Float, comlib.GetDouble(pparam.fkey4)),
                        odal.CreateParameter("@fkey5", SqlDbType.Float, comlib.GetDouble(pparam.fkey5)),
                        odal.CreateParameter("@dkey1", SqlDbType.DateTime, comlib.CToDate(pparam.dkey1)),
                        odal.CreateParameter("@dkey2", SqlDbType.DateTime, comlib.CToDate(pparam.dkey2)),
                        odal.CreateParameter("@dkey3", SqlDbType.DateTime, comlib.CToDate(pparam.dkey3)),
                        odal.CreateParameter("@dkey4", SqlDbType.DateTime, comlib.CToDate(pparam.dkey4)),
                        odal.CreateParameter("@dkey5", SqlDbType.DateTime, comlib.CToDate(pparam.dkey5)))
                If rdr.Read Then
                    sResultValue = comlib.GetText(rdr("InvalidMessage"))
                End If
            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return sResultValue
        End Function
        Private Function RunTask(odal As SQLAccess, pparam As cParams) As cResult
            Try
                ores = New cResult
                'Validation
                ores.InvalidMessage = IsValid(odal, pparam)

                'Run Tasks
                If ores.InvalidMessage = "" Then
                    odal.BeginTransactions()
                    odal.ExecuteCommandSP("sp_task",
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                        odal.CreateParameter("@TaskType", SqlDbType.VarChar, comlib.GetText(pparam.paramtype)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pparam.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pparam.skey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pparam.skey3)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pparam.skey4)),
                        odal.CreateParameter("@skey5", SqlDbType.VarChar, comlib.GetText(pparam.skey5)),
                        odal.CreateParameter("@skey6", SqlDbType.VarChar, comlib.GetText(pparam.skey6)),
                        odal.CreateParameter("@skey7", SqlDbType.VarChar, comlib.GetText(pparam.skey7)),
                        odal.CreateParameter("@skey8", SqlDbType.VarChar, comlib.GetText(pparam.skey8)),
                        odal.CreateParameter("@skey9", SqlDbType.VarChar, comlib.GetText(pparam.skey9)),
                        odal.CreateParameter("@skey10", SqlDbType.VarChar, comlib.GetText(pparam.skey10)),
                        odal.CreateParameter("@ikey1", SqlDbType.Int, comlib.GetInteger(pparam.ikey1)),
                        odal.CreateParameter("@ikey2", SqlDbType.Int, comlib.GetInteger(pparam.ikey2)),
                        odal.CreateParameter("@ikey3", SqlDbType.Int, comlib.GetInteger(pparam.ikey3)),
                        odal.CreateParameter("@ikey4", SqlDbType.Int, comlib.GetInteger(pparam.ikey4)),
                        odal.CreateParameter("@ikey5", SqlDbType.Int, comlib.GetInteger(pparam.ikey5)),
                        odal.CreateParameter("@fkey1", SqlDbType.Float, comlib.GetDouble(pparam.fkey1)),
                        odal.CreateParameter("@fkey2", SqlDbType.Float, comlib.GetDouble(pparam.fkey2)),
                        odal.CreateParameter("@fkey3", SqlDbType.Float, comlib.GetDouble(pparam.fkey3)),
                        odal.CreateParameter("@fkey4", SqlDbType.Float, comlib.GetDouble(pparam.fkey4)),
                        odal.CreateParameter("@fkey5", SqlDbType.Float, comlib.GetDouble(pparam.fkey5)),
                        odal.CreateParameter("@dkey1", SqlDbType.DateTime, comlib.CToDate(pparam.dkey1)),
                        odal.CreateParameter("@dkey2", SqlDbType.DateTime, comlib.CToDate(pparam.dkey2)),
                        odal.CreateParameter("@dkey3", SqlDbType.DateTime, comlib.CToDate(pparam.dkey3)),
                        odal.CreateParameter("@dkey4", SqlDbType.DateTime, comlib.CToDate(pparam.dkey4)),
                        odal.CreateParameter("@dkey5", SqlDbType.DateTime, comlib.CToDate(pparam.dkey5)),
                        odal.CreateParameter("@Notes", SqlDbType.VarChar, comlib.GetText(pparam.Notes)),
                        odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput),
                        odal.CreateParameter("@ProcessBy", SqlDbType.VarChar, comlib.GetText(pparam.ProcessBy)))
                    ores.InvalidMessage = odal.ReturnValue(1).ToString

                    If ores.InvalidMessage = "" Then
                        odal.CommitTransactions()
                    Else
                        odal.RollBackTransactions()
                    End If
                End If
            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            ores.Result = IIf(ores.InvalidMessage = "", "S", "F")
            Return ores

            'DETAIL PARAMETERS

            'companyid: IS REQUIRED for All Task Type
            'processby: IS REQUIRED for All Task Type

            '----USER------------------------------------------------------------------------------------
            'LOGOT - log out            : skey1:userid
            'USERA - actiavate          : skey1:userid
            'USERU - unlock             : skey1:userid|skey2:reason
            'USERT - terminate          : skey1:userid|skey2:reason 
            'USERD - delete             : skey1:userid|skey2:reason
            'USERR - reset password     : skey1:userid|skey2:new password|skey3:reason
            'USERC - change password    : skey1:userid|skey2:old password|skey3:new password


        End Function
        Public Function InsertGER(pparam As cParams) As cResult

            Dim odal As New SQLAccess("core")

            Try
                ores = New cResult
                'Validation
                'ores.InvalidMessage = IsValid(odal, pparam)

                'Run Tasks
                If ores.InvalidMessage = "" Then
                    odal.BeginTransactions()
                    odal.ExecuteCommandSP("insertger",
                        odal.CreateParameter("@table", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pparam.paramtype)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pparam.skey1)),
                        odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))
                    ores.InvalidMessage = odal.ReturnValue(1).ToString

                    If ores.InvalidMessage = "Berhasil" Then
                        odal.CommitTransactions()
                    Else
                        odal.RollBackTransactions()
                    End If
                End If
            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            ores.Result = "SUCCESS"
            Return ores

        End Function
        Private Function SetError(pex As Exception) As cResult
            Dim ores As New cResult
            Try
                ores.Message = "FAILURE"
                ores.InvalidMessage = "Error Occurred"
                ores.ErrorCode = pex.StackTrace
                ores.ErrorDescription = pex.Message
            Catch ex As Exception
            End Try
            Return ores
        End Function

#End Region

#Region "General Functions"

        'Created : RS
        'Date   : 19 Sept 2018
        'Desc   : print function

        Public Function CheckRejectFunction(pparam As cParams) As cResult

            Dim odal As New SQLAccess("core")

            Try
                ores = New cResult

                If ores.InvalidMessage = "" Then
                    odal.BeginTransactions()
                    odal.ExecuteCommandSP("usp_check_reject_function",
                        odal.CreateParameter("@table", SqlDbType.VarChar, "REJECT_FORM"),
                        odal.CreateParameter("@Companyid", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                        odal.CreateParameter("@FormNum", SqlDbType.VarChar, comlib.GetText(pparam.skey1)),
                        odal.CreateParameter("@Roles", SqlDbType.VarChar, comlib.GetText(pparam.skey2)),
                        odal.CreateParameter("@RejectBy", SqlDbType.VarChar, comlib.GetText(pparam.skey3)),
                        odal.CreateParameter("@RejectReason", SqlDbType.VarChar, comlib.GetText(pparam.skey4)),
                        odal.CreateParameter("@Result", SqlDbType.VarChar, ores.ReturnValue, 500, ParameterDirection.InputOutput),
                        odal.CreateParameter("@Result2", SqlDbType.VarChar, ores.ReturnDescription, 500, ParameterDirection.InputOutput),
                        odal.CreateParameter("@Result3", SqlDbType.VarChar, ores.ReturnDescription, 500, ParameterDirection.InputOutput))

                    ores.ReturnValue = odal.ReturnValue(1).ToString
                    ores.ReturnDescription = odal.ReturnValue(2).ToString
                    pparam.skey10 = odal.ReturnValue(3).ToString

                    odal.CommitTransactions()

                End If

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                ores.Result = ex.Message
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try

            If ores.ReturnValue = "YES" Then

                If (ores.ReturnDescription = "RBC" And pparam.skey10 = "PRN") _
                    Or (ores.ReturnDescription = "RBC" And pparam.skey10 = "BNK") _
                    Or (ores.ReturnDescription = "RBB" And pparam.skey10 = "PAID") _
                 Then

                    sendEmailNotificationToPreparer(pparam.skey3, 2, pparam.companyid, pparam.skey4)
                    'sendEmailNotificationToRejector(Data.UserId)
                    'sendEmailNotificationToLastApprover(Data.UserId)
                ElseIf (ores.ReturnDescription = "RBC" And pparam.skey10 = "ABT") _
                    Or (ores.ReturnDescription = "RBT" And pparam.skey10 = "ABU") _
                 Then

                    sendEmailNotificationToPreparer(pparam.skey3, 2, pparam.companyid, pparam.skey4)
                    sendEmailNotificationToLastApprover(pparam.skey3, pparam.companyid, pparam.skey4)

                End If


            End If

            ores.Message = "SUCCESS"
            ores.Result = ""

            Return ores

        End Function

        'Created : RW
        'Date   : 19 June 2018
        'Desc   : print function

        Public Function CheckPrintFunction(pparam As cParams) As cResult

            Dim odal As New SQLAccess("core")

            Try
                ores = New cResult

                If ores.InvalidMessage = "" Then
                    odal.BeginTransactions()
                    odal.ExecuteCommandSP("usp_check_print_function",
                        odal.CreateParameter("@table", SqlDbType.VarChar, "PRINT_GER"),
                        odal.CreateParameter("@Companyid", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                        odal.CreateParameter("@FormNum", SqlDbType.VarChar, comlib.GetText(pparam.skey1)),
                        odal.CreateParameter("@UserID", SqlDbType.VarChar, comlib.GetText(pparam.skey2)),
                        odal.CreateParameter("@Result", SqlDbType.VarChar, ores.ReturnValue, 500, ParameterDirection.InputOutput),
                        odal.CreateParameter("@Result2", SqlDbType.VarChar, ores.ReturnDescription, 500, ParameterDirection.InputOutput))

                    ores.ReturnValue = odal.ReturnValue(1).ToString
                    ores.ReturnDescription = odal.ReturnValue(2).ToString

                    odal.CommitTransactions()

                End If

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                ores.Result = ex.Message
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try

            ores.Message = "SUCCESS"
            ores.Result = ""


            Return ores

        End Function

        'Created : RS
        'Date   : 3 Okt 2018
        'Desc   : check bene name

        Public Function checkAffliationBenName(id As String) As cResult

            Dim odal As New SQLAccess("core")

            Try
                ores = New cResult

                If ores.InvalidMessage = "" Then
                    odal.BeginTransactions()
                    odal.ExecuteCommandSP("usp_check_beneAffliation_function",
                        odal.CreateParameter("@BeneficiaryName", SqlDbType.VarChar, comlib.GetText(id)),
                        odal.CreateParameter("@Result", SqlDbType.VarChar, ores.ReturnValue, 500, ParameterDirection.InputOutput),
                        odal.CreateParameter("@Result2", SqlDbType.VarChar, ores.ReturnDescription, 500, ParameterDirection.InputOutput))

                    ores.ReturnValue = odal.ReturnValue(1).ToString
                    ores.ReturnDescription = odal.ReturnValue(2).ToString

                    odal.CommitTransactions()

                End If

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                ores.Result = ex.Message
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try

            ores.Message = "SUCCESS"
            ores.Result = ""


            Return ores

        End Function

        Public Function GetComboBLL(pprm As ComboParam) As ComboList
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oResult As ComboList = Nothing
            Dim oResultList As ComboValue = Nothing

            oResult = New ComboList
            oResult.ComboValueList = New List(Of ComboValue)()

            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.CompanyID)),
                         odal.CreateParameter("@DeptID", SqlDbType.VarChar, comlib.GetText(pprm.CodeDept)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, comlib.GetText(pprm.TypeCombo)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.OthersKey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.OthersKey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pprm.OthersKey3)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pprm.OthersKey4)),
                        odal.CreateParameter("@skey5", SqlDbType.VarChar, comlib.GetText(pprm.OthersKey5)))
                While rdr.Read
                    oResultList = New ComboValue
                    oResultList.CodeID = comlib.GetText(rdr.Item("CodeID"))
                    oResultList.DescriptionID = comlib.GetText(rdr.Item("DescriptionID"))
                    oResultList.Others1 = comlib.GetText(rdr.Item("Others1"))
                    oResultList.Others2 = comlib.GetText(rdr.Item("Others2"))
                    oResultList.Others3 = comlib.GetText(rdr.Item("Others3"))
                    oResultList.Others4 = comlib.GetText(rdr.Item("Others4"))
                    oResultList.Others5 = comlib.GetText(rdr.Item("Others5"))
                    oResultList.Others6 = comlib.GetText(rdr.Item("Others6"))
                    oResultList.Others7 = comlib.GetText(rdr.Item("Others7"))
                    oResultList.Others8 = comlib.GetText(rdr.Item("Others8"))
                    oResult.ComboValueList.Add(oResultList)
                End While

                oResult.Message = "SUCCESS"
                oResult.Result = ""

            Catch ex As Exception
                oResult.Message = "FAILURE"
                oResult.Result = ex.Message
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oResult

        End Function

        Public Function GetElementVal(pprm As ElementValueParam) As ElementList
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oResult As ElementList = Nothing
            Dim oResultList As ElementValue = Nothing
            Dim Dictionary As New Dictionary(Of String, Boolean)

            oResult = New ElementList
            oResult.ElementValueList = New Dictionary(Of String, Boolean)
            oResult.ElementComboList = New List(Of ElementValue)

            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.CompanyID)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "get_Element_Rules"),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.Status)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.Rules)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pprm.RType)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pprm.formNumber)),
                        odal.CreateParameter("@skey9", SqlDbType.VarChar, comlib.GetText(pprm.Status2)))
                While rdr.Read
                    Dictionary.Add(comlib.GetText(rdr.Item("attributename")), comlib.GetBool(rdr.Item("RulesValue")))

                    oResultList = New ElementValue

                    oResultList.AttributeName = comlib.GetText(rdr.Item("attributename"))
                    oResultList.AttributeType = comlib.GetText(rdr.Item("attributetype"))
                    oResultList.RulesValue = comlib.GetText(rdr.Item("RulesValue"))
                    oResultList.AttributeTag = comlib.GetText(rdr.Item("AttributeTag"))

                    oResult.ElementText = comlib.GetText(rdr.Item("RulesText"))

                    oResult.ElementValueList = Dictionary

                    If oResultList.AttributeType = "CMB" Then
                        oResult.ElementComboList.Add(oResultList)
                    End If

                End While

                oResult.Message = "SUCCESS"
                oResult.Result = ""

            Catch ex As Exception
                oResult.Message = "FAILURE"
                oResult.Result = ex.Message
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oResult

        End Function

        Public Function GetComboValueCompany() As ComboList
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oResult As ComboList = Nothing
            Dim oResultList As ComboValue = Nothing

            oResult = New ComboList
            oResult.ComboValueList = New List(Of ComboValue)()

            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@table", SqlDbType.VarChar, "list_company"))
                While rdr.Read
                    oResultList = New ComboValue
                    oResultList.CodeID = comlib.GetText(rdr.Item("CodeID"))
                    oResultList.DescriptionID = comlib.GetText(rdr.Item("DescriptionID"))
                    oResultList.Others1 = comlib.GetText(rdr.Item("Others1"))
                    oResultList.Others2 = comlib.GetText(rdr.Item("Others2"))
                    oResultList.Others3 = comlib.GetText(rdr.Item("Others3"))
                    oResultList.Others4 = comlib.GetText(rdr.Item("Others4"))
                    oResultList.Others5 = comlib.GetText(rdr.Item("Others5"))
                    oResult.ComboValueList.Add(oResultList)
                End While

                oResult.Message = "SUCCESS"
                oResult.Result = ""

            Catch ex As Exception
                oResult.Message = "FAILURE"
                oResult.Result = ex.Message
            Finally
                rdr = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oResult

        End Function

        Public Function IsValidAD(ByVal pCompanyID As String, ByVal username As String, ByVal pass As String) As loginResult
            Dim theEntry As DirectoryEntry = Nothing
            Dim sresult As String = ""
            'Dim sdomainname As String = GetSingleValue(pCompanyID, "DomainName")

            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader
            Dim rdr2 As IDataReader

            Dim oTempResult As loginResult = Nothing
            Dim tempVal As String = ""
            Dim hasDataFlag As Boolean = False

            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pCompanyID)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "key_login"),
                        odal.CreateParameter("@userid", SqlDbType.VarChar, comlib.GetText(username)))

                While rdr.Read
                    oTempResult = New loginResult
                    oTempResult.Result = ""
                    oTempResult.UserID = comlib.GetText(rdr.Item("UserID"))
                    oTempResult.UserName = comlib.GetText(rdr.Item("UserName"))
                    oTempResult.DeptID = comlib.GetText(rdr.Item("DeptID"))
                    oTempResult.DomainName = comlib.GetText(rdr.Item("DomainName"))
                    oTempResult.Roles = comlib.GetText(rdr.Item("Roles"))

                    tempVal = ""

                    rdr2 = odal.ExecuteDataReader("usp_check_roles", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pCompanyID)),
                        odal.CreateParameter("@userid", SqlDbType.VarChar, comlib.GetText(username)))
                    While rdr2.Read

                        tempVal = tempVal + "'" + comlib.GetText(rdr2.Item("CodeID")) + "',"

                    End While

                    oTempResult.RolesList = tempVal

                    hasDataFlag = True
                End While

                If Not hasDataFlag Then
                    oTempResult = New loginResult
                    oTempResult.Result = "No Data"
                    Return oTempResult
                End If



            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                rdr2 = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try

            Try
                theEntry = New DirectoryEntry("LDAP://" + oTempResult.DomainName, username, pass, AuthenticationTypes.Secure)
                Dim theobject As Object
                theobject = theEntry.NativeObject
            Catch ex As Exception
                oTempResult.Result = ex.Message()
            Finally
                theEntry.Close()
                theEntry.Dispose()
            End Try

            Return oTempResult
        End Function

        Public Function GetValue(pparam As cParams) As String
            Dim odal As New SQLAccess("core")
            Try
                Return GetValue(odal, pparam)
            Catch ex As Exception
                Throw ex
            Finally
                odal = Nothing
            End Try
        End Function
        Public Function GetDataTable(pparam As cParams) As DataTable
            Dim odal As New SQLAccess("core")
            Dim odt As New DataTable
            Try
                GetDataTable(odal, pparam, odt)
            Catch ex As Exception
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return odt
        End Function
        Public Function GetDataSet(pparams As List(Of cParams)) As DataSet
            Dim odal As New SQLAccess("core")
            Dim ods As New DataSet
            Try
                For i As Integer = 0 To pparams.Count - 1
                    GetDataTable(odal, pparams.Item(i), ods.Tables.Add)
                Next
            Catch ex As Exception
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return ods
        End Function
        Public Function GetComboList(pparam As cParams) As List(Of cCombo)
            Dim odal As New SQLAccess("core")
            Dim locb As New List(Of cCombo)
            Dim ocb As cCombo

            Try
                'setting parameters
                pparam.pageno = 1
                pparam.pagesize = 1000

                locb = New List(Of cCombo)

                rdr = GetRows(odal, pparam)
                While rdr.Read
                    ocb = New cCombo
                    ocb.ComboValue = comlib.GetText(rdr.Item("CodeID"))
                    ocb.ComboText = comlib.GetText(rdr.Item("CodeName"))
                    ocb.Description = comlib.GetText(rdr.Item("Description"))
                    locb.Add(ocb)
                End While
            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return locb
        End Function
        Public Function IsValid(pparam As cParams) As String
            Dim odal As New SQLAccess("core")
            Try
                sretval = ""
                sretval = IsValid(odal, pparam)
            Catch ex As Exception
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return sretval
        End Function
        Public Function InsertTemporary(plotemp As List(Of cTemp)) As cResult
            Dim odal As New SQLAccess("core")
            Try
                ores = New cResult
                ores.InvalidMessage = ""
                ssql = "INSERT INTO ttemp " &
                           "(CompanyID, TempID, TempFunction, TempKey, ProcessBy) " &
                           "SELECT " &
                           "@companyid, @TempID, @TempFunction, @TempKey, @ProcessBy"

                odal.BeginTransactions()

                For Each otemp As cTemp In plotemp
                    odal.ExecuteCommandText(ssql,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, otemp.CompanyID),
                        odal.CreateParameter("@TempID", SqlDbType.VarChar, otemp.TempID),
                        odal.CreateParameter("@TempFunction", SqlDbType.VarChar, otemp.TempFunction),
                        odal.CreateParameter("@TempKey", SqlDbType.VarChar, otemp.TempKey),
                        odal.CreateParameter("@ProcessBy", SqlDbType.VarChar, otemp.ProcessBy))
                Next

                odal.CommitTransactions()

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            ores.Result = IIf(ores.InvalidMessage = "", "S", "F")
            Return ores
        End Function

        Public Function GetCodeList(ByVal pCompanyID As String, ByVal pCodeType As String) As List(Of cCode)
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader
            Dim locod As List(Of cCode) = Nothing
            Dim ocod As cCode
            Try

                'setting parameters
                oprm = New cParams
                oprm.companyid = pCompanyID
                oprm.paramtype = "lst_code"
                oprm.skey1 = pCodeType

                locod = New List(Of cCode)

                rdr = GetRows(odal, oprm)
                While rdr.Read
                    ocod = New cCode
                    ocod.CodeID = comlib.GetText(rdr.Item("CodeID"))
                    ocod.CodeName = comlib.GetText(rdr.Item("CodeName"))
                    ocod.CodeCategory = comlib.GetText(rdr.Item("CodeCategory"))
                    ocod.SeqNum = comlib.GetInteger(rdr.Item("SeqNum"))
                    ocod.IsSystemCode = comlib.GetBool(rdr.Item("IsSystemCode"))
                    locod.Add(ocod)
                End While
            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                oprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return locod
        End Function
        Public Function GetCode(ByVal pCompanyID As String, ByVal pCodeType As String, ByVal pCodeID As String) As cCode
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader
            Dim oCode As cCode = Nothing
            Try

                'setting parameters
                oprm = New cParams
                oprm.companyid = pCompanyID
                oprm.paramtype = "key_code"
                oprm.skey1 = pCodeType
                oprm.skey2 = pCodeID

                oCode = New cCode

                rdr = GetRows(odal, oprm)
                If rdr.Read Then
                    oCode.CompanyID = comlib.GetText(rdr("CompanyID"))
                    oCode.CodeType = comlib.GetText(rdr("CodeType"))
                    oCode.CodeID = comlib.GetText(rdr("CodeID"))
                    oCode.CodeName = comlib.GetText(rdr("CodeName"))
                    oCode.CodeCategory = comlib.GetText(rdr("CodeCategory"))
                    oCode.IsSystemCode = comlib.GetBool(rdr("IsSystemCode"))
                    oCode.SeqNum = comlib.GetInteger(rdr("SeqNum"))
                    oCode.Notes = comlib.GetText(rdr("Notes"))
                    oCode.CreatedBy = comlib.GetText(rdr("CreatedBy"))
                    oCode.CreatedDate = comlib.CToDate(rdr("CreatedDate"))
                    oCode.UpdatedBy = comlib.GetText(rdr("UpdatedBy"))
                    oCode.UpdatedDate = comlib.CToDate(rdr("UpdatedDate"))
                Else
                    oCode = Nothing
                End If

                Return oCode
            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                oprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
        End Function
        Public Function SaveCode(ByVal pMode As String, ByVal pCode As cCode, ByVal pProcessBy As String) As cResult
            Dim odal As New SQLAccess("core")
            Try
                ores = New cResult

                odal.BeginTransactions()

                odal.ExecuteCommandSP("usp_save_tcode",
                                     odal.CreateParameter("@SaveMode", SqlDbType.VarChar, Left(pMode, 1)),
                                     odal.CreateParameter("@companyid", SqlDbType.VarChar, pCode.CompanyID),
                                     odal.CreateParameter("@CodeType", SqlDbType.VarChar, pCode.CodeType),
                                     odal.CreateParameter("@CodeID", SqlDbType.VarChar, pCode.CodeID),
                                     odal.CreateParameter("@CodeName", SqlDbType.VarChar, pCode.CodeName),
                                     odal.CreateParameter("@IsSystemCode", SqlDbType.Bit, pCode.IsSystemCode),
                                     odal.CreateParameter("@CodeCategory", SqlDbType.VarChar, pCode.CodeCategory),
                                     odal.CreateParameter("@SeqNum", SqlDbType.Int, pCode.SeqNum),
                                     odal.CreateParameter("@Notes", SqlDbType.VarChar, pCode.Notes),
                                     odal.CreateParameter("@ProcessBy", SqlDbType.VarChar, pProcessBy))
                ores.InvalidMessage = odal.ReturnValue(1).ToString

                If ores.InvalidMessage = "" Then
                    odal.CommitTransactions()
                Else
                    odal.RollBackTransactions()
                End If

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return ores
        End Function
        Public Function DeleteCode(ByVal pCompanyID As String, ByVal pCodeType As String, ByVal pCodeID As String, pNotes As String, ByVal pProcessBy As String) As cResult
            Dim odal As New SQLAccess("core")
            Try
                'setting parameters
                oprm = New cParams
                oprm.companyid = pCompanyID
                oprm.paramtype = "DEL_CODE"
                oprm.skey1 = pCodeType
                oprm.skey2 = pCodeID
                oprm.Notes = pNotes
                oprm.ProcessBy = pProcessBy

                ores = RunTask(odal, oprm)

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                Throw ex
            Finally
                oprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return ores
        End Function

        Public Function GetListNoIdP(pprm As cParams) As cListNoIdP
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            'Dim oListNoIdC As cListNoIdC
            Dim oListNoId As cListNoIdP
            oListNoId = New cListNoIdP
            oListNoId.chlid = New List(Of cListNoIdC)()

            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "ListNoIdDT"),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, "parent"),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.skey2)))
                While rdr.Read
                    oListNoId = New cListNoIdP
                    oListNoId.ListNoId = comlib.GetText(rdr.Item("ListNo"))
                End While
            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try

            Return oListNoId

        End Function

        Public Function GetListNoIdC(pprm As cParams) As cListNoIdP
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oListNoIdC As cListNoIdC
            Dim oListNoId As cListNoIdP
            oListNoId = New cListNoIdP
            oListNoId.chlid = New List(Of cListNoIdC)()

            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "ListNoIdDT"),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, "child"),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.skey2)))
                While rdr.Read
                    oListNoIdC = New cListNoIdC
                    oListNoIdC.ListNoId = comlib.GetText(rdr.Item("ListNo"))
                    oListNoIdC.PolicyID = comlib.GetText(rdr.Item("PolicyID"))
                    oListNoIdC.CurrencyID = comlib.GetText(rdr.Item("CurrencyID"))
                    oListNoIdC.SystemTreatyNumber = comlib.GetText(rdr.Item("SystemTreatyNumber"))
                    oListNoIdC.ReinsCo = comlib.GetText(rdr.Item("ReinsCo"))
                    oListNoIdC.PlanCode = comlib.GetText(rdr.Item("PlanCode"))
                    oListNoIdC.Amount = comlib.GetDouble(rdr.Item("NettReinsPremium"))
                    oListNoId.chlid.Add(oListNoIdC)
                End While
            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try

            Return oListNoId

        End Function

        Public Function GetMenuList(pprm As cParams) As cMenuList
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oMenuListDetail As cMenuListDetail
            Dim oMenu As cMenuList
            oMenu = New cMenuList
            oMenu.cMenuListDetail = New List(Of cMenuListDetail)()


            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "Menu_List"),
                        odal.CreateParameter("@userid", SqlDbType.VarChar, comlib.GetText(pprm.userid)))
                While rdr.Read
                    oMenuListDetail = New cMenuListDetail

                    oMenuListDetail.CompanyId = comlib.GetText(rdr.Item("CompanyId"))
                    oMenuListDetail.ObjectId = comlib.GetText(rdr.Item("ObjectId"))
                    oMenuListDetail.ObjectName = comlib.GetText(rdr.Item("ObjectName"))
                    oMenuListDetail.ObjectTitle = comlib.GetText(rdr.Item("ObjectTitle"))
                    oMenuListDetail.ObjectType = comlib.GetText(rdr.Item("ObjectType"))
                    oMenuListDetail.ObjectParent = comlib.GetText(rdr.Item("ObjectParent"))
                    oMenuListDetail.ObjectSequence = comlib.GetText(rdr.Item("ObjectSequence"))
                    oMenuListDetail.ObjectLink = comlib.GetText(rdr.Item("ObjectLink"))
                    oMenuListDetail.ObjectImage = comlib.GetText(rdr.Item("ObjectImage"))
                    oMenuListDetail.LinkChild = comlib.GetText(rdr.Item("LinkChild"))
                    oMenuListDetail.ObjectShortcut = comlib.GetBool(rdr.Item("ObjectShortcut"))
                    oMenu.cMenuListDetail.Add(oMenuListDetail)
                    'oMenu.ObjectparentH = comlib.GetText(rdr.Item("ObjectparentH"))
                    'oMenu.ObjectNameH = comlib.GetText(rdr.Item("ObjectNameH"))





                End While
                'oTAX.message = "SUCCESS"
                'oTAX.result = ""

                'Dim listMenu As List(Of cMenuListDetail2) = New List(Of cMenuListDetail2)
                'listMenu = New cMenuListDetail
                'listMenu = New cMenuList


                'Child = From menuch In oMenu.cMenuListDetail
                '                        Where menuch.ObjectParent = menu.ObjectId
                '                        Order By menuch.ObjectSequence Descending
                '                        Select
                '                            menuch.ObjectId,
                '                            menuch.ObjectName,
                'menuch.ObjectLink

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            'Dim listMenu As List(Of cMenuListDetail2) = New List(Of cMenuListDetail2)()
            'listMenu = (From menu In oMenu.cMenuListDetail
            '            Where menu.ObjectType = "G"
            '            Select New cMenuListDetail With {
            '                    .ObjectId = menu.ObjectId,
            '                    .ObjectName = menu.ObjectName,
            '                    .ObjectLink = menu.ObjectLink,
            '                    .Child = From menuch In oMenu.cMenuListDetail
            '                             Where menuch.ObjectParent = menu.ObjectId
            '                             Order By menuch.ObjectSequence Descending
            '                             Select New cMenuListDetail With {
            '                                     .ObjectId = menuch.ObjectId,
            '                                     .ObjectName = menuch.ObjectName,
            '                                     .ObjectLink = menuch.ObjectLink
            '                                 }})

            Return oMenu

        End Function

#End Region

#Region "List Reject"

        'Created : RW
        'Date   : 8 June 2018
        'Desc   : List Reject

        Public Function GetRejected(pprm As cParams) As cRejectedList
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oRejected As cRejectedList = Nothing
            oRejected = New cRejectedList
            oRejected.cRejectedDetail = New List(Of cRejectedDetail)()

            Dim oRejectedDetail As cRejectedDetail


            Try

                rdr = odal.ExecuteDataReader("sp_get_list_rejected", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@view", SqlDbType.VarChar, comlib.GetText(pprm.paramtype)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.skey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pprm.skey3)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pprm.skey4)),
                        odal.CreateParameter("@skey5", SqlDbType.VarChar, comlib.GetText(pprm.skey5)),
                        odal.CreateParameter("@skey6", SqlDbType.VarChar, comlib.GetText(pprm.skey6)),
                        odal.CreateParameter("@skey7", SqlDbType.VarChar, comlib.GetText(pprm.skey7)),
                        odal.CreateParameter("@skey8", SqlDbType.VarChar, comlib.GetText(pprm.skey8)),
                        odal.CreateParameter("@skey9", SqlDbType.VarChar, comlib.GetText(pprm.skey9)),
                        odal.CreateParameter("@skey10", SqlDbType.VarChar, comlib.GetText(pprm.skey10)),
                        odal.CreateParameter("@ikey1", SqlDbType.Int, comlib.GetInteger(pprm.ikey1)),
                        odal.CreateParameter("@ikey2", SqlDbType.Int, comlib.GetInteger(pprm.ikey2)),
                        odal.CreateParameter("@ikey3", SqlDbType.Int, comlib.GetInteger(pprm.ikey3)),
                        odal.CreateParameter("@ikey4", SqlDbType.Int, comlib.GetInteger(pprm.ikey4)),
                        odal.CreateParameter("@ikey5", SqlDbType.Int, comlib.GetInteger(pprm.ikey5)),
                        odal.CreateParameter("@dkey1", SqlDbType.DateTime, comlib.CToDate(pprm.dkey1)),
                        odal.CreateParameter("@dkey2", SqlDbType.DateTime, comlib.CToDate(pprm.dkey2)),
                        odal.CreateParameter("@dkey3", SqlDbType.DateTime, comlib.CToDate(pprm.dkey3)),
                        odal.CreateParameter("@dkey4", SqlDbType.DateTime, comlib.CToDate(pprm.dkey4)),
                        odal.CreateParameter("@dkey5", SqlDbType.DateTime, comlib.CToDate(pprm.dkey5)),
                        odal.CreateParameter("@userid", SqlDbType.VarChar, comlib.GetText(pprm.ProcessBy)),
                        odal.CreateParameter("@pageno", SqlDbType.VarChar, comlib.GetText(pprm.pageno)),
                        odal.CreateParameter("@pagesize", SqlDbType.VarChar, comlib.GetText(pprm.pagesize)))
                While rdr.Read
                    oRejectedDetail = New cRejectedDetail
                    oRejectedDetail.FormNum = comlib.GetText(rdr.Item("FormNum"))
                    oRejectedDetail.Dept = comlib.GetText(rdr.Item("Dept"))
                    oRejectedDetail.RejectDate = comlib.GetText(rdr.Item("RejectDt"))
                    oRejectedDetail.RejectReason = comlib.GetText(rdr.Item("RejectReason"))
                    oRejectedDetail.RejectBy = comlib.GetText(rdr.Item("RejectBy"))
                    oRejectedDetail.RejectType = comlib.GetText(rdr.Item("RejectType"))
                    oRejectedDetail.CopiedTo = comlib.GetText(rdr.Item("CopiedTo"))
                    oRejectedDetail.PolRelated = comlib.GetText(rdr.Item("PolRelated"))
                    oRejected.cRejectedDetail.Add(oRejectedDetail)
                End While
                oRejected.message = "SUCCESS"
                oRejected.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oRejected

        End Function
        'Update Ronald 29 May End

        Public Function ProcessCreateCopyGER(pGer As cGER) As cResult
            Dim odal As New SQLAccess("core")
            Try
                ores = New cResult

                odal.BeginTransactions()

                odal.ExecuteCommandSP("usp_process_createcopyger",
                                     odal.CreateParameter("@Companyid", SqlDbType.VarChar, pGer.CompanyID),
                                     odal.CreateParameter("@FormNumNew", SqlDbType.VarChar, pGer.FormNumNew, 15, ParameterDirection.InputOutput),
                                     odal.CreateParameter("@FormNum", SqlDbType.VarChar, pGer.FormNum),
                                     odal.CreateParameter("@GERType", SqlDbType.VarChar, pGer.GERType),
                                     odal.CreateParameter("@ProcessBy", SqlDbType.VarChar, pGer.UserID))
                ores.ReturnValue = odal.ReturnValue(1).ToString

                If ores.ReturnValue <> "" Then
                    ores.InvalidMessage = ""
                    odal.CommitTransactions()
                Else
                    odal.RollBackTransactions()
                End If

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return ores
        End Function


        'Created : RS
        'Date    : 4 September 2018
        'Desc    : Get Data Policy List GER

        Public Function getGERPolicyNoList(pPolicy As policyListParameter) As policyListResult
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim listPolicy As policyListDetail = Nothing
            Dim oPolicy As policyListResult = Nothing

            Dim sort As String = ""

            Try

                For Each obj In pPolicy.sortParam
                    sort = Convert.ToString(comlib.GetInteger(obj.column) + 4) + " " + obj.dir
                Next

                pPolicy.PageNum = (pPolicy.PageNum + pPolicy.PageSize) / pPolicy.PageSize

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                                     odal.CreateParameter("@table", SqlDbType.VarChar, "ger_policyNolist"),
                                     odal.CreateParameter("@skey2", SqlDbType.VarChar, pPolicy.Search),
                                     odal.CreateParameter("@PageSize", SqlDbType.VarChar, pPolicy.PageSize),
                                     odal.CreateParameter("@PageNum", SqlDbType.VarChar, pPolicy.PageNum),
                                     odal.CreateParameter("@skey10", SqlDbType.VarChar, sort),
                                     odal.CreateParameter("@CompanyID", SqlDbType.VarChar, pPolicy.companyID))

                oPolicy = New policyListResult
                oPolicy.policyList = New List(Of policyListDetail)()

                While rdr.Read
                    listPolicy = New policyListDetail
                    listPolicy.policyNumber = comlib.GetText(rdr.Item("policyNumber"))
                    listPolicy.totalAmount = comlib.GetText(rdr.Item("totalAmount"))
                    listPolicy.paidAmount = comlib.GetText(rdr.Item("paidAmount"))
                    listPolicy.remainingAmount = comlib.GetText(rdr.Item("remainingAmount"))
                    oPolicy.TotalFilter = comlib.GetInteger(rdr.Item("TotalFilter"))
                    oPolicy.TotalRows = comlib.GetInteger(rdr.Item("TotalRows"))
                    oPolicy.policyList.Add(listPolicy)
                End While

                If listPolicy Is Nothing Then
                    oPolicy.Result = "FAILURE"
                    oPolicy.Message = "Data Not Found"
                Else
                    oPolicy.Result = "SUCCESS"
                    oPolicy.Message = ""
                End If


            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try

            Return oPolicy
        End Function

        'Created : RS
        'Date    : 4 September 2018
        'Desc    : Get Beneficiary List GER

        Public Function getGERBeneficiaryListView(pprm As beneficiaryListParameter) As beneficiaryListResult
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oGERBen As beneficiaryListResult = Nothing
            oGERBen = New beneficiaryListResult
            oGERBen.beneficiaryList = New List(Of ListGERBeneficiaryDetail)()

            Dim oGERBenListDetail As ListGERBeneficiaryDetail

            Dim sort As String = ""

            Try

                For Each obj In pprm.sortParam
                    sort = Convert.ToString(comlib.GetInteger(obj.column) + 4) + " " + obj.dir
                Next

                pprm.PageNum = (pprm.PageNum + pprm.PageSize) / pprm.PageSize

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                                     odal.CreateParameter("@table", SqlDbType.VarChar, "ger_BeneficiaryListView"),
                                     odal.CreateParameter("@skey2", SqlDbType.VarChar, pprm.Search),
                                     odal.CreateParameter("@PageSize", SqlDbType.VarChar, pprm.PageSize),
                                     odal.CreateParameter("@PageNum", SqlDbType.VarChar, pprm.PageNum),
                                     odal.CreateParameter("@skey10", SqlDbType.VarChar, sort),
                                     odal.CreateParameter("@skey1", SqlDbType.VarChar, pprm.sType),
                                     odal.CreateParameter("@CompanyID", SqlDbType.VarChar, pprm.companyID))

                While rdr.Read
                    oGERBenListDetail = New ListGERBeneficiaryDetail
                    oGERBenListDetail.BenID = comlib.GetText(rdr.Item("BenID"))
                    oGERBenListDetail.BeneficiaryName = comlib.GetText(rdr.Item("BeneficiaryName"))
                    oGERBenListDetail.Beneficiary_Bank_Name = comlib.GetText(rdr.Item("Beneficiary_Bank_Name"))
                    oGERBenListDetail.Beneficiary_Bank_Account = comlib.GetText(rdr.Item("Beneficiary_Bank_Account"))
                    oGERBenListDetail.Beneficiary_Bank_Branch = comlib.GetText(rdr.Item("Beneficiary_Bank_Branch"))
                    oGERBenListDetail.Beneficiary_Bank_City = comlib.GetText(rdr.Item("Beneficiary_Bank_City"))
                    oGERBenListDetail.Beneficiary_Email = comlib.GetText(rdr.Item("Beneficiary_Email"))
                    oGERBenListDetail.OnlyForDept = comlib.GetText(rdr.Item("OnlyForDept"))
                    oGERBenListDetail.BeneficiaryTypeCd = comlib.GetText(rdr.Item("BeneficiaryTypeCd"))
                    oGERBenListDetail.BeneficiaryResidenStatusCd = comlib.GetText(rdr.Item("BeneficiaryResidenStatusCd"))
                    oGERBenListDetail.BeneficiaryTranTypeCd = comlib.GetText(rdr.Item("BeneficiaryTranTypeCd"))
                    oGERBenListDetail.BeneficiaryTranfacilityTypeCd = comlib.GetText(rdr.Item("BeneficiaryTranfacilityTypeCd"))


                    oGERBenListDetail.BeneficiaryTypeCode = comlib.GetText(rdr.Item("BeneficiaryTypeCode"))
                    oGERBenListDetail.BeneficiaryResidenStatusCode = comlib.GetText(rdr.Item("BeneficiaryResidenStatusCode"))
                    oGERBenListDetail.BeneficiaryTranTypeCode = comlib.GetText(rdr.Item("BeneficiaryTranTypeCode"))
                    oGERBenListDetail.BeneficiaryTranfacilityTypeCode = comlib.GetText(rdr.Item("BeneficiaryTranfacilityTypeCode"))

                    oGERBenListDetail.BeneficiaryBankCode = comlib.GetText(rdr.Item("Beneficiary_Bank_Code"))

                    oGERBen.TotalFilter = comlib.GetInteger(rdr.Item("TotalFilter"))
                    oGERBen.TotalRows = comlib.GetInteger(rdr.Item("TotalRows"))

                    oGERBen.beneficiaryList.Add(oGERBenListDetail)
                End While

                oGERBen.Message = "SUCCESS"
                oGERBen.Result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oGERBen

        End Function


        'Created : RS
        'Date    : 17 September 2018
        'Desc    : Get CAR Filter List

        Public Function getCARFilterListView(pprm As carFilterListParameter) As carFilterListResult
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oCARFilter As carFilterListResult = Nothing
            oCARFilter = New carFilterListResult
            oCARFilter.carFilterList = New List(Of carFilterListDetail)()

            Dim oCARFilterListDetail As carFilterListDetail

            Dim sort As String = ""

            Try

                For Each obj In pprm.sortParam
                    sort = Convert.ToString(comlib.GetInteger(obj.column) + 4) + " " + obj.dir
                Next

                pprm.PageNum = (pprm.PageNum + pprm.PageSize) / pprm.PageSize

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                                     odal.CreateParameter("@table", SqlDbType.VarChar, "ger_CARFilterListView"),
                                     odal.CreateParameter("@skey2", SqlDbType.VarChar, pprm.Search),
                                     odal.CreateParameter("@PageSize", SqlDbType.VarChar, pprm.PageSize),
                                     odal.CreateParameter("@PageNum", SqlDbType.VarChar, pprm.PageNum),
                                     odal.CreateParameter("@skey10", SqlDbType.VarChar, sort),
                                     odal.CreateParameter("@skey1", SqlDbType.VarChar, pprm.sType),
                                     odal.CreateParameter("@CompanyID", SqlDbType.VarChar, pprm.companyID))

                While rdr.Read
                    oCARFilterListDetail = New carFilterListDetail
                    oCARFilterListDetail.carNumber = comlib.GetText(rdr.Item("carNumber"))
                    oCARFilterListDetail.paidAmount = comlib.GetText(rdr.Item("paidAmount"))
                    oCARFilterListDetail.totalAmount = comlib.GetText(rdr.Item("totalAmount"))

                    oCARFilter.TotalFilter = comlib.GetInteger(rdr.Item("TotalFilter"))
                    oCARFilter.TotalRows = comlib.GetInteger(rdr.Item("TotalRows"))

                    oCARFilter.carFilterList.Add(oCARFilterListDetail)
                End While

                oCARFilter.Message = "SUCCESS"
                oCARFilter.Result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oCARFilter

        End Function

#End Region

#Region "GER"

        'Created: RS
        'Date    : 24 September 2018
        'Desc    : Policy Bulk Detail List

        Public Function getPolicyBulkDetailListView(pprm As gerPolicyBulkDetailParameter) As gerPolicyBulkDetailResult
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oGERbulk As gerPolicyBulkDetailResult = Nothing
            oGERbulk = New gerPolicyBulkDetailResult
            oGERbulk.gerPolicyBulkDetailList = New List(Of gerPolicyBulkDetailSub)()

            Dim oGERBulkSubDetail As gerPolicyBulkDetailSub

            Dim sort As String = ""

            Try

                For Each obj In pprm.sortParam
                    sort = Convert.ToString(comlib.GetInteger(obj.column) + 4) + " " + obj.dir
                Next

                pprm.PageNum = (pprm.PageNum + pprm.PageSize) / pprm.PageSize

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                                     odal.CreateParameter("@table", SqlDbType.VarChar, "ger_policyBulkDetailList"),
                                     odal.CreateParameter("@skey2", SqlDbType.VarChar, pprm.Search),
                                     odal.CreateParameter("@PageSize", SqlDbType.VarChar, pprm.PageSize),
                                     odal.CreateParameter("@PageNum", SqlDbType.VarChar, pprm.PageNum),
                                     odal.CreateParameter("@skey10", SqlDbType.VarChar, sort),
                                     odal.CreateParameter("@skey1", SqlDbType.VarChar, pprm.formNum),
                                     odal.CreateParameter("@CompanyID", SqlDbType.VarChar, pprm.companyID))

                While rdr.Read
                    oGERBulkSubDetail = New gerPolicyBulkDetailSub

                    oGERBulkSubDetail.subGER = comlib.GetText(rdr.Item("subGER"))
                    oGERBulkSubDetail.mainGER = comlib.GetText(rdr.Item("mainGER"))
                    oGERBulkSubDetail.policyNum = comlib.GetText(rdr.Item("policyNum"))
                    oGERBulkSubDetail.beneficiaryName = comlib.GetText(rdr.Item("beneficiaryName"))
                    oGERBulkSubDetail.beneficiary_Bank_Name = comlib.GetText(rdr.Item("beneficiary_Bank_Name"))
                    oGERBulkSubDetail.beneficiary_Bank_Account = comlib.GetText(rdr.Item("beneficiary_Bank_Account"))
                    oGERBulkSubDetail.totalAmount = comlib.GetText(rdr.Item("totalAmount"))

                    oGERbulk.TotalFilter = comlib.GetInteger(rdr.Item("TotalFilter"))
                    oGERbulk.TotalRows = comlib.GetInteger(rdr.Item("TotalRows"))

                    oGERbulk.gerPolicyBulkDetailList.Add(oGERBulkSubDetail)
                End While

                oGERbulk.Message = "SUCCESS"
                oGERbulk.Result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oGERbulk

        End Function

        Public Function SaveGERMTFDetail(pGerMTF As cBulkGERMTFDetail) As cResult
            Dim odal As New SQLAccess("core")
            Try
                ores = New cResult
                odal.BeginTransactions()

                odal.ExecuteCommandSP("usp_DeleteGER_MTFDetail",
                odal.CreateParameter("@FormNum", SqlDbType.VarChar, pGerMTF.FormNum))

                For Each bulkValue As cGERMTFDetail In pGerMTF.bulkGERMTFDetail
                    odal.ExecuteCommandSP("usp_SaveGER_MTFDetail",
                   odal.CreateParameter("@CompanyID", SqlDbType.VarChar, pGerMTF.CompanyID),
                   odal.CreateParameter("@FormNum", SqlDbType.VarChar, pGerMTF.FormNum),
                   odal.CreateParameter("@NomorRekening", SqlDbType.VarChar, bulkValue.NomorRekening),
                   odal.CreateParameter("@NamaPemilikRekening", SqlDbType.VarChar, bulkValue.NamaPemilikRekening),
                   odal.CreateParameter("@Bank", SqlDbType.VarChar, bulkValue.Bank),
                   odal.CreateParameter("@Currency", SqlDbType.VarChar, bulkValue.Currency),
                   odal.CreateParameter("@Amount", SqlDbType.Float, comlib.GetDouble(bulkValue.Amount)),
                   odal.CreateParameter("@Keterangan", SqlDbType.VarChar, bulkValue.Keterangan),
                   odal.CreateParameter("@Email", SqlDbType.VarChar, bulkValue.Email),
                   odal.CreateParameter("@UserID", SqlDbType.VarChar, pGerMTF.UserID))
                Next

                ores.ReturnValue = "Berhasil"


                If ores.ReturnValue = "Berhasil" Then
                    odal.CommitTransactions()
                    ores.InvalidMessage = ""
                    ores.Message = "SUCCESS"
                Else
                    odal.RollBackTransactions()
                End If

            Catch ex As Exception
                odal.RollBackTransactions()
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return ores
        End Function

        'Created : RW
        'Date   : 6 June 2018
        'Desc   : SAVE Data GER Car Summary

        Public Function SaveGERCARSummary(pGer As cGER) As cResult
            Dim odal As New SQLAccess("core")
            Try
                ores = New cResult

                odal.BeginTransactions()

                odal.ExecuteCommandSP("usp_SaveGER",
                odal.CreateParameter("@ProcessType", SqlDbType.VarChar, pGer.ProcessType),
                odal.CreateParameter("@CompanyID", SqlDbType.VarChar, pGer.CompanyID),
                odal.CreateParameter("@Curr", SqlDbType.VarChar, pGer.Currency),
                odal.CreateParameter("@FormNum", SqlDbType.VarChar, pGer.FormNum),
                odal.CreateParameter("@GerType", SqlDbType.VarChar, pGer.GERType),
                odal.CreateParameter("@MainFormNum", SqlDbType.VarChar, pGer.MainFormNum),
                odal.CreateParameter("@FormType", SqlDbType.VarChar, Left(pGer.FormNum, 3)),
                odal.CreateParameter("@FromDept", SqlDbType.VarChar, pGer.FromDept),
                odal.CreateParameter("@AdvanceFormNum", SqlDbType.VarChar, pGer.AdvanceFormNum),
                odal.CreateParameter("@CreateDt", SqlDbType.DateTime, pGer.CreateDt),
                odal.CreateParameter("@CheckedDt", SqlDbType.DateTime, pGer.CheckedDt),
                odal.CreateParameter("@ApprovedDt", SqlDbType.DateTime, pGer.ApprovedDt),
                odal.CreateParameter("@CreateBy", SqlDbType.VarChar, pGer.CreateBy),
                odal.CreateParameter("@CheckedBy", SqlDbType.VarChar, pGer.CheckedBy),
                odal.CreateParameter("@ApprovedBy", SqlDbType.Int, pGer.ApprovedBy),
                odal.CreateParameter("@TotalAmount", SqlDbType.VarChar, pGer.TotalAmount),
                odal.CreateParameter("@DueAmount", SqlDbType.VarChar, pGer.DueAmount),
                odal.CreateParameter("@AdvanceAmount", SqlDbType.VarChar, pGer.AdvanceAmount),
                odal.CreateParameter("@FormStatus", SqlDbType.VarChar, pGer.FormStatus),
                odal.CreateParameter("@ExchangeRate", SqlDbType.VarChar, pGer.ExchangeRate),
                odal.CreateParameter("@TransactionCode", SqlDbType.VarChar, pGer.TransactionCode),
                odal.CreateParameter("@BankName", SqlDbType.VarChar, pGer.BankName),
                odal.CreateParameter("@BankAccNumber", SqlDbType.VarChar, pGer.BankAccNumber),
                odal.CreateParameter("@BeneficiaryName", SqlDbType.VarChar, pGer.BeneficiaryName),
                odal.CreateParameter("@BeneficiaryBankCode", SqlDbType.VarChar, pGer.BeneficiaryBankCode),
                odal.CreateParameter("@BeneficiaryBankAccount", SqlDbType.VarChar, pGer.BeneficiaryBankAccount),
                odal.CreateParameter("@BeneficiaryBankBranch", SqlDbType.VarChar, pGer.BeneficiaryBankBranch),
                odal.CreateParameter("@BeneficiaryBankCity", SqlDbType.VarChar, pGer.BeneficiaryBankCity),
                odal.CreateParameter("@BeneficiaryEmail", SqlDbType.VarChar, pGer.BeneficiaryEmail),
                odal.CreateParameter("@BeneficiaryAccountCurrency", SqlDbType.VarChar, pGer.BeneficiaryAccountCurrency),
                odal.CreateParameter("@TaxAmount", SqlDbType.VarChar, pGer.TaxAmount),
                odal.CreateParameter("@NettAmount", SqlDbType.VarChar, pGer.NettAmount),
                odal.CreateParameter("@PolRelated", SqlDbType.VarChar, pGer.PolRelated),
                odal.CreateParameter("@PolicyNum", SqlDbType.VarChar, pGer.PolicyNum),
                odal.CreateParameter("@FormLocation", SqlDbType.VarChar, pGer.FormLocation),
                odal.CreateParameter("@Subject", SqlDbType.VarChar, pGer.Subject),
                odal.CreateParameter("@PaidBy", SqlDbType.VarChar, pGer.PaidBy),
                odal.CreateParameter("@Taxable", SqlDbType.VarChar, pGer.Taxable),
                odal.CreateParameter("@PoNum", SqlDbType.VarChar, pGer.PoNum),
                odal.CreateParameter("@Budgeted", SqlDbType.VarChar, pGer.Budgeted),
                odal.CreateParameter("@sBenID", SqlDbType.VarChar, pGer.sBenID),
                odal.CreateParameter("@BeneficiaryTypeCd", SqlDbType.VarChar, pGer.BeneficiaryTypeCd),
                odal.CreateParameter("@BeneficiaryResidenStatusCd", SqlDbType.VarChar, pGer.BeneficiaryResidentStatusCd),
                odal.CreateParameter("@BeneficiaryTranTypeCd", SqlDbType.VarChar, pGer.BeneficiaryTranTypeCd),
                odal.CreateParameter("@TaxSubsidy", SqlDbType.Decimal, pGer.TaxSubsidy),
                odal.CreateParameter("@ToGenerate", SqlDbType.VarChar, pGer.ToGenerate),
                odal.CreateParameter("@GenerateRemark", SqlDbType.VarChar, pGer.GenerateRemark),
                odal.CreateParameter("@Journalized", SqlDbType.VarChar, pGer.Journalized),
                odal.CreateParameter("@ToApprovedByTax", SqlDbType.VarChar, pGer.ToApprovedByTax),
                odal.CreateParameter("@DateFrom", SqlDbType.DateTime, pGer.travelDateFrom),
                odal.CreateParameter("@DateUntil", SqlDbType.DateTime, pGer.travelDateUntil),
                odal.CreateParameter("@TravelRange", SqlDbType.Int, pGer.travelDateRange),
                odal.CreateParameter("@TotalIdrAmount", SqlDbType.Float, comlib.GetDouble(pGer.travelTotalIDRAmount)),
                odal.CreateParameter("@CreditCardOAmount", SqlDbType.Float, comlib.GetDouble(pGer.travelCreditCardOAmount)),
                odal.CreateParameter("@CreditCardOCurr", SqlDbType.VarChar, pGer.travelCreditCardOCurr),
                odal.CreateParameter("@CreditCardExchangeRate", SqlDbType.Float, comlib.GetDouble(pGer.travelCreditCardExchangeRate)),
                odal.CreateParameter("@CreditCardIDRAmount", SqlDbType.Float, comlib.GetDouble(pGer.travelCreditCardIDRAmount)),
                odal.CreateParameter("@PaidInCashOAmount", SqlDbType.Float, comlib.GetDouble(pGer.travelPaidInCashOAmount)),
                odal.CreateParameter("@PaidInCashOCurr", SqlDbType.VarChar, pGer.travelPaidInCashOCurr),
                odal.CreateParameter("@PaidInCashExchangeRate", SqlDbType.Float, comlib.GetDouble(pGer.travelPaidInCashExchangeRate)),
                odal.CreateParameter("@PaidInCashIDRAmount", SqlDbType.Float, comlib.GetDouble(pGer.travelPaidInCashIDRAmount)),
                odal.CreateParameter("@PrePaidOAmount", SqlDbType.Float, comlib.GetDouble(pGer.travelPrePaidOAmount)),
                odal.CreateParameter("@PrePaidOCurr", SqlDbType.VarChar, pGer.travelPrePaidOCurr),
                odal.CreateParameter("@PrePaidExchangeRate", SqlDbType.Float, comlib.GetDouble(pGer.travelPrePaidExchangeRate)),
                odal.CreateParameter("@PrePaidIDRAmount", SqlDbType.Float, comlib.GetDouble(pGer.travelPrePaidIDRAmount)),
                odal.CreateParameter("@CashAdvanceNum", SqlDbType.VarChar, pGer.travelCashAdvanceNum),
                odal.CreateParameter("@CashAdvanceOAmount", SqlDbType.Float, comlib.GetDouble(pGer.travelCashAdvanceOAmount)),
                odal.CreateParameter("@CashAdvanceOCurr", SqlDbType.VarChar, pGer.travelCashAdvanceOCurr),
                odal.CreateParameter("@CashAdvanceExchangeRate", SqlDbType.Float, comlib.GetDouble(pGer.travelCashAdvanceExchangeRate)),
                odal.CreateParameter("@CashAdvanceIDRAmount", SqlDbType.Float, comlib.GetDouble(pGer.travelCashAdvanceIDRAmount)),
                odal.CreateParameter("@DueAmountTravel", SqlDbType.Float, comlib.GetDouble(pGer.travelDueAmountTravel)),
                odal.CreateParameter("@TravellerName", SqlDbType.VarChar, pGer.travelTravellerName),
                odal.CreateParameter("@DepartmentTravel", SqlDbType.VarChar, pGer.travelDepartment),
                odal.CreateParameter("@TripDestination", SqlDbType.VarChar, pGer.travelTripDestination),
                odal.CreateParameter("@TripPurpose", SqlDbType.VarChar, pGer.travelTripPurpose),
                odal.CreateParameter("@TravellerPosition", SqlDbType.VarChar, pGer.travelTravellerPosition),
                odal.CreateParameter("@TotalIDRAmountEnter", SqlDbType.Float, comlib.GetDouble(pGer.enterTotalIDRAmount)),
                odal.CreateParameter("@DueAmountEnter", SqlDbType.Float, comlib.GetDouble(pGer.enterTotalDueAmount)),
                odal.CreateParameter("@PayCat", SqlDbType.VarChar, pGer.PayCat),
                odal.CreateParameter("@PayeeDOB", SqlDbType.VarChar, pGer.PayeeDOB),
                odal.CreateParameter("@TransMode", SqlDbType.VarChar, pGer.travelTransport),
                odal.CreateParameter("@Millage", SqlDbType.VarChar, pGer.travelMillage),
                odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))

                ores.ReturnValue = odal.ReturnValue(1).ToString

                If ores.ReturnValue = "Berhasil" Then
                    ores.InvalidMessage = ""
                    ores.Message = "SUCCESS"
                    odal.CommitTransactions()

                    If pGer.listTravelDetail.Count <> 0 Then

                        odal.BeginTransactions()

                        odal.ExecuteCommandSP("usp_SaveTER_Detail",
                                             odal.CreateParameter("@Table", SqlDbType.VarChar, "DELETE_TRAVEL"),
                                             odal.CreateParameter("@CompanyID", SqlDbType.VarChar, pGer.CompanyID),
                                             odal.CreateParameter("@FormNum", SqlDbType.VarChar, pGer.FormNum))

                        odal.CommitTransactions()

                        odal.BeginTransactions()

                        For Each bulkValue As travelDetailData In pGer.listTravelDetail

                            odal.ExecuteCommandSP("usp_SaveTER_Detail",
                                             odal.CreateParameter("@Table", SqlDbType.VarChar, "INSERT_TRAVEL"),
                                             odal.CreateParameter("@CompanyID", SqlDbType.VarChar, comlib.GetText(pGer.CompanyID)),
                                             odal.CreateParameter("@FormNum", SqlDbType.Char, comlib.GetText(pGer.FormNum)),
                                             odal.CreateParameter("@SeqNum", SqlDbType.Int, comlib.GetInteger(bulkValue.seqNum)),
                                             odal.CreateParameter("@Nomor", SqlDbType.VarChar, comlib.GetText(bulkValue.nomor)),
                                             odal.CreateParameter("@TypeOfExpenses", SqlDbType.VarChar, comlib.GetText(bulkValue.typeOfExpenses)),
                                             odal.CreateParameter("@OriginalAmount", SqlDbType.Float, comlib.GetDouble(bulkValue.originalAmount)),
                                             odal.CreateParameter("@OriginalCurr", SqlDbType.VarChar, comlib.GetText(bulkValue.originalCurr)),
                                             odal.CreateParameter("@ExchangeRate", SqlDbType.Float, comlib.GetDouble(bulkValue.exchangeRate)),
                                             odal.CreateParameter("@IdrAmount", SqlDbType.Float, comlib.GetDouble(bulkValue.idrAmount)))


                        Next

                        odal.CommitTransactions()

                    End If

                    'aaaa

                    If pGer.listEnterDetail.Count <> 0 Then


                        odal.BeginTransactions()

                        odal.ExecuteCommandSP("usp_SAVEENTR_Detail",
                                             odal.CreateParameter("@Table", SqlDbType.VarChar, "DELETE_ENTER"),
                                             odal.CreateParameter("@CompanyID", SqlDbType.VarChar, pGer.CompanyID),
                                             odal.CreateParameter("@FormNum", SqlDbType.VarChar, pGer.FormNum))

                        odal.CommitTransactions()

                        odal.BeginTransactions()

                        For Each bulkValue As entertainmentGER_List_Model In pGer.listEnterDetail

                            odal.ExecuteCommandSP("usp_SAVEENTR_Detail",
                                            odal.CreateParameter("@Table", SqlDbType.VarChar, "INSERT_ENTER"),
                                            odal.CreateParameter("@CompanyID", SqlDbType.VarChar, comlib.GetText(pGer.CompanyID)),
                                            odal.CreateParameter("@FormNum", SqlDbType.Char, comlib.GetText(pGer.FormNum)),
                                            odal.CreateParameter("@SeqNum", SqlDbType.Int, comlib.GetInteger(bulkValue.seqNum)),
                                            odal.CreateParameter("@Nomor", SqlDbType.VarChar, comlib.GetText(bulkValue.nomor)),
                                            odal.CreateParameter("@ENTRDate", SqlDbType.DateTime, comlib.CToDate(bulkValue.entrDate)),
                                            odal.CreateParameter("@PersonNm", SqlDbType.VarChar, comlib.GetText(bulkValue.personNm)),
                                            odal.CreateParameter("@CompanyNm", SqlDbType.VarChar, comlib.GetText(bulkValue.companyNm)),
                                            odal.CreateParameter("@Title", SqlDbType.VarChar, comlib.GetText(bulkValue.title)),
                                            odal.CreateParameter("@Place", SqlDbType.VarChar, comlib.GetText(bulkValue.place)),
                                            odal.CreateParameter("@EntertainmentType", SqlDbType.VarChar, comlib.GetText(bulkValue.entertainmentType)),
                                            odal.CreateParameter("@IdrAmount", SqlDbType.Float, comlib.GetDouble(bulkValue.idrAmount)),
                                            odal.CreateParameter("@reason", SqlDbType.VarChar, comlib.GetText(bulkValue.reason)),
                                            odal.CreateParameter("@ProvidedNm", SqlDbType.VarChar, comlib.GetText(bulkValue.ProvidedNm)),
                                            odal.CreateParameter("@TypeOfCompany", SqlDbType.VarChar, comlib.GetText(bulkValue.typeOfCompany)),
                                            odal.CreateParameter("@FullAddress", SqlDbType.VarChar, comlib.GetText(bulkValue.fullAddress)),
                                                  odal.CreateParameter("@EntertaimentTypeDesc", SqlDbType.VarChar, comlib.GetText(bulkValue.EntertaimentTypeDesc)),
                                                  odal.CreateParameter("@ReasonDesc", SqlDbType.VarChar, comlib.GetText(bulkValue.ReasonDesc)))


                        Next

                        odal.CommitTransactions()

                    End If

                Else
                    odal.RollBackTransactions()
                    ores.InvalidMessage = ores.ReturnValue
                    ores.Message = "FAILURE"
                End If

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return ores
        End Function

        Public Function CheckAdditionalRoles(pprm As cParams) As cGERDetailResult
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oGER As cGERDetailResult = Nothing
            oGER = New cGERDetailResult
            oGER.cGERDetail = New List(Of cSubGERDetail)()

            Dim oGERDetail As cSubGERDetail

            Try

                rdr = odal.ExecuteDataReader("usp_check_additional_roles", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, pprm.paramtype),
                        odal.CreateParameter("@userid", SqlDbType.VarChar, comlib.GetText(pprm.skey1)))
                While rdr.Read
                    oGERDetail = New cSubGERDetail
                    oGERDetail.FormStatus = comlib.GetText(rdr.Item("Result"))
                    oGER.cGERDetail.Add(oGERDetail)
                End While

                oGER.message = "SUCCESS"
                oGER.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oGER

        End Function

        Public Function CheckTaxStatus(pprm As cParams) As cResult
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim res As cResult = Nothing

            Try

                rdr = odal.ExecuteDataReader("usp_CheckTaxStatus", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@formNum", SqlDbType.VarChar, comlib.GetText(pprm.skey1)))
                While rdr.Read
                    res = New cResult
                    res.Result = comlib.GetText(rdr.Item("Result"))
                End While

                res.Message = "SUCCESS"

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return res

        End Function

        Public Function GetValidationAppNumber(pprm As cParams) As cResult
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oResult As cResult = Nothing
            oResult = New cResult

            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "check_App_No"),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)))
                While rdr.Read
                    oResult.ResultFlag = comlib.GetBool(rdr.Item("resultFlag"))
                    oResult.Result = comlib.GetText(rdr.Item("ResultMessage"))
                End While

                oResult.Message = "SUCCESS"


            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oResult

        End Function

        'Update Ronald 4 Start
        Public Function GetGERList(pprm As cParams) As cGERList
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oGER As cGERList = Nothing
            oGER = New cGERList
            oGER.cGERDetail = New List(Of cGERDetail)()

            Dim oGERDetail As cGERDetail




            Try

                rdr = odal.ExecuteDataReader("sp_get_list_ger", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@view", SqlDbType.VarChar, comlib.GetText(pprm.paramtype)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.skey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pprm.skey3)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pprm.skey4)),
                        odal.CreateParameter("@skey5", SqlDbType.VarChar, comlib.GetText(pprm.skey5)),
                        odal.CreateParameter("@skey6", SqlDbType.VarChar, comlib.GetText(pprm.skey6)),
                        odal.CreateParameter("@skey7", SqlDbType.VarChar, comlib.GetText(pprm.skey7)),
                        odal.CreateParameter("@skey8", SqlDbType.VarChar, comlib.GetText(pprm.skey8)),
                        odal.CreateParameter("@skey9", SqlDbType.VarChar, comlib.GetText(pprm.skey9)),
                        odal.CreateParameter("@skey10", SqlDbType.VarChar, comlib.GetText(pprm.skey10)),
                        odal.CreateParameter("@ikey1", SqlDbType.Int, comlib.GetInteger(pprm.ikey1)),
                        odal.CreateParameter("@ikey2", SqlDbType.Int, comlib.GetInteger(pprm.ikey2)),
                        odal.CreateParameter("@ikey3", SqlDbType.Int, comlib.GetInteger(pprm.ikey3)),
                        odal.CreateParameter("@ikey4", SqlDbType.Int, comlib.GetInteger(pprm.ikey4)),
                        odal.CreateParameter("@ikey5", SqlDbType.Int, comlib.GetInteger(pprm.ikey5)),
                        odal.CreateParameter("@dkey1", SqlDbType.DateTime, comlib.CToDate(pprm.dkey1)),
                        odal.CreateParameter("@dkey2", SqlDbType.DateTime, comlib.CToDate(pprm.dkey2)),
                        odal.CreateParameter("@dkey3", SqlDbType.DateTime, comlib.CToDate(pprm.dkey3)),
                        odal.CreateParameter("@dkey4", SqlDbType.DateTime, comlib.CToDate(pprm.dkey4)),
                        odal.CreateParameter("@dkey5", SqlDbType.DateTime, comlib.CToDate(pprm.dkey5)),
                        odal.CreateParameter("@userid", SqlDbType.VarChar, comlib.GetText(pprm.ProcessBy)),
                        odal.CreateParameter("@pageno", SqlDbType.VarChar, comlib.GetText(pprm.pageno)),
                        odal.CreateParameter("@pagesize", SqlDbType.VarChar, comlib.GetText(pprm.pagesize)))
                While rdr.Read
                    oGERDetail = New cGERDetail
                    oGERDetail.SequenceNo = comlib.GetText(rdr.Item("SequenceNo"))
                    oGERDetail.Location = comlib.GetText(rdr.Item("Location"))
                    oGERDetail.Currency = comlib.GetText(rdr.Item("Currency"))
                    oGERDetail.CompanyID = comlib.GetText(rdr.Item("CompanyID"))
                    oGERDetail.Type = comlib.GetText(rdr.Item("Type"))
                    oGERDetail.GERNo = comlib.GetText(rdr.Item("GerNo"))
                    oGERDetail.Dept = comlib.GetText(rdr.Item("Dept"))
                    oGERDetail.CARNo = comlib.GetText(rdr.Item("CARNo"))
                    oGERDetail.CreatedDate = comlib.GetText(rdr.Item("CreatedDate"))
                    oGERDetail.CreatedBy = comlib.GetText(rdr.Item("CreatedBy"))
                    oGERDetail.TotalAmount = comlib.GetText(rdr.Item("TotalAmount"))
                    oGERDetail.TaxAmount = comlib.GetText(rdr.Item("TaxAmount"))
                    oGERDetail.NettAmount = comlib.GetText(rdr.Item("NettAmount"))
                    oGERDetail.GERStatus = comlib.GetText(rdr.Item("GERStatus"))
                    oGERDetail.TransactionCode = comlib.GetText(rdr.Item("TransactionCode"))
                    oGERDetail.BeneficiaryName = comlib.GetText(rdr.Item("BeneficiaryName"))
                    oGERDetail.BeneficiaryBankName = comlib.GetText(rdr.Item("BeneficiaryBankName"))
                    oGERDetail.BeneficiaryBankAccount = comlib.GetText(rdr.Item("BeneficiaryBankAccount"))
                    oGERDetail.PolicyNum = comlib.GetText(rdr.Item("PolicyNum"))
                    oGERDetail.PolRelated = comlib.GetText(rdr.Item("PolRelated"))
                    oGERDetail.VoucherNum = comlib.GetText(rdr.Item("VoucherNum"))
                    oGERDetail.TransferredDate = comlib.GetText(rdr.Item("TransferredDate"))
                    oGERDetail.ApplicationNo = comlib.GetText(rdr.Item("ApplicationNo"))
                    oGERDetail.RejectReason = comlib.GetText(rdr.Item("RejectReason"))
                    oGER.totalRows = comlib.GetText(rdr.Item("TotalRows"))
                    oGER.cGERDetail.Add(oGERDetail)
                End While

                oGER.message = "SUCCESS"
                oGER.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oGER

        End Function

        Public Function GetGERDescription(pprm As cParams) As cGERList
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oGER As cGERList = Nothing
            oGER = New cGERList
            oGER.cGERDescription = New List(Of cGERDescription)()

            Dim oGERDescription As cGERDescription


            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, comlib.GetText(pprm.paramtype)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.skey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pprm.skey3)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pprm.skey4)),
                        odal.CreateParameter("@skey5", SqlDbType.VarChar, comlib.GetText(pprm.skey5)))
                While rdr.Read
                    oGERDescription = New cGERDescription
                    oGERDescription.CompanyID = comlib.GetText(rdr.Item("CompanyID"))
                    oGERDescription.FormNum = comlib.GetText(rdr.Item("FormNum"))
                    oGERDescription.SeqNum = comlib.GetText(rdr.Item("SeqNum"))
                    oGERDescription.Nomor = comlib.GetText(rdr.Item("Nomor"))
                    oGERDescription.Description = comlib.GetText(rdr.Item("Description"))
                    oGERDescription.CostCenter = comlib.GetText(rdr.Item("CostCenter"))
                    oGERDescription.COA = comlib.GetText(rdr.Item("COA"))
                    oGERDescription.OriginalAmount = comlib.GetText(rdr.Item("OriginalAmount"))
                    oGERDescription.coa_updated = comlib.GetText(rdr.Item("coa_updated"))
                    oGERDescription.isSyaFlag = comlib.GetInteger(rdr.Item("isSyaFlag"))
                    oGERDescription.SegCode = comlib.GetText(rdr.Item("SegCode"))
                    oGERDescription.InvoiceNo = comlib.GetText(rdr.Item("InvoiceNo"))
                    oGER.cGERDescription.Add(oGERDescription)
                End While
                oGER.message = "SUCCESS"
                oGER.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oGER

        End Function

        Public Function GetGERAttachment(pprm As cParams) As cGERList
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oGER As cGERList = Nothing
            oGER = New cGERList
            oGER.cGERAttachment = New List(Of cGERAttachment)()

            Dim oGERAttachment As cGERAttachment


            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, comlib.GetText(pprm.paramtype)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.skey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pprm.skey3)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pprm.skey4)),
                        odal.CreateParameter("@skey5", SqlDbType.VarChar, comlib.GetText(pprm.skey5)))
                While rdr.Read
                    oGERAttachment = New cGERAttachment
                    oGERAttachment.SeqNum = comlib.GetInteger(rdr.Item("SeqNum"))
                    oGERAttachment.SeqNum2 = comlib.GetText(rdr.Item("SeqNum2"))
                    oGERAttachment.FormNum = comlib.GetText(rdr.Item("FormNum"))
                    oGERAttachment.FileLocation = comlib.GetText(rdr.Item("FileLocation"))
                    oGERAttachment.FileName = comlib.GetText(rdr.Item("FileName"))
                    oGERAttachment.Remark = comlib.GetText(rdr.Item("Remark"))
                    oGER.cGERAttachment.Add(oGERAttachment)
                End While
                oGER.message = "SUCCESS"
                oGER.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oGER

        End Function

        Public Function GetGERAttachmentLoc(pprm As cParams) As cLocAttachment
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader
            Dim fl As String
            Dim Path As String

            Dim oGER As cLocAttachment = Nothing
            oGER = New cLocAttachment


            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "get_Location_Attach"),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.skey2)))
                While rdr.Read
                    fl = rdr.Item("filelocation")
                    If (rdr.Item("attachmenttype") = "pdf") Then
                        oGER.bfile64 = Convert.ToBase64String(File.ReadAllBytes(comlib.GetText(rdr.Item("filelocation"))))
                        oGER.mmType = comlib.GetText(rdr.Item("MMtype"))
                        oGER.attType = comlib.GetText(rdr.Item("attachmenttype"))
                    Else
                        oGER.bfile64 = Convert.ToBase64String(File.ReadAllBytes(comlib.GetText(rdr.Item("filelocation"))))
                        oGER.mmType = comlib.GetText(rdr.Item("MMtype"))
                        oGER.attType = comlib.GetText(rdr.Item("attachmenttype"))

                    End If
                End While

                If oGER Is Nothing Then
                    oGER.message = "FAILURE"
                    oGER.result = "File Not Found"
                Else
                    oGER.message = "SUCCESS"
                    oGER.result = ""
                End If



            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oGER

        End Function

        Public Function CreateAttachment(pGERAttachment As cGERAttachment) As cResult
            Dim odal As New SQLAccess("core")
            Dim objAPIHelper As New comlib
            Dim flupload As String
            Try
                ores = New cResult
                If pGERAttachment.AttachmentType = "pdf" Then
                    flupload = objAPIHelper.getValueComString("ATTACHMENT_UPLOAD")
                Else
                    flupload = objAPIHelper.getValueComString("ATTACHMENT_UPLOADNONPDF")
                End If


                odal.BeginTransactions()

                odal.ExecuteCommandSP("sp_create_Attachment",
                                     odal.CreateParameter("@Table", SqlDbType.VarChar, pGERAttachment.Table),
                                     odal.CreateParameter("@CompanyID", SqlDbType.VarChar, pGERAttachment.CompanyID),
                                     odal.CreateParameter("@FormNum", SqlDbType.VarChar, pGERAttachment.FormNum),
                                     odal.CreateParameter("@FileLocation", SqlDbType.VarChar, flupload),
                                     odal.CreateParameter("@Remark", SqlDbType.VarChar, pGERAttachment.FileName),
                                     odal.CreateParameter("@AttachmentType", SqlDbType.VarChar, pGERAttachment.AttachmentType),
                                     odal.CreateParameter("@Result", SqlDbType.VarChar, pGERAttachment.Result, 500, ParameterDirection.InputOutput),
                                     odal.CreateParameter("@Result2", SqlDbType.VarChar, pGERAttachment.Result2, 500, ParameterDirection.InputOutput))
                ores.ReturnValue = odal.ReturnValue(1).ToString

                pGERAttachment.FileLocation = flupload + pGERAttachment.FormNum + "-" + odal.ReturnValue(2).ToString + "." + pGERAttachment.AttachmentType

                If ores.ReturnValue <> "" Then
                    ores.InvalidMessage = ""
                    odal.CommitTransactions()

                    File.WriteAllBytes(pGERAttachment.FileLocation, Convert.FromBase64String(pGERAttachment.FileData))
                Else
                    odal.RollBackTransactions()
                End If

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return ores
        End Function

        Public Function DeleteAttachment(pDeleteGERAttachment As deleteGERAttachment) As cResult
            Dim odal As New SQLAccess("core")
            Dim objAPIHelper As New comlib

            Try
                ores = New cResult

                odal.BeginTransactions()

                odal.ExecuteCommandSP("sp_create_Attachment",
                                     odal.CreateParameter("@Table", SqlDbType.VarChar, "Delete"),
                                     odal.CreateParameter("@CompanyID", SqlDbType.VarChar, pDeleteGERAttachment.CompanyID),
                                     odal.CreateParameter("@FormNum", SqlDbType.VarChar, pDeleteGERAttachment.formNum),
                                     odal.CreateParameter("@Seqnum", SqlDbType.VarChar, pDeleteGERAttachment.SeqNum),
                                     odal.CreateParameter("@Result", SqlDbType.VarChar, pDeleteGERAttachment.Result, 500, ParameterDirection.InputOutput))
                ores.ReturnValue = odal.ReturnValue(1).ToString

                If ores.ReturnValue <> "" Then

                    odal.CommitTransactions()

                    If File.Exists(ores.ReturnValue) Then

                        File.Delete(ores.ReturnValue)

                    End If

                    ores.InvalidMessage = "SUCCESS"
                    ores.Result = ""

                Else
                    odal.RollBackTransactions()
                End If

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                Throw ex
                ores.InvalidMessage = "FAILURE"
                ores.Result = "File Not Found"
            Finally
                pDeleteGERAttachment = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try

            Return ores
        End Function

        Public Function GetGERHistory(pprm As cParams) As cGERList
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oGER As cGERList = Nothing
            oGER = New cGERList
            oGER.cGERHistory = New List(Of cGERHistory)()
            Dim oGERHistory As cGERHistory


            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, comlib.GetText(pprm.paramtype)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.skey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pprm.skey3)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pprm.skey4)),
                        odal.CreateParameter("@skey5", SqlDbType.VarChar, comlib.GetText(pprm.skey5)))
                While rdr.Read
                    oGERHistory = New cGERHistory
                    oGERHistory.TransDt = comlib.GetText(rdr.Item("TransDt"))
                    oGERHistory.DetailTrans = comlib.GetText(rdr.Item("DetailTrans"))
                    oGERHistory.UpdateBy = comlib.GetText(rdr.Item("UpdateBy"))
                    oGER.cGERHistory.Add(oGERHistory)
                End While
                oGER.message = "SUCCESS"
                oGER.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oGER

        End Function

        Public Function GetGERApprover(pprm As cParams) As cGERList
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oGER As cGERList = Nothing
            oGER = New cGERList
            oGER.cGERApprover = New List(Of cGERApprover)()
            Dim oGERApprover As cGERApprover


            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, comlib.GetText(pprm.paramtype)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.skey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pprm.skey3)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pprm.skey4)),
                        odal.CreateParameter("@skey5", SqlDbType.VarChar, comlib.GetText(pprm.skey5)))
                While rdr.Read
                    oGERApprover = New cGERApprover
                    oGERApprover.Approver = comlib.GetText(rdr.Item("Approver"))
                    oGERApprover.Approver_Dt = comlib.GetText(rdr.Item("Approver_Dt"))
                    oGERApprover.Approver_Layer = comlib.GetText(rdr.Item("Approver_Layer"))
                    oGERApprover.Remark = comlib.GetText(rdr.Item("Remark"))
                    oGER.cGERApprover.Add(oGERApprover)
                End While
                oGER.message = "SUCCESS"
                oGER.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oGER

        End Function

        Public Function GetGERPolicydetail(pprm As cParams) As cGERList
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oGER As cGERList = Nothing
            oGER = New cGERList
            oGER.cGERPolicydetail = New List(Of cGERPolicydetail)()
            Dim oGERPolicydetail As cGERPolicydetail


            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, comlib.GetText(pprm.paramtype)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.skey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pprm.skey3)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pprm.skey4)),
                        odal.CreateParameter("@skey5", SqlDbType.VarChar, comlib.GetText(pprm.skey5)))
                While rdr.Read
                    oGERPolicydetail = New cGERPolicydetail
                    oGERPolicydetail.PolicyNum = comlib.GetText(rdr.Item("PolicyNum"))
                    oGERPolicydetail.RefundAmount = comlib.GetText(rdr.Item("RefundAmount"))
                    oGER.cGERPolicydetail.Add(oGERPolicydetail)
                End While
                oGER.message = "SUCCESS"
                oGER.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oGER

        End Function

        Public Function GetCARList(pprm As cParams) As cGERList
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oGER As cGERList = Nothing
            oGER = New cGERList
            oGER.cGERDetail = New List(Of cGERDetail)()

            Dim oGERDetail As cGERDetail




            Try

                rdr = odal.ExecuteDataReader("sp_get_list_car", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@view", SqlDbType.VarChar, comlib.GetText(pprm.paramtype)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.skey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pprm.skey3)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pprm.skey4)),
                        odal.CreateParameter("@skey5", SqlDbType.VarChar, comlib.GetText(pprm.skey5)),
                        odal.CreateParameter("@skey6", SqlDbType.VarChar, comlib.GetText(pprm.skey6)),
                        odal.CreateParameter("@skey7", SqlDbType.VarChar, comlib.GetText(pprm.skey7)),
                        odal.CreateParameter("@skey8", SqlDbType.VarChar, comlib.GetText(pprm.skey8)),
                        odal.CreateParameter("@skey9", SqlDbType.VarChar, comlib.GetText(pprm.skey9)),
                        odal.CreateParameter("@skey10", SqlDbType.VarChar, comlib.GetText(pprm.skey10)),
                        odal.CreateParameter("@ikey1", SqlDbType.Int, comlib.GetInteger(pprm.ikey1)),
                        odal.CreateParameter("@ikey2", SqlDbType.Int, comlib.GetInteger(pprm.ikey2)),
                        odal.CreateParameter("@ikey3", SqlDbType.Int, comlib.GetInteger(pprm.ikey3)),
                        odal.CreateParameter("@ikey4", SqlDbType.Int, comlib.GetInteger(pprm.ikey4)),
                        odal.CreateParameter("@ikey5", SqlDbType.Int, comlib.GetInteger(pprm.ikey5)),
                        odal.CreateParameter("@dkey1", SqlDbType.DateTime, comlib.CToDate(pprm.dkey1)),
                        odal.CreateParameter("@dkey2", SqlDbType.DateTime, comlib.CToDate(pprm.dkey2)),
                        odal.CreateParameter("@dkey3", SqlDbType.DateTime, comlib.CToDate(pprm.dkey3)),
                        odal.CreateParameter("@dkey4", SqlDbType.DateTime, comlib.CToDate(pprm.dkey4)),
                        odal.CreateParameter("@dkey5", SqlDbType.DateTime, comlib.CToDate(pprm.dkey5)),
                        odal.CreateParameter("@userid", SqlDbType.VarChar, comlib.GetText(pprm.ProcessBy)),
                        odal.CreateParameter("@pageno", SqlDbType.VarChar, comlib.GetText(pprm.pageno)),
                        odal.CreateParameter("@pagesize", SqlDbType.VarChar, comlib.GetText(pprm.pagesize)))
                While rdr.Read
                    oGERDetail = New cGERDetail
                    oGERDetail.SequenceNo = comlib.GetText(rdr.Item("SequenceNo"))
                    oGERDetail.Location = comlib.GetText(rdr.Item("Location"))
                    oGERDetail.Currency = comlib.GetText(rdr.Item("Currency"))
                    oGERDetail.CompanyID = comlib.GetText(rdr.Item("CompanyID"))
                    oGERDetail.Type = comlib.GetText(rdr.Item("Type"))
                    oGERDetail.GERNo = comlib.GetText(rdr.Item("GerNo"))
                    oGERDetail.Dept = comlib.GetText(rdr.Item("Dept"))
                    oGERDetail.CARNo = comlib.GetText(rdr.Item("CARNo"))
                    oGERDetail.CreatedDate = comlib.GetText(rdr.Item("CreatedDate"))
                    oGERDetail.CreatedBy = comlib.GetText(rdr.Item("CreatedBy"))
                    oGERDetail.TotalAmount = comlib.GetText(rdr.Item("TotalAmount"))
                    oGERDetail.TaxAmount = comlib.GetText(rdr.Item("TaxAmount"))
                    oGERDetail.NettAmount = comlib.GetText(rdr.Item("NettAmount"))
                    oGERDetail.GERStatus = comlib.GetText(rdr.Item("GERStatus"))
                    oGERDetail.TransactionCode = comlib.GetText(rdr.Item("TransactionCode"))
                    oGERDetail.BeneficiaryName = comlib.GetText(rdr.Item("BeneficiaryName"))
                    oGERDetail.BeneficiaryBankName = comlib.GetText(rdr.Item("BeneficiaryBankName"))
                    oGERDetail.BeneficiaryBankAccount = comlib.GetText(rdr.Item("BeneficiaryBankAccount"))
                    oGERDetail.PolicyNum = comlib.GetText(rdr.Item("PolicyNum"))
                    oGERDetail.PolRelated = comlib.GetText(rdr.Item("PolRelated"))
                    oGERDetail.VoucherNum = comlib.GetText(rdr.Item("VoucherNum"))
                    oGERDetail.TransferredDate = comlib.GetText(rdr.Item("TransferredDate"))
                    oGERDetail.ApplicationNo = comlib.GetText(rdr.Item("ApplicationNo"))
                    oGERDetail.RejectReason = comlib.GetText(rdr.Item("RejectReason"))
                    oGER.totalRows = comlib.GetText(rdr.Item("TotalRows"))
                    oGER.cGERDetail.Add(oGERDetail)
                End While

                oGER.message = "SUCCESS"
                oGER.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oGER

        End Function

        'Update Ronald 4 end

        Public Function GetGERDetailMaster(pprm As cParams) As cGERDetailResult
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oGER As cGERDetailResult = Nothing
            oGER = New cGERDetailResult
            oGER.cGERDetail = New List(Of cSubGERDetail)()

            Dim oGERDetail As cSubGERDetail

            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "key_GER_Summary"),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)))
                While rdr.Read
                    oGERDetail = New cSubGERDetail
                    oGERDetail.FromDept = comlib.GetText(rdr.Item("FromDept"))
                    oGERDetail.Currency = comlib.GetText(rdr.Item("Curr"))
                    oGERDetail.FormNum = comlib.GetText(rdr.Item("FormNum"))
                    oGERDetail.GERType = comlib.GetText(rdr.Item("FormType"))
                    oGERDetail.AdvanceFormNum = comlib.GetText(rdr.Item("AdvanceFormNum"))
                    oGERDetail.CreateDt = comlib.GetText(rdr.Item("CreateDt"))
                    oGERDetail.CheckedDt = comlib.GetText(rdr.Item("CheckedDt"))
                    oGERDetail.ApprovedDt = comlib.GetText(rdr.Item("ApprovedDt"))
                    oGERDetail.CreateBy = comlib.GetText(rdr.Item("CreateBy"))
                    oGERDetail.CheckedBy = comlib.GetText(rdr.Item("CheckedBy"))
                    oGERDetail.ApprovedBy = comlib.GetText(rdr.Item("ApprovedBy"))
                    oGERDetail.TotalAmount = comlib.GetText(rdr.Item("TotalAmount"))
                    oGERDetail.AdvanceAmount = comlib.GetText(rdr.Item("AdvanceAmount"))
                    oGERDetail.DueAmount = comlib.GetText(rdr.Item("DueAmount"))
                    oGERDetail.FormStatus = comlib.GetText(rdr.Item("FormStatus"))
                    oGERDetail.ExchangeRate = comlib.GetText(rdr.Item("ExchangeRate"))
                    oGERDetail.TransactionCode = comlib.GetText(rdr.Item("TransactionCode"))
                    oGERDetail.Description = comlib.GetText(rdr.Item("Description"))
                    oGERDetail.Journalized = comlib.GetText(rdr.Item("Journalized"))

                    oGERDetail.BeneficiaryBankCode = comlib.GetText(rdr.Item("BeneficiaryBankCode"))
                    oGERDetail.SLFIBankCode = comlib.GetText(rdr.Item("SLFIBankCode"))

                    oGERDetail.BeneficiaryName = comlib.GetText(rdr.Item("BeneficiaryName"))
                    oGERDetail.BeneficiaryBankName = comlib.GetText(rdr.Item("BeneficiaryBankName"))
                    oGERDetail.BeneficiaryBankAccount = comlib.GetText(rdr.Item("BeneficiaryBankAccount"))
                    oGERDetail.BeneficiaryBankBranch = comlib.GetText(rdr.Item("BeneficiaryBankBranch"))
                    oGERDetail.BeneficiaryBankCity = comlib.GetText(rdr.Item("BeneficiaryBankCity"))
                    oGERDetail.BeneficiaryEmail = comlib.GetText(rdr.Item("BeneficiaryEmail"))
                    oGERDetail.BeneficiaryAccountCurrency = comlib.GetText(rdr.Item("BeneficiaryAccountCurrency"))
                    oGERDetail.TaxAmount = comlib.GetText(rdr.Item("TaxAmount"))
                    oGERDetail.NettAmount = comlib.GetText(rdr.Item("NettAmount"))
                    oGERDetail.PolRelated = comlib.GetText(rdr.Item("PolRelated"))
                    oGERDetail.PolicyNum = comlib.GetText(rdr.Item("PolicyNum"))
                    oGERDetail.PolRelated = comlib.GetText(rdr.Item("PolRelated"))
                    oGERDetail.FormLocation = comlib.GetText(rdr.Item("FormLocation"))
                    oGERDetail.Subject = comlib.GetText(rdr.Item("Subject"))
                    oGERDetail.PaidBy = comlib.GetText(rdr.Item("PaidBy"))
                    oGERDetail.SLFIBankAccountNum = comlib.GetText(rdr.Item("SLFIBankAccountNum"))
                    oGERDetail.SLFIBankName = comlib.GetText(rdr.Item("SLFIBankName"))
                    oGERDetail.Taxable = comlib.GetText(rdr.Item("Taxable"))
                    oGERDetail.RejectType = comlib.GetText(rdr.Item("RejectType"))
                    oGERDetail.RejectReason = comlib.GetText(rdr.Item("RejectReason"))
                    oGERDetail.Budgeted = comlib.GetBool(rdr.Item("Budgeted"))
                    oGERDetail.PONumber = comlib.GetText(rdr.Item("PONum"))
                    oGERDetail.BeneficiaryTypeCd = comlib.GetText(rdr.Item("BeneficiaryTypeCd"))
                    oGERDetail.BeneficiaryResidentStatusCd = comlib.GetText(rdr.Item("BeneficiaryResidentStatusCd"))
                    oGERDetail.BeneficiaryTranTypeCd = comlib.GetText(rdr.Item("BeneficiaryTranTypeCd"))
                    oGERDetail.codeTypeTransaction = comlib.GetText(rdr.Item("codeTypeTransaction"))
                    oGERDetail.paymentCategory = comlib.GetText(rdr.Item("PaymentCategory"))
                    oGERDetail.AppNumber = comlib.GetText(rdr.Item("ApplicationNo"))
                    oGERDetail.PayeeDOB = comlib.GetText(rdr.Item("PayeeDOB"))
                    'oGERDetail.ListNoID = comlib.GetText(rdr.Item("ListNoID"))

                    oGER.cGERDetail.Add(oGERDetail)
                End While

                oGER.cGERHistory = New List(Of cGERHistory)()
                Dim oGERHistory As cGERHistory


                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "List_GER_History"),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)))
                While rdr.Read
                    oGERHistory = New cGERHistory
                    oGERHistory.TransDt = comlib.GetText(rdr.Item("TransDt"))
                    oGERHistory.DetailTrans = comlib.GetText(rdr.Item("DetailTrans"))
                    oGERHistory.UpdateBy = comlib.GetText(rdr.Item("UpdateBy"))
                    oGER.cGERHistory.Add(oGERHistory)
                End While

                oGER.message = "SUCCESS"
                oGER.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oGER

        End Function

        Public Function CreateCAR(pGer As cGER) As cResult
            Dim odal As New SQLAccess("core")
            Try
                ores = New cResult

                odal.BeginTransactions()

                odal.ExecuteCommandSP("sp_create_CAR",
                                     odal.CreateParameter("@Companyid", SqlDbType.VarChar, pGer.CompanyID),
                                     odal.CreateParameter("@FormNum", SqlDbType.VarChar, pGer.FormNum, 15, ParameterDirection.InputOutput),
                                     odal.CreateParameter("@GERType", SqlDbType.VarChar, pGer.GERType),
                                     odal.CreateParameter("@MainFormNum", SqlDbType.VarChar, pGer.MainFormNum),
                                     odal.CreateParameter("@Currency", SqlDbType.VarChar, pGer.Currency),
                                     odal.CreateParameter("@ExchangeRate", SqlDbType.VarChar, pGer.ExchangeRate),
                                     odal.CreateParameter("@FromDept", SqlDbType.VarChar, pGer.FromDept),
                                     odal.CreateParameter("@AdvanceFormNum", SqlDbType.VarChar, pGer.AdvanceFormNum),
                                     odal.CreateParameter("@TransactionCode", SqlDbType.VarChar, pGer.TransactionCode),
                                     odal.CreateParameter("@PolRelated", SqlDbType.Bit, pGer.PolRelated),
                                     odal.CreateParameter("@PolicyNum", SqlDbType.VarChar, pGer.PolicyNum),
                                     odal.CreateParameter("@UserID", SqlDbType.VarChar, pGer.UserID),
                                     odal.CreateParameter("@Budgeted", SqlDbType.Bit, pGer.Budgeted),
                                     odal.CreateParameter("@PONumber", SqlDbType.VarChar, pGer.PONumber),
                                     odal.CreateParameter("@Paycat", SqlDbType.VarChar, pGer.PayCat))
                ores.ReturnValue = odal.ReturnValue(1).ToString

                If ores.ReturnValue <> "" Then
                    ores.InvalidMessage = ""
                    odal.CommitTransactions()
                Else
                    odal.RollBackTransactions()
                End If

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return ores
        End Function

        Public Function CreateGER(pGer As cGER) As cResult
            Dim odal As New SQLAccess("core")
            Try
                ores = New cResult

                odal.BeginTransactions()

                odal.ExecuteCommandSP("sp_create_GER",
                                     odal.CreateParameter("@Companyid", SqlDbType.VarChar, pGer.CompanyID),
                                     odal.CreateParameter("@FormNum", SqlDbType.VarChar, pGer.FormNum, 15, ParameterDirection.InputOutput),
                                     odal.CreateParameter("@GERType", SqlDbType.VarChar, pGer.GERType),
                                     odal.CreateParameter("@MainFormNum", SqlDbType.VarChar, pGer.MainFormNum),
                                     odal.CreateParameter("@Currency", SqlDbType.VarChar, pGer.Currency),
                                     odal.CreateParameter("@ExchangeRate", SqlDbType.VarChar, pGer.ExchangeRate),
                                     odal.CreateParameter("@FromDept", SqlDbType.VarChar, pGer.FromDept),
                                     odal.CreateParameter("@AdvanceFormNum", SqlDbType.VarChar, pGer.AdvanceFormNum),
                                     odal.CreateParameter("@TransactionCode", SqlDbType.VarChar, pGer.TransactionCode),
                                     odal.CreateParameter("@PolRelated", SqlDbType.Bit, pGer.PolRelated),
                                     odal.CreateParameter("@PolicyNum", SqlDbType.VarChar, pGer.PolicyNum),
                                     odal.CreateParameter("@UserID", SqlDbType.VarChar, pGer.UserID),
                                     odal.CreateParameter("@Budgeted", SqlDbType.Bit, pGer.Budgeted),
                                     odal.CreateParameter("@PONumber", SqlDbType.VarChar, pGer.PONumber))
                ores.ReturnValue = odal.ReturnValue(1).ToString

                If ores.ReturnValue <> "" Then
                    ores.InvalidMessage = ""
                    odal.CommitTransactions()
                Else
                    odal.RollBackTransactions()
                End If

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return ores
        End Function

        Public Function CreateGER_v2(pGer As cGER) As cResult
            Dim odal As New SQLAccess("core")
            Try
                ores = New cResult

                If pGer.bulkFlagValue = "M" And pGer.cBulkData.Count <> 0 Then

                    If pGer.PolRelated Then
                        For Each i As cBulkData In pGer.cBulkData

                            If Regex.IsMatch(i.BName, "[`~!@#\$%\^&\*\(\)_\-\+=\{\}\[\]\\\|:;""'<>,\.\?/]") Then

                                ores.Message = "FAILED"
                                ores.Result = "This Benefiary Name " & i.BName & " contains Unrestricted Character"

                                Return ores

                            End If

                        Next

                        odal.BeginTransactions()

                        odal.ExecuteCommandSP("usp_process_reloadTablePolicyIngenium")

                        odal.CommitTransactions()

                        For Each i As cBulkData In pGer.cBulkData

                            odal.BeginTransactions()

                            odal.ExecuteCommandSP("sp_check_policyBulk_GER",
                                         odal.CreateParameter("@table", SqlDbType.VarChar, "bulkPolicyCheck"),
                                         odal.CreateParameter("@Companyid", SqlDbType.VarChar, pGer.CompanyID),
                                         odal.CreateParameter("@Result", SqlDbType.VarChar, pGer.tempResult, 100, ParameterDirection.InputOutput),
                                         odal.CreateParameter("@Result2", SqlDbType.VarChar, pGer.tempResult2, 100, ParameterDirection.InputOutput),
                                         odal.CreateParameter("@TotalAmount", SqlDbType.Float, comlib.GetDouble(i.OAmmount)),
                                         odal.CreateParameter("@PolicyNo", SqlDbType.VarChar, comlib.GetText(i.PolicyNo)),
                                         odal.CreateParameter("@BeneficiaryName", SqlDbType.VarChar, comlib.GetText(i.BName)),
                                         odal.CreateParameter("@BankCode", SqlDbType.VarChar, comlib.GetText(i.BCode)))

                            If odal.ReturnValue(1).ToString = "FAILED" Then

                                odal.RollBackTransactions()

                                ores.Message = "FAILED"
                                ores.Result = odal.ReturnValue(2).ToString

                                Return ores

                            Else

                                odal.CommitTransactions()

                            End If

                        Next

                    End If

                ElseIf pGer.bulkFlagValue <> "M" And pGer.cBulkData.Count = 0 And pGer.PolicyNum <> "" And Not pGer.PolicyNum Is Nothing Then

                    odal.BeginTransactions()

                    odal.ExecuteCommandSP("sp_check_policyBulk_GER",
                                     odal.CreateParameter("@table", SqlDbType.VarChar, "singlePolicyCheck"),
                                     odal.CreateParameter("@Companyid", SqlDbType.VarChar, pGer.CompanyID),
                                     odal.CreateParameter("@Result", SqlDbType.VarChar, pGer.tempResult, 100, ParameterDirection.InputOutput),
                                     odal.CreateParameter("@Result2", SqlDbType.VarChar, pGer.tempResult2, 100, ParameterDirection.InputOutput),
                                     odal.CreateParameter("@PolicyNo", SqlDbType.VarChar, comlib.GetText(pGer.PolicyNum)),
                                     odal.CreateParameter("@PolicyCurrency", SqlDbType.VarChar, comlib.GetText(pGer.Currency)),
                                     odal.CreateParameter("@PolicyCurrencyRate", SqlDbType.Float, comlib.GetDouble(pGer.ExchangeRate)),
                                          odal.CreateParameter("@AppNumber", SqlDbType.VarChar, comlib.GetText(pGer.AppNumber)),
                                          odal.CreateParameter("@TransType", SqlDbType.VarChar, comlib.GetText(pGer.TransactionCode)))

                    If odal.ReturnValue(1).ToString = "FAILED" Then

                        odal.RollBackTransactions()

                        ores.Message = "FAILED"
                        ores.Result = odal.ReturnValue(2).ToString

                        Return ores

                    Else

                        odal.CommitTransactions()

                    End If

                ElseIf pGer.bulkFlagValue <> "M" And pGer.cBulkData.Count = 0 And (pGer.PolicyNum = "" Or pGer.PolicyNum Is Nothing) Then

                    odal.BeginTransactions()

                    odal.ExecuteCommandSP("sp_check_policyBulk_GER",
                                     odal.CreateParameter("@table", SqlDbType.VarChar, "ISTARCHECK"),
                                     odal.CreateParameter("@Companyid", SqlDbType.VarChar, pGer.CompanyID),
                                     odal.CreateParameter("@Result", SqlDbType.VarChar, pGer.tempResult, 100, ParameterDirection.InputOutput),
                                     odal.CreateParameter("@Result2", SqlDbType.VarChar, pGer.tempResult2, 100, ParameterDirection.InputOutput),
                                     odal.CreateParameter("@PolicyNo", SqlDbType.VarChar, comlib.GetText(pGer.PolicyNum)),
                                     odal.CreateParameter("@PolicyCurrency", SqlDbType.VarChar, comlib.GetText(pGer.Currency)),
                                     odal.CreateParameter("@PolicyCurrencyRate", SqlDbType.Float, comlib.GetDouble(pGer.ExchangeRate)),
                                          odal.CreateParameter("@AppNumber", SqlDbType.VarChar, comlib.GetText(pGer.AppNumber)),
                                          odal.CreateParameter("@TransType", SqlDbType.VarChar, comlib.GetText(pGer.TransactionCode)))

                    If odal.ReturnValue(1).ToString = "FAILED" Then

                        odal.RollBackTransactions()

                        ores.Message = "FAILED"
                        ores.Result = odal.ReturnValue(2).ToString

                        Return ores

                    Else

                        odal.CommitTransactions()

                    End If

                End If

                odal.BeginTransactions()

                odal.ExecuteCommandSP("sp_create_GER",
                                     odal.CreateParameter("@Companyid", SqlDbType.VarChar, pGer.CompanyID),
                                     odal.CreateParameter("@FormNum", SqlDbType.VarChar, pGer.FormNum, 15, ParameterDirection.InputOutput),
                                     odal.CreateParameter("@GERType", SqlDbType.VarChar, pGer.GERType),
                                     odal.CreateParameter("@MainFormNum", SqlDbType.VarChar, pGer.MainFormNum),
                                     odal.CreateParameter("@Currency", SqlDbType.VarChar, pGer.Currency),
                                     odal.CreateParameter("@ExchangeRate", SqlDbType.VarChar, pGer.ExchangeRate),
                                     odal.CreateParameter("@FromDept", SqlDbType.VarChar, pGer.FromDept),
                                     odal.CreateParameter("@AdvanceFormNum", SqlDbType.VarChar, pGer.AdvanceFormNum),
                                     odal.CreateParameter("@TransactionCode", SqlDbType.VarChar, pGer.TransactionCode),
                                     odal.CreateParameter("@PolRelated", SqlDbType.Bit, pGer.PolRelated),
                                     odal.CreateParameter("@PolicyNum", SqlDbType.VarChar, pGer.PolicyNum),
                                     odal.CreateParameter("@UserID", SqlDbType.VarChar, pGer.UserID),
                                     odal.CreateParameter("@Budgeted", SqlDbType.Bit, pGer.Budgeted),
                                     odal.CreateParameter("@PONumber", SqlDbType.VarChar, pGer.PONumber),
                                     odal.CreateParameter("@AppNum", SqlDbType.VarChar, pGer.AppNumber),
                                     odal.CreateParameter("@PayCat", SqlDbType.VarChar, pGer.PayCat),
                                     odal.CreateParameter("@DetEx", SqlDbType.VarChar, pGer.DetEx))

                ores.ReturnValue = odal.ReturnValue(1).ToString
                pGer.FormNum = odal.ReturnValue(1).ToString

                If ores.ReturnValue <> "" Then
                    ores.InvalidMessage = ""
                    odal.CommitTransactions()
                Else
                    odal.RollBackTransactions()
                End If

                If pGer.bulkFlagValue = "M" And pGer.cBulkData.Count <> 0 Then

                    odal.BeginTransactions()

                    odal.ExecuteCommandSP("sp_getid",
                                         odal.CreateParameter("@ID", SqlDbType.Int, pGer.bulkID, 32, ParameterDirection.InputOutput))

                    ores.ReturnValue = odal.ReturnValue(1).ToString
                    pGer.bulkID = odal.ReturnValue(1).ToString

                    If ores.ReturnValue <> "" Then
                        ores.InvalidMessage = ""
                        odal.CommitTransactions()
                    Else
                        odal.RollBackTransactions()
                    End If

                    odal.BeginTransactions()

                    For Each i As cBulkData In pGer.cBulkData

                        odal.ExecuteCommandText("INSERT INTO tbulk (UploadID,PolicyNum,BankAccountName,BankCode,BankAccountNum,Amount,FormNum,CreatedDate,CreatedBy,UpdatedDate,UpdatedBy,FCompanyID, TransKey,PONum, AppNum, PaymentCategory) SELECT @UID,@PolicyNo,@BName,@BCode,@AccountNo,@OAmmount,@FormNum,@CreatedDate,@CreatedBy,@UpdatedDate,@UpdatedBy,@CompanyID,@TransKey, @PONum, @AppNum, @PaymentCategory ",
                                            odal.CreateParameter("@UID", SqlDbType.Int, comlib.GetInteger(ores.ReturnValue)),
                                            odal.CreateParameter("@PolicyNo", SqlDbType.Char, comlib.GetText(i.PolicyNo)),
                                            odal.CreateParameter("@BName", SqlDbType.VarChar, comlib.GetText(i.BName)),
                                            odal.CreateParameter("@BCode", SqlDbType.VarChar, comlib.GetText(i.BCode)),
                                            odal.CreateParameter("@AccountNo", SqlDbType.VarChar, comlib.GetText(i.AccountNo)),
                                            odal.CreateParameter("@OAmmount", SqlDbType.Float, comlib.GetDouble(i.OAmmount)),
                                            odal.CreateParameter("@FormNum", SqlDbType.VarChar, comlib.GetText(pGer.FormNum)),
                                            odal.CreateParameter("@CreatedDate", SqlDbType.DateTime, DateTime.Now),
                                            odal.CreateParameter("@CreatedBy", SqlDbType.VarChar, comlib.GetText(pGer.UserID)),
                                            odal.CreateParameter("@UpdatedDate", SqlDbType.DateTime, DateTime.Now),
                                            odal.CreateParameter("@UpdatedBy", SqlDbType.VarChar, comlib.GetText(pGer.UserID)),
                                            odal.CreateParameter("@CompanyID", SqlDbType.VarChar, comlib.GetText(pGer.CompanyID)),
                                            odal.CreateParameter("@TransKey", SqlDbType.VarChar, comlib.GetText(i.TransKey)),
                                            odal.CreateParameter("@PONum", SqlDbType.VarChar, comlib.GetText(pGer.PoNum)),
                                            odal.CreateParameter("@AppNum", SqlDbType.VarChar, comlib.GetText(pGer.AppNumber)),
                                            odal.CreateParameter("@PaymentCategory", SqlDbType.VarChar, comlib.GetText(pGer.PayCat)))

                    Next

                    odal.CommitTransactions()

                    odal.BeginTransactions()

                    odal.ExecuteCommandSP("sp_create_SubGER",
                                         odal.CreateParameter("@CompanyID", SqlDbType.VarChar, pGer.CompanyID),
                                         odal.CreateParameter("@FormNum", SqlDbType.VarChar, pGer.FormNum),
                                         odal.CreateParameter("@UploadID", SqlDbType.Int, pGer.bulkID))

                    odal.CommitTransactions()
                ElseIf pGer.bulkFlagValue = "E" And pGer.cBulkData.Count <> 0 Then

                    odal.BeginTransactions()

                    odal.ExecuteCommandSP("sp_getid",
                                         odal.CreateParameter("@ID", SqlDbType.Int, pGer.bulkID, 32, ParameterDirection.InputOutput))

                    ores.ReturnValue = odal.ReturnValue(1).ToString
                    pGer.bulkID = odal.ReturnValue(1).ToString

                    If ores.ReturnValue <> "" Then
                        ores.InvalidMessage = ""
                        odal.CommitTransactions()
                    Else
                        odal.RollBackTransactions()
                    End If

                    odal.BeginTransactions()

                    For Each i As cBulkData In pGer.cBulkData

                        odal.ExecuteCommandText("INSERT INTO tbulk (UploadID,PolicyNum,BankAccountName,BankCode,BankAccountNum,Amount,FormNum,CreatedDate,CreatedBy,UpdatedDate,UpdatedBy,FCompanyID, TransKey,PONum, AppNum, PaymentCategory) SELECT @UID,@PolicyNo,@BName,@BCode,@AccountNo,@OAmmount,@FormNum,@CreatedDate,@CreatedBy,@UpdatedDate,@UpdatedBy,@CompanyID,@TransKey, @PONum, @AppNum, @PaymentCategory ",
                                            odal.CreateParameter("@UID", SqlDbType.Int, comlib.GetInteger(ores.ReturnValue)),
                                            odal.CreateParameter("@PolicyNo", SqlDbType.Char, comlib.GetText(i.PolicyNo)),
                                            odal.CreateParameter("@BName", SqlDbType.VarChar, comlib.GetText(i.BName)),
                                            odal.CreateParameter("@BCode", SqlDbType.VarChar, comlib.GetText(i.BCode)),
                                            odal.CreateParameter("@AccountNo", SqlDbType.VarChar, comlib.GetText(i.AccountNo)),
                                            odal.CreateParameter("@OAmmount", SqlDbType.Float, comlib.GetDouble(i.OAmmount)),
                                            odal.CreateParameter("@FormNum", SqlDbType.VarChar, comlib.GetText(pGer.FormNum)),
                                            odal.CreateParameter("@CreatedDate", SqlDbType.DateTime, DateTime.Now),
                                            odal.CreateParameter("@CreatedBy", SqlDbType.VarChar, comlib.GetText(pGer.UserID)),
                                            odal.CreateParameter("@UpdatedDate", SqlDbType.DateTime, DateTime.Now),
                                            odal.CreateParameter("@UpdatedBy", SqlDbType.VarChar, comlib.GetText(pGer.UserID)),
                                            odal.CreateParameter("@CompanyID", SqlDbType.VarChar, comlib.GetText(pGer.CompanyID)),
                                            odal.CreateParameter("@TransKey", SqlDbType.VarChar, comlib.GetText(i.TransKey)),
                                            odal.CreateParameter("@PONum", SqlDbType.VarChar, comlib.GetText(pGer.PoNum)),
                                            odal.CreateParameter("@AppNum", SqlDbType.VarChar, comlib.GetText(pGer.AppNumber)),
                                            odal.CreateParameter("@PaymentCategory", SqlDbType.VarChar, comlib.GetText(pGer.PayCat)))

                    Next

                    odal.CommitTransactions()

                    odal.BeginTransactions()

                    odal.ExecuteCommandSP("sp_create_SubGER",
                                         odal.CreateParameter("@CompanyID", SqlDbType.VarChar, pGer.CompanyID),
                                         odal.CreateParameter("@FormNum", SqlDbType.VarChar, pGer.FormNum),
                                         odal.CreateParameter("@UploadID", SqlDbType.Int, pGer.bulkID))

                    odal.CommitTransactions()

                End If

                ores.ReturnValue = pGer.FormNum

                ores.Message = "SUCCESS"
                ores.Result = ""

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return ores
        End Function

        Public Function CreateIDBulk(pGer As cBulkParam) As cResult
            Dim odal As New SQLAccess("core")
            Try
                ores = New cResult

                odal.BeginTransactions()

                odal.ExecuteCommandSP("sp_getid",
                                     odal.CreateParameter("@ID", SqlDbType.Int, pGer.BulkID, 32, ParameterDirection.InputOutput))
                ores.ReturnValue = odal.ReturnValue(1).ToString

                If ores.ReturnValue <> "" Then
                    ores.InvalidMessage = ""
                    odal.CommitTransactions()
                Else
                    odal.RollBackTransactions()
                End If

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return ores
        End Function

        Public Function InsertDataBulk(pGer As cBulkDataParam) As cResult
            Dim odal As New SQLAccess("core")
            Try
                ores = New cResult

                odal.BeginTransactions()

                For Each i As cBulkData In pGer.cBulkData

                    odal.ExecuteCommandText("INSERT INTO tbulk (UploadID,PolicyNum,BankAccountName,BankCode,BankAccountNum,Amount) SELECT @UID,@PolicyNo,@BName,@BCode,@AccountNo,@OAmmount ",
                                        odal.CreateParameter("@UID", SqlDbType.Int, comlib.GetInteger(i.UID)),
                                        odal.CreateParameter("@PolicyNo", SqlDbType.Char, comlib.GetText(i.PolicyNo)),
                                        odal.CreateParameter("@BName", SqlDbType.VarChar, comlib.GetText(i.BName)),
                                        odal.CreateParameter("@BCode", SqlDbType.VarChar, comlib.GetText(i.BCode)),
                                        odal.CreateParameter("@AccountNo", SqlDbType.VarChar, comlib.GetText(i.AccountNo)),
                                        odal.CreateParameter("@OAmmount", SqlDbType.Float, comlib.GetDouble(i.OAmmount)))

                Next

                odal.CommitTransactions()

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return ores
        End Function

        Public Function CreateSubGER(pSubGer As cSubGER) As cResult
            Dim odal As New SQLAccess("core")
            Try
                ores = New cResult

                odal.BeginTransactions()

                odal.ExecuteCommandSP("sp_create_SubGER",
                                     odal.CreateParameter("@CompanyID", SqlDbType.VarChar, pSubGer.pCompanyID),
                                     odal.CreateParameter("@FormNum", SqlDbType.VarChar, pSubGer.pFormNum),
                                     odal.CreateParameter("@UploadID", SqlDbType.Int, pSubGer.pUploadID))

                odal.CommitTransactions()

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return ores
        End Function

        'Created    : RZ
        'Date       : 7 June 2018
        'Desc       : send approval

        Public Function SendApprover(pparam As cParams) As cResult

            Dim odal As New SQLAccess("core")

            Try
                ores = New cResult
                'Validation
                'ores.InvalidMessage = IsValid(odal, pparam)

                'Run Tasks
                If ores.InvalidMessage = "" Then
                    odal.BeginTransactions()
                    odal.ExecuteCommandSP("usp_process_approval",
                        odal.CreateParameter("@CompanyID", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                        odal.CreateParameter("@Table", SqlDbType.VarChar, comlib.GetText(pparam.skey1)),
                        odal.CreateParameter("@DeptID", SqlDbType.Char, comlib.GetText(pparam.skey2)),
                        odal.CreateParameter("@UserID", SqlDbType.VarChar, comlib.GetText(pparam.skey3)),
                        odal.CreateParameter("@NextApproverID", SqlDbType.VarChar, comlib.GetText(pparam.skey4)),
                        odal.CreateParameter("@TransactionCode", SqlDbType.VarChar, comlib.GetText(pparam.skey5)),
                        odal.CreateParameter("@ManyGER", SqlDbType.VarChar, comlib.GetText(pparam.skey6)),
                        odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))
                    ores.InvalidMessage = odal.ReturnValue(1).ToString

                    If ores.InvalidMessage = "Berhasil" Then
                        odal.CommitTransactions()
                    Else
                        odal.RollBackTransactions()
                    End If
                End If
            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            ores.Result = "SUCCESS"
            Return ores

        End Function


        Public Function UpdateGER(pGer As cGER) As cResult
            Dim odal As New SQLAccess("core")
            Try
                ores = New cResult

                odal.BeginTransactions()

                odal.ExecuteCommandSP("sp_update_GER",
                                     odal.CreateParameter("@CompanyID", SqlDbType.VarChar, pGer.CompanyID),
                                     odal.CreateParameter("@FormNum", SqlDbType.VarChar, pGer.FormNum, 15, ParameterDirection.InputOutput),
                                     odal.CreateParameter("@GERType", SqlDbType.VarChar, pGer.Subject),
                                     odal.CreateParameter("@Subject", SqlDbType.VarChar, pGer.PaidBy),
                                     odal.CreateParameter("@Taxable", SqlDbType.Bit, pGer.Taxable),
                                     odal.CreateParameter("@BeneficiaryName", SqlDbType.VarChar, pGer.BeneficiaryName),
                                     odal.CreateParameter("@BeneficiaryBankCode", SqlDbType.Int, pGer.BeneficiaryBankCode),
                                     odal.CreateParameter("@BeneficiaryBankAccount", SqlDbType.VarChar, pGer.BeneficiaryBankAccount),
                                     odal.CreateParameter("@BeneficiaryBankBranch", SqlDbType.VarChar, pGer.BeneficiaryBankBranch),
                                     odal.CreateParameter("@BeneficiaryBankCity", SqlDbType.VarChar, pGer.BeneficiaryBankCity),
                                     odal.CreateParameter("@BeneficiaryEmail", SqlDbType.VarChar, pGer.BeneficiaryEmail),
                                     odal.CreateParameter("@BeneficiaryAccountCurrency", SqlDbType.VarChar, pGer.BeneficiaryAccountCurrency),
                                     odal.CreateParameter("@BeneficiaryTypeCd", SqlDbType.VarChar, pGer.BeneficiaryTypeCd),
                                     odal.CreateParameter("@BeneficiaryResidentStatusCd", SqlDbType.VarChar, pGer.BeneficiaryResidentStatusCd),
                                     odal.CreateParameter("@BeneficiaryTranTypeCd", SqlDbType.VarChar, pGer.BeneficiaryTranTypeCd),
                                     odal.CreateParameter("@BeneficiaryTranFacilityTypeCd", SqlDbType.VarChar, pGer.BeneficiaryTranFacilityTypeCd),
                                     odal.CreateParameter("@UserID", SqlDbType.VarChar, pGer.UserID))
                ores.ReturnValue = odal.ReturnValue(1).ToString

                If ores.ReturnValue <> "" Then
                    ores.InvalidMessage = ""
                    odal.CommitTransactions()
                Else
                    odal.RollBackTransactions()
                End If

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return ores
        End Function


        Public Function ListInternetBanking(ByVal pparam As cParams) As cInternetBanking
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oInternetBanking As cInternetBanking = Nothing
            oInternetBanking = New cInternetBanking
            oInternetBanking.cInternetBankingDetail = New List(Of cInternetBankingDetail)()

            Dim oInternetBankingDetail As cInternetBankingDetail

            Try

                rdr = odal.ExecuteDataReader("sp_get", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, comlib.GetText(pparam.paramtype)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pparam.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pparam.skey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pparam.skey3)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pparam.skey4)),
                        odal.CreateParameter("@skey5", SqlDbType.VarChar, comlib.GetText(pparam.skey5)),
                        odal.CreateParameter("@skey6", SqlDbType.VarChar, comlib.GetText(pparam.skey6)),
                        odal.CreateParameter("@skey7", SqlDbType.VarChar, comlib.GetText(pparam.skey7)),
                        odal.CreateParameter("@skey8", SqlDbType.VarChar, comlib.GetText(pparam.skey8)),
                        odal.CreateParameter("@skey9", SqlDbType.VarChar, comlib.GetText(pparam.skey9)),
                        odal.CreateParameter("@skey10", SqlDbType.VarChar, comlib.GetText(pparam.skey10)),
                        odal.CreateParameter("@ikey1", SqlDbType.Int, comlib.GetInteger(pparam.ikey1)),
                        odal.CreateParameter("@ikey2", SqlDbType.Int, comlib.GetInteger(pparam.ikey2)),
                        odal.CreateParameter("@ikey3", SqlDbType.Int, comlib.GetInteger(pparam.ikey3)),
                        odal.CreateParameter("@ikey4", SqlDbType.Int, comlib.GetInteger(pparam.ikey4)),
                        odal.CreateParameter("@ikey5", SqlDbType.Int, comlib.GetInteger(pparam.ikey5)),
                        odal.CreateParameter("@fkey1", SqlDbType.Float, comlib.GetDouble(pparam.fkey1)),
                        odal.CreateParameter("@fkey2", SqlDbType.Float, comlib.GetDouble(pparam.fkey2)),
                        odal.CreateParameter("@fkey3", SqlDbType.Float, comlib.GetDouble(pparam.fkey3)),
                        odal.CreateParameter("@fkey4", SqlDbType.Float, comlib.GetDouble(pparam.fkey4)),
                        odal.CreateParameter("@fkey5", SqlDbType.Float, comlib.GetDouble(pparam.fkey5)),
                        odal.CreateParameter("@dkey1", SqlDbType.DateTime, comlib.CToDate(pparam.dkey1)),
                        odal.CreateParameter("@dkey2", SqlDbType.DateTime, comlib.CToDate(pparam.dkey2)),
                        odal.CreateParameter("@dkey3", SqlDbType.DateTime, comlib.CToDate(pparam.dkey3)),
                        odal.CreateParameter("@dkey4", SqlDbType.DateTime, comlib.CToDate(pparam.dkey4)),
                        odal.CreateParameter("@dkey5", SqlDbType.DateTime, comlib.CToDate(pparam.dkey5)))
                While rdr.Read
                    oInternetBankingDetail = New cInternetBankingDetail
                    oInternetBankingDetail.ToGenerate = comlib.GetText(rdr.Item("ToGenerate"))
                    oInternetBankingDetail.TransactionCode = comlib.GetText(rdr.Item("TransactionCode"))
                    oInternetBankingDetail.Curr = comlib.GetText(rdr.Item("Curr"))
                    oInternetBankingDetail.FormNum = comlib.GetText(rdr.Item("FormNum"))
                    oInternetBankingDetail.FromDept = comlib.GetText(rdr.Item("FromDept"))
                    oInternetBankingDetail.CreateDt = comlib.GetText(rdr.Item("CreateDt"))
                    oInternetBankingDetail.CreateBy = comlib.GetText(rdr.Item("CreateBy"))
                    oInternetBankingDetail.NettAmount = comlib.GetText(rdr.Item("NettAmount"))
                    oInternetBankingDetail.BeneficiaryName = comlib.GetText(rdr.Item("BeneficiaryName"))
                    oInternetBankingDetail.BeneficiaryBankCode = comlib.GetText(rdr.Item("BeneficiaryBankCode"))
                    oInternetBankingDetail.BeneficiaryBankAccount = comlib.GetText(rdr.Item("BeneficiaryBankAccount"))
                    oInternetBankingDetail.BeneficiaryEmail = comlib.GetText(rdr.Item("BeneficiaryEmail"))
                    oInternetBankingDetail.BeneficiaryBankCity = comlib.GetText(rdr.Item("BeneficiaryBankCity"))
                    oInternetBankingDetail.TransactionCode = comlib.GetText(rdr.Item("TransactionCode"))
                    oInternetBankingDetail.BeneficiaryName = comlib.GetText(rdr.Item("BeneficiaryName"))
                    oInternetBankingDetail.BeneficiaryAccountCurrency = comlib.GetText(rdr.Item("BeneficiaryAccountCurrency"))
                    oInternetBankingDetail.Subject = comlib.GetText(rdr.Item("Subject"))
                    oInternetBankingDetail.PaidBy = comlib.GetText(rdr.Item("PaidBy"))
                    oInternetBankingDetail.ExchangeRate = comlib.GetText(rdr.Item("ExchangeRate"))
                    oInternetBanking.cInternetBankingDetail.Add(oInternetBankingDetail)
                End While

                oInternetBanking.message = "SUCCESS"
                oInternetBanking.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                ' pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oInternetBanking

        End Function

        Public Function GetInternetBankingList(pprm As cParams) As cInternetBanking
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oInternetBanking As cInternetBanking = Nothing
            oInternetBanking = New cInternetBanking
            oInternetBanking.cInternetBankingDetail = New List(Of cInternetBankingDetail)()
            Dim oInternetBankingDetail As cInternetBankingDetail

            Try

                rdr = odal.ExecuteDataReader("sp_get_list_Internet_Banking", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@pageno", SqlDbType.VarChar, comlib.GetText(pprm.pageno)),
                        odal.CreateParameter("@view", SqlDbType.VarChar, comlib.GetText(pprm.paramtype)),
                        odal.CreateParameter("@pagesize", SqlDbType.VarChar, comlib.GetText(pprm.pagesize)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.skey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pprm.skey3)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pprm.skey4)),
                        odal.CreateParameter("@skey5", SqlDbType.VarChar, comlib.GetText(pprm.skey5)),
                        odal.CreateParameter("@userid", SqlDbType.VarChar, comlib.GetText(pprm.userid)))
                While rdr.Read
                    oInternetBankingDetail = New cInternetBankingDetail
                    oInternetBankingDetail.SequenceNo = comlib.GetText(rdr.Item("SequenceNo"))
                    oInternetBankingDetail.Selectoption = comlib.GetBool(rdr.Item("Selectoption"))
                    oInternetBankingDetail.TransactionCode = comlib.GetText(rdr.Item("TransactionCode"))
                    oInternetBankingDetail.Curr = comlib.GetText(rdr.Item("Curr"))
                    oInternetBankingDetail.FormNum = comlib.GetText(rdr.Item("FormNum"))
                    oInternetBankingDetail.FromDept = comlib.GetText(rdr.Item("FromDept"))
                    oInternetBankingDetail.CreateDt = comlib.GetText(rdr.Item("CreateDt"))
                    oInternetBankingDetail.CreateBy = comlib.GetText(rdr.Item("CreateBy"))
                    oInternetBankingDetail.NettAmount = comlib.GetText(rdr.Item("NettAmount"))
                    oInternetBankingDetail.BeneficiaryName = comlib.GetText(rdr.Item("BeneficiaryName"))
                    oInternetBankingDetail.BeneficiaryBankCode = comlib.GetText(rdr.Item("BeneficiaryBankCode"))
                    oInternetBankingDetail.BeneficiaryBankAccount = comlib.GetText(rdr.Item("BeneficiaryBankAccount"))
                    oInternetBankingDetail.BeneficiaryEmail = comlib.GetText(rdr.Item("BeneficiaryEmail"))
                    oInternetBankingDetail.BeneficiaryBankCity = comlib.GetText(rdr.Item("BeneficiaryBankCity"))
                    oInternetBankingDetail.BeneficiaryAccountCurrency = comlib.GetText(rdr.Item("BeneficiaryAccountCurrency"))
                    oInternetBankingDetail.Subject = comlib.GetText(rdr.Item("Subject"))
                    oInternetBankingDetail.PaidBy = comlib.GetText(rdr.Item("PaidBy"))
                    oInternetBankingDetail.ExchangeRate = comlib.GetText(rdr.Item("ExchangeRate"))
                    oInternetBanking.totalRows = comlib.GetText(rdr.Item("totalRows"))
                    oInternetBanking.cInternetBankingDetail.Add(oInternetBankingDetail)
                End While

                oInternetBanking.message = "SUCCESS"
                oInternetBanking.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oInternetBanking

        End Function

        Public Function ProcessInternetBanking(pparam As cParams) As cResult
            Dim result As String = ""
            If pparam.paramtype = "ExtractDataIB" Then
                If pparam.skey2 = "CIMBIN" Then
                    Dim vbfrmLippo As New frmLippo
                    result = vbfrmLippo.frmLippo_Load("INHOUSE", pparam.companyid, pparam.skey2, pparam.skey3, pparam.skey4, pparam.userid)
                ElseIf pparam.skey2 = "CIMBIN1" Then
                    Dim vbfrmLippo As New frmLippo
                    result = vbfrmLippo.frmLippo_Load("INHOUSE", pparam.companyid, pparam.skey2, pparam.skey3, pparam.skey4, pparam.userid)
                ElseIf pparam.skey2 = "CIMBDC" Then
                    Dim vbfrmLippo As New frmLippo
                    result = vbfrmLippo.frmLippo_Load("DOMESTIC", pparam.companyid, pparam.skey2, pparam.skey3, pparam.skey4, pparam.userid)
                ElseIf pparam.skey2 = "CIMBDC1" Then
                    Dim vbfrmLippo As New frmLippo
                    result = vbfrmLippo.frmLippo_Load("DOMESTIC", pparam.companyid, pparam.skey2, pparam.skey3, pparam.skey4, pparam.userid)
                ElseIf pparam.skey2 = "BCA" Then
                    Dim vbfrmLippo As New frmLippo
                    result = vbfrmLippo.frmLippo_Load("BCA", pparam.companyid, pparam.skey2, pparam.skey3, pparam.skey4, pparam.userid)
                ElseIf pparam.skey2 = "BNI" Then
                    Dim vbfrmLippo As New frmLippo
                    result = vbfrmLippo.frmLippo_Load("BNI", pparam.companyid, pparam.skey2, pparam.skey3, pparam.skey4, pparam.userid)
                ElseIf pparam.skey2 = "MANDIRI" Then
                    Dim vbfrmLippo As New frmLippo
                    result = vbfrmLippo.frmLippo_Load("MANDIRI", pparam.companyid, pparam.skey2, pparam.skey3, pparam.skey4, pparam.userid)
                ElseIf pparam.skey2 = "MANDIRIIN" Then
                    Dim vbfrmLippo As New frmLippo
                    result = vbfrmLippo.frmLippo_Load("MANDIRI", pparam.companyid, pparam.skey2, pparam.skey3, pparam.skey4, pparam.userid)
                ElseIf pparam.skey2 = "MANDIRIDC" Then
                    Dim vbfrmLippo As New frmLippo
                    result = vbfrmLippo.frmLippo_Load("MANDIRI", pparam.companyid, pparam.skey2, pparam.skey3, pparam.skey4, pparam.userid)
                ElseIf pparam.skey2 = "MANDIRIIN1" Then
                    Dim vbfrmLippo As New frmLippo
                    result = vbfrmLippo.frmLippo_Load("MANDIRI", pparam.companyid, pparam.skey2, pparam.skey3, pparam.skey4, pparam.userid)
                ElseIf pparam.skey2 = "MANDIRIDC1" Then
                    Dim vbfrmLippo As New frmLippo
                    result = vbfrmLippo.frmLippo_Load("MANDIRI", pparam.companyid, pparam.skey2, pparam.skey3, pparam.skey4, pparam.userid)
                ElseIf pparam.skey2 = "MANDIRIUSIN" Then
                    Dim vbfrmLippo As New frmLippo
                    result = vbfrmLippo.frmLippo_Load("MANDIRI", pparam.companyid, pparam.skey2, pparam.skey3, pparam.skey4, pparam.userid)
                ElseIf pparam.skey2 = "MANDIRIUSDC" Then
                    Dim vbfrmLippo As New frmLippo
                    result = vbfrmLippo.frmLippo_Load("MANDIRI", pparam.companyid, pparam.skey2, pparam.skey3, pparam.skey4, pparam.userid)
                ElseIf pparam.skey2 = "HSBC" Then
                    Dim vbfrmHSBCnet As New frmHSBCnet
                    result = vbfrmHSBCnet.frmHSBCnet_Load("", pparam.companyid, pparam.skey2, pparam.skey3, pparam.skey4, pparam.userid)
                ElseIf pparam.skey2 = "CITIBANK" Then
                    Dim vbfrmCitibank As New frmCitibank
                    result = vbfrmCitibank.frmCitibank_Load("", pparam.companyid, pparam.skey2, pparam.skey3, pparam.skey4, pparam.userid)
                ElseIf pparam.skey2 = "DEUTSCHE" Then
                    Dim vbfrmDeutscheBank As New frmDeutscheBank
                    result = vbfrmDeutscheBank.frmDeutscheBank_Load("", pparam.companyid, pparam.skey2, pparam.skey3, pparam.skey4, pparam.userid)
                ElseIf pparam.skey2 = "PETTYCASH-SLFI" Then
                    Dim vbfrmPettyCash As New frmPettyCash
                    result = vbfrmPettyCash.frmPettyCash_Load("", pparam.companyid, pparam.skey2, pparam.skey3, pparam.skey4, pparam.userid)
                ElseIf pparam.skey2 = "ZEROSUM" Then
                    Dim vbfrmZeroSumPayment As New frmZeroSumPayment
                    result = vbfrmZeroSumPayment.frmZeroSumPayment_Load("", pparam.companyid, pparam.skey2, pparam.skey3, pparam.skey4, pparam.userid)
                End If

                'Process DB Extract Internet Banking
                Dim odal As New SQLAccess("core")
                Try
                    ores = New cResult
                    If ores.InvalidMessage = "" Then
                        odal.BeginTransactions()
                        odal.ExecuteCommandSP("usp_process_internetbanking",
                            odal.CreateParameter("@CompanyID", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                            odal.CreateParameter("@Table", SqlDbType.VarChar, comlib.GetText(pparam.paramtype)),
                            odal.CreateParameter("@ManyGER", SqlDbType.VarChar, comlib.GetText(result)),
                            odal.CreateParameter("@SunlifeBankID", SqlDbType.Char, comlib.GetText(pparam.skey2)),
                            odal.CreateParameter("@SunlifeBankAccountNo", SqlDbType.Char, comlib.GetText(pparam.skey3)),
                            odal.CreateParameter("@SunlifeBankCharge", SqlDbType.Char, comlib.GetText(pparam.skey4)),
                            odal.CreateParameter("@UserID", SqlDbType.VarChar, comlib.GetText(pparam.userid)),
                            odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))
                        ores.InvalidMessage = odal.ReturnValue(1).ToString

                        If Left(ores.InvalidMessage, 5) <> "ERROR" Then
                            odal.CommitTransactions()
                            ores.Result = "SUCCESS"
                        Else
                            odal.RollBackTransactions()
                            ores.Result = "ERROR"
                        End If
                    End If
                Catch ex As Exception
                    If Not IsNothing(odal) Then odal.RollBackTransactions()
                    ores = SetError(ex)
                    Throw ex
                Finally
                    odal.CloseAllConnection()
                    odal = Nothing
                End Try



            Else
                'For Process internet banking without extract Data 
                Dim odal As New SQLAccess("core")
                Try
                    ores = New cResult
                    If ores.InvalidMessage = "" Then
                        'odal.BeginTransactions()
                        odal.ExecuteCommandSP("usp_process_internetbanking",
                            odal.CreateParameter("@CompanyID", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                            odal.CreateParameter("@Table", SqlDbType.VarChar, comlib.GetText(pparam.paramtype)),
                            odal.CreateParameter("@ManyGER", SqlDbType.VarChar, comlib.GetText(pparam.skey1)),
                            odal.CreateParameter("@SunlifeBankID", SqlDbType.Char, comlib.GetText(pparam.skey2)),
                            odal.CreateParameter("@SunlifeBankAccountNo", SqlDbType.Char, comlib.GetText(pparam.skey3)),
                            odal.CreateParameter("@SunlifeBankCharge", SqlDbType.Char, comlib.GetText(pparam.skey4)),
                            odal.CreateParameter("@UserID", SqlDbType.VarChar, comlib.GetText(pparam.userid)),
                            odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))
                        ores.InvalidMessage = odal.ReturnValue(1).ToString

                        If Left(ores.InvalidMessage, 5) <> "ERROR" Then
                            'odal.CommitTransactions()
                        Else
                            'odal.RollBackTransactions()
                        End If
                    End If
                Catch ex As Exception
                    If Not IsNothing(odal) Then odal.RollBackTransactions()
                    ores = SetError(ex)
                    odal = Nothing
                End Try
            End If


            ores.Result = "SUCCESS"
            Return ores

        End Function

        'end ronald

        'Public Function GetCode(pprm As cParams) As cGERList
        '    Dim odal As New SQLAccess("core")
        '    Dim rdr As IDataReader

        '    Dim oGER As cGERList = Nothing
        '    oGER = New cGERList
        '    oGER.cGERDetail = New List(Of cGERDetail)()

        '    Dim oGERDetail As cGERDetail




        '    Try

        '        rdr = odal.ExecuteDataReader("sp_get_list_ger", CommandType.StoredProcedure,
        '                odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
        '                odal.CreateParameter("@view", SqlDbType.VarChar, comlib.GetText(pprm.paramtype)),
        '                odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)),
        '                odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.skey2)),
        '                odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pprm.skey3)),
        '                odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pprm.skey4)),
        '                odal.CreateParameter("@skey5", SqlDbType.VarChar, comlib.GetText(pprm.skey5)),
        '                odal.CreateParameter("@skey6", SqlDbType.VarChar, comlib.GetText(pprm.skey6)),
        '                odal.CreateParameter("@skey7", SqlDbType.VarChar, comlib.GetText(pprm.skey7)),
        '                odal.CreateParameter("@skey8", SqlDbType.VarChar, comlib.GetText(pprm.skey8)),
        '                odal.CreateParameter("@skey9", SqlDbType.VarChar, comlib.GetText(pprm.skey9)),
        '                odal.CreateParameter("@skey10", SqlDbType.VarChar, comlib.GetText(pprm.skey10)),
        '                odal.CreateParameter("@ikey1", SqlDbType.Int, comlib.GetInteger(pprm.ikey1)),
        '                odal.CreateParameter("@ikey2", SqlDbType.Int, comlib.GetInteger(pprm.ikey2)),
        '                odal.CreateParameter("@ikey3", SqlDbType.Int, comlib.GetInteger(pprm.ikey3)),
        '                odal.CreateParameter("@ikey4", SqlDbType.Int, comlib.GetInteger(pprm.ikey4)),
        '                odal.CreateParameter("@ikey5", SqlDbType.Int, comlib.GetInteger(pprm.ikey5)),
        '                odal.CreateParameter("@dkey1", SqlDbType.DateTime, comlib.CToDate(pprm.dkey1)),
        '                odal.CreateParameter("@dkey2", SqlDbType.DateTime, comlib.CToDate(pprm.dkey2)),
        '                odal.CreateParameter("@dkey3", SqlDbType.DateTime, comlib.CToDate(pprm.dkey3)),
        '                odal.CreateParameter("@dkey4", SqlDbType.DateTime, comlib.CToDate(pprm.dkey4)),
        '                odal.CreateParameter("@dkey5", SqlDbType.DateTime, comlib.CToDate(pprm.dkey5)),
        '                odal.CreateParameter("@userid", SqlDbType.VarChar, comlib.GetText(pprm.ProcessBy)),
        '                odal.CreateParameter("@pageno", SqlDbType.VarChar, comlib.GetText(pprm.pageno)),
        '                odal.CreateParameter("@pagesize", SqlDbType.VarChar, comlib.GetText(pprm.pagesize)))
        '        While rdr.Read
        '            oGERDetail = New cGERDetail
        '            oGERDetail.Location = comlib.GetText(rdr.Item("Location"))
        '            oGERDetail.Currency = comlib.GetText(rdr.Item("Currency"))
        '            oGERDetail.CompanyID = comlib.GetText(rdr.Item("CompanyID"))
        '            oGERDetail.Type = comlib.GetText(rdr.Item("Type"))
        '            oGERDetail.GERNo = comlib.GetText(rdr.Item("GerNo"))
        '            oGERDetail.Dept = comlib.GetText(rdr.Item("Dept"))
        '            oGERDetail.CARNo = comlib.GetText(rdr.Item("CARNo"))
        '            oGERDetail.CreatedDate = comlib.GetText(rdr.Item("CreatedDate"))
        '            oGERDetail.CreatedBy = comlib.GetText(rdr.Item("CreatedBy"))
        '            oGERDetail.TotalAmount = comlib.GetText(rdr.Item("TotalAmount"))
        '            oGERDetail.TaxAmount = comlib.GetText(rdr.Item("TaxAmount"))
        '            oGERDetail.NettAmount = comlib.GetText(rdr.Item("NettAmount"))
        '            oGERDetail.GERStatus = comlib.GetText(rdr.Item("GERStatus"))
        '            oGERDetail.TransactionCode = comlib.GetText(rdr.Item("TransactionCode"))
        '            oGERDetail.BeneficiaryName = comlib.GetText(rdr.Item("BeneficiaryName"))
        '            oGERDetail.BeneficiaryBankName = comlib.GetText(rdr.Item("BeneficiaryBankName"))
        '            oGERDetail.BeneficiaryBankAccount = comlib.GetText(rdr.Item("BeneficiaryBankAccount"))
        '            oGERDetail.PolicyNum = comlib.GetText(rdr.Item("PolicyNum"))
        '            oGERDetail.PolRelated = comlib.GetText(rdr.Item("PolRelated"))
        '            oGERDetail.VoucherNum = comlib.GetText(rdr.Item("VoucherNum"))
        '            oGERDetail.TransferredDate = comlib.GetText(rdr.Item("TransferredDate"))
        '            oGER.totalRows = comlib.GetText(rdr.Item("TotalRows"))
        '            oGER.cGERDetail.Add(oGERDetail)
        '        End While

        '        oGER.message = "SUCCESS"
        '        oGER.result = ""

        '    Catch ex As Exception
        '        Throw ex
        '    Finally
        '        rdr = Nothing
        '        pprm = Nothing
        '        odal.CloseAllConnection()
        '        odal = Nothing
        '    End Try
        '    Return oGER

        'End Function

        Public Function GetGERBeneficiaryList(pprm As ListGERBeneficiaryParam) As ListGERBeneficiary
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oGERBen As ListGERBeneficiary = Nothing
            oGERBen = New ListGERBeneficiary
            oGERBen.ListGERBeneficiaryDetail = New List(Of ListGERBeneficiaryDetail)()

            Dim oGERBenListDetail As ListGERBeneficiaryDetail




            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.CompanyID)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "List_GER_Beneficiary"),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.Dept)))
                While rdr.Read
                    oGERBenListDetail = New ListGERBeneficiaryDetail
                    oGERBenListDetail.BenID = comlib.GetText(rdr.Item("BenID"))
                    oGERBenListDetail.BeneficiaryName = comlib.GetText(rdr.Item("BeneficiaryName"))
                    oGERBenListDetail.Beneficiary_Bank_Name = comlib.GetText(rdr.Item("Beneficiary_Bank_Name"))
                    oGERBenListDetail.Beneficiary_Bank_Account = comlib.GetText(rdr.Item("Beneficiary_Bank_Account"))
                    oGERBenListDetail.Beneficiary_Bank_Branch = comlib.GetText(rdr.Item("Beneficiary_Bank_Branch"))
                    oGERBenListDetail.Beneficiary_Bank_City = comlib.GetText(rdr.Item("Beneficiary_Bank_City"))
                    oGERBenListDetail.Beneficiary_Email = comlib.GetText(rdr.Item("Beneficiary_Email"))
                    oGERBenListDetail.OnlyForDept = comlib.GetText(rdr.Item("OnlyForDept"))
                    oGERBenListDetail.BeneficiaryTypeCd = comlib.GetText(rdr.Item("BeneficiaryTypeCd"))
                    oGERBenListDetail.BeneficiaryResidenStatusCd = comlib.GetText(rdr.Item("BeneficiaryResidenStatusCd"))
                    oGERBenListDetail.BeneficiaryTranTypeCd = comlib.GetText(rdr.Item("BeneficiaryTranTypeCd"))
                    oGERBenListDetail.BeneficiaryTranfacilityTypeCd = comlib.GetText(rdr.Item("BeneficiaryTranfacilityTypeCd"))


                    oGERBenListDetail.BeneficiaryTypeCode = comlib.GetText(rdr.Item("BeneficiaryTypeCode"))
                    oGERBenListDetail.BeneficiaryResidenStatusCode = comlib.GetText(rdr.Item("BeneficiaryResidenStatusCode"))
                    oGERBenListDetail.BeneficiaryTranTypeCode = comlib.GetText(rdr.Item("BeneficiaryTranTypeCode"))
                    oGERBenListDetail.BeneficiaryTranfacilityTypeCode = comlib.GetText(rdr.Item("BeneficiaryTranfacilityTypeCode"))

                    oGERBenListDetail.BeneficiaryBankCode = comlib.GetText(rdr.Item("Beneficiary_Bank_Code"))

                    oGERBen.ListGERBeneficiaryDetail.Add(oGERBenListDetail)
                End While

                oGERBen.Message = "SUCCESS"
                oGERBen.Result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oGERBen

        End Function

#End Region

#Region "CAR"

#End Region

#Region "INTERNET BANKING"

        Public Function GetInetBankingList(ByVal pparam As cParams) As cInternetBanking
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oInternetBanking As cInternetBanking = Nothing
            oInternetBanking = New cInternetBanking
            oInternetBanking.cInternetBankingDetail = New List(Of cInternetBankingDetail)()

            Dim oInternetBankingDetail As cInternetBankingDetail

            Try

                rdr = odal.ExecuteDataReader("sp_get", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, comlib.GetText(pparam.paramtype)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pparam.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pparam.skey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pparam.skey3)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pparam.skey4)),
                        odal.CreateParameter("@skey5", SqlDbType.VarChar, comlib.GetText(pparam.skey5)),
                        odal.CreateParameter("@skey6", SqlDbType.VarChar, comlib.GetText(pparam.skey6)),
                        odal.CreateParameter("@skey7", SqlDbType.VarChar, comlib.GetText(pparam.skey7)),
                        odal.CreateParameter("@skey8", SqlDbType.VarChar, comlib.GetText(pparam.skey8)),
                        odal.CreateParameter("@skey9", SqlDbType.VarChar, comlib.GetText(pparam.skey9)),
                        odal.CreateParameter("@skey10", SqlDbType.VarChar, comlib.GetText(pparam.skey10)),
                        odal.CreateParameter("@ikey1", SqlDbType.Int, comlib.GetInteger(pparam.ikey1)),
                        odal.CreateParameter("@ikey2", SqlDbType.Int, comlib.GetInteger(pparam.ikey2)),
                        odal.CreateParameter("@ikey3", SqlDbType.Int, comlib.GetInteger(pparam.ikey3)),
                        odal.CreateParameter("@ikey4", SqlDbType.Int, comlib.GetInteger(pparam.ikey4)),
                        odal.CreateParameter("@ikey5", SqlDbType.Int, comlib.GetInteger(pparam.ikey5)),
                        odal.CreateParameter("@fkey1", SqlDbType.Float, comlib.GetDouble(pparam.fkey1)),
                        odal.CreateParameter("@fkey2", SqlDbType.Float, comlib.GetDouble(pparam.fkey2)),
                        odal.CreateParameter("@fkey3", SqlDbType.Float, comlib.GetDouble(pparam.fkey3)),
                        odal.CreateParameter("@fkey4", SqlDbType.Float, comlib.GetDouble(pparam.fkey4)),
                        odal.CreateParameter("@fkey5", SqlDbType.Float, comlib.GetDouble(pparam.fkey5)),
                        odal.CreateParameter("@dkey1", SqlDbType.DateTime, comlib.CToDate(pparam.dkey1)),
                        odal.CreateParameter("@dkey2", SqlDbType.DateTime, comlib.CToDate(pparam.dkey2)),
                        odal.CreateParameter("@dkey3", SqlDbType.DateTime, comlib.CToDate(pparam.dkey3)),
                        odal.CreateParameter("@dkey4", SqlDbType.DateTime, comlib.CToDate(pparam.dkey4)),
                        odal.CreateParameter("@dkey5", SqlDbType.DateTime, comlib.CToDate(pparam.dkey5)))
                While rdr.Read
                    oInternetBankingDetail = New cInternetBankingDetail
                    oInternetBankingDetail.ToGenerate = comlib.GetText(rdr.Item("ToGenerate"))
                    oInternetBankingDetail.TransactionCode = comlib.GetText(rdr.Item("TransactionCode"))
                    oInternetBankingDetail.Curr = comlib.GetText(rdr.Item("Curr"))
                    oInternetBankingDetail.FormNum = comlib.GetText(rdr.Item("FormNum"))
                    oInternetBankingDetail.FromDept = comlib.GetText(rdr.Item("FromDept"))
                    oInternetBankingDetail.CreateDt = comlib.GetText(rdr.Item("CreateDt"))
                    oInternetBankingDetail.CreateBy = comlib.GetText(rdr.Item("CreateBy"))
                    oInternetBankingDetail.NettAmount = comlib.GetText(rdr.Item("NettAmount"))
                    oInternetBankingDetail.BeneficiaryName = comlib.GetText(rdr.Item("BeneficiaryName"))
                    oInternetBankingDetail.BeneficiaryBankCode = comlib.GetText(rdr.Item("BeneficiaryBankCode"))
                    oInternetBankingDetail.BeneficiaryBankAccount = comlib.GetText(rdr.Item("BeneficiaryBankAccount"))
                    oInternetBankingDetail.BeneficiaryEmail = comlib.GetText(rdr.Item("BeneficiaryEmail"))
                    oInternetBankingDetail.BeneficiaryBankCity = comlib.GetText(rdr.Item("BeneficiaryBankCity"))
                    oInternetBankingDetail.TransactionCode = comlib.GetText(rdr.Item("TransactionCode"))
                    oInternetBankingDetail.BeneficiaryName = comlib.GetText(rdr.Item("BeneficiaryName"))
                    oInternetBankingDetail.BeneficiaryAccountCurrency = comlib.GetText(rdr.Item("BeneficiaryAccountCurrency"))
                    oInternetBankingDetail.Subject = comlib.GetText(rdr.Item("Subject"))
                    oInternetBankingDetail.PaidBy = comlib.GetText(rdr.Item("PaidBy"))
                    oInternetBankingDetail.ExchangeRate = comlib.GetText(rdr.Item("ExchangeRate"))
                    oInternetBanking.cInternetBankingDetail.Add(oInternetBankingDetail)
                End While

                oInternetBanking.message = "SUCCESS"
                oInternetBanking.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                ' pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oInternetBanking

        End Function
#End Region

#Region "Report"

        Public Function GetGEReportHeader(pprm As GEReportHeaderParam) As GEReportHeader
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oResult As GEReportHeader = Nothing
            oResult = New GEReportHeader


            Try

                rdr = odal.ExecuteDataReader("sp_getreport", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "Letter_Ger_Header"),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.GERNo)),
                        odal.CreateParameter("@processby", SqlDbType.VarChar, comlib.GetText(pprm.processby)))
                While rdr.Read
                    oResult.todepartment = comlib.GetText(rdr.Item("DeptName"))
                    oResult.fromdepartment = comlib.GetText(rdr.Item("FromDept"))
                    oResult.originalcurrency = comlib.GetText(rdr.Item("Curr"))
                    oResult.exchangerate = comlib.GetText(rdr.Item("ExchangeRate"))
                    oResult.paidincurrency = comlib.GetText(rdr.Item("BeneficiaryAccountCurrency"))
                    oResult.ponumber = comlib.GetText(rdr.Item("ApplicationNo"))
                    oResult.budgeted = comlib.GetText(rdr.Item("Budgeted"))
                    oResult.formnumber = comlib.GetText(rdr.Item("FormNum"))
                    oResult.createdate = comlib.GetText(rdr.Item("CreateDt"))
                    oResult.TransactionType = comlib.GetText(rdr.Item("TransactionName"))
                    oResult.policynumber = comlib.GetText(rdr.Item("PolicyNum"))
                    oResult.cashadvancenumber = comlib.GetText(rdr.Item("AdvanceFormNum"))
                    oResult.Subject = comlib.GetText(rdr.Item("Subject"))
                    oResult.PaidBy = comlib.GetText(rdr.Item("PaidBy"))
                    oResult.BeneficiaryName = comlib.GetText(rdr.Item("BeneficiaryName"))
                    oResult.Bank = comlib.GetText(rdr.Item("BeneficiaryBankName"))
                    oResult.AccountNumber = comlib.GetText(rdr.Item("BeneficiaryBankAccount"))
                    oResult.BankBranch = comlib.GetText(rdr.Item("BeneficiaryBankBranch"))
                    oResult.City = comlib.GetText(rdr.Item("BeneficiaryBankCity"))
                    oResult.BeneficiaryEmail = comlib.GetText(rdr.Item("BeneficiaryEmail"))
                    oResult.Totala = comlib.GetText(rdr.Item("TotalAmount"))
                    oResult.CashAdvanceb = comlib.GetText(rdr.Item("AdvanceAmount"))
                    oResult.DueFrom = comlib.GetText(rdr.Item("DueAmount"))
                    oResult.TotalTax = comlib.GetText(rdr.Item("TaxAmount"))
                    oResult.OriginalNettAmount = comlib.GetText(rdr.Item("NettAmount"))
                    oResult.IDRNettAmount = comlib.GetText(rdr.Item("NettAmount"))
                    oResult.CreateBy = comlib.GetText(rdr.Item("CreateBy"))

                End While

                oResult.Message = "SUCCESS"
                oResult.Result = ""

            Catch ex As Exception
                oResult.Message = "FAILURE"
                oResult.Result = ex.Message
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oResult

        End Function

        Public Function GetGEReportDetailList(pprm As GEReportHeaderParam) As GEReportDetail
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader


            Dim oResultDetail As GEReportDetail = Nothing
            oResultDetail = New GEReportDetail
            oResultDetail.GEReportDetailList = New List(Of GEReportDetailList)()

            Dim oResultDetailList As GEReportDetailList



            Try

                rdr = odal.ExecuteDataReader("sp_getreport", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "Letter_Ger_Detail"),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.GERNo)),
                        odal.CreateParameter("@processby", SqlDbType.VarChar, comlib.GetText(pprm.processby)))
                While rdr.Read
                    oResultDetailList = New GEReportDetailList
                    oResultDetailList.seqNum = comlib.GetText(rdr.Item("SeqNum"))
                    oResultDetailList.NO = comlib.GetText(rdr.Item("Nomor"))
                    oResultDetailList.Description = comlib.GetText(rdr.Item("Description"))
                    oResultDetailList.CostCenter = comlib.GetText(rdr.Item("CostCenter"))
                    oResultDetailList.AccountCode = comlib.GetText(rdr.Item("COA"))
                    oResultDetailList.OriginalAmount = comlib.GetText(rdr.Item("OriginalAmount"))
                    oResultDetailList.CoaUpdated = comlib.GetText(rdr.Item("coa_Updated"))
                    oResultDetail.GEReportDetailList.Add(oResultDetailList)
                End While

                oResultDetail.Message = "SUCCESS"
                oResultDetail.Result = ""

            Catch ex As Exception
                oResultDetail.Message = "FAILURE"
                oResultDetail.Result = ex.Message
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oResultDetail

        End Function

        Public Function GenerateReport(pprm As cParams) As GEReportDetail
            Dim url, destination As String
            Dim oResultDetail As GEReportDetail = Nothing
            oResultDetail = New GEReportDetail
            oResultDetail.GenReportDetail = New List(Of GenRepotDetail)()
            Dim GenReportDetail As GenRepotDetail

            Dim odal As New SQLAccess("core")
            'destination = Dts.Variables("Folder_Destination").Value.ToString + "\" + "Report_" + Dts.Variables("ReportParameter").Value.ToString + "_" + Format(Now, "yyyyMMdd") + ".xls"
            'destination = "\\Sv541048\snaps_report\Report_" + Format(Now, "yyyyMMdd") + ".xls"
            Dim rReportName As String = ""
            Dim rReportFormat As String = ""
            Dim rReportFilePathLocation As String = ""
            Dim rReportFileName As String = ""
            Dim rReportFileType As String = ""
            Dim rReporLink As String = ""


            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, pprm.companyid),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "GetReportSetup"),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, pprm.skey1))
                While rdr.Read
                    rReportName = comlib.GetText(rdr.Item("ReportName"))
                    rReportFormat = comlib.GetText(rdr.Item("ReportFormat"))
                    rReportFilePathLocation = comlib.GetText(rdr.Item("ReportFilePathLocation"))
                    rReportFileName = comlib.GetText(rdr.Item("ReportFileName"))
                    rReportFileType = comlib.GetText(rdr.Item("ReportFileType"))
                    rReporLink = comlib.GetText(rdr.Item("ReportLink"))
                End While

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try

            'destination = rReportFilePathLocation + Trim(rReportFileName) + "." + rReportFileType
            'url = rReporLink + rReportName + "&rs:Command=Render&skey1=" + pprm.param1.ToString + "&Companyid=" + company + "&rs:Format=" + rReportFormat
            url = rReporLink + pprm.skey1 + "&rs:Command=Render&" + pprm.skey2 + "&rs:Format=" + rReportFormat
            Dim dirFolder As String = rReportFilePathLocation + Trim(rReportFileName) + "\" + pprm.skey3
            If Not Directory.Exists(dirFolder) Then
                Directory.CreateDirectory(dirFolder)
            End If

            destination = dirFolder + "\" + Trim(rReportFileName) + "." + rReportFileType
            pprm.skey4 = rReportName

            If File.Exists(destination) Then
                File.Delete(destination)
                SaveFile(url, destination, pprm)
            Else
                SaveFile(url, destination, pprm)
            End If

            'Dts.TaskResult = ScriptResults.Success
            GenReportDetail = New GenRepotDetail
            GenReportDetail.ImageByte = Convert.ToBase64String(File.ReadAllBytes(destination))
            If rReportFileType = "PDF" Then
                GenReportDetail.MMType = "application/pdf"
            ElseIf rReportFileType = "XLS" Then
                GenReportDetail.MMType = "application/vnd.ms-excel"
            ElseIf rReportFileType = "XLSX" Then
                GenReportDetail.MMType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            End If

            GenReportDetail.FileName = Trim(rReportFileName)
            GenReportDetail.Attachment = rReportFormat
            oResultDetail.GenReportDetail.Add(GenReportDetail)

            'oResultDetail.GEReportDetailList.
            oResultDetail.Result = "SUCCESS"
            Return oResultDetail
        End Function

        Public Function GetReport() As ResultReport
            Dim url, destination As String
            Dim result As ResultReport

            url = "http://sv541046/ReportServer?/ReportClientPortal/HospitalListReport&rs:Command=Render&rs:Format=XLS"
            destination = ""

            SaveFile2(url, destination)
            result.MMType = "application/vnd.ms-excel"
            result.ImageByte = Convert.ToBase64String(File.ReadAllBytes(destination))
            Return result

        End Function

        Protected Sub SaveFile2(ByVal url As String, ByVal localpath As String)
            Dim loRequest As System.Net.HttpWebRequest
            Dim loResponse As System.Net.HttpWebResponse
            Dim userCredentials As System.Net.NetworkCredential = Nothing
            Dim loResponseStream As System.IO.Stream
            Dim loFileStream As New System.IO.FileStream(localpath, System.IO.FileMode.Create, System.IO.FileAccess.Write)
            Dim laBytes(256) As Byte
            Dim liCount As Integer = 1
            Try
                loRequest = CType(System.Net.WebRequest.Create(url), System.Net.HttpWebRequest)
                'loRequest.Credentials = System.Net.CredentialCache.DefaultCredentials()
                userCredentials = New System.Net.NetworkCredential("SQL", "Jktadmin01", "ID")
                loRequest.Credentials = userCredentials
                loRequest.Timeout = 600000
                loRequest.Method = "GET"
                loResponse = CType(loRequest.GetResponse, System.Net.HttpWebResponse)
                loResponseStream = loResponse.GetResponseStream
                Do While liCount > 0
                    liCount = loResponseStream.Read(laBytes, 0, 256)
                    loFileStream.Write(laBytes, 0, liCount)
                Loop
            Catch ex As Exception
                Throw ex
            Finally
                loFileStream.Flush()
                loFileStream.Close()
            End Try
        End Sub
        Public Function GenerateReport2(pprm As cParams) As GEReportDetail
            Dim url, destination As String
            Dim oResultDetail As GEReportDetail = Nothing
            oResultDetail = New GEReportDetail
            oResultDetail.GenReportDetail = New List(Of GenRepotDetail)()
            Dim GenReportDetail As GenRepotDetail

            Dim odal As New SQLAccess("core")
            'destination = Dts.Variables("Folder_Destination").Value.ToString + "\" + "Report_" + Dts.Variables("ReportParameter").Value.ToString + "_" + Format(Now, "yyyyMMdd") + ".xls"
            'destination = "\\Sv541048\snaps_report\Report_" + Format(Now, "yyyyMMdd") + ".xls"
            Dim rReportName As String = ""
            Dim rReportFormat As String = ""
            Dim rReportFilePathLocation As String = ""
            Dim rReportFileName As String = ""
            Dim rReportFileType As String = ""
            Dim rReporLink As String = ""
            Dim fileName As String = ""


            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, pprm.companyid),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "GetReportSetup"),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, pprm.skey1))
                While rdr.Read
                    rReportName = comlib.GetText(rdr.Item("ReportName"))
                    rReportFormat = comlib.GetText(rdr.Item("ReportFormat"))
                    rReportFilePathLocation = comlib.GetText(rdr.Item("ReportFilePathLocation"))
                    rReportFileName = comlib.GetText(rdr.Item("ReportFileName"))
                    rReportFileType = comlib.GetText(rdr.Item("ReportFileType"))
                    rReporLink = comlib.GetText(rdr.Item("ReportLink"))
                End While

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try

            'destination = rReportFilePathLocation + Trim(rReportFileName) + "." + rReportFileType
            'url = rReporLink + rReportName + "&rs:Command=Render&skey1=" + pprm.param1.ToString + "&Companyid=" + company + "&rs:Format=" + rReportFormat
            url = rReporLink + rReportName + "&rs:Command=Render&" + pprm.skey2 + "&rs:Format=" + rReportFormat
            Dim dirFolder As String = rReportFilePathLocation + Trim(rReportFileName) + "\" + Replace(pprm.skey3, "/", "-")
            If Not Directory.Exists(dirFolder) Then
                Directory.CreateDirectory(dirFolder)
            End If

            If (pprm.skey4 = "") Then
                destination = dirFolder + "\" + Replace(pprm.skey3, "/", "-") + "-VOUCHER" + "." + rReportFileType
                fileName = Replace(pprm.skey3, "/", "-") + "-VOUCHER" + "." + rReportFileType
            Else
                destination = dirFolder + "\" + pprm.skey4 + "_" + Trim(rReportFileName) + "." + rReportFileType
                fileName = pprm.skey4 + "_" + Trim(rReportFileName) + "." + rReportFileType
            End If
            pprm.skey4 = rReportName

            If File.Exists(destination) Then
                File.Delete(destination)
                SaveFile(url, destination, pprm)
            Else
                SaveFile(url, destination, pprm)
            End If

            'Dts.TaskResult = ScriptResults.Success
            GenReportDetail = New GenRepotDetail
            GenReportDetail.ImageByte = Convert.ToBase64String(File.ReadAllBytes(destination))
            If rReportFileType = "PDF" Then
                GenReportDetail.MMType = "application/pdf"
            ElseIf rReportFileType = "XLS" Then
                GenReportDetail.MMType = "application/vnd.ms-excel"
            ElseIf rReportFileType = "XLSX" Then
                GenReportDetail.MMType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            End If

            GenReportDetail.FileName = fileName
            GenReportDetail.Attachment = rReportFormat
            oResultDetail.GenReportDetail.Add(GenReportDetail)

            'oResultDetail.GEReportDetailList.
            oResultDetail.Result = "SUCCESS"
            oResultDetail.Message = destination

            Return oResultDetail
        End Function



        Public Function ProcessPrintTransactionLog(pParam As cParams) As cResult
            Dim odal As New SQLAccess("core")
            Try
                ores = New cResult

                odal.BeginTransactions()

                odal.ExecuteCommandSP("usp_Print_TransactionLog",
                                     odal.CreateParameter("@Companyid", SqlDbType.VarChar, pParam.companyid),
                                     odal.CreateParameter("@Table", SqlDbType.VarChar, pParam.skey1),
                                     odal.CreateParameter("@RefNo", SqlDbType.VarChar, pParam.skey3),
                                     odal.CreateParameter("@ReportName", SqlDbType.VarChar, pParam.skey4),
                                     odal.CreateParameter("@Others1", SqlDbType.VarChar, ""),
                                     odal.CreateParameter("@ProcessBy", SqlDbType.VarChar, pParam.userid),
                                     odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))
                ores.ReturnValue = odal.ReturnValue(1).ToString

                If ores.ReturnValue <> "" Then
                    ores.InvalidMessage = ""
                    odal.CommitTransactions()
                Else
                    odal.RollBackTransactions()
                End If

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return ores
        End Function

        Protected Sub SaveFile(ByVal url As String, ByVal localpath As String, ByVal params As cParams)
            Dim loRequest As System.Net.HttpWebRequest
            Dim loResponse As System.Net.HttpWebResponse
            'Dim credetialCache As System.Net.CredentialCache
            Dim userCredentials As System.Net.NetworkCredential = Nothing
            Dim loResponseStream As System.IO.Stream
            Dim loFileStream As New System.IO.FileStream(localpath, System.IO.FileMode.Create, System.IO.FileAccess.Write)
            Dim laBytes(256) As Byte
            Dim liCount As Integer = 1
            Try
                loRequest = CType(System.Net.WebRequest.Create(url), System.Net.HttpWebRequest)
                'loRequest.Credentials = System.Net.CredentialCache.DefaultCredentials()
                userCredentials = New System.Net.NetworkCredential("SQL", "Jktadmin01", "ID")
                loRequest.Credentials = userCredentials
                loRequest.Timeout = 600000
                loRequest.Method = "GET"
                loResponse = CType(loRequest.GetResponse, System.Net.HttpWebResponse)
                loResponseStream = loResponse.GetResponseStream

                Do While liCount > 0
                    liCount = loResponseStream.Read(laBytes, 0, 256)
                    loFileStream.Write(laBytes, 0, liCount)
                Loop
                ProcessPrintTransactionLog(params)
            Catch ex As Exception
                'ProcessPrintTransactionLog(params)
                Throw ex
            Finally
                loFileStream.Flush()
                loFileStream.Close()
            End Try
        End Sub


        Public Function GetReportExtract(params As cParams) As cReportExtract
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oReportExtract As cReportExtract = Nothing
            oReportExtract = New cReportExtract
            oReportExtract.cReportExtractDetail = New List(Of cReportExtractDetail)()

            Dim cReportExtractDetailList As cReportExtractDetail
            Try

                rdr = odal.ExecuteDataReader("usp_ExtractReport", CommandType.StoredProcedure,
                        odal.CreateParameter("@Companyid", SqlDbType.VarChar, comlib.GetText(params.companyid)),
                        odal.CreateParameter("@Table", SqlDbType.VarChar, params.paramtype))
                While rdr.Read
                    cReportExtractDetailList = New cReportExtractDetail
                    cReportExtractDetailList.VoucherNum = comlib.GetText(rdr.Item("VoucherNum"))
                    cReportExtractDetailList.SLFIBankAccountNum = comlib.GetText(rdr.Item("SLFIbankAccountNum"))
                    cReportExtractDetailList.FormNum = comlib.GetText(rdr.Item("FormNum"))
                    cReportExtractDetailList.TotalAmount = comlib.GetText(rdr.Item("TotalAmount"))
                    cReportExtractDetailList.TaxAmount = comlib.GetText(rdr.Item("TaxAmount"))
                    cReportExtractDetailList.NettAmount = comlib.GetText(rdr.Item("NettAmount"))
                    cReportExtractDetailList.BeneficiaryName = comlib.GetText(rdr.Item("BeneficiaryName"))
                    oReportExtract.cReportExtractDetail.Add(cReportExtractDetailList)
                End While

                oReportExtract.message = "SUCCESS"
                oReportExtract.result = ""

            Catch ex As Exception
                oReportExtract.message = "FAILURE"
                oReportExtract.result = ex.Message
            Finally
                rdr = Nothing
                params = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oReportExtract
        End Function

        Public Function ExtractIngenandSL(params As cParams) As cResult
            Try
                ores = New cResult
                Dim vbfrmAccountingExtract As New frmAccountingExtract

                ores.Message = vbfrmAccountingExtract.cmdExtract_Click(params.companyid, params.userid, params.skey1)
                ores.Result = "SUCCESS"
            Catch ex As Exception
                ores.Result = "FAILED"
                Throw ex
            End Try
            Return ores
        End Function


#End Region

#Region "GER Detail"

        'Created : RS
        'Date   : 5 June 2018
        'Desc   : Get Data Entertainment Detail

        Public Function getEntertainmentGERDetail(pprm As gerDetailParam) As entertainmentGERModel
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oEnterGERDetail As entertainmentGERModel = Nothing
            oEnterGERDetail = New entertainmentGERModel
            oEnterGERDetail.listEntertainmentGER = New List(Of entertainmentGER_List_Model)()
            oEnterGERDetail.comboTitleEntertainment = New List(Of ComboValue)()
            oEnterGERDetail.comboTypeCompany = New List(Of ComboValue)()
            oEnterGERDetail.comboReason = New List(Of ComboValue)()
            oEnterGERDetail.comboTypeOfEntertaiment = New List(Of ComboValue)()

            Dim oEnterGERDetailList As entertainmentGER_List_Model
            Dim oComboValue As ComboValue

            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyID)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "List_GER_Entertainment"),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.gerNo)))
                While rdr.Read
                    oEnterGERDetailList = New entertainmentGER_List_Model
                    oEnterGERDetailList.seqNum = comlib.GetText(rdr.Item("seqNum"))
                    oEnterGERDetailList.nomor = comlib.GetText(rdr.Item("nomor"))
                    oEnterGERDetailList.entrDate = comlib.GetText(rdr.Item("entrDate"))
                    oEnterGERDetailList.personNm = comlib.GetText(rdr.Item("personNm"))
                    oEnterGERDetailList.companyNm = comlib.GetText(rdr.Item("companyNm"))
                    oEnterGERDetailList.title = comlib.GetText(rdr.Item("title"))
                    oEnterGERDetailList.place = comlib.GetText(rdr.Item("place"))
                    oEnterGERDetailList.entertainmentType = comlib.GetText(rdr.Item("entertainmentType"))
                    oEnterGERDetailList.idrAmount = comlib.GetText(rdr.Item("idrAmount"))
                    oEnterGERDetailList.reason = comlib.GetText(rdr.Item("reason"))
                    oEnterGERDetailList.ProvidedNm = comlib.GetText(rdr.Item("ProvidedNm"))
                    oEnterGERDetailList.typeOfCompany = comlib.GetText(rdr.Item("typeOfCompany"))
                    oEnterGERDetailList.fullAddress = comlib.GetText(rdr.Item("fullAddress"))
                    oEnterGERDetailList.EntertaimentTypeDesc = comlib.GetText(rdr.Item("EntertaimentTypeDesc"))
                    oEnterGERDetailList.ReasonDesc = comlib.GetText(rdr.Item("ReasonDesc"))
                    oEnterGERDetail.listEntertainmentGER.Add(oEnterGERDetailList)

                End While

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@table", SqlDbType.VarChar, "combo_ENTRE_title"))
                While rdr.Read
                    oComboValue = New ComboValue
                    oComboValue.CodeID = comlib.GetText(rdr.Item("CodeID"))
                    oComboValue.DescriptionID = comlib.GetText(rdr.Item("DescriptionID"))
                    oComboValue.Others1 = comlib.GetText(rdr.Item("Others1"))
                    oComboValue.Others2 = comlib.GetText(rdr.Item("Others2"))
                    oComboValue.Others3 = comlib.GetText(rdr.Item("Others3"))
                    oComboValue.Others4 = comlib.GetText(rdr.Item("Others4"))
                    oComboValue.Others5 = comlib.GetText(rdr.Item("Others5"))
                    oEnterGERDetail.comboTitleEntertainment.Add(oComboValue)
                End While

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@table", SqlDbType.VarChar, "combo_ENTRE_typeCompany"))
                While rdr.Read
                    oComboValue = New ComboValue
                    oComboValue.CodeID = comlib.GetText(rdr.Item("CodeID"))
                    oComboValue.DescriptionID = comlib.GetText(rdr.Item("DescriptionID"))
                    oComboValue.Others1 = comlib.GetText(rdr.Item("Others1"))
                    oComboValue.Others2 = comlib.GetText(rdr.Item("Others2"))
                    oComboValue.Others3 = comlib.GetText(rdr.Item("Others3"))
                    oComboValue.Others4 = comlib.GetText(rdr.Item("Others4"))
                    oComboValue.Others5 = comlib.GetText(rdr.Item("Others5"))
                    oEnterGERDetail.comboTypeCompany.Add(oComboValue)
                End While

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@table", SqlDbType.VarChar, "combo_ENTRE_Reason"))
                While rdr.Read
                    oComboValue = New ComboValue
                    oComboValue.CodeID = comlib.GetText(rdr.Item("CodeID"))
                    oComboValue.DescriptionID = comlib.GetText(rdr.Item("DescriptionID"))
                    oComboValue.Others1 = comlib.GetText(rdr.Item("Others1"))
                    oComboValue.Others2 = comlib.GetText(rdr.Item("Others2"))
                    oComboValue.Others3 = comlib.GetText(rdr.Item("Others3"))
                    oComboValue.Others4 = comlib.GetText(rdr.Item("Others4"))
                    oComboValue.Others5 = comlib.GetText(rdr.Item("Others5"))
                    oEnterGERDetail.comboReason.Add(oComboValue)
                End While

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@table", SqlDbType.VarChar, "combo_ENTRE_typeOfEntertaiment"))
                While rdr.Read
                    oComboValue = New ComboValue
                    oComboValue.CodeID = comlib.GetText(rdr.Item("CodeID"))
                    oComboValue.DescriptionID = comlib.GetText(rdr.Item("DescriptionID"))
                    oComboValue.Others1 = comlib.GetText(rdr.Item("Others1"))
                    oComboValue.Others2 = comlib.GetText(rdr.Item("Others2"))
                    oComboValue.Others3 = comlib.GetText(rdr.Item("Others3"))
                    oComboValue.Others4 = comlib.GetText(rdr.Item("Others4"))
                    oComboValue.Others5 = comlib.GetText(rdr.Item("Others5"))
                    oEnterGERDetail.comboTypeOfEntertaiment.Add(oComboValue)
                End While


                oEnterGERDetail.message = "SUCCESS"
                oEnterGERDetail.result = ""

            Catch ex As Exception
                oEnterGERDetail.message = "FAILURE"
                oEnterGERDetail.result = "Problem with Services"
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oEnterGERDetail

        End Function

        'Created : RS
        'Date   : 6 June 2018
        'Desc   : Get Data Travel Detail

        Public Function getTravelGERDetail(pprm As gerDetailParam) As travelGERModel
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oTravleGERDetail As travelGERModel = Nothing
            oTravleGERDetail = New travelGERModel
            oTravleGERDetail.listTravelGER = New List(Of travelGER_List_Model)()

            Dim oTravelGERDetailList As travelGER_List_Model

            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyID)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "List_GER_Travel"),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.gerNo)))
                While rdr.Read
                    oTravelGERDetailList = New travelGER_List_Model
                    oTravelGERDetailList.seqNum = comlib.GetText(rdr.Item("seqNum"))
                    oTravelGERDetailList.nomor = comlib.GetText(rdr.Item("nomorRow"))
                    oTravelGERDetailList.typeOfExpenses = comlib.GetText(rdr.Item("typeOfExpenses"))
                    oTravelGERDetailList.originalAmount = comlib.GetText(rdr.Item("originalAmount"))
                    oTravelGERDetailList.originalCurr = comlib.GetText(rdr.Item("originalCurr"))
                    oTravelGERDetailList.exchangeRate = comlib.GetText(rdr.Item("exchangeRate"))
                    oTravelGERDetailList.idrAmount = comlib.GetText(rdr.Item("idrAmount"))

                    If Not oTravelGERDetailList.seqNum Is Nothing And Not oTravelGERDetailList.seqNum Is "" Then
                        oTravleGERDetail.listTravelGER.Add(oTravelGERDetailList)
                    End If

                    oTravleGERDetail.travellerName = comlib.GetText(rdr.Item("TravellerName"))
                    oTravleGERDetail.dateFrom = comlib.GetText(rdr.Item("dateFrom"))
                    oTravleGERDetail.dateUntil = comlib.GetText(rdr.Item("dateUntil"))
                    oTravleGERDetail.department = comlib.GetText(rdr.Item("Department"))
                    oTravleGERDetail.tripDestination = comlib.GetText(rdr.Item("TripDestination"))
                    oTravleGERDetail.travelTransport = comlib.GetText(rdr.Item("TransportMode"))
                    oTravleGERDetail.travelMillage = comlib.GetText(rdr.Item("Millage"))
                    oTravleGERDetail.tripPurpose = comlib.GetText(rdr.Item("TripPurpose"))

                    oTravleGERDetail.lengthOfTrip = comlib.GetInteger(rdr.Item("LengthOfTrip"))
                    oTravleGERDetail.travellerPosition = comlib.GetText(rdr.Item("TravellerPosition"))

                    oTravleGERDetail.creditCardOriginalAmount = comlib.GetText(rdr.Item("CreditCardOAmount"))
                    oTravleGERDetail.creditCardOriginalCurrency = comlib.GetText(rdr.Item("CreditCardOCurr"))
                    oTravleGERDetail.creditCardExchangeRate = comlib.GetText(rdr.Item("CreditCardExchangeRate"))
                    oTravleGERDetail.creditCardAmount = comlib.GetText(rdr.Item("CreditCardIdrAmount"))

                    oTravleGERDetail.cashAdvanceOriginalAmount = comlib.GetText(rdr.Item("CashAdvanceOAmount"))
                    oTravleGERDetail.cashAdvanceOriginalCurrency = comlib.GetText(rdr.Item("CashAdvanceOCurr"))
                    oTravleGERDetail.cashAdvanceExchangeRate = comlib.GetText(rdr.Item("CashAdvanceExchangeRate"))
                    oTravleGERDetail.cashAdvanceAmount = comlib.GetText(rdr.Item("CashAdvanceIdrAmount"))

                    oTravleGERDetail.prepaidOriginalAmount = comlib.GetText(rdr.Item("PrePaidOAmount"))
                    oTravleGERDetail.prepaidOriginalCurrency = comlib.GetText(rdr.Item("PrePaidOCurr"))
                    oTravleGERDetail.prepaidExchangeRate = comlib.GetText(rdr.Item("PrePaidExchangeRate"))
                    oTravleGERDetail.prepaidAmount = comlib.GetText(rdr.Item("PrepaidIdrAmount"))

                    oTravleGERDetail.totalAmount = comlib.GetText(rdr.Item("TotalIdrAmount"))
                    oTravleGERDetail.dueAmount = comlib.GetText(rdr.Item("DueAmount"))
                End While

                oTravleGERDetail.message = "SUCCESS"
                oTravleGERDetail.result = ""

            Catch ex As Exception
                oTravleGERDetail.message = "FAILURE"
                oTravleGERDetail.result = "Problem with Services"
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oTravleGERDetail

        End Function

        'Created : RS
        'Date   : 6 June 2018
        'Desc   : insert Data Detail GER

        Public Function insertGERDetailData(pGer As gerDetailParamBulk) As cResult
            Dim odal As New SQLAccess("core")
            Try
                ores = New cResult

                If pGer.bulkGERDetailData.Count = 0 Then
                    ores.Message = "SUCCESS"
                    ores.Result = ""
                    Return ores
                End If

                odal.BeginTransactions()

                odal.ExecuteCommandSP("usp_SaveGER_Detail",
                                     odal.CreateParameter("@typeEdit", SqlDbType.VarChar, "DELETE"),
                                     odal.CreateParameter("@CompanyID", SqlDbType.VarChar, pGer.bulkGERDetailData(0).companyID),
                                     odal.CreateParameter("@FormNum", SqlDbType.VarChar, pGer.bulkGERDetailData(0).formNum))

                odal.CommitTransactions()

                odal.BeginTransactions()

                For Each bulkValue As gerDetail In pGer.bulkGERDetailData

                    odal.ExecuteCommandSP("usp_SaveGER_Detail",
                                     odal.CreateParameter("@typeEdit", SqlDbType.VarChar, "NEW"),
                                     odal.CreateParameter("@CompanyID", SqlDbType.VarChar, comlib.GetText(bulkValue.companyID)),
                                     odal.CreateParameter("@FormNum", SqlDbType.VarChar, comlib.GetText(bulkValue.formNum)),
                                     odal.CreateParameter("@SeqNum", SqlDbType.VarChar, comlib.GetText(bulkValue.seqNum)),
                                     odal.CreateParameter("@Nomor", SqlDbType.VarChar, comlib.GetText(bulkValue.nomor)),
                                     odal.CreateParameter("@Description", SqlDbType.VarChar, comlib.GetText(bulkValue.description)),
                                     odal.CreateParameter("@CostCenter", SqlDbType.VarChar, comlib.GetText(bulkValue.costCenter)),
                                     odal.CreateParameter("@COA", SqlDbType.VarChar, comlib.GetText(bulkValue.coa)),
                                     odal.CreateParameter("@OriginalAmount", SqlDbType.Float, comlib.GetDouble(bulkValue.originalAmount)),
                                     odal.CreateParameter("@codeCostCenter", SqlDbType.VarChar, comlib.GetText(bulkValue.codecostcenter)),
                                     odal.CreateParameter("@isSyaFlag", SqlDbType.Int, comlib.GetInteger(bulkValue.isSyaFlag)),
                                     odal.CreateParameter("@SegCode", SqlDbType.VarChar, comlib.GetText(bulkValue.segCode)),
                                     odal.CreateParameter("@InvoiceNo", SqlDbType.VarChar, comlib.GetText(bulkValue.invoiceNo)),
                                     odal.CreateParameter("@adpro", SqlDbType.VarChar, comlib.GetText(bulkValue.adpro)),
                                     odal.CreateParameter("@adproL", SqlDbType.VarChar, comlib.GetText(bulkValue.adproL)),
                                     odal.CreateParameter("@CertificatNo", SqlDbType.VarChar, comlib.GetText(bulkValue.certificateNo)),
                                     odal.CreateParameter("@PolicyNo", SqlDbType.VarChar, comlib.GetText(bulkValue.policyNo)))


                Next

                odal.CommitTransactions()

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return ores
        End Function

        Public Function insertBulkListNoId(listNoId As cBulkListNoId) As cResult
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader
            Try
                ores = New cResult
                If listNoId.bulkListNoId.Count = 0 Then
                    ores.Message = "SUCCESS"
                    ores.Result = ""
                    Return ores
                End If

                odal.BeginTransactions()
                odal.ExecuteCommandSP("usp_save_bulk_listnoid",
                                    odal.CreateParameter("@CompanyID", SqlDbType.VarChar, comlib.GetText(listNoId.bulkListNoId.Item(0).CompanyID)),
                                    odal.CreateParameter("@FormNum", SqlDbType.VarChar, comlib.GetText(listNoId.bulkListNoId.Item(0).FormNum)),
                                    odal.CreateParameter("@ListNoId", SqlDbType.VarChar, comlib.GetText("")),
                                    odal.CreateParameter("@ket", SqlDbType.VarChar, comlib.GetText("delete")))
                odal.CommitTransactions()

                ' odal.BeginTransactions()
                For Each bulkValue As cListNoIdC In listNoId.bulkListNoId
                    odal.ExecuteCommandSP("usp_save_bulk_listnoid",
                                    odal.CreateParameter("@CompanyID", SqlDbType.VarChar, comlib.GetText(bulkValue.CompanyID)),
                                    odal.CreateParameter("@FormNum", SqlDbType.VarChar, comlib.GetText(bulkValue.FormNum)),
                                    odal.CreateParameter("@ListNoId", SqlDbType.VarChar, comlib.GetText(bulkValue.ListNoId)),
                                    odal.CreateParameter("@ket", SqlDbType.VarChar, comlib.GetText("insert")))

                    rdr = odal.ExecuteDataReader("usp_detail_data_MFE", CommandType.StoredProcedure,
                                    odal.CreateParameter("@ID", SqlDbType.VarChar, comlib.GetText(bulkValue.ID)))
                    While rdr.Read
                        odal.ExecuteCommandSP("usp_insert_detail_dataMFE",
                                    odal.CreateParameter("@MajorProduct", SqlDbType.VarChar, comlib.GetText(rdr.Item("MajorProduct"))),
                                    odal.CreateParameter("@NaturalAccountIFRS17", SqlDbType.VarChar, comlib.GetText(rdr.Item("NaturalAccountIFRS17"))),
                                    odal.CreateParameter("@CostCenter", SqlDbType.VarChar, comlib.GetText(rdr.Item("CostCenter"))),
                                    odal.CreateParameter("@Amount", SqlDbType.VarChar, comlib.GetText(rdr.Item("Amount"))),
                                    odal.CreateParameter("@Currency", SqlDbType.VarChar, comlib.GetText(rdr.Item("Currency"))),
                                    odal.CreateParameter("@InterSegment", SqlDbType.VarChar, comlib.GetText(rdr.Item("InterSegment"))),
                                    odal.CreateParameter("@InsuranceIndicator", SqlDbType.VarChar, comlib.GetText(rdr.Item("InsuranceIndicator"))),
                                    odal.CreateParameter("@Residence", SqlDbType.VarChar, comlib.GetText(rdr.Item("Residence"))),
                                    odal.CreateParameter("@IFRS17Portofolio", SqlDbType.VarChar, comlib.GetText(rdr.Item("IFRS17Portofolio"))),
                                    odal.CreateParameter("@IFRS17PortofolioGrouping", SqlDbType.VarChar, comlib.GetText(rdr.Item("IFRS17PortofolioGrouping"))),
                                    odal.CreateParameter("@UnderlyingDirectGroup", SqlDbType.VarChar, comlib.GetText(rdr.Item("UnderlyingDirectGroup"))),
                                    odal.CreateParameter("@CashflowIndicator", SqlDbType.VarChar, comlib.GetText(rdr.Item("CashflowIndicator"))),
                                    odal.CreateParameter("@ProductType", SqlDbType.VarChar, comlib.GetText(rdr.Item("ProductType"))),
                                    odal.CreateParameter("@DistributionChannel", SqlDbType.VarChar, comlib.GetText(rdr.Item("DistributionChannel"))),
                                    odal.CreateParameter("@Reinsurer", SqlDbType.VarChar, comlib.GetText(rdr.Item("Reinsurer"))),
                                    odal.CreateParameter("@LineItemText", SqlDbType.VarChar, comlib.GetText(rdr.Item("LineItemText"))),
                                    odal.CreateParameter("@TransactionDescription", SqlDbType.VarChar, comlib.GetText(rdr.Item("TransactionDescription"))),
                                    odal.CreateParameter("@IsTotal", SqlDbType.VarChar, comlib.GetInteger(rdr.Item("IsTotal"))),
                                    odal.CreateParameter("@ID", SqlDbType.VarChar, comlib.GetText(bulkValue.ID)),
                                    odal.CreateParameter("@Formnum", SqlDbType.VarChar, comlib.GetText(bulkValue.FormNum)))
                    End While

                Next
                ' odal.CommitTransactions()


            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return ores
        End Function

        Public Function GETSumListNoID(pListNoID As cParams) As String
            Dim odal As New SQLAccess("core")
            Dim rValue As String = 0

            Dim rdr As IDataReader

            Try
                rdr = odal.ExecuteDataReader("usp_get_sum_ListNoID", CommandType.StoredProcedure,
                        odal.CreateParameter("@ListNoID", SqlDbType.VarChar, comlib.GetText(pListNoID.skey1)))
                While rdr.Read
                    rValue = comlib.GetText(rdr.Item("NettReinsPremium"))
                End While

            Catch ex As Exception
                rValue = 0
            Finally
                rdr = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return rValue
        End Function

#End Region

#Region "View Tax"
        Public Function GetTAXSummary(pprm As cParams) As cTAXList
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oTAX As cTAXList = Nothing
            oTAX = New cTAXList
            oTAX.cTAXDetail = New List(Of cTAXDetail)()

            Dim oTAXDetail As cTAXDetail


            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "List_TaxEntry_Summary"),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)))
                While rdr.Read
                    'oTAXDetail = New cTAXDetail
                    oTAX.FormNum = comlib.GetText(rdr.Item("FormNum"))
                    oTAX.BeneficiaryName = comlib.GetText(rdr.Item("BeneficiaryName"))
                    oTAX.ExchangeRate = comlib.GetText(rdr.Item("ExchangeRate"))
                    oTAX.Curr = comlib.GetText(rdr.Item("Curr"))
                    oTAX.TotalAmount = comlib.GetText(rdr.Item("TotalAmount"))
                    oTAX.TaxAmount = comlib.GetText(rdr.Item("TaxAmount"))
                    oTAX.TaxSubsidy = comlib.GetText(rdr.Item("TaxSubsidy"))
                    oTAX.NettAmount = comlib.GetText(rdr.Item("NettAmount"))
                    oTAX.FormStatus = comlib.GetText(rdr.Item("FormStatus"))
                    oTAX.PolRelated = comlib.GetText(rdr.Item("PolRelated"))
                    oTAX.AdvanceAmount = comlib.GetText(rdr.Item("AdvanceAmount"))

                End While


                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "List_TaxEntry_Detail"),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)))
                While rdr.Read
                    oTAXDetail = New cTAXDetail
                    oTAXDetail.No = comlib.GetText(rdr.Item("No"))
                    oTAXDetail.InvoiceNum = comlib.GetText(rdr.Item("InvoiceNum"))
                    oTAXDetail.TypeOfCost = comlib.GetText(rdr.Item("TypeOfCost"))
                    oTAXDetail.TypeOfTax = comlib.GetText(rdr.Item("TypeOfTax"))
                    oTAXDetail.TypeOfCalc = comlib.GetText(rdr.Item("TypeOfCalc"))
                    oTAXDetail.OrigTaxableAmt = comlib.GetText(rdr.Item("OrigTaxableAmt"))
                    oTAXDetail.OrigTaxAmt = comlib.GetText(rdr.Item("OrigTaxAmt"))
                    oTAXDetail.TaxDeducted = comlib.GetText(rdr.Item("TaxDeducted"))
                    oTAXDetail.IdrTaxAmount = comlib.GetText(rdr.Item("IdrTaxAmount"))
                    oTAXDetail.NamaWP = comlib.GetText(rdr.Item("NamaWP"))
                    oTAXDetail.NPWP = comlib.GetText(rdr.Item("NPWP"))
                    oTAXDetail.NIK = comlib.GetText(rdr.Item("NIK"))
                    oTAXDetail.Description = comlib.GetText(rdr.Item("Description"))
                    oTAXDetail.TaxRate = comlib.GetText(rdr.Item("TaxRate"))
                    oTAXDetail.ExchangeRate = comlib.GetText(rdr.Item("ExchangeRate"))
                    oTAXDetail.AccountCode = comlib.GetText(rdr.Item("AccountCode"))
                    oTAXDetail.KodeWP = comlib.GetText(rdr.Item("KodeWP"))
                    oTAXDetail.NamaWP = comlib.GetText(rdr.Item("NamaWP"))
                    oTAXDetail.TaxId = comlib.GetText(rdr.Item("TaxID"))
                    oTAXDetail.PerkiraanPenghasilanBruto = comlib.GetText(rdr.Item("perkPenghBruto"))
                    oTAXDetail.TarifUmum = comlib.GetText(rdr.Item("TarifUmum"))
                    oTAXDetail.IdrTaxableAmount = comlib.GetText(rdr.Item("IdrTaxableAmount"))
                    oTAXDetail.LokasiTanahBangunan = comlib.GetText(rdr.Item("LokasiTanahBangunan"))
                    oTAXDetail.DJPOnline = comlib.GetText(rdr.Item("DJPOnline"))
                    oTAX.cTAXDetail.Add(oTAXDetail)
                End While
                oTAX.message = "SUCCESS"
                oTAX.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oTAX

        End Function

        Public Function GetTAXDetail(pprm As cParams) As cTAXDetail
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            'Dim oTAX As cTAXList = Nothing
            'oTAX = New cTAXList
            'oTAX.cTAXDetail = New List(Of cTAXDetail)()

            Dim oTAXDetail As cTAXDetail


            Try


                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "Key_TaxDetail"),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)))
                While rdr.Read
                    oTAXDetail = New cTAXDetail
                    oTAXDetail.No = comlib.GetText(rdr.Item("No"))
                    oTAXDetail.InvoiceNum = comlib.GetText(rdr.Item("InvoiceNum"))
                    oTAXDetail.TypeOfCost = comlib.GetText(rdr.Item("TypeOfCost"))
                    oTAXDetail.TypeOfTax = comlib.GetText(rdr.Item("TypeOfTax"))
                    oTAXDetail.TypeOfCalc = comlib.GetText(rdr.Item("TypeOfCalc"))
                    oTAXDetail.OrigTaxableAmt = comlib.GetText(rdr.Item("OrigTaxableAmt"))
                    oTAXDetail.OrigTaxAmt = comlib.GetText(rdr.Item("OrigTaxAmt"))
                    oTAXDetail.TaxDeducted = comlib.GetText(rdr.Item("TaxDeducted"))
                    oTAXDetail.IdrTaxAmount = comlib.GetText(rdr.Item("IdrTaxAmount"))
                    oTAXDetail.NamaWP = comlib.GetText(rdr.Item("NamaWP"))
                    oTAXDetail.NPWP = comlib.GetText(rdr.Item("NPWP"))
                    oTAXDetail.Description = comlib.GetText(rdr.Item("Description"))
                    oTAXDetail.TaxRate = comlib.GetText(rdr.Item("TaxRate"))
                    oTAXDetail.ExchangeRate = comlib.GetText(rdr.Item("ExchangeRate"))
                    oTAXDetail.AccountCode = comlib.GetText(rdr.Item("AccountCode"))
                    'oTAX.cTAXDetail.Add(oTAXDetail)
                End While
                'oTAX.message = "SUCCESS"
                'oTAX.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oTAXDetail

        End Function


        Public Function TaxUpdateHeader(pparam As cParams) As cResult

            Dim odal As New SQLAccess("core")
            Try
                ores = New cResult
                'Validation
                'ores.InvalidMessage = IsValid(odal, pparam)

                'Run Tasks
                If ores.InvalidMessage = "" Then
                    odal.BeginTransactions()
                    odal.ExecuteCommandSP("usp_SAVETaxSubsidy",
                        odal.CreateParameter("@CompanyID", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                        odal.CreateParameter("@Table", SqlDbType.VarChar, comlib.GetText(pparam.skey1)),
                        odal.CreateParameter("@FormNum", SqlDbType.VarChar, comlib.GetText(pparam.skey2)),
                        odal.CreateParameter("@TaxSubsidy", SqlDbType.VarChar, comlib.GetText(pparam.skey3)),
                        odal.CreateParameter("@ProcessBy", SqlDbType.VarChar, comlib.GetText(pparam.skey4)),
                        odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))
                    ores.InvalidMessage = odal.ReturnValue(1).ToString

                    If ores.InvalidMessage = "Berhasil" Then
                        odal.CommitTransactions()
                    Else
                        odal.RollBackTransactions()
                    End If
                End If
            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            ores.Result = "SUCCESS"
            Return ores

        End Function

        Public Function TaxUpdateDetail(pparam As cTAXDetail) As cResult

            Dim odal As New SQLAccess("core")

            Try
                ores = New cResult
                'Validation
                'ores.InvalidMessage = IsValid(odal, pparam)

                'Run Tasks
                If ores.InvalidMessage = "" Then
                    odal.BeginTransactions()
                    odal.ExecuteCommandSP("usp_SAVETaxEntry",
                        odal.CreateParameter("@CompanyID", SqlDbType.VarChar, comlib.GetText(pparam.CompanyID)),
                        odal.CreateParameter("@Table", SqlDbType.VarChar, comlib.GetText(pparam.Table)),
                        odal.CreateParameter("@SeqNum", SqlDbType.VarChar, comlib.GetText(pparam.No)),
                        odal.CreateParameter("@FormNum", SqlDbType.VarChar, comlib.GetText(pparam.FormNum)),
                        odal.CreateParameter("@InvoiceNum", SqlDbType.VarChar, comlib.GetText(pparam.InvoiceNum)),
                        odal.CreateParameter("@NamaWP", SqlDbType.VarChar, comlib.GetText(pparam.NamaWP)),
                        odal.CreateParameter("@OriginalTaxableAmount", SqlDbType.VarChar, comlib.GetText(pparam.OrigTaxableAmt)),
                        odal.CreateParameter("@TaxId", SqlDbType.VarChar, comlib.GetText(pparam.TaxId)),
                        odal.CreateParameter("@TypeOfCost", SqlDbType.VarChar, comlib.GetText(pparam.TypeOfCost)),
                        odal.CreateParameter("@TypeOfTax", SqlDbType.VarChar, comlib.GetText(pparam.TypeOfTax)),
                        odal.CreateParameter("@TarifUmum", SqlDbType.VarChar, comlib.GetText(pparam.TarifUmum)),
                        odal.CreateParameter("@TaxRate", SqlDbType.VarChar, comlib.GetText(pparam.TaxRate)),
                        odal.CreateParameter("@TypeOfCalc", SqlDbType.VarChar, comlib.GetText(pparam.TypeOfCalc)),
                        odal.CreateParameter("@OriginalTaxAmount", SqlDbType.VarChar, comlib.GetText(pparam.OrigTaxAmt)),
                        odal.CreateParameter("@TaxDeduction2Supplier", SqlDbType.VarChar, comlib.GetText(pparam.TaxDeducted)),
                        odal.CreateParameter("@LokasiTanahBangunan", SqlDbType.VarChar, comlib.GetText(pparam.LokasiTanahBangunan)),
                        odal.CreateParameter("@IdrTaxableAmount", SqlDbType.VarChar, comlib.GetText(pparam.IdrTaxableAmount)),
                        odal.CreateParameter("@IdrTaxAmount", SqlDbType.VarChar, comlib.GetText(pparam.IdrTaxAmount)),
                        odal.CreateParameter("@Description", SqlDbType.VarChar, comlib.GetText(pparam.Description)),
                        odal.CreateParameter("@KodeWP", SqlDbType.VarChar, comlib.GetText(pparam.KodeWP)),
                        odal.CreateParameter("@NPWP", SqlDbType.VarChar, comlib.GetText(pparam.NPWP)),
                        odal.CreateParameter("@NIK", SqlDbType.VarChar, comlib.GetText(pparam.NIK)),
                        odal.CreateParameter("@ExchangeRate", SqlDbType.VarChar, comlib.GetText(pparam.ExchangeRate)),
                        odal.CreateParameter("@AccountCode", SqlDbType.VarChar, comlib.GetText(pparam.AccountCode)),
                        odal.CreateParameter("@ProcessBy", SqlDbType.VarChar, comlib.GetText(pparam.ProcessBy)),
                        odal.CreateParameter("@DJPOnlinfe", SqlDbType.VarChar, comlib.GetText(pparam.DJPOnline)),
                        odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))
                    ores.InvalidMessage = odal.ReturnValue(1).ToString

                    If ores.InvalidMessage = "Berhasil" Then
                        odal.CommitTransactions()
                    Else
                        odal.RollBackTransactions()
                    End If
                End If
            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            ores.Result = "SUCCESS"
            Return ores

        End Function

        Public Function GetWPList(pprm As cParams) As cTAXList
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oTAXWPList As cTAXWPList
            Dim oTAX As cTAXList = Nothing
            oTAX = New cTAXList
            oTAX.cTAXWPList = New List(Of cTAXWPList)()



            Try
                rdr = odal.ExecuteDataReader("sp_get_list_WP", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@pagesize", SqlDbType.VarChar, pprm.pagesize),
                        odal.CreateParameter("@pageno", SqlDbType.VarChar, comlib.GetText(pprm.pageno)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.skey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pprm.skey3)))
                While rdr.Read
                    oTAXWPList = New cTAXWPList
                    oTAXWPList.SequenceNo = comlib.GetText(rdr.Item("SequenceNo"))
                    oTAXWPList.CompanyID = comlib.GetText(rdr.Item("CompanyID"))
                    oTAXWPList.NoUrut = comlib.GetText(rdr.Item("NoUrut"))
                    oTAXWPList.KodeWP = comlib.GetText(rdr.Item("KodeWP"))
                    oTAXWPList.NamaWP = comlib.GetText(rdr.Item("NamaWP"))
                    oTAXWPList.NPWP = comlib.GetText(rdr.Item("NPWP"))
                    oTAXWPList.Alamat = comlib.GetText(rdr.Item("Alamat"))
                    oTAXWPList.Valid = comlib.GetText(rdr.Item("Valid"))
                    oTAXWPList.SelectedStatus = comlib.GetText(rdr.Item("SelectedStatus"))
                    oTAXWPList.TotalRows = comlib.GetText(rdr.Item("TotalRows"))
                    oTAXWPList.NIK = comlib.GetText(rdr.Item("NIK"))
                    oTAX.cTAXWPList.Add(oTAXWPList)
                End While
                'oTAX.message = "SUCCESS"
                'oTAX.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oTAX

        End Function

        Public Function GetTaxList(pprm As cParams) As cTAXList
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oTAXIDList As cTAXIDList
            Dim oTAX As cTAXList = Nothing
            oTAX = New cTAXList
            oTAX.cTAXIDList = New List(Of cTAXIDList)()



            Try
                rdr = odal.ExecuteDataReader("usp_ListTAXID", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@pagesize", SqlDbType.VarChar, pprm.pagesize),
                        odal.CreateParameter("@pageno", SqlDbType.VarChar, comlib.GetText(pprm.pageno)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.skey2)))
                While rdr.Read
                    oTAXIDList = New cTAXIDList
                    oTAXIDList.TAXID = comlib.GetText(rdr.Item("TAXID"))
                    oTAXIDList.BarisBP = comlib.GetText(rdr.Item("BarisBP"))
                    oTAXIDList.TypeOfCost = comlib.GetText(rdr.Item("TypeOfCost"))
                    oTAXIDList.TypeOfTax = comlib.GetText(rdr.Item("TypeOfTax"))
                    oTAXIDList.PerkPenghBruto = comlib.GetText(rdr.Item("PerkPenghBruto"))
                    oTAXIDList.TarifUmum = comlib.GetText(rdr.Item("TarifUmum"))
                    oTAXIDList.TaxRate = comlib.GetText(rdr.Item("TaxRate"))
                    oTAXIDList.Calc = comlib.GetText(rdr.Item("Calc"))
                    oTAXIDList.NPWP = comlib.GetText(rdr.Item("NPWP"))
                    ' oTAXIDList.KodeObjectPajak = comlib.GetText(rdr.Item("KodeObjectPajak"))
                    oTAXIDList.Status = comlib.GetText(rdr.Item("Status"))
                    oTAXIDList.CompanyID = comlib.GetText(rdr.Item("CompanyID"))
                    oTAXIDList.TotalRows = comlib.GetText(rdr.Item("TotalRows"))
                    oTAX.cTAXIDList.Add(oTAXIDList)
                End While
                'oTAX.message = "SUCCESS"
                'oTAX.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oTAX

        End Function

        Public Function ProcessTax(pparam As cParams) As cResult
            Dim ret As String = ""
            'Process DB Extract Internet Banking
            Dim odal As New SQLAccess("core")
            Try
                ores = New cResult
                If ores.InvalidMessage = "" Then
                    odal.BeginTransactions()
                    odal.ExecuteCommandSP("usp_process_tax",
                            odal.CreateParameter("@CompanyID", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                            odal.CreateParameter("@Table", SqlDbType.VarChar, comlib.GetText(pparam.paramtype)),
                            odal.CreateParameter("@FormNum", SqlDbType.VarChar, comlib.GetText(pparam.skey1)),
                            odal.CreateParameter("@sRoles", SqlDbType.VarChar, comlib.GetText(pparam.skey2)),
                            odal.CreateParameter("@UserID", SqlDbType.VarChar, comlib.GetText(pparam.userid)),
                            odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))
                    ores.InvalidMessage = odal.ReturnValue(1).ToString

                    If Left(ores.InvalidMessage, 5) <> "ERROR" Then
                        odal.CommitTransactions()
                    Else
                        odal.RollBackTransactions()
                    End If
                End If
            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try


            ores.Result = "SUCCESS"
            Return ores

        End Function

        Public Function TaxCalculation(params As cParams) As cTAXDetail
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            'Dim oTAX As cTAXList = Nothing
            'oTAX = New cTAXList
            'oTAX.cTAXDetail = New List(Of cTAXDetail)()

            Dim oTAXDetail As cTAXDetail


            Try


                rdr = odal.ExecuteDataReader("usp_tax_calculation", CommandType.StoredProcedure,
                        odal.CreateParameter("@Companyid", SqlDbType.VarChar, comlib.GetText(params.companyid)),
                        odal.CreateParameter("@OriginalTaxableAmoumt", SqlDbType.VarChar, params.skey1),
                        odal.CreateParameter("@WPCode", SqlDbType.VarChar, params.skey2),
                        odal.CreateParameter("@TaxID", SqlDbType.VarChar, params.skey3),
                        odal.CreateParameter("@TypeOfCalc", SqlDbType.VarChar, comlib.GetText(params.skey4)),
                        odal.CreateParameter("@FormNum", SqlDbType.VarChar, comlib.GetText(params.skey5)))
                While rdr.Read
                    oTAXDetail = New cTAXDetail
                    oTAXDetail.OrigTaxAmt = comlib.GetText(rdr.Item("OriginalTaxAmount"))
                    oTAXDetail.TaxDeducted = comlib.GetText(rdr.Item("TaxDeductionToSupplier"))
                    oTAXDetail.IdrTaxAmount = comlib.GetText(rdr.Item("IDRTaxAmount"))
                    oTAXDetail.IdrTaxableAmount = comlib.GetText(rdr.Item("IDRTaxableAmount"))
                    oTAXDetail.COACode = comlib.GetText(rdr.Item("COACode"))
                    oTAXDetail.DJPOnline = comlib.GetText(rdr.Item("DJPAmount"))
                End While

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                params = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oTAXDetail

        End Function

        Public Function LockForm(params As cParams) As cResult
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim res As cResult
            Try
                rdr = odal.ExecuteDataReader("usp_lockformnum", CommandType.StoredProcedure,
                                         odal.CreateParameter("@companyID", SqlDbType.VarChar, comlib.GetText(params.companyid)),
                                         odal.CreateParameter("@formnum", SqlDbType.VarChar, params.skey1),
                                         odal.CreateParameter("@userID", SqlDbType.VarChar, params.userid),
                                         odal.CreateParameter("@param", SqlDbType.VarChar, params.skey2))
                While rdr.Read
                    res = New cResult
                    res.Message = comlib.GetText(rdr.Item("Result"))
                End While
            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                params = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return res
        End Function

#End Region

#Region "Master"
        Public Function BeneficiaryUpdate(pparam As cBeneficiary) As cResult

            Dim odal As New SQLAccess("core")

            Try
                ores = New cResult
                'Validation
                'ores.InvalidMessage = IsValid(odal, pparam)

                'Run Tasks
                If ores.InvalidMessage = "" Then
                    odal.BeginTransactions()
                    odal.ExecuteCommandSP("usp_SAVEBeneficiary",
                        odal.CreateParameter("@CompanyID", SqlDbType.VarChar, comlib.GetText(pparam.CompanyID)),
                        odal.CreateParameter("@Table", SqlDbType.VarChar, comlib.GetText(pparam.Table)),
                        odal.CreateParameter("@BenID", SqlDbType.VarChar, comlib.GetText(pparam.BenId)),
                        odal.CreateParameter("@BeneficiaryName", SqlDbType.VarChar, comlib.GetText(pparam.BeneficiaryName)),
                        odal.CreateParameter("@BeneficiaryStatus", SqlDbType.VarChar, comlib.GetText(pparam.BeneficiaryStatus)),
                        odal.CreateParameter("@Beneficiary_Bank_Name", SqlDbType.VarChar, comlib.GetText(pparam.BeneficiaryBankName)),
                        odal.CreateParameter("@Beneficiary_Bank_Account", SqlDbType.VarChar, comlib.GetText(pparam.BeneficiaryBankAccount)),
                        odal.CreateParameter("@Beneficiary_Bank_Branch", SqlDbType.VarChar, comlib.GetText(pparam.BeneficiaryBankBranch)),
                        odal.CreateParameter("@Beneficiary_Bank_City", SqlDbType.VarChar, comlib.GetText(pparam.BeneficiaryBankCity)),
                        odal.CreateParameter("@Beneficiary_Email", SqlDbType.VarChar, comlib.GetText(pparam.BeneficiaryEmail)),
                        odal.CreateParameter("@OnlyForDept", SqlDbType.VarChar, comlib.GetText(pparam.OnlyForDept)),
                        odal.CreateParameter("@BeneficiaryTypeCd", SqlDbType.VarChar, comlib.GetText(pparam.BeneficiaryTypeCd)),
                        odal.CreateParameter("@BeneficiaryResidenStatusCd", SqlDbType.VarChar, comlib.GetText(pparam.BeneficiaryResidenStatusCd)),
                        odal.CreateParameter("@BeneficiaryTranTypeCd", SqlDbType.VarChar, comlib.GetText(pparam.BeneficiaryTranTypeCd)),
                        odal.CreateParameter("@BeneficiaryTranfacilityTypeCd", SqlDbType.VarChar, comlib.GetText(pparam.BeneficiaryTranfacilityTypeCd)),
                        odal.CreateParameter("@ProcessBy", SqlDbType.VarChar, comlib.GetText(pparam.ProcessBy)),
                        odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))
                    ores.InvalidMessage = odal.ReturnValue(1).ToString

                    If ores.InvalidMessage = "Berhasil" Then
                        ores.Result = "SUCCESS"
                        odal.CommitTransactions()
                    Else
                        ores.Result = "NO SUCCESS"
                        odal.RollBackTransactions()
                    End If
                End If
            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try

            Return ores

        End Function

        Public Function GetBeneficiaryList(pprm As cParams) As cGERList
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oGER As cGERList = Nothing
            oGER = New cGERList
            oGER.cGERBeneficiary = New List(Of cGERBeneficiary)()

            Dim oGERDetail As cGERBeneficiary

            Try

                rdr = odal.ExecuteDataReader("usp_get_list_Beneficiary", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@pageno", SqlDbType.VarChar, comlib.GetText(pprm.pageno)),
                        odal.CreateParameter("@pagesize", SqlDbType.VarChar, comlib.GetText(pprm.pagesize)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.skey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pprm.skey3)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pprm.skey4)))
                While rdr.Read
                    oGERDetail = New cGERBeneficiary
                    oGERDetail.SequenceNo = comlib.GetText(rdr.Item("SequenceNo"))
                    oGERDetail.BenId = comlib.GetText(rdr.Item("BenId"))
                    oGERDetail.BeneficiaryName = comlib.GetText(rdr.Item("BeneficiaryName"))
                    oGERDetail.BeneficiaryBankName = comlib.GetText(rdr.Item("BeneficiaryBankName"))
                    oGERDetail.BeneficiaryBankAccount = comlib.GetText(rdr.Item("BeneficiaryBankAccount"))
                    oGERDetail.BeneficiaryBankBranch = comlib.GetText(rdr.Item("BeneficiaryBankBranch"))
                    oGERDetail.BeneficiaryBankCity = comlib.GetText(rdr.Item("BeneficiaryBankCity"))
                    oGERDetail.BeneficiaryEmail = comlib.GetText(rdr.Item("BeneficiaryEmail"))
                    oGERDetail.OnlyForDept = comlib.GetText(rdr.Item("OnlyForDept"))
                    oGERDetail.BeneficiaryTypeCd = comlib.GetText(rdr.Item("BeneficiaryTypeCd"))
                    oGERDetail.BeneficiaryTypeNm = comlib.GetText(rdr.Item("BeneficiaryTypeNm"))
                    oGERDetail.BeneficiaryResidenStatusCd = comlib.GetText(rdr.Item("BeneficiaryResidenStatusCd"))
                    oGERDetail.BeneficiaryResidenStatusNm = comlib.GetText(rdr.Item("BeneficiaryResidenStatusNm"))
                    oGERDetail.BeneficiaryTranTypeCd = comlib.GetText(rdr.Item("BeneficiaryTranTypeCd"))
                    oGERDetail.BeneficiaryTranTypeNm = comlib.GetText(rdr.Item("BeneficiaryTranTypeNm"))
                    oGERDetail.BeneficiaryTranfacilityTypeCd = comlib.GetText(rdr.Item("BeneficiaryTranfacilityTypeCd"))
                    oGERDetail.BeneficiaryTranfacilityTypeNm = comlib.GetText(rdr.Item("BeneficiaryTranfacilityTypeNm"))
                    oGERDetail.CompanyID = comlib.GetText(rdr.Item("CompanyID"))
                    oGERDetail.BeneficiaryStatus = comlib.GetText(rdr.Item("BeneficiaryStatus"))
                    oGER.totalRows = comlib.GetText(rdr.Item("TotalRows"))
                    oGER.cGERBeneficiary.Add(oGERDetail)
                End While

                oGER.message = "SUCCESS"
                oGER.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oGER

        End Function

        Public Function WPSave(pparam As cParams) As cResult

            Dim odal As New SQLAccess("core")

            Try
                ores = New cResult
                'Validation
                'ores.InvalidMessage = IsValid(odal, pparam)

                'Run Tasks
                If ores.InvalidMessage = "" Then
                    odal.BeginTransactions()
                    odal.ExecuteCommandSP("usp_SAVEWP",
                        odal.CreateParameter("@CompanyID", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                        odal.CreateParameter("@Table", SqlDbType.VarChar, comlib.GetText(pparam.paramtype)),
                        odal.CreateParameter("@NoUrut", SqlDbType.VarChar, comlib.GetText(pparam.skey1)),
                        odal.CreateParameter("@KodeWP", SqlDbType.VarChar, comlib.GetText(pparam.skey2)),
                        odal.CreateParameter("@NamaWP", SqlDbType.VarChar, comlib.GetText(pparam.skey3)),
                        odal.CreateParameter("@NPWP", SqlDbType.VarChar, comlib.GetText(pparam.skey4)),
                        odal.CreateParameter("@Alamat", SqlDbType.VarChar, comlib.GetText(pparam.skey5)),
                        odal.CreateParameter("@Valid", SqlDbType.VarChar, comlib.GetText(pparam.skey6)),
                        odal.CreateParameter("@SelectedStatus", SqlDbType.VarChar, comlib.GetText(pparam.skey7)),
                        odal.CreateParameter("@NIK", SqlDbType.VarChar, comlib.GetText(pparam.skey8)),
                        odal.CreateParameter("@ProcessBy", SqlDbType.VarChar, comlib.GetText(pparam.userid)),
                        odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))
                    ores.InvalidMessage = odal.ReturnValue(1).ToString

                    If ores.InvalidMessage = "Berhasil" Then
                        ores.Result = "SUCCESS"
                        odal.CommitTransactions()
                    Else
                        ores.Result = "NO SUCCESS"
                        odal.RollBackTransactions()
                    End If
                End If
            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try

            Return ores

        End Function

        Public Function TAXSave(pparam As cParams) As cResult

            Dim odal As New SQLAccess("core")

            Try
                ores = New cResult
                'Validation
                'ores.InvalidMessage = IsValid(odal, pparam)

                'Run Tasks
                If ores.InvalidMessage = "" Then
                    odal.BeginTransactions()
                    odal.ExecuteCommandSP("usp_SAVETAXID",
                        odal.CreateParameter("@CompanyID", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                        odal.CreateParameter("@Table", SqlDbType.VarChar, comlib.GetText(pparam.paramtype)),
                        odal.CreateParameter("@TaxId", SqlDbType.VarChar, comlib.GetText(pparam.skey1)),
                        odal.CreateParameter("@BarisBP", SqlDbType.VarChar, comlib.GetText(pparam.skey2)),
                        odal.CreateParameter("@TypeOfCost", SqlDbType.VarChar, comlib.GetText(pparam.skey3)),
                        odal.CreateParameter("@TypeOfTax", SqlDbType.VarChar, comlib.GetText(pparam.skey4)),
                        odal.CreateParameter("@PerkPenghBruto", SqlDbType.VarChar, comlib.GetText(pparam.skey5)),
                        odal.CreateParameter("@TarifUmum", SqlDbType.VarChar, comlib.GetText(pparam.skey6)),
                        odal.CreateParameter("@TaxRate", SqlDbType.VarChar, comlib.GetText(pparam.skey7)),
                        odal.CreateParameter("@Calc", SqlDbType.VarChar, comlib.GetText(pparam.skey8)),
                        odal.CreateParameter("@NPWP", SqlDbType.VarChar, comlib.GetText(pparam.skey9)),
                        odal.CreateParameter("@Status", SqlDbType.VarChar, comlib.GetText(pparam.skey10)),
                        odal.CreateParameter("@ProcessBy", SqlDbType.VarChar, comlib.GetText(pparam.userid)),
                        odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))
                    ores.InvalidMessage = odal.ReturnValue(1).ToString

                    If ores.InvalidMessage = "Berhasil" Then
                        ores.Result = "SUCCESS"
                        odal.CommitTransactions()
                    Else
                        ores.Result = "NO SUCCESS"
                        odal.RollBackTransactions()
                    End If
                End If
            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try

            Return ores

        End Function


#End Region

#Region "System Admin"
        Public Function Sysadminchangesstatus(pparam As cParams) As cResult

            Dim odal As New SQLAccess("core")

            Try
                ores = New cResult
                'Validation
                'ores.InvalidMessage = IsValid(odal, pparam)

                'Run Tasks
                If ores.InvalidMessage = "" Then
                    'odal.BeginTransactions()
                    odal.ExecuteCommandSP("usp_process_sysadmin_changes_status",
                        odal.CreateParameter("@CompanyID", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                        odal.CreateParameter("@Table", SqlDbType.VarChar, comlib.GetText(pparam.paramtype)),
                        odal.CreateParameter("@FormNum", SqlDbType.VarChar, comlib.GetText(pparam.skey1)),
                        odal.CreateParameter("@ChangesReason", SqlDbType.VarChar, comlib.GetText(pparam.skey2)),
                        odal.CreateParameter("@StatusTypeProcess", SqlDbType.VarChar, comlib.GetText(pparam.skey3)),
                        odal.CreateParameter("@ProcessBy", SqlDbType.VarChar, comlib.GetText(pparam.ProcessBy)),
                        odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))
                    ores.InvalidMessage = odal.ReturnValue(1).ToString

                End If
            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            ores.Result = "SUCCESS"
            Return ores

        End Function

        Public Function GetListSendToNewApprover(pprm As cParams) As cSendToNewApprover
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oSendToNewApprover As cSendToNewApprover = Nothing
            oSendToNewApprover = New cSendToNewApprover
            oSendToNewApprover.cSendToNewApproverDetail = New List(Of cSendToNewApproverDetail)()

            Dim oSendToNewApproverDetail As cSendToNewApproverDetail


            Try

                rdr = odal.ExecuteDataReader("sp_get_list_changes_approval", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@view", SqlDbType.VarChar, comlib.GetText(pprm.paramtype)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.skey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pprm.skey3)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pprm.skey4)),
                        odal.CreateParameter("@skey5", SqlDbType.VarChar, comlib.GetText(pprm.skey5)),
                        odal.CreateParameter("@dkey1", SqlDbType.VarChar, comlib.GetText(pprm.skey6)),
                        odal.CreateParameter("@dkey2", SqlDbType.VarChar, comlib.GetText(pprm.skey7)),
                        odal.CreateParameter("@userid", SqlDbType.VarChar, comlib.GetText(pprm.ProcessBy)))
                While rdr.Read
                    oSendToNewApproverDetail = New cSendToNewApproverDetail
                    oSendToNewApproverDetail.NewApproval = comlib.GetText(rdr.Item("NewApproval"))
                    oSendToNewApproverDetail.Location = comlib.GetText(rdr.Item("Location"))
                    oSendToNewApproverDetail.FormNum = comlib.GetText(rdr.Item("FormNum"))
                    oSendToNewApproverDetail.Dept = comlib.GetText(rdr.Item("Dept"))
                    oSendToNewApproverDetail.Curr = comlib.GetText(rdr.Item("Curr"))
                    oSendToNewApproverDetail.TotalAmount = comlib.GetText(rdr.Item("TotalAmount"))
                    oSendToNewApproverDetail.Status = comlib.GetText(rdr.Item("Status"))
                    oSendToNewApproverDetail.TransactionCode = comlib.GetText(rdr.Item("TransactionCode"))
                    oSendToNewApproverDetail.Transaction_Name = comlib.GetText(rdr.Item("Transaction_Name"))
                    oSendToNewApproverDetail.PolNum = comlib.GetText(rdr.Item("PolNum"))
                    oSendToNewApproverDetail.PolRelated = comlib.GetText(rdr.Item("PolRelated"))
                    oSendToNewApproverDetail.Budgeted = comlib.GetText(rdr.Item("Budgeted"))
                    oSendToNewApproverDetail.CreateBy = comlib.GetText(rdr.Item("CreateBy"))
                    oSendToNewApproverDetail.CreateDt = comlib.GetText(rdr.Item("CreateDt"))
                    oSendToNewApproverDetail.BeneficiaryName = comlib.GetText(rdr.Item("BeneficiaryName"))
                    oSendToNewApprover.cSendToNewApproverDetail.Add(oSendToNewApproverDetail)
                End While
                oSendToNewApprover.message = "SUCCESS"
                oSendToNewApprover.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oSendToNewApprover

        End Function

        Public Function SendNewApprover(pparam As cParams) As cResult

            Dim odal As New SQLAccess("core")

            Try
                ores = New cResult

                If ores.InvalidMessage = "" Then
                    odal.BeginTransactions()
                    odal.ExecuteCommandSP("usp_process_changes_approval",
                        odal.CreateParameter("@CompanyID", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                        odal.CreateParameter("@Table", SqlDbType.VarChar, comlib.GetText(pparam.paramtype)),
                        odal.CreateParameter("@AllVar", SqlDbType.VarChar, comlib.GetText(pparam.skey1)),
                        odal.CreateParameter("@UserID", SqlDbType.VarChar, comlib.GetText(pparam.userid)),
                        odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))
                    ores.InvalidMessage = odal.ReturnValue(1).ToString

                    If ores.InvalidMessage = "Berhasil" Then
                        odal.CommitTransactions()
                    Else
                        odal.RollBackTransactions()
                    End If
                End If
            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            ores.Result = "SUCCESS"
            Return ores

        End Function
#End Region

#Region "Reset Voucher Number"
        Public Function ProcessResetVoucher(pprm As cParams) As cResetVoucher
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oResetVoucher As cResetVoucher = Nothing
            oResetVoucher = New cResetVoucher
            oResetVoucher.cResetVoucherDetail = New List(Of cResetVoucherDetail)()

            Dim oResetVoucherDetail As cResetVoucherDetail

            Try

                rdr = odal.ExecuteDataReader("usp_process_reset_Voucher", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@Table", SqlDbType.VarChar, comlib.GetText(pprm.paramtype)),
                        odal.CreateParameter("@SunlifeBankCode", SqlDbType.VarChar, comlib.GetText(pprm.skey1)),
                        odal.CreateParameter("@UserID", SqlDbType.VarChar, comlib.GetText(pprm.userid)),
                        odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))
                While rdr.Read
                    oResetVoucherDetail = New cResetVoucherDetail
                    oResetVoucherDetail.Bank = comlib.GetText(rdr.Item("Bank"))
                    oResetVoucherDetail.AccountNum = comlib.GetText(rdr.Item("AccountNum"))
                    oResetVoucherDetail.VoucherCode = comlib.GetText(rdr.Item("VoucherCode"))
                    oResetVoucherDetail.ActiveNum = comlib.GetText(rdr.Item("ActiveNum"))
                    oResetVoucherDetail.InActiveNum = comlib.GetText(rdr.Item("InActiveNum"))
                    oResetVoucherDetail.StartDt = comlib.GetText(rdr.Item("StartDt"))
                    oResetVoucherDetail.ResultMessage = comlib.GetText(rdr.Item("ResultMessage"))
                    oResetVoucher.cResetVoucherDetail.Add(oResetVoucherDetail)
                End While

                oResetVoucher.message = "SUCCESS"
                oResetVoucher.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oResetVoucher

        End Function
#End Region

#Region "Bank Book"
        Public Function GetBankBookList(pprm As cParams) As cBankBook
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oBankBook As cBankBook = Nothing
            oBankBook = New cBankBook
            oBankBook.cBankBookDetail = New List(Of cBankBookDetail)()

            Dim oBankBookDetail As cBankBookDetail

            Try

                rdr = odal.ExecuteDataReader("usp_get_list_Bank_Book", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(pprm.companyid)),
                        odal.CreateParameter("@pageno", SqlDbType.VarChar, comlib.GetText(pprm.pageno)),
                        odal.CreateParameter("@pagesize", SqlDbType.VarChar, comlib.GetText(pprm.pagesize)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(pprm.skey5)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(pprm.skey2)),
                        odal.CreateParameter("@skey3", SqlDbType.VarChar, comlib.GetText(pprm.skey3)),
                        odal.CreateParameter("@skey4", SqlDbType.VarChar, comlib.GetText(pprm.skey4)))
                While rdr.Read
                    oBankBookDetail = New cBankBookDetail
                    oBankBookDetail.VoucherNum = comlib.GetText(rdr.Item("VoucherNum"))
                    oBankBookDetail.SLFIBankAccountNum = comlib.GetText(rdr.Item("SLFIBankAccountNum"))
                    oBankBookDetail.FormNum = comlib.GetText(rdr.Item("FormNum"))
                    oBankBookDetail.PreparedDt = comlib.GetText(rdr.Item("PreparedDt"))
                    oBankBookDetail.TransferedDt = comlib.GetText(rdr.Item("TransferedDt"))
                    oBankBookDetail.Status = comlib.GetText(rdr.Item("Status"))
                    oBankBookDetail.Orig_Curr = comlib.GetText(rdr.Item("Orig_Curr"))
                    oBankBookDetail.Total_Orig_Amt = comlib.GetText(rdr.Item("Total_Orig_Amt"))
                    oBankBookDetail.Paid_Curr = comlib.GetText(rdr.Item("Paid_Curr"))
                    oBankBookDetail.Exc_Rate = comlib.GetText(rdr.Item("Exc_Rate"))
                    oBankBookDetail.PaidAmount = comlib.GetText(rdr.Item("PaidAmount"))
                    oBankBookDetail.ProcessBy = comlib.GetText(rdr.Item("ProcessBy"))
                    oBankBookDetail.TransactionCode = comlib.GetText(rdr.Item("TransactionCode"))
                    oBankBookDetail.PolRelated = comlib.GetText(rdr.Item("PolRelated"))
                    oBankBookDetail.PolicyNum = comlib.GetText(rdr.Item("PolicyNum"))
                    oBankBookDetail.IsGenerated = comlib.GetText(rdr.Item("isgenerated"))
                    oBankBook.cBankBookDetail.Add(oBankBookDetail)
                End While

                oBankBook.message = "SUCCESS"
                oBankBook.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                pprm = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oBankBook

        End Function

        Public Function ProcessBankBook(pparam As cParams) As cResult
            Dim odal As New SQLAccess("core")
            Dim voucherCode As String = ""

            Try
                ores = New cResult
                'Validation
                'ores.InvalidMessage = IsValid(odal, pparam)

                'Run Tasks
                If ores.InvalidMessage = "" Then
                    odal.BeginTransactions()
                    odal.ExecuteCommandSP("usp_process_bank_book",
                        odal.CreateParameter("@CompanyID", SqlDbType.VarChar, comlib.GetText(pparam.companyid)),
                        odal.CreateParameter("@Table", SqlDbType.VarChar, comlib.GetText("SetToPaid")),
                        odal.CreateParameter("@BankID", SqlDbType.Char, comlib.GetText(pparam.skey1)),
                        odal.CreateParameter("@AccountNum", SqlDbType.VarChar, comlib.GetText(pparam.skey2)),
                        odal.CreateParameter("@TempVoucherCode", SqlDbType.VarChar, comlib.GetText(pparam.skey3)),
                        odal.CreateParameter("@PreparedDate", SqlDbType.VarChar, comlib.GetText(pparam.skey4)),
                        odal.CreateParameter("@TransferedDate", SqlDbType.VarChar, comlib.GetText(pparam.skey6)),
                        odal.CreateParameter("@BatchNum", SqlDbType.VarChar, comlib.GetText(pparam.skey5)),
                        odal.CreateParameter("@UserID", SqlDbType.VarChar, comlib.GetText(pparam.userid)),
                        odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput),
                        odal.CreateParameter("@VoucherCode ", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))
                    ores.InvalidMessage = odal.ReturnValue(1).ToString
                    voucherCode = odal.ReturnValue(2).ToString

                    If ores.InvalidMessage = "Berhasil" Then
                        odal.CommitTransactions()
                        'ores.Message = voucherCode
                        'MergeReports(pparam.companyid, voucherCode, pparam.skey3, pparam.skey5)
                    Else
                        odal.RollBackTransactions()
                    End If
                End If
            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            ores.Message = voucherCode
            ores.Result = "SUCCESS"
            Return ores

        End Function

        Public Sub ProcessAttachmentReport(companyID As String, formNum As String, voucherNum As String, fileLocation As String, remark As String, activity As String, attachmentType As String, result As String, result2 As String, table As String, userid As String) 'As cResult
            Dim odal As New SQLAccess("core")
            Dim objAPIHelper As New comlib
            Try
                ores = New cResult

                odal.BeginTransactions()

                odal.ExecuteCommandSP("sp_create_Attachment",
                                     odal.CreateParameter("@Table", SqlDbType.VarChar, table),
                                     odal.CreateParameter("@CompanyID", SqlDbType.VarChar, companyID),
                                     odal.CreateParameter("@FormNum", SqlDbType.VarChar, formNum),
                                     odal.CreateParameter("@VoucherNum", SqlDbType.VarChar, voucherNum),
                                     odal.CreateParameter("@FileLocation", SqlDbType.VarChar, fileLocation),
                                     odal.CreateParameter("@Remark", SqlDbType.VarChar, remark),
                                     odal.CreateParameter("@Activity", SqlDbType.VarChar, activity),
                                     odal.CreateParameter("@AttachmentType", SqlDbType.VarChar, attachmentType),
                                     odal.CreateParameter("@userid", SqlDbType.VarChar, userid),
                                     odal.CreateParameter("@Result", SqlDbType.VarChar, result, 500, ParameterDirection.InputOutput),
                                     odal.CreateParameter("@Result2", SqlDbType.VarChar, result2, 500, ParameterDirection.InputOutput))
                ores.ReturnValue = odal.ReturnValue(1).ToString

                If ores.ReturnValue <> "" Then
                    ores.InvalidMessage = ""
                    odal.CommitTransactions()

                Else
                    odal.RollBackTransactions()
                End If

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            'Return ores
        End Sub

        Public Function BankBookSetToPaid(params As cParams) As GEReportDetail
            Dim result As cResult
            Dim reportResult As GEReportDetail = New GEReportDetail()
            Try
                Dim bankBookList As cBankBook = New cBankBook
                Dim oBankBookDetail As cBankBookDetail = New cBankBookDetail

                bankBookList = GetBankBookList(params)
                For Each item As cBankBookDetail In bankBookList.cBankBookDetail
                    params.skey10 = item.FormNum
                    Dim destination As String = GenReportGERLatterApprv(params)
                    ProcessAttachmentReport(params.companyid, params.skey10, "", destination, "", "", "", "", "", "NEWFORREPORT", params.userid)
                Next

                result = ProcessBankBook(params)
                params.skey3 = result.Message
                reportResult = GenReportVoucher(params)
                ProcessAttachmentReport(params.companyid, "", params.skey3, reportResult.Message, params.skey7, params.skey8, "", "", "", "REPORTFORVOUCHER", params.userid)
                reportResult.Result = "SUCCESS"
            Catch ex As Exception
                Throw ex
            End Try

            Return reportResult
        End Function

        Protected Function GenReportGERLatterApprv(params As cParams) As String
            Dim res As String
            Dim paramsRPT As cParams = New cParams()

            paramsRPT.companyid = params.companyid
            paramsRPT.skey1 = "GERLetterAPPRV"
            paramsRPT.skey2 = "skey1=" + params.skey10 + "&Companyid=" + params.companyid
            paramsRPT.skey3 = params.skey5
            paramsRPT.skey4 = params.skey10
            paramsRPT.userid = params.userid

            res = GenerateReport2(paramsRPT).Message
            Return res
        End Function

        Protected Sub GenReportCARLatterApprv(params As cParams)
            'Dim res As String
            Dim paramsRPT As cParams = New cParams()

            paramsRPT.companyid = params.companyid
            paramsRPT.skey1 = "CARAPPRV"
            paramsRPT.skey2 = "skey1=" + params.skey1 + "&Companyid=" + params.companyid
            paramsRPT.skey3 = params.skey2
            paramsRPT.skey4 = params.skey3
            paramsRPT.userid = params.userid

            GenerateCARAPPRV(paramsRPT)
            'Return res
        End Sub

        Protected Sub GenerateCARAPPRV(pprm As cParams)
            Dim url, destination As String
            Dim oResultDetail As GEReportDetail = Nothing
            oResultDetail = New GEReportDetail
            oResultDetail.GenReportDetail = New List(Of GenRepotDetail)()
            'Dim GenReportDetail As GenRepotDetail

            Dim odal As New SQLAccess("core")
            'destination = Dts.Variables("Folder_Destination").Value.ToString + "\" + "Report_" + Dts.Variables("ReportParameter").Value.ToString + "_" + Format(Now, "yyyyMMdd") + ".xls"
            'destination = "\\Sv541048\snaps_report\Report_" + Format(Now, "yyyyMMdd") + ".xls"
            Dim rReportName As String = ""
            Dim rReportFormat As String = ""
            Dim rReportFilePathLocation As String = ""
            Dim rReportFileName As String = ""
            Dim rReportFileType As String = ""
            Dim rReporLink As String = ""


            Try

                rdr = odal.ExecuteDataReader("usp_get_records", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, pprm.companyid),
                        odal.CreateParameter("@table", SqlDbType.VarChar, "GetReportSetup"),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, pprm.skey1))
                While rdr.Read
                    rReportName = comlib.GetText(rdr.Item("ReportName"))
                    rReportFormat = comlib.GetText(rdr.Item("ReportFormat"))
                    rReportFilePathLocation = comlib.GetText(rdr.Item("ReportFilePathLocation"))
                    rReportFileName = comlib.GetText(rdr.Item("ReportFileName"))
                    rReportFileType = comlib.GetText(rdr.Item("ReportFileType"))
                    rReporLink = comlib.GetText(rdr.Item("ReportLink"))
                End While

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try

            'destination = rReportFilePathLocation + Trim(rReportFileName) + "." + rReportFileType
            'url = rReporLink + rReportName + "&rs:Command=Render&skey1=" + pprm.param1.ToString + "&Companyid=" + company + "&rs:Format=" + rReportFormat
            url = rReporLink + pprm.skey1 + "&rs:Command=Render&" + pprm.skey2 + "&rs:Format=" + rReportFormat
            Dim dirFolder As String = rReportFilePathLocation + Trim(rReportFileName) + "\" + Replace(pprm.skey3, "/", "-")
            If Not Directory.Exists(dirFolder) Then
                Directory.CreateDirectory(dirFolder)
            End If

            destination = dirFolder + "\" + Trim(rReportFileName) + "." + rReportFileType
            pprm.skey4 = rReportName

            If File.Exists(destination) Then
                File.Delete(destination)
                SaveFile(url, destination, pprm)
            Else
                SaveFile(url, destination, pprm)
            End If

        End Sub

        Protected Function GenReportVoucher(params As cParams) As GEReportDetail
            Dim paramsRPT As cParams = New cParams()
            Dim reportResult As GEReportDetail = New GEReportDetail()

            paramsRPT.companyid = params.companyid
            paramsRPT.skey1 = "Voucher"
            paramsRPT.skey2 = "skey1=" + params.skey3 + "&Companyid=" + params.companyid
            paramsRPT.skey3 = params.skey3
            paramsRPT.skey4 = ""
            paramsRPT.userid = params.userid

            reportResult = GenerateReport2(paramsRPT)
            Return reportResult
        End Function

#End Region

#Region "List Voucher Doc"
        Public Function GetListVoucherDoc(params As cParams) As cVoucherDoc
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oVoucherDoc As cVoucherDoc = Nothing
            oVoucherDoc = New cVoucherDoc
            oVoucherDoc.cVoucherDocDetail = New List(Of cVoucherDocDetail)()

            Dim oVoucherDocDetail As cVoucherDocDetail

            Try

                rdr = odal.ExecuteDataReader("usp_ListVoucher", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(params.companyid)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(params.skey1)))
                While rdr.Read
                    oVoucherDocDetail = New cVoucherDocDetail
                    oVoucherDocDetail.FormNum = comlib.GetText(rdr.Item("FormNum"))
                    oVoucherDocDetail.SLFIBankAccountNum = comlib.GetText(rdr.Item("SLFIBankAccountNum"))
                    oVoucherDocDetail.VoucherNum = comlib.GetText(rdr.Item("VoucherNum"))
                    oVoucherDocDetail.TransferedDt = comlib.GetText(rdr.Item("TransferedDt"))
                    oVoucherDocDetail.PaidAmount = comlib.GetText(rdr.Item("PaidAmount"))
                    oVoucherDocDetail.Status = comlib.GetText(rdr.Item("Status"))
                    oVoucherDocDetail.ProcessBy = comlib.GetText(rdr.Item("ProcessBy"))
                    oVoucherDocDetail.BeneficiaryName = comlib.GetText(rdr.Item("BeneficiaryName"))
                    oVoucherDocDetail.BeneficiaryBankAccount = comlib.GetText(rdr.Item("BeneficiaryBankAccount"))
                    oVoucherDocDetail.BeneficiaryBankBranch = comlib.GetText(rdr.Item("BeneficiaryBankBranch"))
                    oVoucherDocDetail.BeneficiaryBankCity = comlib.GetText(rdr.Item("BeneficiaryBankCity"))
                    oVoucherDocDetail.BeneficiaryAccountCurrency = comlib.GetText(rdr.Item("BeneficiaryAccountCurrency"))
                    oVoucherDocDetail.BankName = comlib.GetText(rdr.Item("BankName"))
                    oVoucherDoc.cVoucherDocDetail.Add(oVoucherDocDetail)
                End While

                oVoucherDoc.message = "SUCCESS"
                oVoucherDoc.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                params = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oVoucherDoc
        End Function

        Public Function GetDocument(params As cParams) As cVoucherDoc
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oVoucherDoc As cVoucherDoc = Nothing
            oVoucherDoc = New cVoucherDoc
            oVoucherDoc.cDocumentDetail = New List(Of cDocumentDetail)()

            Dim oDocumentDetail As cDocumentDetail

            Try

                rdr = odal.ExecuteDataReader("usp_list_voucher_doc", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(params.companyid)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(params.skey1)))
                While rdr.Read
                    oDocumentDetail = New cDocumentDetail
                    oDocumentDetail.DocumentLocation = comlib.GetText(rdr.Item("DocumentAttachment"))
                    oDocumentDetail.DocumentPreparedBy = comlib.GetText(rdr.Item("Preparedby"))
                    oDocumentDetail.DocumentPreparedDt = comlib.GetText(rdr.Item("PreparedDate"))
                    oDocumentDetail.Remark = comlib.GetText(rdr.Item("Remark"))
                    oDocumentDetail.DocByte = Convert.ToBase64String(File.ReadAllBytes(comlib.GetText(rdr.Item("DocumentAttachment"))))
                    oDocumentDetail.FileName = Replace(comlib.GetText(rdr.Item("VoucherNum")), "/", "-") + "-VOUCHER"
                    oVoucherDoc.cDocumentDetail.Add(oDocumentDetail)
                End While

                oVoucherDoc.message = "SUCCESS"
                oVoucherDoc.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                params = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oVoucherDoc
        End Function

        Public Function GetListLog(params As cParams) As cVoucherDoc
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oVoucherDoc As cVoucherDoc = Nothing
            oVoucherDoc = New cVoucherDoc
            oVoucherDoc.cListLog = New List(Of cListLog)()

            Dim oListLog As cListLog

            Try

                rdr = odal.ExecuteDataReader("usp_list_log", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(params.companyid)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(params.skey1)))
                While rdr.Read
                    oListLog = New cListLog
                    oListLog.VoucherNum = comlib.GetText(rdr.Item("VoucherNum"))
                    oListLog.LogDate = comlib.GetText(rdr.Item("LogDate"))
                    oListLog.Activity = comlib.GetText(rdr.Item("Activity"))
                    oListLog.UpdateBy = comlib.GetText(rdr.Item("UpdateBy"))
                    oVoucherDoc.cListLog.Add(oListLog)
                End While

                oVoucherDoc.message = "SUCCESS"
                oVoucherDoc.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                params = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oVoucherDoc
        End Function

        Public Function AddAttachment(params As cParams) As cResult
            Dim odal As New SQLAccess("core")
            Dim objAPIHelper As New comlib
            Try
                ores = New cResult

                odal.BeginTransactions()

                odal.ExecuteCommandSP("usp_InsertVoucherDocumentInfo",
                                     odal.CreateParameter("@CompanyID", SqlDbType.VarChar, params.companyid),
                                     odal.CreateParameter("@userid", SqlDbType.VarChar, params.userid),
                                     odal.CreateParameter("@voucherNum", SqlDbType.VarChar, params.skey1),
                                     odal.CreateParameter("@remark", SqlDbType.VarChar, params.skey2),
                                     odal.CreateParameter("@documentLocation", SqlDbType.VarChar, objAPIHelper.getValueComString("ATTACHMENT_UPLOAD")),
                                     odal.CreateParameter("@attachmentType", SqlDbType.VarChar, params.skey5),
                                     odal.CreateParameter("@role", SqlDbType.VarChar, params.skey7),
                                     odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 500, ParameterDirection.InputOutput),
                                     odal.CreateParameter("@Result2", SqlDbType.VarChar, sretval, 500, ParameterDirection.InputOutput))
                ores.ReturnValue = odal.ReturnValue(1).ToString

                If ores.ReturnValue <> "" Then
                    ores.InvalidMessage = ""
                    odal.CommitTransactions()
                    params.skey6 = odal.ReturnValue(2).ToString

                    File.WriteAllBytes(params.skey6, Convert.FromBase64String(params.skey3))
                Else
                    odal.RollBackTransactions()
                End If

            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return ores
        End Function
#End Region

#Region "List Approval"
        Public Function GetListApproval(params As cParams) As cListApproval
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oListApproval As cListApproval = Nothing
            oListApproval = New cListApproval
            oListApproval.cListApprovalDetail = New List(Of cListApprovalDetail)()

            Dim oListApprovalDetail As cListApprovalDetail

            Try

                rdr = odal.ExecuteDataReader("usp_ListApproval", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(params.companyid)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(params.skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(params.skey2)))
                While rdr.Read
                    oListApprovalDetail = New cListApprovalDetail
                    oListApprovalDetail.Currency = comlib.GetText(rdr.Item("Curr"))
                    oListApprovalDetail.FormNum = comlib.GetText(rdr.Item("FormNum"))
                    oListApprovalDetail.FormType = comlib.GetText(rdr.Item("FormType"))
                    oListApprovalDetail.FromDept = comlib.GetText(rdr.Item("FromDept"))
                    oListApprovalDetail.AdvanceFormNum = comlib.GetText(rdr.Item("AdvanceFormNum"))
                    oListApprovalDetail.CreateDt = comlib.GetText(rdr.Item("CreateDt"))
                    oListApprovalDetail.CreateBy = comlib.GetText(rdr.Item("CreateBy"))
                    oListApprovalDetail.TotalAmount = comlib.GetText(rdr.Item("TotalAmount"))
                    oListApprovalDetail.AdvanceAmount = comlib.GetText(rdr.Item("AdvanceAmount"))
                    oListApprovalDetail.DueAmount = comlib.GetText(rdr.Item("DueAmount"))
                    oListApprovalDetail.FormStatus = comlib.GetText(rdr.Item("FormStatus"))
                    oListApprovalDetail.ExchangeRate = comlib.GetText(rdr.Item("ExchangeRate"))
                    oListApprovalDetail.TransactionCode = comlib.GetText(rdr.Item("TransactionCode"))
                    oListApprovalDetail.Description = comlib.GetText(rdr.Item("Description"))
                    oListApprovalDetail.Journalized = comlib.GetText(rdr.Item("Journalized"))
                    oListApprovalDetail.BeneficiaryName = comlib.GetText(rdr.Item("BeneficiaryName"))
                    oListApprovalDetail.BeneficiaryBankName = comlib.GetText(rdr.Item("BeneficiaryBankName"))
                    oListApprovalDetail.BeneficiaryBankAccount = comlib.GetText(rdr.Item("BeneficiaryBankAccount"))
                    oListApprovalDetail.BeneficiaryBankBranch = comlib.GetText(rdr.Item("BeneficiaryBankBranch"))
                    oListApprovalDetail.BeneficiaryBankCity = comlib.GetText(rdr.Item("BeneficiaryBankCity"))
                    oListApprovalDetail.BeneficiaryEmail = comlib.GetText(rdr.Item("BeneficiaryEmail"))
                    oListApprovalDetail.BeneficiaryAccountCurrency = comlib.GetText(rdr.Item("BeneficiaryAccountCurrency"))
                    oListApprovalDetail.TaxAmount = comlib.GetText(rdr.Item("TaxAmount"))
                    oListApprovalDetail.NettAmount = comlib.GetText(rdr.Item("NettAmount"))
                    oListApprovalDetail.PolRelated = comlib.GetText(rdr.Item("PolRelated"))
                    oListApprovalDetail.PolicyNum = comlib.GetText(rdr.Item("PolicyNum"))
                    oListApprovalDetail.FormLocation = comlib.GetText(rdr.Item("FormLocation"))
                    oListApprovalDetail.Subject = comlib.GetText(rdr.Item("Subject"))
                    oListApprovalDetail.PaidBy = comlib.GetText(rdr.Item("PaidBy"))
                    oListApprovalDetail.SLFIBankAccount = comlib.GetText(rdr.Item("SLFIBankAccountNum"))
                    oListApprovalDetail.SLFIBankName = comlib.GetText(rdr.Item("SLFIBankName"))
                    oListApprovalDetail.Taxable = comlib.GetText(rdr.Item("Taxable"))
                    oListApprovalDetail.RejectType = comlib.GetText(rdr.Item("RejectType"))
                    oListApprovalDetail.ApprovalGroupCode = comlib.GetText(rdr.Item("ApprovalGroupCode"))
                    oListApprovalDetail.Budgeted = comlib.GetText(rdr.Item("Budgeted"))
                    oListApprovalDetail.LimitType = comlib.GetText(rdr.Item("LimitType"))
                    oListApprovalDetail.NextApprover = comlib.GetText(rdr.Item("NextApprover"))
                    oListApprovalDetail.NextAppr = comlib.GetText(rdr.Item("NextApprover1"))
                    oListApprovalDetail.SelectApprover = comlib.GetText(rdr.Item("selectApprover"))
                    oListApprovalDetail.CodeApprover = comlib.GetText(rdr.Item("codeApprover"))
                    oListApprovalDetail.ApprGroupCode = comlib.GetText(rdr.Item("ApprGroupCode"))
                    oListApproval.cListApprovalDetail.Add(oListApprovalDetail)
                End While

                oListApproval.message = "SUCCESS"
                oListApproval.result = ""

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                params = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oListApproval
        End Function

        'Protected Sub SqlDataSource2_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles SqlDataSource2.Load
        '    SqlDataSource2.ConnectionString = FB5_Utility.GetConnectionString()
        'End Sub

        'Private Sub DeleteSendingEmail(ByVal sApprovedBy As String, ByVal nInt As Integer)
        '    Dim sqlSrc As SqlDataSource
        '    If SqlDataSource2.ConnectionString = "" Then SqlDataSource2_Load(Nothing, Nothing)
        '    sqlSrc = SqlDataSource2
        '    If nInt = 1 Then
        '        sqlSrc.DeleteCommand = "Delete from fb_approve_reject_email where ApprovedBy='" & sApprovedBy & "'"
        '    Else
        '        sqlSrc.DeleteCommand = "Delete from fb_approve_reject_email where DeniedBy='" & sApprovedBy & "'"
        '    End If
        '    sqlSrc.Delete()
        'End Sub

        Public Sub Approve(data As cListApproval)
            'Dim sFormNum As String
            'Dim sFormLocation As String = ""
            'Dim sFormStatus As String
            'Dim sPreparedBy As String
            'Dim nApprovalLayer As Integer
            'Dim sNextApproverID As String
            CompanyId = data.CompanyId
            'Enumerate the GridViewRows
            DeleteSendingEmail(data.UserId, 1, data.CompanyId)

            For Each dt As cListApprovalDetail In data.cListApprovalDetail
                Dim sAccountNum As String = ""
                Dim sFormNum As String = ""
                Dim sFormLocation As String = ""
                Dim sFormStatus As String = ""
                Dim sPreparedBy As String = ""
                Dim nApprovalLayer As Integer
                Dim sNextApproverID As String = ""
                Dim sBudgeted As String
                If Not dt.PolRelated Then
                    If dt.Budgeted Then
                        sBudgeted = "BUD"
                    Else
                        sBudgeted = "NBUD"
                    End If
                Else
                    sBudgeted = ""
                End If

                Dim sApprovalGroupCode As String
                If Not dt.PolRelated Then
                    sApprovalGroupCode = dt.ApprovalGroupCode & sBudgeted _
                                            & getLimitType(dt.FromDept, dt.TransactionCode, sBudgeted)
                Else
                    sApprovalGroupCode = dt.ApprovalGroupCode
                End If

                nApprovalLayer = Convert.ToInt32(Right(dt.FormStatus, 1))
                sFormLocation = dt.CodeApprover
                sFormNum = dt.FormNum
                If UCase(sFormLocation) <> "TAX" And UCase(sFormLocation) <> "CASHIER" Then
                    sNextApproverID = Split(sFormLocation, ",")(0)
                Else
                    sNextApproverID = sFormLocation
                End If

                If NotYetApprove(dt.FormLocation, sFormNum,
                                   dt.FormStatus) Then

                    updateSendingEmail(sFormNum, Split(dt.CreateBy, " ")(0), dt.FormLocation, sNextApproverID, "", CompanyId)
                    If UCase(sFormLocation) = "CASHIER" Then
                        sFormStatus = "ABT"
                    ElseIf sFormLocation = "TAX" Then
                        sFormStatus = "ABU"
                    Else
                        sFormLocation = sNextApproverID
                    End If
                    Dim nMaxLevel As Integer = getMaxLevel(dt.TransactionCode, dt.FormLocation,
                                                               dt.PolRelated, sApprovalGroupCode,
                                                               dt.FromDept, dt.Currency, dt.TotalAmount, CompanyId)
                    'Dim lblNextLevel As Label = CType(FormList.Rows(index).FindControl("lblNextApproverLevel"), Label)
                    Dim dDate As Date = Now()
                    If Trim(dt.NextApprover) = "" Then

                        If sFormLocation = "CASHIER" Then
                            If dt.PolRelated And Trim(dt.PaidBy) = getParamValue("Zero_Sum_Code", CompanyId) Then
                                sFormStatus = "PAID"
                                If CreateDummyPayment(sFormNum, System.Convert.ToDouble(dt.NettAmount),
                                                          dt.PolRelated, sAccountNum, CompanyId) = 1 Then
                                    VoucherIncrement(sAccountNum)
                                End If
                                UpdateIngenOS(sFormNum, Trim(dt.PolicyNum))
                            Else
                                sFormStatus = sFormStatus
                            End If

                        Else

                            sFormStatus = Left(dt.FormStatus, 2) _
                                     & dt.NextApprover
                        End If

                        updateStatus(sFormNum, sFormStatus, sFormLocation, data.CompanyId, data.UserId, dt.CodeApprover, "Approve")
                        updateApproverInfo(sFormNum, dt.FormLocation, nApprovalLayer, dDate, "", CompanyId)
                        'ElseIf dt.NextApprover <> "CASHIER" And dt.NextApprover <> "TAX" Then

                    ElseIf (Convert.ToInt32(dt.NextApprover) >= nMaxLevel) Then
                        If sFormStatus = "ABT" Then
                            sFormStatus = sFormStatus
                        ElseIf sFormStatus = "ABU" Then
                            sFormStatus = sFormStatus
                        Else
                            sFormStatus = Left(dt.FormStatus, 2) _
                                         & Convert.ToInt32(dt.NextApprover)
                        End If
                        updateStatus(sFormNum, sFormStatus, sFormLocation, data.CompanyId, data.UserId, dt.CodeApprover, "Approve")
                        updateApproverInfo(sFormNum, dt.FormLocation, nApprovalLayer, dDate, "", CompanyId)
                        'End If
                    ElseIf sFormLocation = "CASHIER" Then
                        If dt.PolRelated And Trim(dt.PaidBy) = getParamValue("Zero_Sum_Code", CompanyId) Then
                            sFormStatus = "PAID"
                            'continue
                            If CreateDummyPayment(sFormNum, System.Convert.ToDouble(dt.NettAmount),
                                                          dt.PolRelated, sAccountNum, CompanyId) = 1 Then
                                VoucherIncrement(sAccountNum)
                            End If
                            UpdateIngenOS(sFormNum, Trim(dt.PolicyNum))
                        Else
                            sFormStatus = "ABT"
                        End If
                        updateStatus(sFormNum, sFormStatus, sFormLocation, data.CompanyId, data.UserId, dt.CodeApprover, "Approve")
                        'If dt.NextApprover <> "CASHIER" And dt.NextApprover <> "TAX" Then

                        If Convert.ToInt32(dt.NextApprover) < nMaxLevel Then
                            For i As Integer = nApprovalLayer To nMaxLevel - 1
                                If i = nMaxLevel - 1 Then
                                    updateApproverInfo(sFormNum, dt.FormLocation, i, dDate, "", CompanyId)
                                Else
                                    updateApproverInfo(sFormNum, dt.FormLocation, i, dDate, "AUTO", CompanyId)
                                End If
                            Next
                        End If
                        'End If

                    ElseIf sFormLocation = "TAX" Then
                        sFormStatus = "ABU"
                        updateStatus(sFormNum, sFormStatus, sFormLocation, data.CompanyId, data.UserId, dt.CodeApprover, "Approve")
                        'If dt.NextApprover <> "CASHIER" And dt.NextApprover <> "TAX" Then
                        If Convert.ToInt32(dt.NextApprover) < nMaxLevel Then
                            For i As Integer = nApprovalLayer To nMaxLevel - 1
                                If i = nMaxLevel - 1 Then
                                    updateApproverInfo(sFormNum, dt.FormLocation, i, dDate, "", CompanyId)
                                Else
                                    updateApproverInfo(sFormNum, dt.FormLocation, i, dDate, "AUTO", CompanyId)
                                End If
                            Next
                        End If
                        'End If


                    Else
                        sFormStatus = Left(dt.FormStatus, 2) _
                                 & nMaxLevel
                        updateStatus(sFormNum, sFormStatus, sFormLocation, data.CompanyId, data.UserId, dt.CodeApprover, "Approve")
                        For i As Integer = nApprovalLayer To nMaxLevel - 1
                            If i = nMaxLevel - 1 Then
                                updateApproverInfo(sFormNum, dt.FormLocation, i, dDate, "", CompanyId)
                            Else
                                updateApproverInfo(sFormNum, dt.FormLocation, i, dDate, "AUTO", CompanyId)
                            End If
                        Next
                    End If
                Else
                    Dim strMessage As String
                    strMessage = "Form number " & sFormNum & " is no longer in your area"
                    'With lblError
                    '    .Text = "<script language='javascript'>" + Environment.NewLine +
                    '                "window.alert('" + strMessage + "')</script>"
                    '    .Focus()
                    'End With
                End If
            Next
#Region "old"
            'For index As Integer = 0 To FormList.Rows.Count - 1

            '    'Programmatically access the CheckBox from the TemplateField
            '    'Dim cb As CheckBox = CType(FormList.Rows(index).FindControl("RowLevelCheckBox"), CheckBox)
            '    If cb.Checked Then
            '        sFormStatus = ""
            '        Dim sAccountNum As String = ""
            '        'Dim lblTrxnCode As Label = CType(FormList.Rows(index).FindControl("lblTrxnCode"), Label)
            '        'Dim lblOriginalNettAmount As Label = CType(FormList.Rows(index).FindControl("lblOriginalNettAmount"), Label)
            '        'Dim lblPaidBy As Label = CType(FormList.Rows(index).FindControl("lblPaidBy"), Label)
            '        'Dim isPolRelated As CheckBox = CType(FormList.Rows(index).FindControl("chkPolRelated"), CheckBox)
            '        'Dim sString As Label = CType(FormList.Rows(index).FindControl("lblApprovalGroup"), Label)
            '        'Dim lblPolicyNum As Label = CType(FormList.Rows(index).FindControl("lblPolicyNum"), Label)
            '        'Dim sBudgeted As String
            '        'Dim isBudgeted As CheckBox = CType(FormList.Rows(index).FindControl("chkBudgeted"), CheckBox)
            '        'If Not isPolRelated.Checked Then
            '        '    If isBudgeted.Checked Then
            '        '        sBudgeted = "BUD"
            '        '    Else
            '        '        sBudgeted = "NBUD"
            '        '    End If
            '        'Else
            '        '    sBudgeted = ""
            '        'End If
            '        'Dim lblDept As Label = CType(FormList.Rows(index).FindControl("lblDept"), Label)
            '        'Dim sApprovalGroupCode As String
            '        'If Not isPolRelated.Checked Then
            '        '    sApprovalGroupCode = sString.Text & sBudgeted _
            '        '                        & GetLimitType(lblDept.Text, lblTrxnCode.Text, sBudgeted)
            '        'Else
            '        '    sApprovalGroupCode = sString.Text
            '        'End If

            '        'Dim lblCurrency As Label = CType(FormList.Rows(index).FindControl("lblCurr"), Label)
            '        'Dim lblAmount As Label = CType(FormList.Rows(index).FindControl("lblTotalAmount"), Label)

            '        'sFormNum = CType(FormList.Rows(index).FindControl("lnkFormNum"), LinkButton).Text
            '        'sFormLocation = UCase(CType(FormList.Rows(index).FindControl("ListApprover"), DropDownList).Text)
            '        'sFormStatus = Left(CType(FormList.Rows(index).FindControl("lblStatus"), Label).Text, 2) _
            '        '             & CType(FormList.Rows(index).FindControl("lblNextApproverLevel"), Label).Text
            '        'nApprovalLayer = Right(CType(FormList.Rows(index).FindControl("lblStatus"), Label).Text, 1)
            '        'sPreparedBy = Split(CType(FormList.Rows(index).FindControl("lblPreparedBy"), Label).Text, " ")(0)
            '        'If UCase(sFormLocation) <> "TAX" And UCase(sFormLocation) <> "CASHIER" Then
            '        '    sNextApproverID = Split(sFormLocation, ",")(0)
            '        'Else
            '        '    sNextApproverID = sFormLocation
            '        'End If
            '        If NotYetApprove(lblFormLocation.Text, sFormNum,
            '                        CType(FormList.Rows(index).FindControl("lblStatus"), Label).Text) Then

            '            updateSendingEmail(sFormNum, sPreparedBy, lblFormLocation.Text, sNextApproverID, "")
            '            If UCase(sFormLocation) = "CASHIER" Then
            '                sFormStatus = "ABT"
            '            ElseIf sFormLocation = "TAX" Then
            '                sFormStatus = "ABU"
            '            Else
            '                sFormLocation = sNextApproverID
            '            End If
            '            Dim nMaxLevel As Integer = getMaxLevel(lblTrxnCode.Text, lblFormLocation.Text,
            '                                                   isPolRelated.Checked, sApprovalGroupCode,
            '                                                   lblDept.Text, lblCurrency.Text, lblAmount.Text)
            '            'Dim lblNextLevel As Label = CType(FormList.Rows(index).FindControl("lblNextApproverLevel"), Label)
            '            Dim dDate As Date = Now()
            '            If Trim(lblNextLevel.Text) = "" Then
            '                If sFormLocation = "CASHIER" Then
            '                    If isPolRelated.Checked And Trim(lblPaidBy.Text) = getParamValue("Zero_Sum_Code") Then
            '                        sFormStatus = "PAID"
            '                        If CreateDummyPayment(sFormNum, System.Convert.ToDouble(lblOriginalNettAmount.Text),
            '                                              isPolRelated.Checked, sAccountNum) = 1 Then
            '                            VoucherIncrement(sAccountNum)
            '                        End If
            '                        UpdateIngenOS(sFormNum, Trim(lblPolicyNum.Text))
            '                    Else
            '                        sFormStatus = sFormStatus
            '                    End If
            '                ElseIf sFormLocation = "TAX" Then
            '                    sFormStatus = sFormStatus
            '                Else

            '                    sFormStatus = Left(CType(FormList.Rows(index).FindControl("lblStatus"), Label).Text, 2) _
            '                         & CType(FormList.Rows(index).FindControl("lblNextApproverLevel"), Label).Text
            '                End If
            '                UpdateStatus(sFormNum, sFormStatus, sFormLocation)
            '                updateApproverInfo(sFormNum, lblFormLocation.Text, nApprovalLayer, dDate, "")
            '            ElseIf (lblNextLevel.Text >= nMaxLevel) Then
            '                If sFormStatus = "ABT" Then
            '                    sFormStatus = sFormStatus
            '                ElseIf sFormStatus = "ABU" Then
            '                    sFormStatus = sFormStatus
            '                Else
            '                    sFormStatus = Left(CType(FormList.Rows(index).FindControl("lblStatus"), Label).Text, 2) _
            '                         & CType(FormList.Rows(index).FindControl("lblNextApproverLevel"), Label).Text
            '                End If
            '                UpdateStatus(sFormNum, sFormStatus, sFormLocation)
            '                updateApproverInfo(sFormNum, lblFormLocation.Text, nApprovalLayer, dDate, "")
            '            ElseIf sFormLocation = "CASHIER" Then
            '                If isPolRelated.Checked And Trim(lblPaidBy.Text) = getParamValue("Zero_Sum_Code") Then
            '                    sFormStatus = "PAID"
            '                    'continue
            '                    If CreateDummyPayment(sFormNum, System.Convert.ToDouble(lblOriginalNettAmount.Text),
            '                                          isPolRelated.Checked, sAccountNum) = 1 Then
            '                        VoucherIncrement(sAccountNum)
            '                    End If
            '                    UpdateIngenOS(sFormNum, Trim(lblPolicyNum.Text))
            '                Else
            '                    sFormStatus = "ABT"
            '                End If
            '                UpdateStatus(sFormNum, sFormStatus, sFormLocation)
            '                If lblNextLevel.Text < nMaxLevel Then
            '                    For i As Integer = nApprovalLayer To nMaxLevel - 1
            '                        If i = nMaxLevel - 1 Then
            '                            updateApproverInfo(sFormNum, lblFormLocation.Text, i, dDate, "")
            '                        Else
            '                            updateApproverInfo(sFormNum, lblFormLocation.Text, i, dDate, "AUTO")
            '                        End If
            '                    Next
            '                End If
            '            ElseIf sFormLocation = "TAX" Then
            '                sFormStatus = "ABU"
            '                UpdateStatus(sFormNum, sFormStatus, sFormLocation)
            '                If lblNextLevel.Text < nMaxLevel Then
            '                    For i As Integer = nApprovalLayer To nMaxLevel - 1
            '                        If i = nMaxLevel - 1 Then
            '                            updateApproverInfo(sFormNum, lblFormLocation.Text, i, dDate, "")
            '                        Else
            '                            updateApproverInfo(sFormNum, lblFormLocation.Text, i, dDate, "AUTO")
            '                        End If
            '                    Next
            '                End If
            '            Else
            '                sFormStatus = Left(CType(FormList.Rows(index).FindControl("lblStatus"), Label).Text, 2) _
            '                     & nMaxLevel
            '                UpdateStatus(sFormNum, sFormStatus, sFormLocation)
            '                For i As Integer = nApprovalLayer To nMaxLevel - 1
            '                    If i = nMaxLevel - 1 Then
            '                        updateApproverInfo(sFormNum, lblFormLocation.Text, i, dDate, "")
            '                    Else
            '                        updateApproverInfo(sFormNum, lblFormLocation.Text, i, dDate, "AUTO")
            '                    End If
            '                Next
            '            End If
            '        Else
            '            Dim strMessage As String
            '            strMessage = "Form number " & sFormNum & " is no longer in your area"
            '            'With lblError
            '            '    .Text = "<script language='javascript'>" + Environment.NewLine +
            '            '                "window.alert('" + strMessage + "')</script>"
            '            '    .Focus()
            '            'End With
            '        End If
            '    End If
            'Next
#End Region

            sendEmailNotificationToApprover(data.UserId, CompanyId)
            sendEmailNotificationToPreparer(data.UserId, 1, CompanyId, "")
            SendEmailToNextApprover(data.UserId, CompanyId)

            DeleteSendingEmail(data.UserId, 1, data.CompanyId)
            'FormList.DataBind()
        End Sub

        Private Sub DeleteSendingEmail(ByVal sApprovedBy As String, ByVal nInt As Integer, ByVal cmpnyID As String)
            Dim sString As String
            sString = ""
            Dim dr_Approver As SqlDataReader
            Dim SqlConn As SqlConnection
            SqlConn = New SqlConnection()
            SqlConn.ConnectionString =
                getConnectionString()

            Dim sqlCmdDeleteEmail As SqlCommand = SqlConn.CreateCommand
            Try

                If nInt = 1 Then
                    sqlCmdDeleteEmail.CommandText = "Delete from fb_approve_reject_email where ApprovedBy='" & sApprovedBy & "' and CompanyId='" & cmpnyID & "'"
                Else
                    sqlCmdDeleteEmail.CommandText = "Delete from fb_approve_reject_email where DeniedBy='" & sApprovedBy & "' and CompanyId='" & cmpnyID & "'"
                End If
                SqlConn.Open()
                dr_Approver = sqlCmdDeleteEmail.ExecuteReader(CommandBehavior.Default)
            Catch ex As Exception
                'lblException.Text = ex.ToString
                Throw ex
            Finally
                If SqlConn.State = ConnectionState.Open Then SqlConn.Close()
            End Try
        End Sub


        Private Sub SendEmailToNextApprover(ByVal sApproverID As String, ByVal sCompanyId As String)
            Dim sString As String
            sString = ""
            Dim sNextApproverID As String
            Dim dr_Approver As SqlDataReader
            Dim SqlConn As SqlConnection
            SqlConn = New SqlConnection()
            SqlConn.ConnectionString =
                getConnectionString()

            'sNextApproverID = objEncrypt.EncryptQueryString(sApproverID)
            Dim sqlCmdNextApprover As SqlCommand = SqlConn.CreateCommand
            Try
                sqlCmdNextApprover.CommandText = "Select distinct(A.NextApprover) as NextApprover " _
                                & "from fb_approve_reject_email A " _
                                & "where A.ApprovedBy='" & sApproverID & "' and a.companyid='" & sCompanyId & "'"
                SqlConn.Open()
                dr_Approver = sqlCmdNextApprover.ExecuteReader(CommandBehavior.Default)
                With dr_Approver
                    If .HasRows Then
                        While .Read
                            sNextApproverID = UCase(.Item("NextApprover").ToString)
                            If sNextApproverID <> "CASHIER" And sNextApproverID <> "TAX" Then
                                SendEmailToEachNextApprover(sNextApproverID, sApproverID, sCompanyId)
                            End If
                        End While
                    End If
                    .Close()
                End With
            Catch ex As Exception
                'lblException.Text = ex.ToString
                Throw ex
            Finally
                If SqlConn.State = ConnectionState.Open Then SqlConn.Close()
            End Try

        End Sub

        Private Sub SendEmailToEachNextApprover(ByVal sNextApproverID As String, ByVal sPreviousApprover As String, ByVal sCompanyId As String)
            Dim sNextApproverEmail As String = getEmailAddress(sNextApproverID, sCompanyId)
            Dim sString As String = ""
            Dim sFormList As String = ""
            Dim dr_Reader As SqlDataReader
            Dim SqlConn As SqlConnection
            SqlConn = New SqlConnection()
            SqlConn.ConnectionString =
                getConnectionString()
            SqlConn.Open()
            Dim command As SqlCommand = SqlConn.CreateCommand
            Try
                'new
                command.CommandText = "Select A.FormNum, A.ApprovedBy, B.UserName as CurrentApproverName, " _
                                & "A.NextApprover,C.UserName as NextApproverName, " _
                                & "A.PreparedBy, D.UserName as PreparerName, E.Curr," _
                                & "CAST(CONVERT(varchar(20), CAST(E.totalamount AS money), 1) AS varchar(20))AS TotalAmount, " _
                                & "E.TransactionCode,E.BeneficiaryName " _
                                & "from fb_approve_reject_email A " _
                                & "inner join fb_user_info B on A.ApprovedBy=B.UserID and a.companyid=b.companyid " _
                                & "left join fb_user_info C on A.NextApprover=C.UserID and a.companyid=c.companyid " _
                                & "inner join fb_user_info D on A.PreparedBy=D.UserID and a.companyid=d.companyid " _
                                & "inner join fb_ger_info E on A.FormNum = E.FormNum and a.companyid=e.companyid " _
                                & "where A.ApprovedBy='" & sPreviousApprover & "' and a.companyid='" & sCompanyId & "' and A.NextApprover = '" & sNextApproverID & "'"

                dr_Reader = command.ExecuteReader(CommandBehavior.Default)
                With dr_Reader
                    If .HasRows Then
                        sFormList = "<table style=width: 800px><tr>" _
                                  & "<th align=left>FormNum</th>" _
                                  & "<th align=left>TrxnCode</th>" _
                                  & "<th align=left>Curr</th>" _
                                  & "<th align=right>Gross Amount </th>" _
                                  & "<th align=left>Preparer</th>" _
                                  & "<th align=left>Previous Approver</th>" _
                                  & "<th align=left>Beneficiary Name</th>" _
                                  & "</tr>"
                        While .Read
                            sFormList = sFormList _
                                    & "<tr>" _
                                    & "<td align=left>" & .Item("FormNum").ToString & "</td>" _
                                    & "<td align=left>" & .Item("TransactionCode").ToString & "</td>" _
                                    & "<td align=left>" & .Item("Curr").ToString & "</td>" _
                                    & "<td align=right>" & .Item("TotalAmount").ToString & "</td>" _
                                    & "<td align=left>" & .Item("PreparedBy").ToString & ", " & .Item("PreparerName").ToString & "</td>" _
                                    & "<td align=left>" & .Item("ApprovedBy").ToString & ", " & .Item("CurrentApproverName").ToString & "</td>" _
                                    & "<td align=left>" & .Item("BeneficiaryName").ToString & "</td>" _
                                    & "</tr>"
                        End While
                        sFormList = sFormList & "</table> "
                    End If
                    .Close()
                End With
                'end ofnew
                dr_Reader.Close()
                Dim sLink As String
                Dim foldername As String

                foldername = getFolderName(sCompanyId)
                'foldername = Replace(foldername, "[UID]", sNextApproverID)
                'foldername = Replace(foldername, "[COID]", sCompanyId)

                If OldLinkApprover(sNextApproverID) Then
                    'sLink = "http://" & getServerName() & "/" & foldername & "?id=" & EncryptQueryString(sNextApproverID)
                    sLink = "http://" & getServerName(sCompanyId) & "/" & foldername & "?id=" & compSecurity.Encrypt(sNextApproverID, "useridObject") & "&co=" & compSecurity.Encrypt(sCompanyId, "companyObject")
                Else
                    sLink = "<a href=""http://" & getServerName(sCompanyId) & "/" & foldername & "?id=" & compSecurity.Encrypt(sNextApproverID, "useridObject") & "&co=" & compSecurity.Encrypt(sCompanyId, "companyObject") & """/>SnAPS Approval Page</a> <br /> <br /> "
                    '& "<a href=""awb://" & getServerName(sCompanyId) & "/" & foldername & "?id=" & compSecurity.Encrypt(sNextApproverID, "useridObject") & "&co=" & compSecurity.Encrypt(sCompanyId, "companyObject") & """/>SnAPS Approval Page For IOS</a>"
                End If

                'old production link: "<a href=http://" & getServerName() & "/" & getFolderName() & "/Snaps_Authenticate.aspx?lID=" & objEncrypt.EncryptQueryString(sNextApproverID) & ">SnAPS Approval Page</a>"
                sString = "EXEC msdb.dbo.sp_send_dbmail " _
                    & "@profile_name = '" & getParamValue("Email_Profile", sCompanyId) & "'," _
                    & "@recipients = '" & sNextApproverEmail & "'," _
                    & "@subject = 'GER/CAR for your approval'," _
                    & "@body='There are General Expense Reports / Cash Advance Requisition that require your approval. Details are:" _
                    & "<br /><br />" _
                    & sFormList _
                    & "<br /><br />" _
                    & "Please click the link below to view and approve/reject." _
                    & "<br /><br />" _
                    & sLink _
                    & "<br /><br /><br />" _
                    & "This email is generated automatically by SnAPS application. Please do not reply." & "'," _
                    & "@body_format = 'HTML' ;"
                Dim cmdSendEmail As SqlCommand = SqlConn.CreateCommand
                cmdSendEmail.CommandText = sString
                cmdSendEmail.ExecuteNonQuery()
            Catch ex As Exception
                'lblException.Text = ex.ToString
                Throw ex
            Finally
                If SqlConn.State = ConnectionState.Open Then SqlConn.Close()
            End Try
        End Sub
        Public Function EncryptQueryString(ByVal stringToEncrypt As String) As String
            Dim sEncryptionKey As String = "A1B2C3D4" '"!#$a54?3"
            Try
                key = System.Text.Encoding.UTF8.GetBytes(Left(sEncryptionKey, 8))
                Dim des As New DESCryptoServiceProvider()
                Dim inputByteArray() As Byte = Encoding.UTF8.GetBytes(
                stringToEncrypt)
                Dim ms As New MemoryStream()
                Dim cs As New CryptoStream(ms, des.CreateEncryptor(key, IV),
                CryptoStreamMode.Write)
                cs.Write(inputByteArray, 0, inputByteArray.Length)
                cs.FlushFinalBlock()
                Return Convert.ToBase64String(ms.ToArray())
            Catch e As Exception
                Return e.Message
            End Try
        End Function


        Private Function getLimitType(ByVal sDept As String,
                                  ByVal sTrxn As String, ByVal sBudget As String) As String
            Dim sString As String = ""
            Dim SqlConn As SqlConnection
            SqlConn = New SqlConnection()
            SqlConn.ConnectionString =
                getConnectionString()

            Dim command As SqlCommand = SqlConn.CreateCommand()
            Dim rs_User_Info As SqlDataReader
            Try
                command.CommandText =
                           "select limitType from fb_dept_transactiontype " _
                         & "where transactionTypeCode=@TrxnTypeCode and deptcode=@Dept"
                command.CommandType = CommandType.Text
                Dim paramTrxnTypeCode As SqlParameter = New SqlParameter("@TrxnTypeCode", SqlDbType.VarChar)
                paramTrxnTypeCode.Value = sTrxn
                command.Parameters.Add(paramTrxnTypeCode)
                Dim paramDept As SqlParameter = New SqlParameter("@Dept", SqlDbType.VarChar)
                paramDept.Value = sDept
                command.Parameters.Add(paramDept)
                SqlConn.Open()
                rs_User_Info = command.ExecuteReader(CommandBehavior.CloseConnection) '  SingleRow)
                With rs_User_Info
                    If .HasRows Then
                        While .Read
                            If sBudget = "BUD" Then
                                sString = Left(Trim(.Item("limitType").ToString), 1)
                            Else
                                sString = Right(Trim(.Item("limitType").ToString), 1)
                            End If
                        End While
                    End If
                    .Close()
                End With
            Catch ex As Exception
                'With lblException
                '    .Visible = True
                '    .Text = "Exception: {0}" & "," & ex.Message
                'End With
                Throw ex
            Finally
                If SqlConn.State = ConnectionState.Open Then SqlConn.Close()
            End Try
            Return sString
        End Function

        Private Sub updateApproverInfo(ByVal sFormNum As String,
                                   ByVal sApproverID As String,
                                   ByVal nApprovalLayer As Integer,
                                   ByVal dDate As Date,
                                   ByVal sRemark As String,
                                   ByVal companyid As String)
            Dim odal As New SQLAccess("core")

            Try
                ores = New cResult
                'Validation
                'ores.InvalidMessage = IsValid(odal, pparam)

                'Run Tasks
                If ores.InvalidMessage = "" Then
                    odal.BeginTransactions()
                    odal.ExecuteCommandSP("usp_InsertGERApprovalInfo",
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(companyid)),
                        odal.CreateParameter("@formNum", SqlDbType.VarChar, comlib.GetText(sFormNum)),
                        odal.CreateParameter("@approvalId", SqlDbType.VarChar, comlib.GetText(sApproverID)),
                        odal.CreateParameter("@approvalLayer", SqlDbType.VarChar, comlib.GetText(nApprovalLayer)),
                        odal.CreateParameter("@approvalDt", SqlDbType.VarChar, comlib.GetText(dDate)),
                        odal.CreateParameter("@remark", SqlDbType.VarChar, comlib.GetText(sRemark)),
                        odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))
                    ores.InvalidMessage = odal.ReturnValue(1).ToString

                    If ores.InvalidMessage = "Berhasil" Then
                        odal.CommitTransactions()
                    Else
                        odal.RollBackTransactions()
                    End If
                End If
            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            'ores.Result = "SUCCESS"
            'Return ores
        End Sub

        Private Sub updateSendingEmail(ByVal sFormNum As String,
                                   ByVal sPreparedBy As String,
                                   ByVal sApprovedBy As String,
                                   ByVal sNextApproverID As String,
                                   ByVal sDeniedBy As String,
                                    ByVal companyid As String)
            Dim odal As New SQLAccess("core")

            Try
                ores = New cResult
                'Validation
                'ores.InvalidMessage = IsValid(odal, pparam)

                'Run Tasks
                If ores.InvalidMessage = "" Then
                    odal.BeginTransactions()
                    odal.ExecuteCommandSP("usp_UpdateSendingEmail",
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(companyid)),
                        odal.CreateParameter("@formNum", SqlDbType.VarChar, comlib.GetText(sFormNum)),
                        odal.CreateParameter("@preparedBy", SqlDbType.VarChar, comlib.GetText(sPreparedBy)),
                        odal.CreateParameter("@approvedBy", SqlDbType.VarChar, comlib.GetText(sApprovedBy)),
                        odal.CreateParameter("@nextApprover", SqlDbType.VarChar, comlib.GetText(sNextApproverID)),
                        odal.CreateParameter("@deniedBy", SqlDbType.VarChar, comlib.GetText(sDeniedBy)),
                        odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))
                    ores.InvalidMessage = odal.ReturnValue(1).ToString

                    If ores.InvalidMessage = "Berhasil" Then
                        odal.CommitTransactions()
                    Else
                        odal.RollBackTransactions()
                    End If
                End If
            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            'ores.Result = "SUCCESS"
            'Return ores
        End Sub

        Private Sub updateStatus(ByVal sFormNum As String,
                             ByVal sFormStatus As String,
                             ByVal sFormLocation As String, ByVal companyid As String, ByVal userId As String, ByVal sNextAppr As String, ByVal Table As String)
            Dim odal As New SQLAccess("core")

            Try
                ores = New cResult
                'Validation
                'ores.InvalidMessage = IsValid(odal, pparam)

                'Run Tasks
                If ores.InvalidMessage = "" Then
                    odal.BeginTransactions()
                    odal.ExecuteCommandSP("usp_UpdateStatus",
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(companyid)),
                        odal.CreateParameter("@formNum", SqlDbType.VarChar, comlib.GetText(sFormNum)),
                        odal.CreateParameter("@formLocation", SqlDbType.VarChar, comlib.GetText(sFormLocation)),
                        odal.CreateParameter("@formStatus", SqlDbType.VarChar, comlib.GetText(sFormStatus)),
                        odal.CreateParameter("@userid", SqlDbType.VarChar, comlib.GetText(userId)),
                        odal.CreateParameter("@nextAppr", SqlDbType.VarChar, comlib.GetText(sNextAppr)),
                        odal.CreateParameter("@Table", SqlDbType.VarChar, comlib.GetText(Table)),
                        odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))
                    ores.InvalidMessage = odal.ReturnValue(1).ToString

                    If ores.InvalidMessage = "Berhasil" Then
                        odal.CommitTransactions()
                    Else
                        odal.RollBackTransactions()
                    End If
                End If
            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            'ores.Result = "SUCCESS"
            'Return ores
        End Sub

        'Private Sub DeleteSendingEmail(ByVal sApprovedBy As String, ByVal nInt As Integer)
        '    Dim sqlSrc As SqlDataSource
        '    If SqlDataSource2.ConnectionString = "" Then SqlDataSource2_Load(Nothing, Nothing)
        '    sqlSrc = SqlDataSource2
        '    If nInt = 1 Then
        '        sqlSrc.DeleteCommand = "Delete from fb_approve_reject_email where ApprovedBy='" & sApprovedBy & "'"
        '    Else
        '        sqlSrc.DeleteCommand = "Delete from fb_approve_reject_email where DeniedBy='" & sApprovedBy & "'"
        '    End If
        '    sqlSrc.Delete()
        'End Sub

        Private Function NotYetApprove(ByVal sLocation As String,
                                   ByVal sFormNum As String,
                                   ByVal sStatus As String) As Boolean
            Dim bBol As Boolean = False
            Dim dr_ApproverEmail As SqlDataReader
            Dim SqlConn As SqlConnection
            SqlConn = New SqlConnection()
            SqlConn.ConnectionString =
                    getConnectionString()

            Dim command As SqlCommand = SqlConn.CreateCommand()
            Try
                command.CommandText = "Select FormLocation, FormStatus from fb_ger_info where FormNum=@FormNum"
                SqlConn.Open()
                Dim paramID As SqlParameter = New SqlParameter("@FormNum", SqlDbType.Char)
                paramID.Value = sFormNum
                command.Parameters.Add(paramID)
                dr_ApproverEmail = command.ExecuteReader(CommandBehavior.SingleRow)
                With dr_ApproverEmail
                    If .HasRows Then
                        While .Read
                            Dim a As String = Trim(.Item("FormLocation").ToString)
                            Dim b As String = Trim(.Item("FormStatus").ToString)
                            If UCase(sLocation) = UCase(Trim(.Item("FormLocation").ToString)) And
                                UCase(sStatus) = UCase(Trim(.Item("FormStatus").ToString)) Then
                                bBol = True
                            End If
                        End While

                    End If
                    .Close()
                End With
            Catch ex As Exception
                'lblException.Text = ex.ToString
                Throw ex
            Finally
                If SqlConn.State = ConnectionState.Open Then SqlConn.Close()
            End Try

            NotYetApprove = bBol
        End Function

        'Private Sub updateSendingEmail(ByVal sFormNum As String,
        '                       ByVal sPreparedBy As String,
        '                       ByVal sApprovedBy As String,
        '                       ByVal sNextApproverID As String,
        '                       ByVal sDeniedBy As String)
        '    Dim sApproverID As String = ""
        '    If Trim(sApprovedBy) <> "" Then
        '        sApproverID = sApprovedBy
        '    Else
        '        sApproverID = sDeniedBy
        '    End If
        '    Dim sqlSrc As SqlDataSource
        '    If SqlDataSource2.ConnectionString = "" Then SqlDataSource2_Load(Nothing, Nothing)
        '    sqlSrc = SqlDataSource2
        '    sqlSrc.InsertCommand = "Insert Into fb_approve_reject_email(FormNum, PreparedBy,ApprovedBy, NextApprover,DeniedBy) " _
        '                         & "values('" & sFormNum & "','" & sPreparedBy & "','" & sApprovedBy & "','" & sNextApproverID & "','" & sDeniedBy & "')"
        '    sqlSrc.Insert()
        '    sqlSrc.DeleteCommand = "Delete from fb_Approver_Reminder_Info where formnum='" & sFormNum & "'"
        '    sqlSrc.Delete()
        'End Sub

        Public Shared Function getMaxLevel(ByVal sTrxnCode As String,
                                    ByVal sUID As String,
                                    ByVal bPolRelated As Boolean,
                                    ByVal sApprovalCode As String,
                                    ByVal sDeptID As String,
                                    ByVal sCurr As String,
                                    ByVal nAmount As Double,
                                    ByVal sCompanyId As String) As Integer
            Dim nInt As Integer
            Dim SqlConn As SqlConnection
            SqlConn = New SqlConnection()
            SqlConn.ConnectionString =
                    getConnectionString()

            Dim command As SqlCommand = SqlConn.CreateCommand()
            Dim Approver_Info As SqlDataReader
            Try
                With command
                    'If sCurr = "IDR" Then
                    '    .CommandText = "SELECT Max(A.ApprovalLevel) as MaxLevel " _
                    '                 & "FROM dbo.fb_Approver_ID AS A inner join fb_approval_MaxAMount B " _
                    '                 & "on A.ApprovalGroupCode=B.ApprovalGroupCode " _
                    '                 & "WHERE (A.ApproverID = @ApproverID) " _
                    '                 & "AND (A.ApprovalGroupCode = @ApprovalGroupCode) " _
                    '                 & "AND (A.DeptID = @DeptID) " _
                    '                 & "AND (B.MaxAmountIDR <=" & nAmount & ") " _
                    '                 & "AND (A.isDefault=1)"
                    'Else
                    '    .CommandText = "SELECT Max(A.ApprovalLevel) as MaxLevel " _
                    '                 & "FROM dbo.fb_Approver_ID AS A inner join fb_approval_MaxAMount B " _
                    '                 & "on A.ApprovalGroupCode=B.ApprovalGroupCode " _
                    '                 & "WHERE (A.ApproverID = @ApproverID) " _
                    '                 & "AND (A.ApprovalGroupCode = @ApprovalGroupCode) " _
                    '                 & "AND (A.DeptID = @DeptID) " _
                    '                 & "AND (B.MaxAmountUSD <=" & nAmount & ")" _
                    '                 & "AND (A.isDefault=1)"
                    'End If
                    .CommandText = "SELECT Max(A.ApprovalLevel) as MaxLevel " &
                                  "FROM dbo.fb_Approver_ID AS A inner join fb_approval_MaxAMount B " &
                                  "on A.ApprovalGroupCode=B.ApprovalGroupCode and A.Companyid=B.Companyid " &
                                  "WHERE (A.ApproverID = @ApproverID) " &
                                  "AND (A.ApprovalGroupCode = @ApprovalGroupCode) " &
                                  "AND (A.DeptID = @DeptID) " &
                                  "AND (B.MaxAmount <=" & nAmount & ")" &
                                  "AND (B.Currency='" & sCurr & "') " &
                                  "AND (A.Companyid='" & sCompanyId & "') " &
                                  "AND (A.isDefault=1)"
                    .CommandType = CommandType.Text
                End With
                Dim paramApproverID As SqlParameter = New SqlParameter("@ApproverID", SqlDbType.Char)
                Dim paramApproverGroupCode As SqlParameter = New SqlParameter("@ApprovalGroupCode", SqlDbType.Char)
                Dim paramDeptID As SqlParameter = New SqlParameter("@DeptID", SqlDbType.Char)

                paramApproverID.Value = sUID
                paramApproverGroupCode.Value = sApprovalCode
                paramDeptID.Value = sDeptID
                With command.Parameters
                    .Add(paramApproverID)
                    .Add(paramApproverGroupCode)
                    .Add(paramDeptID)
                End With
                SqlConn.Open()
                Approver_Info = command.ExecuteReader(CommandBehavior.CloseConnection)
                With Approver_Info
                    If .HasRows Then
                        While .Read
                            If Trim(.Item("MaxLevel").ToString) <> "" Then
                                nInt = .Item("MaxLevel").ToString + 1
                            End If
                        End While
                    End If
                End With
            Catch ex As Exception
                Print(ex.Message)
            Finally
                getMaxLevel = nInt
                If SqlConn.State = ConnectionState.Open Then SqlConn.Close()
            End Try
            Return nInt
        End Function

        Public Shared Function getParamValue(ByVal sParamName As String, ByVal sCompanyId As String) As String
            Dim sString As String = ""
            Dim conn As New SqlConnection
            With conn
                .ConnectionString = getConnectionString()
                .Open()
            End With
            Dim cmd As SqlCommand = conn.CreateCommand
            Dim dr As SqlDataReader
            Try
                With cmd
                    Dim SSelect As String = "Select ParamValue from fb_param_info where ParamName='" & sParamName & "' and CompanyID ='" & sCompanyId & "'"
                    .CommandText = SSelect
                    .CommandType = CommandType.Text
                End With
                dr = cmd.ExecuteReader(CommandBehavior.SingleRow)
                With dr
                    If .HasRows Then
                        While .Read
                            sString = .Item("ParamValue").ToString
                        End While
                    End If
                    .Close()
                End With
            Catch ex As Exception

            Finally
                conn.Close()
            End Try
            Return sString
        End Function

        Public Shared Function CreateDummyPayment(ByVal sFormNum As String,
                                              ByVal nAmount As Double,
                                              ByVal bPolRel As Boolean,
                                              ByRef sAccountNum As String, ByVal sCompanyId As String) As Integer
            Dim conn As New SqlConnection
            With conn
                .ConnectionString = getConnectionString()
                .Open()
            End With
            Dim cmd As SqlCommand = New SqlCommand("fb_InsertPaymentInfo", conn)
            Dim dDate As Date = Now()
            Dim sVoucherNum As String = ""
            Dim nResult As Integer = 0
            Dim sVoucherCode As String = getParamValue("VoucherCode_ZeroSumGER_POL", sCompanyId)
            If sVoucherCode <> "" Then
                sAccountNum = getDummyAccount(bPolRel, sVoucherNum, sVoucherCode)
                Try
                    With cmd
                        .CommandType = CommandType.StoredProcedure
                        .Parameters.Clear()
                        .Parameters.AddWithValue("@Companyid", sCompanyId)
                        .Parameters.AddWithValue("@FormNum", sFormNum)
                        .Parameters.AddWithValue("@SLFIBankAccountNum", sAccountNum)
                        .Parameters.AddWithValue("@VoucherNum", sVoucherNum)
                        .Parameters.AddWithValue("@VoucherReceivedDt", dDate)
                        .Parameters.AddWithValue("@PaymentPreparedDt", dDate)
                        .Parameters.AddWithValue("@TransferedDt", dDate)
                        .Parameters.AddWithValue("@TransferRemark", "Dummy payment")
                        .Parameters.AddWithValue("@PaidAmount", nAmount)
                        .Parameters.AddWithValue("@ProcessBy", "AUTO")
                        .Parameters.AddWithValue("@Status", "PAID")
                        nResult = .ExecuteNonQuery
                    End With
                Catch ex As Exception
                Finally
                    conn.Close()
                End Try
            End If
            Return nResult
        End Function

        Public Shared Function getDummyAccount(ByVal bPolRel As Boolean, ByRef sVoucherNum As String,
                                           ByVal sVoucherCode As String) As String
            Dim sString As String = ""
            Dim conn As New SqlConnection
            With conn
                .ConnectionString = getConnectionString()
                .Open()
            End With
            Dim cmd As SqlCommand = conn.CreateCommand
            Try
                With cmd
                    .CommandType = CommandType.Text
                    .CommandText = "Select AccountNum,VoucherCode,ActiveNum from fb_ListVoucher " &
                                   "Where VoucherCode='" & sVoucherCode & "'"
                End With
                Dim dr As SqlDataReader = cmd.ExecuteReader(CommandBehavior.SingleRow)
                With dr
                    If .HasRows Then
                        While .Read
                            sString = .Item("AccountNum").ToString
                            Dim sActiveNum As String
                            Dim sYear As String
                            Dim sMonth As String
                            sActiveNum = System.Convert.ToInt64(.Item("ActiveNum")).ToString("D3")
                            sMonth = Month(Date.Today).ToString("D2")
                            sYear = System.Convert.ToInt64(Right(System.Convert.ToString(Year(Date.Today)), 2)).ToString("D2")
                            sVoucherNum = .Item("VoucherCode").ToString & sActiveNum & "/" & sMonth & "/" & sYear
                            'sVoucherNum = .Item("VoucherCode").ToString & _
                            '              System.Convert.ToString(.Item("ActiveNum")).ToString("D3") & "/" & _
                            '              System.Convert.ToString(Month(Date.Today)).ToString("D2") & "/" & _
                            '              Right(System.Convert.ToString(Year(Date.Today)), 2).ToString("D2")
                        End While
                    End If
                    .Close()
                End With
            Catch ex As Exception

            End Try
            Return sString
        End Function

        Public Shared Sub VoucherIncrement(ByVal sAccountNum As String)
            Dim conn As New SqlConnection
            With conn
                .ConnectionString = getConnectionString()
                .Open()
            End With
            Dim cmdUpdate As SqlCommand = conn.CreateCommand
            With cmdUpdate
                .CommandType = CommandType.Text
                .CommandText = "Update fb_ListVoucher set ActiveNum=ActiveNum+1 " &
                               "WHERE AccountNum='" & sAccountNum & "'"
                .ExecuteNonQuery()
            End With
        End Sub

        Public Shared Sub UpdateIngenOS(ByVal sFormNum As String,
                                ByVal sPolicyNum As String)
            Dim conn As New SqlConnection
            With conn
                .ConnectionString = getConnectionString()
                .Open()
            End With
            Dim cmdUpdate As SqlCommand = conn.CreateCommand
            With cmdUpdate
                .CommandType = CommandType.Text
                .CommandText = "Update fb_ingen_os_disb_Info " &
                               "set Settled_Today=Settled_Today+ " & getTotalOS_ByForm(sFormNum) &
                               "WHERE Pol_Num='" & sPolicyNum & "'"
                .ExecuteNonQuery()
            End With
            'getTotalOS_ByForm(sFormNum)
        End Sub

        Public Shared Function getTotalOS_ByForm(ByVal sFormNum As String) As Double
            Dim nDouble As Double = 0
            Dim dr As SqlDataReader
            Dim conn As New SqlConnection
            With conn
                .ConnectionString = getConnectionString()
                .Open()
            End With
            Dim cmd As SqlCommand = conn.CreateCommand
            Try
                With cmd
                    .CommandType = CommandType.Text
                    .CommandText = "Select COA,OriginalAmount from fb_ger_detail_info where formnum='" & sFormNum & "'"
                End With
                dr = cmd.ExecuteReader
                With dr
                    If .HasRows Then
                        While .Read
                            If COA_OS(.Item("COA")) Then
                                nDouble = nDouble + .Item("OriginalAmount")
                            End If
                        End While
                    End If
                    .Close()
                End With
            Catch ex As Exception

            Finally
                conn.Close()
            End Try
            Return nDouble
        End Function

        Private Shared Function COA_OS(ByVal sCode As String) As Boolean
            Dim bBol As Boolean
            Dim dr As SqlDataReader
            Dim conn As New SqlConnection
            With conn
                .ConnectionString = getConnectionString()
                .Open()
            End With
            Dim cmd As SqlCommand = conn.CreateCommand
            Try
                With cmd
                    .CommandType = CommandType.Text
                    .CommandText = "Select null from fb_OS_Account_Info where OS_Account_Code='" & Trim(sCode) & "'"
                End With
                dr = cmd.ExecuteReader
                With dr
                    If .HasRows Then
                        bBol = True
                    End If
                    .Close()
                End With
            Catch ex As Exception

            Finally
                conn.Close()
            End Try
            Return bBol
        End Function

        Public Sub Denyall(data As cListApproval)
            Dim sformnum As String
            Dim sformlocation As String = ""
            Dim sformstatus As String
            Dim srejector As String
            Dim spreparedby As String
            Dim spreparedid As String
            Dim sadvancenum As String = ""
            Dim ncurrentlevel As Integer
            Dim strxncode As String
            Dim spolicynum As String
            Dim ntotalamount As Double
            CompanyId = data.CompanyId
            'enumerate the gridviewrows
            DeleteSendingEmail(data.UserId, 2, data.CompanyId)

            For Each dt As cListApprovalDetail In data.cListApprovalDetail
                sformnum = dt.FormNum
                sformlocation = dt.FromDept
                srejector = data.UserId
                spreparedby = dt.CreateBy
                sadvancenum = dt.AdvanceFormNum
                spreparedid = Split(dt.CreateBy, " ")(0)
                ncurrentlevel = Right(dt.FormStatus, 1)
                strxncode = dt.TransactionCode
                spolicynum = dt.PolicyNum
                ntotalamount = System.Convert.ToDouble(dt.TotalAmount)

                sformstatus = "REJ"
                updateStatus(sformnum, sformstatus, spreparedid, data.CompanyId, data.UserId, dt.CodeApprover, "Reject")
                InsertRejectReason(sformnum,
                                       sformlocation,
                                       data.RejectReason,
                                       dt.FormLocation, "RBA", data.CompanyId)

                updateSendingEmail(sformnum, Split(spreparedby, " ")(0), "", "", dt.FormLocation, data.CompanyId)
                DeleteAdvanceAndSettlement_info(Trim(sadvancenum))
                If dt.PolRelated = True Then
                    If AdcRefundManyPolicy(strxncode, sformnum) Then
                        BalancingLocalOS(sformnum, data.CompanyId)
                    Else
                        'Dim sqlsrc As sqldatasource
                        'If sqldatasource2.connectionstring = "" Then sqldatasource2_load(Nothing, Nothing)
                        'sqlsrc = sqldatasource2
                        'sqlsrc.updatecommand = "update fb_ingen_os_disb_info " _
                        '                        & "set on_request=on_request-" & getTotalOS_ByForm(sformnum) _
                        '                        & " where pol_num='" & spolicynum & "'"
                        'sqlsrc.update()

                        Dim conn As New SqlConnection
                        With conn
                            .ConnectionString = getConnectionString()
                            .Open()
                        End With
                        Dim cmdUpdate As SqlCommand = conn.CreateCommand
                        With cmdUpdate
                            .CommandType = CommandType.Text
                            .CommandText = "update fb_ingen_os_disb_info " &
                                           "set on_request=on_request-" & getTotalOS_ByForm(sformnum) &
                                           "WHERE Pol_Num='" & spolicynum & "' and companyid = '" & data.CompanyId & "'"
                            .ExecuteNonQuery()
                        End With
                    End If
                End If
            Next

            'For index As Integer = 0 To formlist.rows.count - 1
            '    'programmatically access the checkbox from the templatefield
            '    'Dim cb As checkbox = CType(formlist.rows(index).findcontrol("rowlevelcheckbox"), checkbox)
            '    'Dim bpolrelated As checkbox = CType(formlist.rows(index).findcontrol("chkpolrelated"), checkbox)
            '    'If cb.checked Then
            '    '    sformnum = CType(formlist.rows(index).findcontrol("lnkformnum"), linkbutton).text
            '    '    sformlocation = CType(formlist.rows(index).findcontrol("lbldept"), label).text
            '    '    srejector = lblapprovername.text
            '    '    spreparedby = CType(formlist.rows(index).findcontrol("lblpreparedby"), label).text
            '    '    sadvancenum = CType(formlist.rows(index).findcontrol("lbladvancenum"), label).text
            '    '    spreparedid = Split(spreparedby, " ")(0)
            '    '    ncurrentlevel = Right(CType(formlist.rows(index).findcontrol("lblstatus"), label).text, 1)
            '    '    strxncode = CType(formlist.rows(index).findcontrol("lbltrxncode"), label).text
            '    '    spolicynum = CType(formlist.rows(index).findcontrol("lblpolicynum"), label).text
            '    '    ntotalamount = System.Convert.ToDouble(CType(formlist.rows(index).findcontrol("lbltotalamount"), label).text)

            '    '    sformstatus = "rej"
            '    '    updateStatus(sformnum, sformstatus, spreparedid)
            '    '    insertrejectreason(sformnum,
            '    '                       sformlocation,
            '    '                       txtrejectreason.text,
            '    '                       lblformlocation.text, "rba")

            '    'updateSendingEmail(sformnum, Split(spreparedby, " ")(0), "", "", lblformlocation.text)
            '    'DeleteAdvanceAndSettlement_info(Trim(sadvancenum))
            '    If bpolrelated.checked = True Then
            '        If adcrefundmanypolicy(strxncode, sformnum) Then
            '            balancinglocalos(sformnum)
            '        Else
            '            Dim sqlsrc As sqldatasource
            '            If sqldatasource2.connectionstring = "" Then sqldatasource2_load(Nothing, Nothing)
            '            sqlsrc = sqldatasource2
            '            sqlsrc.updatecommand = "update fb_ingen_os_disb_info " _
            '                                    & "set on_request=on_request-" & getTotalOS_ByForm(sformnum) _
            '                                    & " where pol_num='" & spolicynum & "'"
            '            sqlsrc.update()
            '        End If
            '    End If
            '    End If
            'Next
            sendEmailNotificationToPreparer(data.UserId, 2, data.CompanyId, data.RejectReason)
            sendEmailNotificationToRejector(data.UserId, data.CompanyId, data.RejectReason)
            sendEmailNotificationToLastApprover(data.UserId, data.CompanyId, data.RejectReason)
            DeleteSendingEmail(data.UserId, 2, data.CompanyId)
            ''Dim strurl As String
            ''strurl = "listform.aspx"
            ''response.redirect(strurl)
        End Sub

        Private Sub BalancingLocalOS(ByVal sFormNum As String, ByVal companyid As String)
            Dim odal As New SQLAccess("core")

            Try
                ores = New cResult
                'Validation
                'ores.InvalidMessage = IsValid(odal, pparam)

                'Run Tasks
                If ores.InvalidMessage = "" Then
                    odal.BeginTransactions()
                    odal.ExecuteCommandSP("usp_BalancingLocalOS",
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(companyid)),
                        odal.CreateParameter("@formNum", SqlDbType.VarChar, comlib.GetText(sFormNum)),
                        odal.CreateParameter("@Result", SqlDbType.VarChar, sretval, 8000, ParameterDirection.InputOutput))
                    ores.InvalidMessage = odal.ReturnValue(1).ToString

                    If ores.InvalidMessage = "Berhasil" Then
                        odal.CommitTransactions()
                    Else
                        odal.RollBackTransactions()
                    End If
                End If
            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            'ores.Result = "SUCCESS"
            'Return ores
        End Sub

        Private Sub sendEmailNotificationToPreparer(ByVal sApproverID As String, ByVal nInt As Integer, ByVal sCompanyId As String, ByVal sRejectReason As String)
            Dim sFormList As String = ""
            'Dim sString As String
            Dim sPreparerID As String
            Dim dr_Preparer As SqlDataReader
            'Dim dr_GER As SqlDataReader
            Dim SqlConn As SqlConnection
            SqlConn = New SqlConnection()
            SqlConn.ConnectionString =
                getConnectionString()

            Dim sqlCmdGER As SqlCommand = SqlConn.CreateCommand()
            Dim sqlCmdPreparer As SqlCommand = SqlConn.CreateCommand()
            Try
                If nInt = 1 Then
                    sqlCmdPreparer.CommandText = "Select distinct(A.PreparedBy) as Preparer " _
                                & "from fb_approve_reject_email A " _
                                & "where A.ApprovedBy='" & sApproverID & "' and a.companyid='" & sCompanyId & "'"
                Else
                    sqlCmdPreparer.CommandText = "Select distinct(A.PreparedBy) as Preparer " _
                                & "from fb_approve_reject_email A " _
                                & "where A.DeniedBy='" & sApproverID & "' and a.companyid='" & sCompanyId & "'"
                End If

                SqlConn.Open()
                dr_Preparer = sqlCmdPreparer.ExecuteReader(CommandBehavior.Default)
                With dr_Preparer
                    If .HasRows Then
                        While .Read
                            sPreparerID = .Item("Preparer").ToString
                            sendEmailToPreparer(sApproverID, sPreparerID, nInt, sCompanyId, sRejectReason)
                        End While
                    End If
                    .Close()
                End With
            Catch ex As Exception
                'lblException.Text = ex.ToString
                Throw ex
            Finally
                If SqlConn.State = ConnectionState.Open Then SqlConn.Close()
            End Try

        End Sub

        Private Sub sendEmailNotificationToLastApprover(ByVal sApproverID As String, ByVal sCompanyId As String, ByVal sRejectReason As String)
            Dim sFormList As String = ""
            'Dim sString As String
            Dim sLastApprovalID As String
            Dim dr As SqlDataReader
            'Dim dr_GER As SqlDataReader
            Dim SqlConn As SqlConnection
            SqlConn = New SqlConnection()
            SqlConn.ConnectionString =
                getConnectionString()

            Dim sqlCmdPreparer As SqlCommand = SqlConn.CreateCommand()
            Try
                'If nInt = 1 Then
                '    sqlCmdPreparer.CommandText = "Select distinct(A.PreparedBy) as Preparer " _
                '                & "from fb_approve_reject_email A " _
                '                & "where A.ApprovedBy='" & sApproverID & "'"
                'Else
                sqlCmdPreparer.CommandText = "Select distinct b.approval_id from fb_approve_reject_email A " _
                                & "inner join (select FormNum, max(approval_layer)-1 as previousapproval, approval_id from fb_GER_Approval_Info group by formnum,approval_id ) b on a.formnum=b.formnum " _
                                & "where A.DeniedBy='" & sApproverID & "' and A.CompanyID = '" & sCompanyId & "'"
                'End If

                SqlConn.Open()
                dr = sqlCmdPreparer.ExecuteReader(CommandBehavior.Default)
                With dr
                    If .HasRows Then
                        While .Read
                            sLastApprovalID = .Item("approval_id").ToString
                            sendEmailToLastApproval(sApproverID, sLastApprovalID, sCompanyId, sRejectReason)
                        End While
                    End If
                    .Close()
                End With
            Catch ex As Exception
                'lblException.Text = ex.ToString
                Throw ex
            Finally
                If SqlConn.State = ConnectionState.Open Then SqlConn.Close()
            End Try

        End Sub

        Private Sub sendEmailToLastApproval(ByVal sApproverID As String, ByVal sLastApprovalID As String, ByVal sCompanyId As String, ByVal sRejectReason As String)
            Dim sFormList As String = ""
            Dim sString As String
            Dim sBody As String = ""
            Dim sWhere As String = ""
            Dim sColumnApproveHeader As String = ""
            Dim sJoin As String = ""
            'Dim sPreviusId As String = ""
            Dim dr_GER As SqlDataReader
            Dim SqlConn As SqlConnection
            SqlConn = New SqlConnection()
            SqlConn.ConnectionString =
                getConnectionString()

            Dim sqlCmdGER As SqlCommand = SqlConn.CreateCommand()
            Try
                SqlConn.Open()
                'If nInt = 1 Then
                '    sBody = "Your following GER/CAR have been approved by "
                '    sColumnApproveHeader = "<th align=left>ApprovedBy</th>"
                '    sqlCmdGER.CommandText = "Select A.FormNum, A.ApprovedBy, B.UserName as CurrentApproverName, " _
                '                    & "A.NextApprover,C.UserName as NextApproverName, " _
                '                    & "A.PreparedBy, D.UserName as PreparerName, E.Curr," _
                '                    & "CAST(CONVERT(varchar(20), CAST(E.totalamount AS money), 1) AS varchar(20))AS TotalAmount, " _
                '                    & "E.TransactionCode " _
                '                    & "from fb_approve_reject_email A " _
                '                    & "inner join fb_user_info B on A.ApprovedBy=B.UserID " _
                '                    & "left join fb_user_info C on A.NextApprover=C.UserID " _
                '                    & "inner join fb_user_info D on A.PreparedBy=D.UserID " _
                '                    & "inner join fb_ger_info E on A.FormNum = E.FormNum " _
                '                    & "where A.ApprovedBy='" & sApproverID & "' and A.PreparedBy='" & sPreparerID & "'"
                'Else
                sBody = "Your following GER/CAR have been denied by "
                sColumnApproveHeader = "<th align=left>DeniedBy</th>"
                sqlCmdGER.CommandText = "Select A.FormNum, A.DeniedBy, B.UserName as CurrentApproverName, A.NextApprover, " _
                                      & "case when C.UserName is null then ' ' else C.UserName end as NextApproverName, " _
                                      & "A.PreparedBy, D.UserName as PreparerName, E.Curr," _
                                      & "CAST(CONVERT(varchar(20), CAST(E.totalamount AS money), 1) AS varchar(20))AS TotalAmount, " _
                                      & "E.TransactionCode " _
                                      & "from fb_approve_reject_email A " _
                                      & "inner join (select CompanyId, FormNum, max(approval_layer)-1 as previousapproval, approval_id from fb_GER_Approval_Info group by CompanyId, formnum,approval_id ) f on a.formnum=f.formnum and a.companyid=f.companyid " _
                                      & "inner join fb_user_info B on A.DeniedBy=B.UserID and a.companyid=b.companyid " _
                                      & "left join fb_user_info C on A.NextApprover=C.UserID and a.companyid=c.companyid " _
                                      & "inner join fb_user_info D on A.PreparedBy=D.UserID and a.companyid=d.companyid " _
                                      & "inner join fb_ger_info E on A.FormNum = E.FormNum and a.companyid=e.companyid " _
                                      & "where A.DeniedBy='" & sApproverID & "' and f.Approval_ID='" & sLastApprovalID & "'"
                'End If


                dr_GER = sqlCmdGER.ExecuteReader(CommandBehavior.Default)
                With dr_GER
                    If .HasRows Then
                        sFormList = "<table style=width: 800px><tr>" _
                              & "<th align=left>FormNum</th>" _
                              & "<th align=left>TrxnCode</th>" _
                              & "<th align=left>Curr</th>" _
                              & "<th align=right>Gross Amount </th>" _
                              & "<th align=left>Preparer</th>" & sColumnApproveHeader _
                              & "<th align=left>Next Approver</th>" _
                              & "</tr>"
                        While .Read
                            'If nInt = 1 Then
                            '    sFormList = sFormList _
                            '        & "<tr>" _
                            '        & "<td align=left>" & .Item("FormNum").ToString & "</td>" _
                            '        & "<td align=left>" & .Item("TransactionCode").ToString & "</td>" _
                            '        & "<td align=left>" & .Item("Curr").ToString & "</td>" _
                            '        & "<td align=right>" & .Item("TotalAmount").ToString & "</td>" _
                            '        & "<td align=left>" & .Item("PreparedBy").ToString & ", " & .Item("PreparerName").ToString & "</td>" _
                            '        & "<td align=left>" & .Item("ApprovedBy").ToString & ", " & .Item("CurrentApproverName").ToString & "</td>" _
                            '        & "<td align=left>" & .Item("NextApprover").ToString & ", " & .Item("NextApproverName").ToString & "</td>" _
                            '        & "</tr>"
                            'Else
                            sFormList = sFormList _
                                    & "<tr>" _
                                    & "<td align=left>" & .Item("FormNum").ToString & "</td>" _
                                    & "<td align=left>" & .Item("TransactionCode").ToString & "</td>" _
                                    & "<td align=left>" & .Item("Curr").ToString & "</td>" _
                                    & "<td align=right>" & .Item("TotalAmount").ToString & "</td>" _
                                    & "<td align=left>" & .Item("PreparedBy").ToString & ", " & .Item("PreparerName").ToString & "</td>" _
                                    & "<td align=left>" & .Item("DeniedBy").ToString & ", " & .Item("CurrentApproverName").ToString & "</td>" _
                                    & "<td align=left>" & .Item("NextApprover").ToString & ", " & .Item("NextApproverName").ToString & "</td>" _
                                    & "</tr>"
                            'End If
                        End While
                        sFormList = sFormList & "</table>"
                        'sPreparerID
                        dr_GER.Close()
                        'If (nInt = 1) Then
                        '    sString = "EXEC msdb.dbo.sp_send_dbmail " _
                        '    & "@profile_name = '" & getParamValue("Email_Profile") & "'," _
                        '    & "@recipients = '" & getEmailAddress(sPreparerID) & "'," _
                        '    & "@subject = 'GER/CAR approval notice'," _
                        '    & "@body='" & sBody & sApproverID _
                        '    & "<br /><br />" _
                        '    & sFormList _
                        '    & "<br /><br />" _
                        '    & "<br /><br />" _
                        '    & "This email is generated automatically by SnAPS application. Please do not reply." & "'," _
                        '    & "@body_format = 'HTML' ;"
                        'Else
                        'sPreviusId = GetPreviousAppr()
                        sString = "EXEC msdb.dbo.sp_send_dbmail " _
                             & "@profile_name = '" & getParamValue("Email_Profile", sCompanyId) & "'," _
                             & "@recipients = '" & getEmailAddress(sLastApprovalID, sCompanyId) & "'," _
                             & "@subject = 'GER/CAR approval notice'," _
                             & "@body='" & sBody & sApproverID _
                             & "<br /><br />" _
                             & sFormList _
                             & "<br /><br />" _
                             & "Reject Reason : " & sRejectReason _
                             & "<br /><br />" _
                             & "<br /><br />" _
                             & "This email is generated automatically by SnAPS application. Please do not reply." & "'," _
                             & "@body_format = 'HTML' ;"
                        'End If

                        'SqlConn.Open()
                        Dim cmdSendEmail As SqlCommand = SqlConn.CreateCommand
                        cmdSendEmail.CommandText = sString
                        cmdSendEmail.ExecuteNonQuery()
                    End If
                    .Close()
                End With
            Catch ex As Exception
                'lblException.Text = ex.ToString
                Throw ex
            Finally
                If SqlConn.State = ConnectionState.Open Then SqlConn.Close()
            End Try
        End Sub



        Private Sub sendEmailToPreparer(ByVal sApproverID As String, ByVal sPreparerID As String, ByVal nInt As Integer, ByVal sCompanyId As String, ByVal sRejectReason As String)
            Dim sFormList As String = ""
            Dim sString As String
            Dim sBody As String = ""
            Dim sWhere As String = ""
            Dim sColumnApproveHeader As String = ""
            Dim sJoin As String = ""
            Dim dr_GER As SqlDataReader
            Dim SqlConn As SqlConnection
            SqlConn = New SqlConnection()
            SqlConn.ConnectionString =
                getConnectionString()

            Dim sqlCmdGER As SqlCommand = SqlConn.CreateCommand()
            Try
                SqlConn.Open()
                If nInt = 1 Then
                    sBody = "Your following GER/CAR have been approved by "
                    sColumnApproveHeader = "<th align=left>ApprovedBy</th>"
                    sqlCmdGER.CommandText = "Select A.FormNum, A.ApprovedBy, B.UserName as CurrentApproverName, " _
                                    & "A.NextApprover,C.UserName as NextApproverName, " _
                                    & "A.PreparedBy, D.UserName as PreparerName, E.Curr," _
                                    & "CAST(CONVERT(varchar(20), CAST(E.totalamount AS money), 1) AS varchar(20))AS TotalAmount, " _
                                    & "E.TransactionCode " _
                                    & "from fb_approve_reject_email A " _
                                    & "inner join fb_user_info B on A.ApprovedBy=B.UserID and a.companyid=b.companyid " _
                                    & "left join fb_user_info C on A.NextApprover=C.UserID and a.companyid=c.companyid " _
                                    & "inner join fb_user_info D on A.PreparedBy=D.UserID and a.companyid=d.companyid " _
                                    & "inner join fb_ger_info E on A.FormNum = E.FormNum and a.companyid=e.companyid " _
                                    & "where A.ApprovedBy='" & sApproverID & "' and A.PreparedBy='" & sPreparerID & "' and a.companyid='" & sCompanyId & "'"
                Else
                    sBody = "Your following GER/CAR have been denied by "
                    sColumnApproveHeader = "<th align=left>DeniedBy</th>"
                    sqlCmdGER.CommandText = "Select A.FormNum, A.DeniedBy, B.UserName as CurrentApproverName, A.NextApprover, " _
                                      & "case when C.UserName is null then ' ' else C.UserName end as NextApproverName, " _
                                      & "A.PreparedBy, D.UserName as PreparerName, E.Curr," _
                                      & "CAST(CONVERT(varchar(20), CAST(E.totalamount AS money), 1) AS varchar(20))AS TotalAmount, " _
                                      & "E.TransactionCode " _
                                      & "from fb_approve_reject_email A " _
                                      & "inner join fb_user_info B on A.DeniedBy=B.UserID and a.companyid=b.companyid " _
                                      & "left join fb_user_info C on A.NextApprover=C.UserID and a.companyid=c.companyid " _
                                      & "inner join fb_user_info D on A.PreparedBy=D.UserID and a.companyid=d.companyid " _
                                      & "inner join fb_ger_info E on A.FormNum = E.FormNum and a.companyid=e.companyid " _
                                      & "where A.DeniedBy='" & sApproverID & "' and A.PreparedBy='" & sPreparerID & "' and a.companyid='" & sCompanyId & "'"
                End If


                dr_GER = sqlCmdGER.ExecuteReader(CommandBehavior.Default)
                With dr_GER
                    If .HasRows Then
                        sFormList = "<table style=width: 800px><tr>" _
                              & "<th align=left>FormNum</th>" _
                              & "<th align=left>TrxnCode</th>" _
                              & "<th align=left>Curr</th>" _
                              & "<th align=right>Gross Amount </th>" _
                              & "<th align=left>Preparer</th>" & sColumnApproveHeader _
                              & "<th align=left>Next Approver</th>" _
                              & "</tr>"
                        While .Read
                            If nInt = 1 Then
                                sFormList = sFormList _
                                    & "<tr>" _
                                    & "<td align=left>" & .Item("FormNum").ToString & "</td>" _
                                    & "<td align=left>" & .Item("TransactionCode").ToString & "</td>" _
                                    & "<td align=left>" & .Item("Curr").ToString & "</td>" _
                                    & "<td align=right>" & .Item("TotalAmount").ToString & "</td>" _
                                    & "<td align=left>" & .Item("PreparedBy").ToString & ", " & .Item("PreparerName").ToString & "</td>" _
                                    & "<td align=left>" & .Item("ApprovedBy").ToString & ", " & .Item("CurrentApproverName").ToString & "</td>" _
                                    & "<td align=left>" & .Item("NextApprover").ToString & ", " & .Item("NextApproverName").ToString & "</td>" _
                                    & "</tr>"
                            Else
                                sFormList = sFormList _
                                    & "<tr>" _
                                    & "<td align=left>" & .Item("FormNum").ToString & "</td>" _
                                    & "<td align=left>" & .Item("TransactionCode").ToString & "</td>" _
                                    & "<td align=left>" & .Item("Curr").ToString & "</td>" _
                                    & "<td align=right>" & .Item("TotalAmount").ToString & "</td>" _
                                    & "<td align=left>" & .Item("PreparedBy").ToString & ", " & .Item("PreparerName").ToString & "</td>" _
                                    & "<td align=left>" & .Item("DeniedBy").ToString & ", " & .Item("CurrentApproverName").ToString & "</td>" _
                                    & "<td align=left>" & .Item("NextApprover").ToString & ", " & .Item("NextApproverName").ToString & "</td>" _
                                    & "</tr>"
                            End If
                        End While
                        sFormList = sFormList & "</table>"
                        'sPreparerID
                        dr_GER.Close()
                        If nInt = 1 Then
                            sString = "EXEC msdb.dbo.sp_send_dbmail " _
                            & "@profile_name = '" & getParamValue("Email_Profile", sCompanyId) & "'," _
                            & "@recipients = '" & getEmailAddress(sPreparerID, sCompanyId) & "'," _
                            & "@subject = 'GER/CAR approval notice'," _
                            & "@body='" & sBody & sApproverID _
                            & "<br /><br />" _
                            & sFormList _
                            & "<br /><br />" _
                            & "<br /><br />" _
                            & "This email is generated automatically by SnAPS application. Please do not reply." & "'," _
                            & "@body_format = 'HTML' ;"
                        Else
                            sString = "EXEC msdb.dbo.sp_send_dbmail " _
                            & "@profile_name = '" & getParamValue("Email_Profile", sCompanyId) & "'," _
                            & "@recipients = '" & getEmailAddress(sPreparerID, sCompanyId) & "'," _
                            & "@subject = 'GER/CAR approval notice'," _
                            & "@body='" & sBody & sApproverID _
                            & "<br /><br />" _
                            & sFormList _
                            & "<br /><br />" _
                            & "Reject Reason : " & sRejectReason _
                            & "<br /><br />" _
                            & "<br /><br />" _
                            & "This email is generated automatically by SnAPS application. Please do not reply." & "'," _
                            & "@body_format = 'HTML' ;"
                        End If
                        'SqlConn.Open()
                        Dim cmdSendEmail As SqlCommand = SqlConn.CreateCommand
                        cmdSendEmail.CommandText = sString
                        cmdSendEmail.ExecuteNonQuery()
                    End If
                    .Close()
                End With
            Catch ex As Exception
                'lblException.Text = ex.ToString
                Throw ex
            Finally
                If SqlConn.State = ConnectionState.Open Then SqlConn.Close()
            End Try
        End Sub

        Private Sub sendEmailNotificationToRejector(ByVal sApproverID As String, ByVal sCompanyId As String, ByVal sRejectReason As String)
            Dim sFormList As String = ""
            Dim sString As String
            Dim dr_ApproverEmail As SqlDataReader
            Dim SqlConn As SqlConnection
            SqlConn = New SqlConnection()
            SqlConn.ConnectionString =
                getConnectionString()

            Dim command As SqlCommand = SqlConn.CreateCommand()
            Try
                command.CommandText = "Select A.FormNum, A.DeniedBy, B.UserName as CurrentApproverName, " _
                                & "A.NextApprover,C.UserName as NextApproverName, " _
                                & "A.PreparedBy, D.UserName as PreparerName, E.Curr," _
                                & "CAST(CONVERT(varchar(20), CAST(E.totalamount AS money), 1) AS varchar(20))AS TotalAmount, " _
                                & "E.TransactionCode " _
                                & "from fb_approve_reject_email A " _
                                & "inner join fb_user_info B on A.DeniedBy=B.UserID and a.companyid=b.companyid " _
                                & "left join fb_user_info C on A.NextApprover=C.UserID and a.companyid=c.companyid " _
                                & "inner join fb_user_info D on A.PreparedBy=D.UserID and a.companyid=d.companyid " _
                                & "inner join fb_ger_info E on A.FormNum = E.FormNum and a.companyid=e.companyid " _
                                & "where A.DeniedBy='" & sApproverID & "' and A.CompanyID = '" & sCompanyId & "'"
                SqlConn.Open()
                Dim paramID As SqlParameter = New SqlParameter("@ApproverID", SqlDbType.Char)
                paramID.Value = sApproverID
                command.Parameters.Add(paramID)
                dr_ApproverEmail = command.ExecuteReader(CommandBehavior.Default)
                With dr_ApproverEmail
                    If .HasRows Then
                        sFormList = "<table style=width: 800px><tr>" _
                                  & "<th align=left>FormNum</th>" _
                                  & "<th align=left>TrxnCode</th>" _
                                  & "<th align=left>Curr</th>" _
                                  & "<th align=right>Gross Amount </th>" _
                                  & "<th align=left>Preparedby</th>" _
                                  & "<th>DeniedBy</th>" _
                                  & "</tr>"
                        While .Read
                            sFormList = sFormList _
                                    & "<tr>" _
                                    & "<td align=left>" & .Item("FormNum").ToString & "</td>" _
                                    & "<td align=left>" & .Item("TransactionCode").ToString & "</td>" _
                                    & "<td align=left>" & .Item("Curr").ToString & "</td>" _
                                    & "<td align=right>" & .Item("TotalAmount").ToString & "</td>" _
                                    & "<td align=left>" & .Item("PreparedBy").ToString & ", " & .Item("PreparerName").ToString & "</td>" _
                                    & "<td align=left>" & .Item("DeniedBy").ToString & ", " & .Item("CurrentApproverName").ToString & "</td>" _
                                    & "</tr>"
                        End While
                        dr_ApproverEmail.Close()
                        sFormList = sFormList & "</table>"
                        sString = "EXEC msdb.dbo.sp_send_dbmail " _
                    & "@profile_name = '" & getParamValue("Email_Profile", sCompanyId) & "'," _
                    & "@recipients = '" & getEmailAddress(sApproverID, sCompanyId) & "'," _
                    & "@subject = 'GER/CAR Rejection notice'," _
                    & "@body='You have just rejected following GER/CAR: " _
                    & "<br /><br />" _
                    & sFormList _
                    & "<br /><br />" _
                    & "Reject Reason : " & sRejectReason _
                    & "<br /><br />" _
                    & "<br /><br />" _
                    & "This email is generated automatically by SnAPS v1.1. Please do not reply." & "'," _
                    & "@body_format = 'HTML' ;"
                        Dim cmdSendEmail As SqlCommand = SqlConn.CreateCommand
                        cmdSendEmail.CommandText = sString
                        cmdSendEmail.ExecuteNonQuery()
                    End If
                    .Close()
                End With
            Catch ex As Exception
                'lblException.Text = ex.ToString
                Throw ex
            Finally
                If SqlConn.State = ConnectionState.Open Then SqlConn.Close()
            End Try

        End Sub

        Private Sub sendEmailNotificationToApprover(ByVal sApproverID As String, ByVal sCompanyId As String)
            Dim sFormList As String = ""
            Dim sString As String = ""
            Dim dr_ApproverEmail As SqlDataReader
            Dim SqlConn As SqlConnection
            SqlConn = New SqlConnection()
            SqlConn.ConnectionString =
                getConnectionString()

            Dim command As SqlCommand = SqlConn.CreateCommand()
            Try
                command.CommandText = "Select A.FormNum, A.ApprovedBy, B.UserName as CurrentApproverName, " _
                                & "A.NextApprover,C.UserName as NextApproverName, " _
                                & "A.PreparedBy, D.UserName as PreparerName, E.Curr," _
                                & "CAST(CONVERT(varchar(20), CAST(E.totalamount AS money), 1) AS varchar(20))AS TotalAmount, " _
                                & "E.TransactionCode " _
                                & "from fb_approve_reject_email A " _
                                & "inner join fb_user_info B on A.ApprovedBy=B.UserID and a.companyid=b.companyid " _
                                & "left join fb_user_info C on A.NextApprover=C.UserID and a.companyid=c.companyid " _
                                & "inner join fb_user_info D on A.PreparedBy=D.UserID and a.companyid=d.companyid " _
                                & "inner join fb_ger_info E on A.FormNum = E.FormNum and a.companyid=e.companyid " _
                                & "where A.ApprovedBy='" & sApproverID & "' and a.companyid='" & sCompanyId & "'"
                SqlConn.Open()
                Dim paramID As SqlParameter = New SqlParameter("@ApproverID", SqlDbType.Char)
                paramID.Value = sApproverID
                command.Parameters.Add(paramID)
                dr_ApproverEmail = command.ExecuteReader(CommandBehavior.Default)
                With dr_ApproverEmail
                    If .HasRows Then
                        sFormList = "<table style=width: 800px><tr>" _
                                  & "<th align=left>FormNum</th>" _
                                  & "<th align=left>TrxnCode</th>" _
                                  & "<th align=left>Curr</th>" _
                                  & "<th align=right>Gross Amount </th>" _
                                  & "<th align=left>Preparedby</th>" _
                                  & "<th align=left>ApprovedBy</th>" _
                                  & "<th align=left>Next Approver</th>" _
                                  & "</tr>"
                        While .Read
                            sFormList = sFormList _
                                    & "<tr>" _
                                    & "<td align=left>" & .Item("FormNum").ToString & "</td>" _
                                    & "<td align=left>" & .Item("TransactionCode").ToString & "</td>" _
                                    & "<td align=left>" & .Item("Curr").ToString & "</td>" _
                                    & "<td align=right>" & .Item("TotalAmount").ToString & "</td>" _
                                    & "<td align=left>" & .Item("PreparedBy").ToString & ", " & .Item("PreparerName").ToString & "</td>" _
                                    & "<td align=left>" & .Item("ApprovedBy").ToString & ", " & .Item("CurrentApproverName").ToString & "</td>" _
                                    & "<td align=left>" & .Item("NextApprover").ToString & ", " & .Item("NextApproverName").ToString & "</td>" _
                                    & "</tr>"
                        End While
                        sFormList = sFormList & "</table>"
                        '====>> for SLFI is & "@profile_name = 'fobu'," _ <<====
                        dr_ApproverEmail.Close()

                        sString = "EXEC msdb.dbo.sp_send_dbmail " _
                    & "@profile_name = '" & getParamValue("Email_Profile", sCompanyId) & "'," _
                    & "@recipients = '" & getEmailAddress(sApproverID, sCompanyId) & "'," _
                    & "@subject = 'GER/CAR approval notice'," _
                    & "@body='You have just approved following GER/CAR: " _
                    & "<br /><br />" _
                    & sFormList _
                    & "<br /><br />" _
                    & "<br /><br />" _
                    & "This email is generated automatically by SnAPS application. Please do not reply." & "'," _
                    & "@body_format = 'HTML' ;"
                        Dim cmdSendEmail As SqlCommand = SqlConn.CreateCommand
                        cmdSendEmail.CommandText = sString
                        cmdSendEmail.ExecuteNonQuery()
                    End If
                    .Close()
                End With
            Catch ex As Exception
                'lblException.Text = ex.ToString
                Throw ex
            Finally
                If SqlConn.State = ConnectionState.Open Then SqlConn.Close()
            End Try

        End Sub

        Private Function AdcRefundManyPolicy(ByVal sCode As String, ByVal sFrmNumToCheck As String) As Boolean
            Dim bBol As Boolean
            Dim dr_ADC As SqlDataReader
            Dim SqlConn As SqlConnection
            SqlConn = New SqlConnection()
            SqlConn.ConnectionString =
                getConnectionString()
            Dim command As SqlCommand = SqlConn.CreateCommand()
            Try
                command.CommandText = "Select TrxnCode from fb_ADC_Transaction where TrxnCode=@Code"
                SqlConn.Open()
                Dim paramID As SqlParameter = New SqlParameter("@Code", SqlDbType.Char)
                paramID.Value = sCode
                command.Parameters.Add(paramID)
                dr_ADC = command.ExecuteReader(CommandBehavior.SingleRow)
                With dr_ADC
                    If .HasRows Then
                        If IsManyPolicy(sFrmNumToCheck) Then
                            bBol = True
                        End If
                    End If
                    .Close()
                End With
            Catch ex As Exception
                'lblException.Text = ex.ToString
                Throw ex
            Finally
                If SqlConn.State = ConnectionState.Open Then SqlConn.Close()
            End Try

            Return bBol
        End Function

        Private Function IsManyPolicy(ByVal sFrmNumToCheck As String) As Boolean
            Dim bBol As Boolean
            Dim dr_ADC As SqlDataReader
            Dim SqlConn As SqlConnection
            SqlConn = New SqlConnection()
            SqlConn.ConnectionString =
                getConnectionString()
            Dim command As SqlCommand = SqlConn.CreateCommand()
            Try
                command.CommandText = "Select * from fb_Refund_Many_Policy where FormNum=@sFrmNumToCheck"
                SqlConn.Open()
                Dim paramID As SqlParameter = New SqlParameter("@sFrmNumToCheck", SqlDbType.Char)
                paramID.Value = sFrmNumToCheck
                command.Parameters.Add(paramID)
                dr_ADC = command.ExecuteReader(CommandBehavior.SingleRow)
                With dr_ADC
                    If .HasRows Then
                        bBol = True
                    End If
                    .Close()
                End With
            Catch ex As Exception
                'lblException.Text = ex.ToString
                Throw ex
            Finally
                If SqlConn.State = ConnectionState.Open Then SqlConn.Close()
            End Try
            Return bBol
        End Function


        Public Shared Sub DeleteAdvanceAndSettlement_info(ByVal sFormNum As String)
            Dim conn As New SqlConnection
            With conn
                .ConnectionString = getConnectionString()
                .Open()
            End With
            Dim cmd As SqlCommand = New SqlCommand("fb_DeleteAdvanceAndSettlement_info", conn)
            Dim dDate As Date = Now()
            Dim nResult As Integer = 0
            Try
                With cmd
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.Clear()
                    .Parameters.AddWithValue("@AdvanceFormNum", sFormNum)
                    nResult = .ExecuteNonQuery
                End With
            Catch ex As Exception
            Finally
                conn.Close()
            End Try
        End Sub

        Public Shared Function InsertRejectReason(ByVal sFormNum As String,
                                          ByVal sDeptID As String,
                                          ByVal sReason As String,
                                          ByVal sRejectBy As String,
                                          ByVal sRejectType As String, ByVal sCompanyId As String) As Integer
            Dim conn As New SqlConnection
            With conn
                .ConnectionString = getConnectionString()
                .Open()
            End With
            Dim cmd As SqlCommand = New SqlCommand("Insert_GER_Reject_reason", conn)
            Dim dDate As Date = Now()
            Dim nResult As Integer = 0
            Try
                With cmd
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.Clear()
                    .Parameters.AddWithValue("@companyid", sCompanyId)
                    .Parameters.AddWithValue("@FormNum", sFormNum)
                    .Parameters.AddWithValue("@Dept", sDeptID)
                    .Parameters.AddWithValue("@RejectDt", dDate)
                    .Parameters.AddWithValue("@RejectReason", sReason)
                    .Parameters.AddWithValue("@RejectBy", sRejectBy)
                    .Parameters.AddWithValue("@RejectType", sRejectType)
                    nResult = .ExecuteNonQuery
                End With
            Catch ex As Exception
                Throw ex
            Finally
                conn.Close()
            End Try
            Return nResult
        End Function
#End Region


#Region "Merge Report"
        Public Sub MergeReports(sCompanyId As String, sVoucherNumFinal As String, sVoucherCdFinal As String, sTempVoucher As String)
            'Dim strInputFile1 As Object
            'Dim strInputFile2 As String 'Assume full path
            'Dim strOutputFile As String 'Assume full path
            'Dim strPDFTK As String 'Assume full path to PDFTK
            Dim strQ As String 'Holds double quotes to enclose full paths potentially with spaces
            'Dim strPageRange As String
            'Dim intMaxDelayInSeconds As Short
            Dim sFileName2, sFileName0, sFileName1, sFileName3 As Object
            Dim sFileNameOutDir As String
            Dim sFileNameOutDir2 As String
            Dim sFileNameOut As String
            Dim sFileNameOut2 As String
            Dim skey As String = ""
            Dim skey2 As String = ""


            strQ = """"

            Dim currentDate As DateTime = DateTime.Now

            sFileNameOutDir = getParamInfo(sCompanyId, "DestinationMergeFile") + "\" + currentDate.Year.ToString() + "\(" + currentDate.Month.ToString().PadLeft(2, "0") + ") " + Format(currentDate, "MMMM").ToUpper() + "\" + Trim(sVoucherCdFinal) + "\" + Trim(Replace(sVoucherNumFinal, "/", "-")) + "\"
            If Not Directory.Exists(getParamInfo(sCompanyId, "DestinationMergeFile") + "\" + currentDate.Year.ToString() + "\") Then
                Directory.CreateDirectory(getParamInfo(sCompanyId, "DestinationMergeFile") + "\" + currentDate.Year.ToString() + "\")
            End If
            If Not Directory.Exists(getParamInfo(sCompanyId, "DestinationMergeFile") + "\" + currentDate.Year.ToString() + "\(" + currentDate.Month.ToString().PadLeft(2, "0") + ") " + Format(currentDate, "MMMM").ToUpper() + "\") Then
                Directory.CreateDirectory(getParamInfo(sCompanyId, "DestinationMergeFile") + "\" + currentDate.Year.ToString() + "\(" + currentDate.Month.ToString().PadLeft(2, "0") + ") " + Format(currentDate, "MMMM").ToUpper() + "\")
            End If
            If Not Directory.Exists(getParamInfo(sCompanyId, "DestinationMergeFile") + "\" + currentDate.Year.ToString() + "\(" + currentDate.Month.ToString().PadLeft(2, "0") + ") " + Format(currentDate, "MMMM").ToUpper() + "\" + Trim(sVoucherCdFinal) + "\") Then
                Directory.CreateDirectory(getParamInfo(sCompanyId, "DestinationMergeFile") + "\" + currentDate.Year.ToString() + "\(" + currentDate.Month.ToString().PadLeft(2, "0") + ") " + Format(currentDate, "MMMM").ToUpper() + "\" + Trim(sVoucherCdFinal) + "\")
            End If
            If Not Directory.Exists(getParamInfo(sCompanyId, "DestinationMergeFile") + "\" + currentDate.Year.ToString() + "\(" + currentDate.Month.ToString().PadLeft(2, "0") + ") " + Format(currentDate, "MMMM").ToUpper() + "\" + Trim(sVoucherCdFinal) + "\" + Trim(Replace(sVoucherNumFinal, "/", "-")) + "\") Then
                Directory.CreateDirectory(getParamInfo(sCompanyId, "DestinationMergeFile") + "\" + currentDate.Year.ToString() + "\(" + currentDate.Month.ToString().PadLeft(2, "0") + ") " + Format(currentDate, "MMMM").ToUpper() + "\" + Trim(sVoucherCdFinal) + "\" + Trim(Replace(sVoucherNumFinal, "/", "-")) + "\")
            End If

            sFileNameOutDir2 = getParamInfo(sCompanyId, "FileMergedLocation") + "\Letter_TMP\" + sTempVoucher + "\"
            If Not Directory.Exists(getParamInfo(sCompanyId, "FileMergedLocation") + "\Letter_TMP\" + sTempVoucher + "\") Then
                Directory.CreateDirectory(getParamInfo(sCompanyId, "FileMergedLocation") + "\Letter_TMP\" + sTempVoucher + "\")
            End If

            sFileNameOut = sFileNameOutDir + Trim(Replace(sVoucherNumFinal, "/", "-")) + ".PDF"
            sFileNameOut2 = sFileNameOutDir2 + Trim(sTempVoucher) + "-TMP.PDF"

            sFileName1 = getParamInfo(sCompanyId, "FileMergedLocation") + "\Letter_BankDataTransfer\" + sTempVoucher + "\Letter_BankDataTransfer.PDF"
            sFileName2 = getParamInfo(sCompanyId, "FileMergedLocation") + "\Letter_ApprovalReport\" + sTempVoucher + "\Letter_ApprovalReport.PDF"

            skey = sFileName1 + " " + sFileName2
            skey2 = skey
            Dim lAttachment = New List(Of GERApproval)()
            lAttachment = GetListGERApprovalMergerAttachment(sVoucherNumFinal, sCompanyId).listGERApproval
            For Each listGERApproval As GERApproval In GetListGERApprovalMerger(sVoucherNumFinal, sCompanyId).listGERApproval
                sFileName3 = ""
                sFileName0 = ""
                'sFileName3 = getParamInfo(sCompanyId, "FileMergedLocation") + "\Letter\" + sTempVoucher + "\" + listGERApproval.FormNum + "_Letter.PDF"
                If listGERApproval.IsTax = "1" Then
                    sFileName0 = getParamInfo(sCompanyId, "FileMergedLocation") + "\Letter\" + listGERApproval.FormNum + "\Letter.PDF"
                    skey = skey + " " + sFileName0
                End If

                If lAttachment.Where(Function(a) a.FormNum.Equals(listGERApproval.FormNum)).Count() > 0 Then
                    For Each list As GERApproval In lAttachment.Where(Function(a) a.FormNum.Equals(listGERApproval.FormNum))
                        skey = skey + " " + list.FileLocation
                    Next
                End If
            Next

            'skey = skey + " CAT OUTPUT " + sFileNameOut + " DONT_ASK"
            GFile(skey2, sFileNameOut)
            GFile(skey, sFileNameOut)
            MergeFile(skey2, sFileNameOut2)
            MergeFile(skey, sFileNameOut)

        End Sub

        Public Sub MergeFile(skey1 As String, skey2 As String)
            Dim odal As New SQLAccess("core")
            Try
                ores = New cResult
                'Validation
                'ores.InvalidMessage = IsValid(odal, pparam)

                'Run Tasks
                odal.BeginTransactions()
                odal.ExecuteCommandSP("usp_MergeFile",
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(skey1)),
                        odal.CreateParameter("@skey2", SqlDbType.VarChar, comlib.GetText(skey2)))
                odal.CommitTransactions()
            Catch ex As Exception
                If Not IsNothing(odal) Then odal.RollBackTransactions()
                ores = SetError(ex)
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
        End Sub

        Public Function GetListGERApprovalMerger(sTempVoucher As String, sCompanyId As String) As cGER
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oGERAppr As cGER = Nothing
            oGERAppr = New cGER
            oGERAppr.listGERApproval = New List(Of GERApproval)()

            Dim oGERApproval As GERApproval

            Try
                rdr = odal.ExecuteDataReader("usp_ListMergeGERApproval", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(sCompanyId)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(sTempVoucher)))
                While rdr.Read
                    oGERApproval = New GERApproval
                    oGERApproval.FormNum = comlib.GetText(rdr.Item("FormNum"))
                    oGERApproval.IsTax = comlib.GetText(rdr.Item("isTax"))
                    oGERAppr.listGERApproval.Add(oGERApproval)
                End While

            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oGERAppr
        End Function

        Public Function GetListGERApprovalMergerAttachment(sTempVoucher As String, sCompanyId As String) As cGER
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader

            Dim oGERAppr As cGER = Nothing
            oGERAppr = New cGER
            oGERAppr.listGERApproval = New List(Of GERApproval)()

            Dim oGERApproval As GERApproval

            Try

                rdr = odal.ExecuteDataReader("usp_ListMergeGERApprovalAttachment", CommandType.StoredProcedure,
                        odal.CreateParameter("@companyid", SqlDbType.VarChar, comlib.GetText(sCompanyId)),
                        odal.CreateParameter("@skey1", SqlDbType.VarChar, comlib.GetText(sTempVoucher)))
                While rdr.Read
                    oGERApproval = New GERApproval
                    oGERApproval.FormNum = comlib.GetText(rdr.Item("FormNum"))
                    oGERApproval.FileLocation = comlib.GetText(rdr.Item("FileLocation"))
                    oGERAppr.listGERApproval.Add(oGERApproval)
                End While



            Catch ex As Exception
                Throw ex
            Finally
                rdr = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return oGERAppr
        End Function

        Private Function getMLISTByBatchNum(ByVal sBatchNum As String) As String
            Dim sReturn As String
            Dim sHoldDQ As String
            Dim rsAtt As New ADODB.Recordset

            sHoldDQ = """"
            rsAtt = deFB5.cn1.Execute("Select a.TMPFileLocation from SnAPS_Voucher_TMP a " & "Where a.TMPNum='" & sBatchNum & "'")
            With rsAtt
                sReturn = ""
                If Not .BOF Then .MoveFirst()
                Do While Not .EOF()
                    If FileExist(Trim(.Fields("TMPFileLocation").Value)) Then
                        sReturn = sReturn & " " & sHoldDQ & (.Fields("TMPFileLocation")).Value & sHoldDQ
                    Else
                        'SendMess("Voucher file is not found.")
                    End If
                    .MoveNext()
                Loop
                .Close()
            End With
            'UPGRADE_NOTE: Object rsAtt may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
            rsAtt = Nothing
            getMLISTByBatchNum = sReturn
        End Function

        'Private Function getAttachmentByFormNum(ByVal sVoucherNumTemp As String) As String
        '    Dim sReturn As String
        '    Dim sHoldDQ As String
        '    Dim rsAtt As New ADODB.Recordset

        '    sHoldDQ = """"
        '    rsAtt = deFB5.cn1.Execute("Select b.FileLocation from fb_Payment_Info a " & "inner join SnAPS_GER_File_Attachment_Info b on a.FormNum=b.FormNum " & "Where a.VoucherNum='" & sVoucherNumTemp & "' order by b.FormNum,b.AttachmentType,b.SeqNum")
        '    Dim sTempFilename2 As String
        '    Dim l() As String
        '    With rsAtt
        '        sReturn = ""
        '        If Not .BOF Then .MoveFirst()
        '        Do While Not .EOF()
        '            If FileExist(.Fields("FileLocation").Value) Then
        '                l = Split(.Fields("FileLocation").Value, "\")
        '                sTempFilename2 = MappedDrive & "\" & l(UBound(l))

        '                sReturn = sReturn & " " & sHoldDQ & sTempFilename2 & sHoldDQ
        '                sTempFilename2 = ""
        '            Else
        '                SendMess("This file attachment is not found. [" & (.Fields("FileLocation")).Value & "]")
        '            End If
        '            .MoveNext()
        '        Loop
        '        .Close()
        '    End With
        '    'UPGRADE_NOTE: Object rsAtt may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
        '    rsAtt = Nothing
        '    getAttachmentByFormNum = sReturn
        'End Function

        Private Declare Function OpenProcess Lib "kernel32" (ByVal dwDesiredAccess As Integer, ByVal bInheritHandle As Integer, ByVal dwProcessId As Integer) As Integer
        Private Declare Function WaitForSingleObject Lib "kernel32" (ByVal hHandle As Integer, ByVal dwMilliseconds As Integer) As Integer
        Private Declare Function CloseHandle Lib "kernel32" (ByVal hObject As Integer) As Integer

        Public Sub ShellAndWait(ByVal program_name As String, Optional ByVal window_style As AppWinStyle = AppWinStyle.NormalFocus, Optional ByVal max_wait_seconds As Integer = 0)
            Dim lngProcessId As Integer
            Dim lngProcessHandle As Integer
            Dim datStartTime As Date
            Dim lngCursor As Integer
            Const WAIT_TIMEOUT As Integer = &H102
            Const SYNCHRONIZE As Integer = &H100000
            Const INFINITE As Integer = &HFFFFFFFF

            'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
            'lngCursor = Convert.ToInt32(System.Windows.Forms.Cursor.Current)
            'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
            ' Start the program.
            'On Error GoTo ShellError
            lngProcessId = Shell(program_name, AppWinStyle.Hide)
            'On Error GoTo 0

            System.Windows.Forms.Application.DoEvents()

            ' Wait for the program to finish.
            ' Get the process handle.
            lngProcessHandle = OpenProcess(SYNCHRONIZE, 0, lngProcessId)
            If lngProcessHandle <> 0 Then
                datStartTime = Now
                Do
                    If WaitForSingleObject(lngProcessHandle, 250) <> WAIT_TIMEOUT Then
                        Exit Do
                    End If
                    System.Windows.Forms.Application.DoEvents()
                    If max_wait_seconds > 0 Then
                        'UPGRADE_WARNING: DateDiff behavior may be different. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6B38EC3F-686D-4B2E-B5A5-9E8E7A762E32"'
                        If DateDiff(Microsoft.VisualBasic.DateInterval.Second, datStartTime, Now) > max_wait_seconds Then Exit Do
                    End If
                Loop
                CloseHandle(lngProcessHandle)
            End If
            'UPGRADE_ISSUE: Screen property Screen.MousePointer does not support custom mousepointers. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="45116EAB-7060-405E-8ABE-9DBB40DC2E86"'
            'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
            'System.Windows.Forms.Cursor.Current =  lngCursor

            Exit Sub

ShellError:
        End Sub
#End Region

        Public Function Report() As String
            Dim odal As New SQLAccess("core")
            Dim rdr As IDataReader
            Dim str As String

            Dim oGERAppr As cGER = Nothing
            oGERAppr = New cGER
            oGERAppr.listrptRepor = New List(Of rptReport)()

            Dim oGERApproval As rptReport

            Try
                rdr = odal.ExecuteDataReader("usp_GenListReport", CommandType.StoredProcedure)
                While rdr.Read
                    oGERApproval = New rptReport
                    oGERApproval.CompanyId = comlib.GetText(rdr.Item("Companyid"))
                    oGERApproval.TMPNum = comlib.GetText(rdr.Item("TMPNum"))
                    oGERApproval.VoucherNum = comlib.GetText(rdr.Item("vouchernum"))
                    oGERApproval.CodeVoucher = comlib.GetText(rdr.Item("codevoucher"))
                    oGERApproval.PaidDate = rdr.Item("TransferedDt")
                    oGERApproval.Formnum = rdr.Item("formnum1")
                    oGERAppr.listrptRepor.Add(oGERApproval)
                End While

                For Each x As rptReport In oGERAppr.listrptRepor
                    Dim prm As cParams = New cParams()
                    prm.companyid = x.CompanyId
                    prm.skey1 = x.VoucherNum
                    prm.skey2 = x.TMPNum
                    prm.userid = "FA92"
                    GenReportApprovalReport(prm)
                    GenReportBankDataTransfer(prm)
                    MergeReports2(x.CompanyId, x.VoucherNum, x.CodeVoucher, x.TMPNum, x.PaidDate)
                    update(x.Formnum, 1, "")
                Next
                str = "Sukses"
            Catch ex As Exception
                str = ex.Message.ToString()
            Finally
                rdr = Nothing
                odal.CloseAllConnection()
                odal = Nothing
            End Try
            Return str
        End Function

        Protected Sub GenReportApprovalReport(params As cParams)
            Dim res As String
            Dim paramsRPT As cParams = New cParams()

            paramsRPT.companyid = params.companyid
            paramsRPT.skey1 = "ApprovalReport_A"
            paramsRPT.skey2 = "skey1=" + params.skey1 + "&Companyid=" + params.companyid + "&skey2=" + params.skey2
            paramsRPT.skey3 = params.skey2
            paramsRPT.userid = params.userid

            res = GenerateReport(paramsRPT).Message
        End Sub

        Protected Sub GenReportBankDataTransfer(params As cParams)
            Dim res As String
            Dim paramsRPT As cParams = New cParams()

            paramsRPT.companyid = params.companyid
            paramsRPT.skey1 = "BankDataTransfer_A"
            paramsRPT.skey2 = "skey1=" + params.skey1 + "&Companyid=" + params.companyid + "&skey2=" + params.skey2
            paramsRPT.skey3 = params.skey2
            paramsRPT.userid = params.userid

            res = GenerateReport(paramsRPT).Message
        End Sub

        Public Sub MergeReports2(sCompanyId As String, sVoucherNumFinal As String, sVoucherCdFinal As String, sTempVoucher As String, sPaidDate As DateTime)
            'Dim strInputFile1 As Object
            'Dim strInputFile2 As String 'Assume full path
            'Dim strOutputFile As String 'Assume full path
            'Dim strPDFTK As String 'Assume full path to PDFTK
            Dim strQ As String 'Holds double quotes to enclose full paths potentially with spaces
            'Dim strPageRange As String
            'Dim intMaxDelayInSeconds As Short
            Dim sFileName2, sFileName0, sFileName1, sFileName3 As Object
            Dim sFileNameOutDir As String
            Dim sFileNameOutDir2 As String
            Dim sFileNameOut As String
            Dim sFileNameOut2 As String
            Dim skey As String = ""
            Dim skey2 As String = ""


            strQ = """"

            Dim currentDate As DateTime = sPaidDate

            sFileNameOutDir = getParamInfo(sCompanyId, "DestinationMergeFile") + "\" + currentDate.Year.ToString() + "\(" + currentDate.Month.ToString().PadLeft(2, "0") + ") " + Format(currentDate, "MMMM").ToUpper() + "\" + Trim(sVoucherCdFinal) + "\" + Trim(Replace(sVoucherNumFinal, "/", "-")) + "\"
            If Not Directory.Exists(getParamInfo(sCompanyId, "DestinationMergeFile") + "\" + currentDate.Year.ToString() + "\") Then
                Directory.CreateDirectory(getParamInfo(sCompanyId, "DestinationMergeFile") + "\" + currentDate.Year.ToString() + "\")
            End If
            If Not Directory.Exists(getParamInfo(sCompanyId, "DestinationMergeFile") + "\" + currentDate.Year.ToString() + "\(" + currentDate.Month.ToString().PadLeft(2, "0") + ") " + Format(currentDate, "MMMM").ToUpper() + "\") Then
                Directory.CreateDirectory(getParamInfo(sCompanyId, "DestinationMergeFile") + "\" + currentDate.Year.ToString() + "\(" + currentDate.Month.ToString().PadLeft(2, "0") + ") " + Format(currentDate, "MMMM").ToUpper() + "\")
            End If
            If Not Directory.Exists(getParamInfo(sCompanyId, "DestinationMergeFile") + "\" + currentDate.Year.ToString() + "\(" + currentDate.Month.ToString().PadLeft(2, "0") + ") " + Format(currentDate, "MMMM").ToUpper() + "\" + Trim(sVoucherCdFinal) + "\") Then
                Directory.CreateDirectory(getParamInfo(sCompanyId, "DestinationMergeFile") + "\" + currentDate.Year.ToString() + "\(" + currentDate.Month.ToString().PadLeft(2, "0") + ") " + Format(currentDate, "MMMM").ToUpper() + "\" + Trim(sVoucherCdFinal) + "\")
            End If
            If Not Directory.Exists(getParamInfo(sCompanyId, "DestinationMergeFile") + "\" + currentDate.Year.ToString() + "\(" + currentDate.Month.ToString().PadLeft(2, "0") + ") " + Format(currentDate, "MMMM").ToUpper() + "\" + Trim(sVoucherCdFinal) + "\" + Trim(Replace(sVoucherNumFinal, "/", "-")) + "\") Then
                Directory.CreateDirectory(getParamInfo(sCompanyId, "DestinationMergeFile") + "\" + currentDate.Year.ToString() + "\(" + currentDate.Month.ToString().PadLeft(2, "0") + ") " + Format(currentDate, "MMMM").ToUpper() + "\" + Trim(sVoucherCdFinal) + "\" + Trim(Replace(sVoucherNumFinal, "/", "-")) + "\")
            End If

            sFileNameOutDir2 = getParamInfo(sCompanyId, "FileMergedLocation") + "\Letter_TMP\" + sTempVoucher + "\"
            If Not Directory.Exists(getParamInfo(sCompanyId, "FileMergedLocation") + "\Letter_TMP\" + sTempVoucher + "\") Then
                Directory.CreateDirectory(getParamInfo(sCompanyId, "FileMergedLocation") + "\Letter_TMP\" + sTempVoucher + "\")
            End If

            sFileNameOut = sFileNameOutDir + Trim(Replace(sVoucherNumFinal, "/", "-")) + ".PDF"
            sFileNameOut2 = sFileNameOutDir2 + Trim(sTempVoucher) + "-TMP.PDF"

            sFileName1 = getParamInfo(sCompanyId, "FileMergedLocation") + "\Letter_BankDataTransfer\" + sTempVoucher + "\Letter_BankDataTransfer.PDF"
            sFileName2 = getParamInfo(sCompanyId, "FileMergedLocation") + "\Letter_ApprovalReport\" + sTempVoucher + "\Letter_ApprovalReport.PDF"

            skey = sFileName1 + " " + sFileName2
            skey2 = skey
            Dim lAttachment = New List(Of GERApproval)()
            lAttachment = GetListGERApprovalMergerAttachment(sVoucherNumFinal, sCompanyId).listGERApproval
            For Each listGERApproval As GERApproval In GetListGERApprovalMerger(sVoucherNumFinal, sCompanyId).listGERApproval
                sFileName3 = ""
                sFileName0 = ""
                'sFileName3 = getParamInfo(sCompanyId, "FileMergedLocation") + "\Letter\" + sTempVoucher + "\" + listGERApproval.FormNum + "_Letter.PDF"
                If listGERApproval.IsTax = "1" Then
                    sFileName0 = getParamInfo(sCompanyId, "FileMergedLocation") + "\Letter\" + listGERApproval.FormNum + "\Letter.PDF"
                    skey = skey + " " + sFileName0
                End If

                If lAttachment.Where(Function(a) a.FormNum.Equals(listGERApproval.FormNum)).Count() > 0 Then
                    For Each list As GERApproval In lAttachment.Where(Function(a) a.FormNum.Equals(listGERApproval.FormNum))
                        skey = skey + " " + list.FileLocation
                    Next
                End If
            Next

            'skey = skey + " CAT OUTPUT " + sFileNameOut + " DONT_ASK"
            GFile(skey2, sFileNameOut2)
            GFile(skey, sFileNameOut)

        End Sub

        Public Sub update(formnum As String, comp As Int16, message As String)

            Dim odal As New SQLAccess("core")

            Try
                odal.BeginTransactions()
                odal.ExecuteCommandSP("usp_updatestatusMF",
                odal.CreateParameter("@isComplate", SqlDbType.Int, comp),
                odal.CreateParameter("@formnum", SqlDbType.VarChar, comlib.GetText(formnum)),
                odal.CreateParameter("@message", SqlDbType.VarChar, comlib.GetText(message)))

                odal.CommitTransactions()
            Catch ex As Exception
                Throw ex
            Finally
                odal.CloseAllConnection()
                odal = Nothing
            End Try
        End Sub

        Protected Sub GFile(skey1 As String, skey2 As String)
            Try
                Dim str As String = "C:\Temp\PDFTK\pdftk.exe " + skey1 + " CAT OUTPUT """ + skey2 + """ DONT_ASK"
                ShellAndWait(str, AppWinStyle.Hide)

            Catch ex As Exception
                Throw ex
            End Try
        End Sub

    End Class

End Namespace
