-- ==========================================================  
-- Author  : Ronald Wilbert  
-- Create date : 09/25/2012  
-- Work Unit : 01  
-- Description : Initial Version  
--      This sp will do:   
--      - generic get records from database  
--     as parameters parsed  
-- ======================================================  
-->ENHANCEMENT  
-- ======================================================  
-- Author  :   
-- Create date :   
-- Work Unit :   
-- Description :  
/*  
  
 exec usp_get_records   
  @CompanyID='SLF',  
  @table='Combo_transaction_Code'  
  
*/  
  
-- ======================================================  
  
CREATE PROCEDURE [dbo].[usp_get_records]  
 @CompanyID varchar(20)='',  
 @DeptID  varchar(20)='',  
 @table  varchar(500),  
 @nkey1  int = 0,  
 @nkey2  int = 0,  
 @nkey3  int = 0,  
 @nkey4  int = 0,  
 @nkey5  int = 0,  
 @ikey1  int = 0,      
 @ikey2  int = 0,  
 @ikey3  int = 0,  
 @ikey4  int = 0,  
 @ikey5  int = 0,  
 @skey1  varchar(50) = '',  
 @skey2  varchar(5000) = '',  
 @skey3  varchar(50) = '',  
 @skey4  varchar(50) = '',  
 @skey5  varchar(50) = '',  
 @skey6  varchar(50) = '',  
 @skey7  varchar(50) = '',  
 @skey8  varchar(50) = '',  
 @skey9  varchar(50) = '',  
 @skey10  varchar(50) = '',  
 @skey11  varchar(50) = '',  
 @skey12  varchar(50) = '',  
 @skey13  varchar(50) = '',  
 @dkey1  datetime = null,  
 @dkey2  datetime = null,  
 @dkey3  datetime = null,  
 @dkey4  datetime = null,  
 @dkey5  datetime = null,  
 @bkey1  bit = null,  
 @bkey2  bit = null,  
 @bkey3  bit = null,  
 @bkey4  bit = null,  
 @bkey5  bit = null,  
 @userid  varchar(15)='',  
 @pageNum INT=1,  
 @pageno  int=1,  
 @pagesize int=10  
   
   
AS  
BEGIN  
 SET NOCOUNT ON;  
 DECLARE @stmt   VARCHAR(max)  
 DECLARE @stmt2   VARCHAR(max)  
 DECLARE @stmt3   VARCHAR(max)  
 DECLARE @TotalRows  INT  
 DECLARE @PathExtract varchar(max)  
 declare @FieldFilter varchar(100)  
 declare @Statement4 varchar(max)  
 declare @Roles varchar(max)  
 DECLARE @TotalRows2  INT  
  
 insert into test values (getdate(),@table,'@table')  
 insert into test values (getdate(),@skey1,'@skey1')  
 insert into test values (getdate(),@skey2,'@skey2')  
 insert into test values (getdate(),@skey3,'@skey3')  
  
 IF @nkey1 = 0 OR @nkey2 = 0  
 BEGIN  
  SET @NKEY1 =1   
  SET @NKEY2 = 15  
 END  
   
 if @skey11='All Data'  
  set @skey11=''  
  
 -----------  
    
    IF @table = 'Combo_transaction_Code'  
     BEGIN  
  
  insert into test values (getdate(),'masuk 1','')  
  insert into test values (getdate(),@skey1,@skey1)  
  
    IF @skey2='CAR_COMBO'  
    BEGIN  
       
     select  
     A.TransactionTypeCode as Codeid,   
     B.Description as DescriptionID, B.Category as Others1,   
     case when B.IsTaxable = 0 then 'NO' ELSE 'YES' END as Others2,  
     case when b.isbulk=0 then 'NO' ELSE 'YES' END as Others3,  
     '' as Others4,  
     '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
     from fb_Dept_TransactionType A   
     Inner join fb_TransactionType B   
     on A.TransactionTypeCode=B.Code and a.companyid=b.companyid  
     Where A.TransactionTypeCode in(select advCode from fb_advance_code)   
     And A.DeptCode =@skey1 and a.companyid=@companyid  
     Order by A.TransactionTypeCode  
  
    END  
    ELSE IF @skey2 = 'GERCARCOMBOAPP'  
    BEGIN  
     select  
     A.TransactionTypeCode as Codeid,   
     B.Description as DescriptionID, B.Category as Others1,   
     case when B.IsTaxable = 0 then 'NO' ELSE 'YES' END as Others2,  
     case when b.isbulk=0 then 'NO' ELSE 'YES' END as Others3,  
     '' as Others4,  
     '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
     from fb_Dept_TransactionType A   
     Inner join fb_TransactionType B   
     on A.TransactionTypeCode=B.Code and a.companyid=b.companyid  
     Where A.DeptCode =@skey1 and a.companyid=@companyid  
     Order by A.TransactionTypeCode  
    END  
    ELSE  
    BEGIN  
  
     select  
     A.TransactionTypeCode as Codeid,   
     B.Description as DescriptionID, B.Category as Others1,   
     case when B.IsTaxable = 0 then 'NO' ELSE 'YES' END as Others2,  
     case when b.isbulk=0 then 'NO' ELSE 'YES' END as Others3,  
     '' as Others4,  
     '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
     from fb_Dept_TransactionType A   
     Inner join fb_TransactionType B   
     on A.TransactionTypeCode=B.Code and a.companyid=b.companyid  
     Where A.TransactionTypeCode not in(select advCode from fb_advance_code)   
     And A.DeptCode =@skey1 and a.companyid=@companyid  
     Order by A.TransactionTypeCode  
  
    END  
  
  
  
  END  
  
      IF @table = 'Combo_WP'  
     BEGIN  
    delete test  
    insert into test values (getdate(),@CompanyID,@CompanyID)  
     
    select selectedstatus as Others1, valid as Others2, kodewp as Codeid,   
    namawp as DescriptionID, npwp as Others3, alamat as Others4,'' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8 from fb_wajibpajak  
    where companyid=@CompanyID  
    order by NamaWP  
  
  END  
  
    IF @table = 'Combo_TypeOfCost'  
     BEGIN  
     
   declare @isnpwp int=null  
   --select @isnpwp= case when npwp='0' then 0  
   --   else 1 end  from fb_WajibPajak where KodeWP=@skey2  
   if exists(  
select distinct NIK  from [dbo].[fb_WajibPajak]   
where companyid=@companyid and nik in (  
'0',  
'0.000.000.000.0-000.000',  
'00.000.000.0-000.000',  
'000000',  
'0000000',  
'00000000',  
'000000000',  
'0000000000',  
'00000000000',  
'00-000-000-000',  
'000000000000',  
'00000000000000',  
'000000000000000',  
' '  
) and KodeWP=@skey2   
)  
begin  
 set @isnpwp=0  
end  
else  
begin  
 set @isnpwp=1  
end  
     
     
   If (select PolRelated from fb_ger_info where FormNum=@skey1)=1   
   begin  
  
    if @isnpwp =0  
    begin  
     select a.taxid as Codeid, a.typeOfCost as DescriptionID, barisBP as Others1,   
     typeofTax as Others2, PerkPenghBruto as Others3, TarifUmum as OThers4, TaxRate as others5,calc as others6,  
     NPWP as others7, KodeObjectPajak as others8  
       from fb_taxId A   
     Where A.TaxId in(Select B.TaxId from fb_tax_role B)   
     and NPWP in ('NO','ALL')  and a.CompanyID=@CompanyID and a.[Status] = 'A'  
     order by A.typeOftax, A.TaxId  
    end  
    else  
    begin  
     select a.taxid as Codeid, a.typeOfCost as DescriptionID, barisBP as Others1,   
     typeofTax as Others2, PerkPenghBruto as Others3, TarifUmum as OThers4, TaxRate as others5,calc as others6,  
     NPWP as others7, KodeObjectPajak as others8  
       from fb_taxId A   
     Where A.TaxId in(Select B.TaxId from fb_tax_role B)   
     and NPWP in ('YES','ALL')  and a.CompanyID=@CompanyID and a.[Status] = 'A'  
     order by A.typeOftax, A.TaxId  
  
    end  
  
   end  
  
   Else  
   begin  
      
    if @isnpwp=0  
    begin  
      select a.taxid as Codeid, a.typeOfCost as DescriptionID, barisBP as Others1,   
      typeofTax as Others2, PerkPenghBruto as Others3, TarifUmum as OThers4, TaxRate as others5,calc as others6,  
      NPWP as others7, KodeObjectPajak as others8 from fb_taxId A   
        Where NPWP in ('NO','ALL')   
          and companyid=@CompanyID and a.[Status] = 'A'  
      order by A.typeOftax, A.TaxId  
    end  
    else  
    begin  
      select a.taxid as Codeid, a.typeOfCost as DescriptionID, barisBP as Others1,   
      typeofTax as Others2, PerkPenghBruto as Others3, TarifUmum as OThers4, TaxRate as others5,calc as others6,  
      NPWP as others7, KodeObjectPajak as others8 from fb_taxId A   
        Where NPWP in ('YES','ALL')   
          and companyid=@CompanyID and a.[Status] = 'A'  
      order by A.typeOftax, A.TaxId  
  
    end  
  
   end  
  
  
  END  
  
   IF @table = 'Combo_transaction_Code_CAR'  
     BEGIN  
    select   
    A.TransactionTypeCode,   
    B.Description , B.Category, B.IsTaxable   
    from fb_Dept_TransactionType A   
    Inner join fb_TransactionType B   
    on A.TransactionTypeCode=B.Code and a.companyid=b.companyid  
    Where A.TransactionTypeCode  in(select advCode from fb_advance_code) and a.CompanyID=@CompanyID  
    And A.DeptCode =@skey1 Order by A.TransactionTypeCode  
  
  
  
  END  
  
     IF @table = 'Combo_Year_Transaction'  
     BEGIN  
    select   
    YearofPreparation as Codeid, YearofPreparation as DescriptionID,   
    '' as Others1,  
   '' as Others2,   
   '' as Others3,  
   '' as Others4,  
   '' as Others5,  
   '' as Others6,  
   '' as Others7, '' as others8  
    from fb_YearOfPreparation where companyid= @companyid  
    order by YearofPreparation desc  
  
  END  
  
     IF @table = 'Combo_Roles'  
     BEGIN  
      
    delete test  
    insert into test values (getdate(),'ronald2'+@skey1,@CompanyID)  
      
    exec usp_check_roles @companyid,@skey1  
  END  
 ELSE IF @table = 'Combo_currency'  
 BEGIN  
  
   select CurrCode as Codeid, CurrCode as DescriptionID,'' as Others1,  
   '' as Others2,   
   '' as Others3,  
   '' as Others4,  
   '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
   from fb_curr_group_detail where code='ALL' and companyid=@companyid  
     
 END  
  ELSE IF @table = 'Combo_currency_new_ger'  
 BEGIN  
  
    select CurrCode  as Codeid,  
    CurrCode as DescriptionID,'' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
    from fb_curr_group_Detail a  
    inner join fb_Department b  
    on a.code=b.currencygroup and a.companyid=b.companyid  
    where b.code = @skey1 and a.companyid=@companyid  
  
 END  
  
ELSE IF @table = 'Combo_approver'  
 BEGIN  
     
  --set @skey4='OTH'  
  --set @skey3='yes'   
  --set @skey2='ITAPP'  
  
  --set @skey2='OTH'  
  --set @skey3='yes'   
  --set @skey1='ITAPP'  
  
  insert into test10 values (getdate(),@skey1,'')  
  insert into test10 values (getdate(),@skey2,'')  
  insert into test10 values (getdate(),@skey3,'')  
  
    SELECT A.ApproverID Codeid,   
    B.UserName as DescriptionID,  
    '' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
    FROM fb_Approver_id A  
    INNER JOIN  
    fb_USER_info B  
    ON A.ApproverID=B.UserID and a.companyid=b.companyid  
    WHERE A.ApprovalLevel=1 AND  
    A.companyid=@companyid AND  
    A.DeptId=@skey1 AND  
    A.ApprovalGroupCode IN   
    (  
    SELECT ApprovalGroupCode +   
    CASE WHEN ApprovalGroupCode='NPOL'   
       THEN CASE WHEN  @skey3=1   
          THEN 'BUD'   
          ELSE 'NBUD'   
          END +  
          dbo.fGetLimitType(@skey2,@skey1, @skey3,@companyID)   
       ELSE '' END ApprovalGroupCode  
    FROM fb_TransactionType  
    WHERE Code=@skey2 AND COMPANYID=@COMPANYID  
    )  
    ORDER BY A.IsDefault DESC   
     
 END  
  
  
 ELSE IF @table = 'Combo_new_approver'  
 BEGIN  
   delete test7  
   insert into test7 values (getdate(),@skey4,'@skey4')  
   insert into test7 values (getdate(),@skey1,'@skey1')  
   insert into test7 values (getdate(),@skey2,'@skey2')  
   insert into test7 values (getdate(),@skey3,'@skey3')  
   insert into test7 values (getdate(),@skey5,'@skey5')  
     
  
   DECLARE @LevelCurrentApprover varchar(2)  
   select @LevelCurrentApprover= ApprovalLevel from fb_Approver_id where approverid=@skey4 and companyid=@CompanyID and DeptID = @skey1  
     
   SELECT A.ApproverID Codeid,   
    B.UserName as DescriptionID,  
    '' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
    FROM fb_Approver_id A  
    INNER JOIN  
    fb_USER_info B  
    ON A.ApproverID=B.UserID  AND A.CompanyID=B.CompanyID  
    WHERE A.ApprovalLevel=@skey5  
    AND A.ApproverID<>@skey4  
    AND COALESCE(B.LogonStatus,'')<>'DIS'  
    AND A.DeptId=@skey1  
    AND A.COMPANYID=@COMPANYID  
    AND A.ApprovalGroupCode IN   
    (  
     SELECT CASE WHEN ApprovalGroupCode='NPOL'  
     THEN  ApprovalGroupCode +   
     CASE WHEN ApprovalGroupCode='NPOL' THEN   
     CASE WHEN @skey3=1   
     THEN 'BUD'   
     ELSE 'NBUD'   
     END   
     ELSE ''   
     END +dbo.fGetLimitType(@skey2,@skey1, @skey3,@companyid)   
     ELSE  
     ApprovalGroupCode  
     END  
     ApprovalGroupCode  
     FROM fb_TransactionType  
     WHERE Code=@skey2 and companyid=@companyid  
    )  
  
    ORDER BY A.IsDefault DESC  
  
 END  
 else if @table = 'Combo_new_approver_all'  
 begin  
  
  select distinct  
  A.ApproverID Codeid,   
    B.UserName as DescriptionID,  
    '' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7,  
     '' as Others8  
     from   
fb_Approver_ID a  
inner join fb_USER_info b on a.CompanyID = b.CompanyID and a.ApproverID = b.UserId  
where a.CompanyID = @CompanyID and b.LogonStatus <> 'DIS'  
  
 end  
 else if @table = 'Combo_next_approver'  
 BEGIN  
  
  delete test10  
  insert into  test10 values (getdate(),'Combo_next_approver','Combo_next_approver')  
  insert into test10 values (getdate(),'@skey1',@skey1)  
  insert into test10 values (getdate(),'@skey2',@skey2)  
  insert into test10 values (getdate(),'@skey3',@skey3)  
  insert into test10 values (getdate(),'@skey4',@skey4)  
    
  
  SELECT  
    A.ApproverID as Codeid,  
    B.UserName as DescriptionID,   
    a.[ApproverID] +'#'+ b.UserName as Others1,   
    '' as Others2,  
     '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7,  
     '' as Others8  
   FROM dbo.fb_Approver_ID AS A   
   INNER JOIN dbo.fb_USER_info AS B ON A.ApproverID = B.UserId AND A.CompanyID=B.CompanyID  
   INNER JOIN fb_dept_transactiontype C On A.DeptId= C.DeptCode AND A.CompanyID=C.CompanyID  
   WHERE (((A.ApprovalLevel=@skey4 and A.ApprovalGroupCode=  
       (  
          
        SELECT CASE WHEN ApprovalGroupCode='NPOL'  
        THEN  ApprovalGroupCode +   
        CASE WHEN ApprovalGroupCode='NPOL' THEN   
          CASE WHEN  @skey3=1   
             THEN 'BUD'   
             ELSE 'NBUD'   
          END   
        ELSE ''   
        END +dbo.fGetLimitType(@skey2,@skey1, @skey3,@companyid)   
  ELSE  
  ApprovalGroupCode  
 END  
 ApprovalGroupCode  
 FROM fb_TransactionType  
 WHERE Code=@skey2 and companyid=@companyid  
          
  
       )) and A.DeptId=@skey1)and C.TransactionTypeCode=@skey2)  
        AND A.ApproverID<>'' AND A.CompanyID=@CompanyID   
       ORDER by A.Isdefault desc  
 END  
 else if @table = 'Combo_next_approver'  
 BEGIN  
  
  delete test10  
  insert into  test10 values (getdate(),'Combo_next_approver','Combo_next_approver')  
  insert into test10 values (getdate(),'@skey1',@skey1)  
  insert into test10 values (getdate(),'@skey2',@skey2)  
  insert into test10 values (getdate(),'@skey3',@skey3)  
  insert into test10 values (getdate(),'@skey4',@skey4)  
    
  
  SELECT  
    A.ApproverID as Codeid,  
    B.UserName as DescriptionID,   
    a.[ApproverID] +'#'+ b.UserName as Others1,   
    '' as Others2,  
     '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
   FROM dbo.fb_Approver_ID AS A   
   INNER JOIN dbo.fb_USER_info AS B ON A.ApproverID = B.UserId AND A.CompanyID=B.CompanyID  
   INNER JOIN fb_dept_transactiontype C On A.DeptId= C.DeptCode AND A.CompanyID=C.CompanyID  
   WHERE (((A.ApprovalLevel=@skey4 and A.ApprovalGroupCode=  
       (  
          
        SELECT CASE WHEN ApprovalGroupCode='NPOL'  
        THEN  ApprovalGroupCode +   
        CASE WHEN ApprovalGroupCode='NPOL' THEN   
          CASE WHEN  @skey3=1   
             THEN 'BUD'   
             ELSE 'NBUD'   
          END   
        ELSE ''   
        END +dbo.fGetLimitType(@skey2,@skey1, @skey3,@companyid)   
  ELSE  
  ApprovalGroupCode  
 END  
 ApprovalGroupCode  
 FROM fb_TransactionType  
 WHERE Code=@skey2 and companyid=@companyid  
          
  
       )) and A.DeptId=@skey1)and C.TransactionTypeCode=@skey2)  
        AND A.ApproverID<>'' AND A.CompanyID=@CompanyID   
       ORDER by A.Isdefault desc  
 END  
  
  
  ELSE IF @table = 'Combo_status'  
 BEGIN  
  
     
  --set @CompanyID='SLF'  
  
  --select @Roles=Roles from fb_USER_info where userid=@skey1 and CompanyID=@CompanyID    
  set @roles=@skey2  
  
  delete test  
  insert into test values (getdate(),@skey1,@Roles)  
  
  if @Roles  in ('TAX','TAX_ALL')  
   BEGIN  
    select CodeID as Codeid, Codename as DescriptionID,'' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
    from tdcode where CodeType='FRMST' AND CodeID in (  
    'ABT','ABU','BNK','NEW','PAID','PRN','REJ'  
    )  
    UNION  
    select '*' as Codeid, 'All Data' as DescriptionID,  
    '' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5 ,  
     '' as Others6,  
     '' as Others7, '' as others8  
    order by CodeID  
  
  
   END  
  ELSE IF @Roles ='AUDIT'  
  BEGIN   
    select CodeID as Codeid, Codename as DescriptionID,'' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
    from tdcode where CodeType='FRMST' AND CodeID in   
     ('ABT','BNK','PAID','REJ'  
    )  
    UNION  
    select '*' as Codeid, 'All Data' as DescriptionID,  
    '' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5 ,  
     '' as Others6,  
     '' as Others7, '' as others8  
    order by CodeID  
  END  
  ELSE IF @Roles='UPREP'  OR @Roles='CASHIER' OR @Roles='CC' or  @Roles='ACC' or @Roles = 'GS' or @Roles = 'VWONLY'  
  begin   
  select CodeID as Codeid, Codename as DescriptionID,'' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
    from tdcode where CodeType='FRMST'   
    UNION  
  select '*' as Codeid, 'All Data' as DescriptionID,  
    '' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5 ,  
     '' as Others6,  
     '' as Others7, '' as others8  
  order by CodeID  
  
  end  
     
     
 END  
  
  
 ELSE IF @table = 'Combo_department'  
     BEGIN  
  --set @CompanyID='SLF'  
  set @roles=@skey2  
  
  --select @Roles=Roles from fb_USER_info where userid=@skey1 and CompanyID=@CompanyID  
  
  if @Roles  in ('CASHIER','AUDIT','TAX_ALL','ACC')  
   BEGIN  
  
    select distinct (a.deptcode) as Codeid, b.description as DescriptionID,'' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
    from fb_user_department a inner join fb_department b  
    on a.deptcode=b.code and a.companyid = b.companyid where a.CompanyID=@CompanyID and a.deptcode   
    not in (select code from fb_costcenter_distribution_info where CompanyID=@CompanyID) and a.companyid = @companyid  
    union  
    select '*' as Codeid, 'All Data' as DescriptionID,  
    '' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5 ,  
     '' as Others6,  
     '' as Others7, '' as others8  
    order by a.deptcode  
  
  
   END  
   ELSE IF @Roles in ('UPREP', 'TAX')  
   BEGIN  
     if exists(select deptcode from fb_user_dept_from where userid=@skey1 and companyid=@companyid)  
     begin  
  
  
      select a.deptcode as Codeid, b.description as DescriptionID,  
      '' as Others1,  
      '' as Others2,   
      '' as Others3,  
      '' as Others4,  
      '' as Others5 ,  
     '' as Others6,  
     '' as Others7, '' as others8  
      from fb_user_dept_from a  
      inner join fb_department b on a.deptcode=b.code and a.CompanyID = b.CompanyID where a.UserID=@skey1 and a.companyid = @companyid  
      union  
      select '*' as Codeid, 'All Data' as DescriptionID,  
      '' as Others1,  
      '' as Others2,   
      '' as Others3,  
      '' as Others4,  
      '' as Others5 ,  
     '' as Others6,  
     '' as Others7, '' as others8  
      order by a.DeptCode  
        
  
     end  
     else  
     begin  
      select a.deptid as Codeid, b.description as DescriptionID,  
      '' as Others1,  
      '' as Others2,   
      '' as Others3,  
      '' as Others4,  
      '' as Others5 ,  
     '' as Others6,  
     '' as Others7, '' as others8  
      from fb_user_info a   
      inner join fb_department b  
      on a.deptid=b.code and a.companyid = b.companyid where a.UserId=@skey1 and a.companyid = @companyid  
      union  
      select '*' as Codeid, 'All Data' as DescriptionID,  
      '' as Others1,  
      '' as Others2,   
      '' as Others3,  
      '' as Others4,  
      '' as Others5 ,  
     '' as Others6,  
     '' as Others7, '' as others8  
      order by a.deptid  
     end  
  
   END  
   ELSE IF @Roles in ('CC')  
   BEGIN  
     SELECT DISTINCT(a.deptcode) as Codeid, C.Description as DescriptionID,  
     '' as Others1,  
     '' as Others2,   
     '' as Others3,  
     '' as Others4,  
     '' as Others5 ,  
     '' as Others6,  
     '' as Others7, '' as others8       
     from fb_Dept_TransactionType A  
     inner join fb_transactiontype b  
     on a.transactiontypecode= b.code  and a.companyid = b.companyid  inner join fb_department c  
     on a.deptcode=c.code and a.companyid = c.companyid  
     where b.category='POL' and a.companyid = @companyid  
     union  
     select '*' as Codeid, 'All Data' as DescriptionID,  
     '' as Others1,  
     '' as Others2,   
     '' as Others3,  
     '' as Others4,  
     '' as Others5 ,  
     '' as Others6,  
     '' as Others7, '' as others8  
     order by a.deptcode  
   END  
   if @Roles = 'VWONLY'  
   begin   
    select '*' as Codeid, 'All Data' as DescriptionID,  
     '' as Others1,  
     '' as Others2,   
     '' as Others3,  
     '' as Others4,  
     '' as Others5 ,  
     '' as Others6,  
     '' as Others7, '' as others8  
     union  
     select   
     DISTINCT(a.[DeptCode]) as Codeid, b.Description as DescriptionID,  
     '' as Others1,  
     '' as Others2,   
     '' as Others3,  
     '' as Others4,  
     '' as Others5 ,  
     '' as Others6,  
     '' as Others7, '' as others8  
     from [fb_usersegrole_detail] a  
     left join fb_department b on a.[DeptCode] = b.Code and a.companyid = b.CompanyID  
     where a.CompanyID = @companyid and a.userid = @skey1  
   end  
   else  
     
   begin  
   select '*' as Codeid, 'All Data' as DescriptionID,  
     '' as Others1,  
     '' as Others2,   
     '' as Others3,  
     '' as Others4,  
     '' as Others5 ,  
     '' as Others6,  
     '' as Others7, '' as others8  
     union  
   SELECT 'CLM' as Codeid,'Claim' as DescriptionID,  
     '' as Others1,  
     '' as Others2,   
     '' as Others3,  
     '' as Others4,  
     '' as Others5 ,  
     '' as Others6,  
     '' as Others7, '' as others8    
      
       
       
   end  
     
 END  
 ELSE IF @table = 'Combo_department_ben'  
     BEGIN  
  --set @CompanyID='SLF'  
  
  
  --select @Roles=Roles from fb_USER_info where userid=@skey1 and CompanyID=@CompanyID  
  
  
  
     if exists(select deptcode from fb_user_dept_from where userid=@skey1 and companyid=@companyid and companyid=@companyid)  
     begin  
  
  
      select a.deptcode as Codeid, b.description as DescriptionID,  
      '' as Others1,  
      '' as Others2,   
      '' as Others3,  
      '' as Others4,  
      '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8   
      from fb_user_dept_from a  
      inner join fb_department b on a.deptcode=b.code and a.companyid=b.companyid where a.UserID=@skey1 and a.companyid=@companyid  
      --union  
      --select '*' as Codeid, 'All Data' as DescriptionID,  
      --'' as Others1,  
      --'' as Others2,   
      --'' as Others3,  
      --'' as Others4,  
      --'' as Others5   
      --order by a.DeptCode  
        
  
     end  
     else  
     begin  
      select a.deptid as Codeid, b.description as DescriptionID,  
      '' as Others1,  
      '' as Others2,   
      '' as Others3,  
      '' as Others4,  
      '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8   
      from fb_user_info a   
      inner join fb_department b  
      on a.deptid=b.code and a.companyid=b.companyid where a.UserId=@skey1 and a.companyid=@companyid  
      --union        --select '*' as Codeid, 'All Data' as DescriptionID,  
      --'' as Others1,  
      --'' as Others2,   
      --'' as Others3,  
      --'' as Others4,  
      --'' as Others5   
      --order by a.deptid  
     end  
  
     
  
  
 END  
  
  ELSE IF @table = 'Combo_current_apprv'  
     BEGIN  
   select distinct(A.formLocation)as Codeid, B.UserName as DescriptionID,    
         '' as Others1,  
      '' as Others2,   
      '' as Others3,  
      '' as Others4,  
      '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8   
            from fb_ger_info A inner join fb_user_info B on A.formLocation=B.UserID and a.companyid=b.CompanyID  
            where left(A.FormStatus,2)='FA' and a.companyid=@Companyid  
  
 end  
  
   ELSE IF @table = 'Combo_dept_current_apprv'  
     BEGIN  
  
   select distinct(A.FromDept)as Codeid, B.Description as DescriptionID,  
      '' as Others1,  
      '' as Others2,   
      '' as Others3,  
      '' as Others4,  
      '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8    
            from fb_ger_info A inner join fb_Department B on A.FromDept=B.Code and a.companyid=b.companyid  
            where left(A.FormStatus,2)='FA' and A.FormLocation=@skey1 and a.companyid=@Companyid  
  
  
 end  
  
  
  
  
  ELSE IF @table = 'Combo_department_new_ger'  
     BEGIN  
  --set @CompanyID='SLF'  
  set @roles=@skey2  
  
  --select @Roles=Roles from fb_USER_info where userid=@skey1 and CompanyID=@CompanyID  
  
  if @Roles  in ('TAX','CASHIER','AUDIT','TAX_ALL','ACC')  
   BEGIN  
  
    select distinct (a.deptcode) as Codeid, b.description as DescriptionID,'' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
    from fb_user_department a inner join fb_department b  
    on a.deptcode=b.code and a.CompanyID=b.CompanyID where a.CompanyID=@CompanyID and a.deptcode   
    not in (select code from fb_costcenter_distribution_info where CompanyID=@CompanyID )   
    order by a.deptcode  
  
  
   END  
   ELSE IF @Roles='UPREP'  
   BEGIN  
     if exists(select deptcode from fb_user_dept_from where userid=@skey1 and companyid=@companyid)  
     begin  
  
      select distinct a.deptcode as Codeid, b.description as DescriptionID,  
      '' as Others1,  
      '' as Others2,   
      '' as Others3,  
      '' as Others4,  
      '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8   
      from fb_user_dept_from a  
      inner join fb_department b on a.deptcode=b.code and a.companyid=b.companyid where a.UserID=@skey1  
      and a.companyid=@companyid  
      order by a.DeptCode  
  
     end  
     else  
     begin  
      select distinct a.deptid as Codeid, b.description as DescriptionID,  
      '' as Others1,  
      '' as Others2,   
      '' as Others3,  
      '' as Others4,  
      '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8   
      from fb_user_info a   
      inner join fb_department b  
      on a.deptid=b.code and a.companyid=b.companyid where a.UserId=@skey1 and a.companyid=@companyid  
      order by a.deptid  
     end  
  
   END  
   ELSE IF @Roles='CC'  
   BEGIN  
     SELECT DISTINCT(a.deptcode) as Codeid, C.Description as DescriptionID,  
     '' as Others1,  
     '' as Others2,   
     '' as Others3,  
     '' as Others4,  
     '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8        
     from fb_Dept_TransactionType A  
     inner join fb_transactiontype b  
     on a.transactiontypecode= b.code and a.companyid=b.companyid inner join fb_department c  
     on a.deptcode=c.code and a.companyid=c.companyid  
     where b.category='POL' and a.companyid=@companyid  
     order by a.deptcode  
   END  
 END  
  
 ELSE IF @table = 'Combo_department_travel'  
 begin  
   SELECT DISTINCT code as Codeid, ltrim(rtrim(Description)) as DescriptionID,  
     '' as Others1,  
     '' as Others2,   
     '' as Others3,  
     '' as Others4,  
     '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8 from fb_department where left(code,2)<>'00'  
     and CompanyID=@CompanyID  
     order by DescriptionID asc  
 end  
  
  ELSE IF @table = 'Combo_department_appr'  
     BEGIN  
  --set @CompanyID='SLF'  
  --set @roles=@skey2  
  
     if exists(select deptcode from fb_user_dept_from where userid=@skey1)  
     begin  
  
  
      select a.deptcode as Codeid, b.description as DescriptionID,  
      '' as Others1,  
      '' as Others2,   
      '' as Others3,  
      '' as Others4,  
      '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8   
      from fb_user_dept_from a  
      inner join fb_department b on a.deptcode=b.code and a.companyid=b.companyid where a.UserID=@skey1  
      and a.companyid=@companyid  
      union  
      select '*' as Codeid, 'All Data' as DescriptionID,  
      '' as Others1,  
      '' as Others2,   
      '' as Others3,  
      '' as Others4,  
      '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8   
      order by a.DeptCode  
        
  
     end  
     else  
     begin  
      select a.deptid as Codeid, b.description as DescriptionID,  
      '' as Others1,  
      '' as Others2,   
      '' as Others3,  
      '' as Others4,  
      '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8   
      from fb_user_info a   
      inner join fb_department b  
      on a.deptid=b.code and a.companyid=b.companyid where a.UserId=@skey1 and a.companyid=@companyid  
      union  
      select '*' as Codeid, 'All Data' as DescriptionID,  
      '' as Others1,  
      '' as Others2,   
      '' as Others3,  
      '' as Others4,  
      '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8   
      order by a.deptid  
     end  
   
 ENd  
  
 ELSE IF @table = 'Combo_search'  
     BEGIN  
   
   select CodeID, CodeName as DescriptionID, '' as Others1,  
   '' as Others2,   
   '' as Others3,  
   '' as Others4,  
   '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8 from tdcode where codetype='SEARCH'   
  
 END  
  ELSE IF @table = 'Combo_search_APR'  
     BEGIN  
   
   select CodeID, CodeName as DescriptionID, '' as Others1,  
   '' as Others2,   
   '' as Others3,  
   '' as Others4,  
   '' as Others5,  
     '' as Others6,  
     '' as Others7,  
     '' as Others8 from tdcode where codetype='SEARCHAPR'   
  
 END  
 ELSE IF @table = 'Combo_rejecttype'  
     BEGIN  
   
   select CodeID, CodeName as DescriptionID, '' as Others1,  
   '' as Others2,   
   '' as Others3,  
   '' as Others4,  
   '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8 from tdcode where codetype='REJCTP'  
  
 END  
 ELSE IF @table = 'Combo_taxstatus'  
     BEGIN  
   
   select CodeID, CodeName as DescriptionID, '' as Others1,  
   '' as Others2,   
   '' as Others3,  
   '' as Others4,  
   '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8 from tdcode where codetype='taxst'  
  
 END  
  
 ELSE IF @table = 'Combo_all_code'  
     BEGIN  
   
   select CodeID, CodeName as DescriptionID, '' as Others1,  
   '' as Others2,   
   '' as Others3,  
   '' as Others4,  
   '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8 from tdcode where codetype=@skey1  
   ORDER BY CodeSequence  
  
 END  
 ELSE IF @table = 'Combo_coa_code'  
     BEGIN  
   
  select Distinct COA as CodeID, COA  as DescriptionID, '' as Others1,  
   '' as Others2,   
   '' as Others3,  
   '' as Others4,  
   '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8 from fb_ger_detail_info where FormNum=@skey1 and CompanyID=@Companyid and COA <> ''  
   ORDER BY COA  
  
 END  
  
 ELSE IF @table = 'Combo_beneficiarytype'  
     BEGIN  
   
   select CodeID, CodeName as DescriptionID, '' as Others1,  
   '' as Others2,   
   '' as Others3,  
   '' as Others4,  
   '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8 from tdcode where codetype='BNFTP'  
  
 END  
  
  ELSE IF @table = 'Combo_beneficiarytransactiontype'  
     BEGIN  
   
   select CodeID, CodeName as DescriptionID, '' as Others1,  
   '' as Others2,   
   '' as Others3,  
   '' as Others4,  
   '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8 from tdcode where codetype='BNFTRTP'  
  
 END  
  
 ELSE IF @table = 'Combo_Policy'  
     BEGIN  
         
   select POL_ID as Codeid, POL_ID as DescriptionID, '' as Others1,  
   '' as Others2,   
   '' as Others3,  
   '' as Others4,  
   '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
   from si_tpol  
   where CO_ID='CP'   
   and sbsdry_co_id=@skey1   
   and POL_CRCY_CD=@skey2  
   and POL_OS_DISB_AMT > 0   
   UNION  
   select '' as Codeid, '' as DescriptionID, '' as Others1,  
   '' as Others2,   
   '' as Others3,  
   '' as Others4,  
   '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
  
  
 END  
  
  ELSE IF @table = 'Combo_ChargeTo'  
     BEGIN  
     
        
    select code as Codeid, Description as DescriptionID, costcenter as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
     from fb_Department   
     where code in (  
       select distinct x.deptcode  from  
       (  
       select CompanyID, userid, DeptCode from fb_user_department where UserID=@skey1 AND CompanyID=@COMPANYID  
       union  
       select CompanyID, userid, DeptCode from fb_user_dept_from where UserID=@skey1 AND CompanyID=@COMPANYID  
       )x  
    ) AND CompanyID=@COMPANYID  
  
 END  
 ELSE IF @table = 'Combo_SegCode'  
     BEGIN  
     
        
    select CodeID as Codeid, CodeName as DescriptionID, '' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
     from tdcode   
     where CodeType = 'SEGCD' order by CodeSequence  
  
 END  
  
  ELSE IF @table = 'Combo_CashAdvance'  
     BEGIN  
   Select A.FormNum as Codeid,A.FormNum as DescriptionID,  
   '' as Others1,  
   '' as Others2,   
   '' as Others3,  
   '' as Others4,  
   '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8 From Fb_ger_info A   
                inner join fb_payment_info C   
                on A.FormNum = C.FormNum   
                Left join fb_AdvanceAndSettlement_info B   
                on A.FormNum = B.AdvanceFormNum   
                WHERE A.FormType='CAR'  
                and C.Status='PAID'   
                and A.FromDept=@skey1  
                and B.SettleStatus is Null   
                and A.TransactionCode NOT IN('TADVLOC','TADVINT')   
    UNION  
    select '' as Codeid, '' as DescriptionID,  
    '' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8   
    order by CodeID  
  
 END  
  
  
  ELSE IF @table = 'Combo_Subject'  
  BEGIN  
  Select FormSubject as Codeid,FormSubject as DescriptionID,  
  '' as Others1,  
  '' as Others2,   
  '' as Others3,  
  '' as Others4,  
  '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8 From [dbo].[fb_Subject_info] WHERE CompanyID=@COMPANYID  
  END  
  
  ELSE IF @table = 'Combo_PaidBy'  
  BEGIN  
  Select PaidBy as Codeid,PaidBy as DescriptionID,  
  '' as Others1,  
  '' as Others2,   
  '' as Others3,  
  '' as Others4,  
  '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8 From [dbo].[fb_Paid_by_info] where PaidBy <>'Bilyet Giro' AND CompanyID=@COMPANYID  
  END  
  
  ELSE IF @table = 'Combo_Bank_Reset_Voucher'  
  BEGIN  
  
    Select distinct(bank) as Codeid, bank as DescriptionID,  
    '' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
    from fb_ListVoucher where Bank<>'LIPPO' AND CompanyID=@COMPANYID  
  
  END  
  
  ELSE IF @table = 'Combo_Bank_For_Bank_Book'  
  BEGIN  
  
    Select distinct(bank) as Codeid, bank as DescriptionID,  
    '' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
    from fb_ListVoucher where companyid=@companyid  
  
  END  
  
  ELSE IF @table = 'Combo_Prepared_Date'  
  BEGIN  
  
   declare @vouchercode as varchar(20)  
  
    Select @vouchercode=VoucherCode  
    from fb_listVoucher where AccountNum=@skey1 and companyid=@companyid  
  
  
    Select distinct convert(varchar(10),paymentprepareddt,120) as Codeid, convert(varchar(10),paymentprepareddt,120) as DescriptionID,  
    @vouchercode as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
    from fb_payment_info where companyid=@companyid  
    and SLFIBankAccountNum=@skey1 and Status='BNK' and LEFT(vouchernum,3)='TMP'  
    order by convert(varchar(10),paymentprepareddt,120) desc  
  
  END  
  
  ELSE IF @table = 'Combo_Batch_Number'  
  BEGIN  
  
      
  
   Select Distinct(VoucherNum) as Codeid , VoucherNum as DescriptionID,  
   '' as Others1,  
   '' as Others2,   
   '' as Others3,  
   '' as Others4,  
   '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
   from fb_payment_info   
   where companyid=@companyid and SLFIbankAccountNum=@skey1  
   and Status='BNK' and left(VoucherNum,3)='TMP' and   
   convert(varchar(10),PaymentPreparedDt,120)=convert(varchar(10),@skey2,120)  
  
  END  
  
    ELSE IF @table = 'Combo_Voucher_Number'  
  BEGIN  
  
  
   Select Distinct(VoucherNum) as Codeid , VoucherNum as DescriptionID,  
   '' as Others1,  
   '' as Others2,   
   '' as Others3,  
   '' as Others4,  
   '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
   from snaps_payment_voucher_info   
   where companyid=@companyid and bankCode = @skey1 and year(createDt)= @skey2   
  
  END  
  
  
  ELSE IF @table = 'Get_Group_transaction_code'  
  BEGIN  
  
  select isnull(codeid,'NOENTERTAINMENTANDTRAVEL')  
  from vlist_codeTransaction a right join fb_ger_info b on a.codeType=b.TransactionCode   
  and a.companyid=b.companyid  
  where b.FormNum=@skey1 and a.companyid=@CompanyID  
  
  END  
    
  ELSE IF @table = 'Combo_YearPrep'  
  BEGIN  
  
  Select YearOfPreparation as CodeID, YearOfPreparation as DescriptionID,  
  '' as Others1,  
       '' as Others2,   
       '' as Others3,  
       '' as Others4,  
       '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
   from fb_YearOfPreparation where companyid=@Companyid order by YearOfPreparation desc  
    
    
    
  END  
    
  
    
  
  
  ELSE IF @table = 'Combo_Bank'  
  BEGIN  
  
      IF @skey1<>''  
      BEGIN   
  
       if @skey1 in ('CAD', 'HKD', 'SGD')  
       begin   
        set @skey1 = 'USD'  
       end  
    
       select distinct(bank) as Codeid,  
       bank as DescriptionID,  
       '' as Others1,  
       '' as Others2,   
       '' as Others3,  
       '' as Others4,  
       '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
        from fb_listvoucher where Companyid=@CompanyID and currency=@skey1 and bank not in ('LIPPO','PCASH')  
       --AND (Bank NOT LIKE 'PETTYCASH-%')  
  
      END  
      ELSE  
      BEGIN   
       select distinct(bank) as addbankname from fb_listvoucher   
       where Companyid=@CompanyID and bank =(SELECT PARAMVALUE FROM FB_PARAM_INFO B WHERE PARAMNAME='PETTYCASH Code')  
      END  
    
  
  END  
  
  ELSE IF @table = 'Combo_Bank_Account'  
  BEGIN  
       
   if @skey2 =''   
   begin  
  
    if @skey1='ZEROSUM' -- For Bank Zero sum and Negatif Settledment  
    begin  
        
      select accountNum as Codeid,  
      accountNum as DescriptionID,  
      '' as Others1,  
      '' as Others2,   
      '' as Others3,  
      '' as Others4,  
      '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
      from fb_listvoucher where bank in (  
      'NPOLNEGA',  
      'NPOLZERO',  
      'POLZERO'  
      ) AND companyid=@CompanyID  
  
    end  
    else if @skey1 IN ('CIMBIN','CIMBDC','CIMBIN1','CIMBDC1')  
    begin  
      select accountNum as Codeid,  
      accountNum as DescriptionID,  
      '' as Others1,  
      '' as Others2,   
      '' as Others3,  
      '' as Others4,  
      '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
      from fb_listvoucher where Bank='CIMB' AND companyid=@CompanyID  
    end  
    else  
    begin  
  
    select accountNum as Codeid,  
    accountNum as DescriptionID,  
    '' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
    from fb_listvoucher where Bank=@skey1 AND companyid=@CompanyID  
    end  
  
  
   end  
  
   else  
   begin  
  
    IF @skey2 in ('CAD', 'HKD', 'SGD')  
    begin  
     set @skey2 = 'USD'  
    end  
  
    select accountNum as Codeid,  
    accountNum as DescriptionID,  
    '' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
     from fb_listvoucher where Bank=@skey1 and currency=@skey2 AND companyid=@CompanyID  
    --from fb_listvoucher where Bank='CIMB' and currency='IDR' AND companyid='SLF'  
      
  
  
  
   end  
  
  
  
  
  
  
  END  
  
  ELSE IF @table = 'Combo_Account_Code'  
  BEGIN  
       
         
     declare @polrelated varchar(10)  
     declare @TransactionTypeCode varchar(10)  
  
     select @polrelated=polrelated,@TransactionTypeCode=TransactionCode    
     from [dbo].[fb_ger_info] where FormNum=@skey1 AND companyid=@CompanyID  
  
     If @polrelated=1   
     begin  
       SELECT A.ingenCode as Codeid, B.Description as DescriptionID,  
       '' as Others1,  
       '' as Others2,   
       '' as Others3,  
       '' as Others4,  
       '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8   
       from fb_coa_ingen A inner join fb_coa B   
       on A.COAcode= B.Code and a.companyid=b.companyid  
       inner join fb_transactionType_coa C   
       on A.IngenCode =  C.COA and a.companyid=b.companyid and a.companyid=b.companyid and a.companyid=c.companyid and b.companyid=c.companyid  
       WHERE C.TransactionTypeCode=@TransactionTypeCode AND A.companyid=@CompanyID  
       order by B.Description  
     end  
     else  
     begin  
       SELECT A.Code as Codeid, A.Description as DescriptionID,  
       '' as Others1,  
       '' as Others2,   
       '' as Others3,  
       '' as Others4,  
       '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8   
       from fb_coa A inner join fb_transactionType_Coa B   
       on A.code= B.Coa and a.companyid=b.companyid and a.companyid=b.companyid  
       WHERE B.TransactionTypeCode=@TransactionTypeCode AND A.companyid=@CompanyID  
       order by A.Description   
     End  
  END  
  
  
  ELSE IF @table = 'Combo_Beneficiary_Bank'  
  BEGIN  
  Select Code as Codeid,BankName as DescriptionID,  
  '' as Others1,  
  '' as Others2,   
  '' as Others3,  
  '' as Others4,  
  '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8 From [dbo].[fb_ListOfBeneficiaryBank]   
  where CompanyID=@CompanyID  
  END  
  
  
  ELSE IF @table = 'Combo_TransactionType'  
  BEGIN  
    IF @skey1='SCRIT'  
    BEGIN   
      SELECT CodeID, CodeName  
      FROM tdcode  
      WHERE CompanyID=@CompanyID   
      AND CodeType=@skey1   
      AND CodeCategory= (CASE WHEN @skey2='' THEN CodeCategory ELSE @skey2 END)  
      AND IsSystemCode=1  
      ORDER BY CodeSequence  
    ENd  
    ELSE IF @skey1='FRMST'  
    BEGIN  
    IF @skey2='SYSADM'  
    BEGIN  
     SELECT CodeSequence, CodeID, CodeName, 0 AS IsEnabled, 11 AS IndexDefault  
     FROM tdcode  
     WHERE CompanyID=@CompanyID  
     AND CodeType=@skey1  
     AND IsSystemCode=1  
     ORDER BY CodeSequence  
    END  
    END  
    else  
    BEGIN   
     SELECT CodeID, CodeName  
     FROM tdcode  
     WHERE CompanyID=@CompanyID   
     AND CodeType=@skey1   
     AND CodeCategory= (CASE WHEN @skey2='' THEN CodeCategory ELSE @skey2 END)  
     AND IsSystemCode=1  
     ORDER BY CodeSequence  
    END  
 END  
  
  
  
 ELSE IF @table = 'List_GER'  
  BEGIN  
  
      SELECT   
      A.FormLocation as Location, A.Curr as Currency, A.FormNum, A.FromDept as Dept,   
      A.AdvanceFormNum as [GC No. Settlement], A.FormStatus as [GC Status], C.TransferedDt as [GC TransferredDt], A.CreateDt,   
      A.CreateBy, A.TotalAmount, A.TaxAmount, A.NettAmount,   
      A.FormStatus as Status, A.TransactionCode as [Trxn Cd],   
      A.BeneficiaryName as [Ben Name], B.BankName as [Ben Bank],   
      A.BeneficiaryBankAccount as [Ben Account],   
      A.PolicyNum as PolNum, A.PolRelated, C.VoucherNum, C.TransferedDt   
      FROM fb_GER_info A   
      left join fb_ListOfBeneficiaryBank B   
      on A.BeneficiaryBankCode = B.Code   
      left join fb_payment_info C on A.FormNum = C.FormNum   
      where A.fromdept=@skey1   
      and a.CompanyID=@CompanyID  
  
  
 END  
  
  ELSE IF @table = 'List_GER_Description'  
     BEGIN  
  
  select * from fb_ger_detail_info where CompanyID=@CompanyID and  formnum=@skey1  
  and description<>''  
  order by SeqNum  
  
  
  END  
  
    
  ELSE IF @table = 'List_GER_Entertainment'  
     BEGIN  
  
  select SeqNum,REPLACE(nomor,'.','') as Nomor,CASE WHEN CONVERT(varchar,ENTRDate,101) = '12/30/1899' THEN '' ELSE replace(CONVERT(varchar,ENTRDate,106),' ','-') END as ENTRDate,  
  PersonNm,CompanyNm,Title,Place,  
        EntertainmentType,IdrAmount, reason ,coalesce(ProvidedNm,'') ProvidedNm, coalesce(typeOfCompany,'') typeOfCompany,coalesce(fullAddress,'') fullAddress, isnull(EntertaimentTypeDesc, '') as EntertaimentTypeDesc, isnull(ReasonDesc, '') as ReasonDesc 
 
        From fb_ENTR_detail_info    
        where formnum=@skey1 and CompanyID=@CompanyID order by SeqNum  
  
  END  
  
  ELSE IF @table = 'List_GER_Travel'  
     BEGIN  
  
   --select @skey2=case when fb_ger_info.advanceformnum is null THEN fb_ger_info.FormNum  
   --WHEN fb_ger_info.advanceformnum  = '' then  fb_ger_info.FormNum   
   --else fb_ger_info.AdvanceFormNum END  
   --from fb_ger_info where formnum=@skey1 AND CompanyID=@CompanyID  
     
   --select TravellerName,DateFrom,DateUntil,fb_ger_travel_info.Department,TripDestination,  
   --TripPurpose,  
  
   --CreditCardOAmount,CreditCardOCurr,CreditCardExchangeRate,CreditCardIDRAmount,  
  
   --CashAdvanceOAmount,CashAdvanceOCurr,CashAdvanceExchangeRate,CashAdvanceIDRAmount,   
     
   --PrePaidOAmount,PrePaidOCurr,PrePaidExchangeRate,PrePaidIDRAmount,  
     
   --TotalIdrAmount,  
     
   --DueAmount,  
  
   --SeqNum,ROW_NUMBER() OVER (ORDER BY seqNum ASC) AS NomorRow,TypeOfExpenses,OriginalAmount,  
   --OriginalCurr,ExchangeRate ,IdrAmount,fb_ger_travel_info.TravellerPosition,fb_ger_travel_info.LengthOfTrip  
  
   --From fb_ter_info   
   --left join   
   --fb_ter_detail_info   
   --on fb_ter_info.FormNum=fb_ter_detail_info.FormNum and fb_ter_info.CompanyID=fb_ter_detail_info.CompanyID  
   --left join   
   --fb_ger_travel_info  
   --on  fb_ger_travel_info.formnum = @skey2  
   --where fb_ter_info.formnum=@skey1 and fb_ter_info.CompanyID=@CompanyID  order by SeqNum  
  
   select TravellerName,convert(varchar,DateFrom,106) DateFrom,convert(varchar,DateUntil,106) DateUntil,fb_ger_travel_info.Department,TripDestination,  
   TripPurpose,fb_ger_travel_info.TransportMode,fb_ger_travel_info.Millage,  
  
   CreditCardOAmount,CreditCardOCurr,CreditCardExchangeRate,CreditCardIDRAmount,  
  
   CashAdvanceOAmount,CashAdvanceOCurr,CashAdvanceExchangeRate,CashAdvanceIDRAmount,   
     
   PrePaidOAmount,PrePaidOCurr,PrePaidExchangeRate,PrePaidIDRAmount,  
     
   TotalIdrAmount,  
     
   fb_ter_info.DueAmount,  
  
   SeqNum,ROW_NUMBER() OVER (ORDER BY seqNum ASC) AS NomorRow,TypeOfExpenses,OriginalAmount,  
   OriginalCurr,fb_ter_detail_info.ExchangeRate ,IdrAmount,fb_ger_travel_info.TravellerPosition,fb_ger_travel_info.LengthOfTrip  
  
   From fb_ter_info   
   inner join   
   fb_ter_detail_info   
   on fb_ter_info.FormNum=fb_ter_detail_info.FormNum and fb_ter_info.CompanyID=fb_ter_detail_info.CompanyID  
   right join fb_ger_info on fb_ter_info.FormNum=fb_ger_info.FormNum  
   right join fb_ger_travel_info on fb_ger_travel_info.FormNum = case when fb_ger_info.AdvanceFormNum is null or fb_ger_info.AdvanceFormNum = '' then fb_ger_info.FormNum else fb_ger_info.AdvanceFormNum end  
   where fb_ger_info.formnum=@skey1 and fb_ger_info.CompanyID=@CompanyID  order by SeqNum  
  
    
  END  
  
  
  
  ELSE IF @table = 'List_Attachment'  
     BEGIN  
  
  SELECT convert(int,seqnum)+1 as seqnum,formnum, filelocation  
  ,'' as [filename], remark, seqnum as seqnum2  FROM [dbo].[SnAPS_GER_File_Attachment_Info]  
  where formnum=@skey1 and companyid=@CompanyID  
  
 END  
  ELSE IF @table = 'List_Attachment_Appr'  
     BEGIN  
  
  SELECT convert(int,seqnum)+1 as seqnum,formnum, filelocation,  
  replace(replace(replace(replace(replace(replace(replace(replace(replace([FileLocation], '\\sv5418\SLFI$\',''), '\\10.154.3.8\SLFI$\',''), '\\10.154.3.8\csl$\',''), '\\sv5418\syariah$\',''), '\\10.154.3.8\syariah$\',''), '\\sv5418.id.sunlife\syariah$\','
'), '\\SV5402.id.sunlife\syariah$\',''),'\\sv5402\ISTAR\SNAPS\attachment\',''),'\\sv5402\ISTAR\SNAPS\','') as [FileName]  
  , remark, seqnum as seqnum2  FROM [dbo].[SnAPS_GER_File_Attachment_Info]  
  where formnum=@skey1 and companyid=@CompanyID  
  
 END  
  
  ELSE IF @table = 'List_GER_History'  
     BEGIN  
  
  SELECT TransDt, DetailTrans, UpdateBy  FROM [dbo].[fb_TransLog]  
  where formnum=@skey1 and companyid=@CompanyID  
  order by transdt ASC  
  
  END  
  
  
  ELSE IF @table = 'List_GER_Approver'  
     BEGIN  
  
  Select A.UserName as Approver, B.Approval_Dt as Approver_Dt, B.Approval_Layer as Approver_Layer,B.Remark   
        from fb_ger_Approval_info B inner join fb_user_info A on B.Approval_ID = A.UserID and a.companyid=b.companyid  
        Where B.FormNum=@skey1 and a.companyid=@companyid order by B.Approval_Layer   
  
  
  END  
  
  
  
  ELSE IF @table = 'List_GER_Policydetail'  
     BEGIN  
    select PolicyNum, RefundAmount from  fb_Refund_Many_Policy  
    where FormNum=@skey1 and CompanyID=@CompanyID  
  
  END  
  
  ELSE IF @table = 'List_GER_Beneficiary'  
     BEGIN  
  
   /*  
   change : add code  
   Name : RS  
   Date : 11 Juli 2018  
   */  
  
   Select BenID, BeneficiaryName, Beneficiary_Bank_Name,   
   Beneficiary_Bank_Account, Beneficiary_Bank_Branch,   
   Beneficiary_Bank_City, Beneficiary_Email, OnlyForDept,   
   dbo.fnc_getLOVNAME('*','BNFTP',BeneficiaryTypeCd) as BeneficiaryTypeCd,   
   dbo.fnc_getLOVNAME('*','BNFRECST',BeneficiaryResidenStatusCd) as BeneficiaryResidenStatusCd ,   
   dbo.fnc_getLOVNAME('*','BNFTRTP',BeneficiaryTranTypeCd) as BeneficiaryTranTypeCd,   
   dbo.fnc_getLOVNAME('*','BNFFCTP',BeneficiaryTranfacilityTypeCd) as BeneficiaryTranfacilityTypeCd,  
  
   dbo.fnc_getBeneficiaryCodeBank(Beneficiary_Bank_Name,CompanyID) as  Beneficiary_Bank_Code,  
   BeneficiaryTypeCd as BeneficiaryTypeCode,  
   BeneficiaryResidenStatusCd as BeneficiaryResidenStatusCode,  
   BeneficiaryTranTypeCd as BeneficiaryTranTypeCode,  
   BeneficiaryTranfacilityTypeCd as BeneficiaryTranfacilityTypeCode  
  
   From fb_Beneficiary_Info   
   where CompanyID=@CompanyID  
   and OnlyForDept=@skey1 and BeneficiaryStatus=1  
   order by BeneficiaryName  
 END  
  
 --  ELSE IF @table = 'List_Rejected'  
 --    BEGIN  
  
 --  SELECT FormNum, Dept, RejectDt, RejectReason, RejectBy, RejectType, CopiedTo FROM fb_ger_reject_info   
 --  WHERE companyid=@Companyid and Left(FormNum,3)=@skey2 and Dept =@skey1 order by FormNum desc  
  
 --END  
  
   ELSE IF @table = 'Key_GER_Beneficiary'  
     BEGIN  
  
   Select BenID, BeneficiaryName, Beneficiary_Bank_Name,   
   Beneficiary_Bank_Account, Beneficiary_Bank_Branch,   
   Beneficiary_Bank_City, Beneficiary_Email, OnlyForDept,   
   BeneficiaryTypeCd, Beneficiary_Bank_Name, Beneficiary_Bank_Account,  
   Beneficiary_Bank_Branch, BeneficiaryTranTypeCd,'IDR' as Beneficiaryacccurrency ,   
   BeneficiaryResidenStatusCd, Beneficiary_Bank_City, Beneficiary_Email  
   From fb_Beneficiary_Info   
   where CompanyID=@CompanyID  
   and BenId=@skey1      
 END  
  
  
 ELSE IF @table = 'Key_GER_header'  
 BEGIN  
   select b.code,b.Description,  
 '' as Others1,  
 '' as Others2,   
 '' as Others3,  
 '' as Others4,  
 '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
 from fb_user_dept_from a  
 inner join fb_department b  
 on a.deptcode=b.code  
 where a.userid=@skey1 AND a.companyid=@companyid  
  
  
 END  
  
   ELSE IF @table = 'GetReportSetup'  
     BEGIN  
  
  select * from fb_reportSetup where CompanyID=@CompanyID and  ReportID=@skey1   
  
  END  
  
  ELSE IF @table = 'List_TaxEntry_Summary'  
     BEGIN  
  
  --declare @taxdeduction2supplier float  
  --select  @taxdeduction2supplier=sum(taxdeduction2supplier) from fb_TaxEntry  
  --where CompanyID=@CompanyID and  formnum=@skey1   
  
  --SELECT FormNum, BeneficiaryName, ExchangeRate, Curr, TotalAmount, TaxAmount, TaxSubsidy, NettAmount, FormStatus, PolRelated, AdvanceAmount   
  --FROM fb_GER_info   
  --where CompanyID=@CompanyID and  formnum=@skey1   
  
  SELECT a.FormNum, a.BeneficiaryName, a.ExchangeRate, a.Curr, a.TotalAmount, isnull(a.TaxSubsidy, 0) as TaxSubsidy, iSnull(a.NettAmount, 0) as NettAmount, a.FormStatus, a.PolRelated, a.AdvanceAmount ,   
  isnull(sum(b.taxdeduction2supplier), 0) as Taxamount  
  FROM fb_GER_info a  
  left join fb_TaxEntry b  
  on a.formnum=b.formnum and a.companyid=b.companyid  
  where a.CompanyID=@CompanyID and  a.formnum=@skey1  
  group by a.FormNum, BeneficiaryName, a.ExchangeRate, Curr, TotalAmount, TaxSubsidy, NettAmount, FormStatus, PolRelated, AdvanceAmount   
  
  
  END  
  
  ELSE IF @table = 'List_TaxEntry_Detail'  
     BEGIN  
  
  select SeqNum as No ,a.InvoiceNum, a.TypeOfCost , a.TypeOfTax, a.TypeOfCalc, round(a.OriginalTaxableAmount,0,2) as OrigTaxableAmt,   
  round(a.OriginalTaxAmount,0,2) as OrigTaxAmt, round(a.TaxDeduction2Supplier,0,2) as TaxDeducted, round(a.IdrTaxAmount,0,2) as IdrTaxAmount, a.NamaWP, a.NPWP, a.NIK, a.[Description], a.TaxRate, a.ExchangeRate,   
  a.AccountCode, a.KodeWP, a.NamaWP, a.TaxID, b.perkPenghBruto,  b.TarifUmum, a.IdrTaxableAmount, a.LokasiTanahBangunan , a.DJPOnline  
  from fb_TaxEntry a  
  left outer join fb_taxId b on a.TaxID=b.TaxID and a.companyid = b.companyid  
  where a.CompanyID=@CompanyID and  a.formnum=@skey1  order by [No]  
  
  END  
  
  ELSE IF @table = 'Key_TaxDetail'  
     BEGIN  
  
  select FormNum, SeqNum as [No] ,TypeOfCost , TypeOfTax, TypeOfCalc, TarifUmum, TypeOfCost,TypeOfTax,   
  OriginalTaxableAmount as [Orig Taxable Amt], LokasiTanahBangunan, OriginalTaxAmount as [Orig Tax Amt],   
  TaxDeduction2Supplier as [Tax Deducted], IdrTaxAmount, KodeWP , InvoiceNum, [Description], TaxRate, TaxID,   
  ExchangeRate, AccountCode from fb_TaxEntry where CompanyID=@CompanyID and  formnum=@skey1 and SeqNum=1  
  
    
  END  
  
  
  
 ELSE IF @table = 'list_company'  
 BEGIN  
  
 select CompanyID as Codeid, CompanyName as DescriptionID,  
 '' as Others1,  
 '' as Others2,   
 '' as Others3,  
 '' as Others4,  
 '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
 from tcompany  
  
 END  
  
  
 ELSE IF @table = 'key_GER_Summary'  
 BEGIN  
  
  select @skey5=CASE WHEN codeID = 'TRAVEL' then 'TRAVLE' WHEN codeID ='ENTERTAINMENT' then 'ENTREE' ELSE 'OTHER'  END  
  from vlist_codeTransaction a right join fb_ger_info b on a.codeType=b.TransactionCode and a.companyid=b.companyid where b.FormNum=@skey1 and b.companyid=@companyid  
  
  IF @skey5 = 'OTHER' and dbo.fCheckBulkPolicy(@skey1,@CompanyID) <> 'OTHER'  
  BEGIN  
  
   SET @skey5 = 'POLICY'  
  
  
  END  
  
  SELECT   
     A.Curr, A.FormNum,A.FormType,A.FromDept,A.AdvanceFormNum,A.CreateDt,A.CheckedDt,A.ApprovedDt,   
     A.CreateBy, A.CheckedBy, A.ApprovedBy, COALESCE(A.TotalAmount,'0') AS TotalAmount, COALESCE(A.AdvanceAmount,'0') AS AdvanceAmount, COALESCE(A.DueAmount,'0') AS DueAmount, A.FormStatus,   
     A.ExchangeRate, A.TransactionCode, B.Description, A.Journalized,   
     A.BeneficiaryName, c.Code as BeneficiaryBankCode, C.BankName as BeneficiaryBankName, A.BeneficiaryBankAccount,     
     A.BeneficiaryBankBranch, A.BeneficiaryBankCity, A.BeneficiaryEmail, A.BeneficiaryAccountCurrency,   
     COALESCE(A.TaxAmount,'0') AS TaxAmount, COALESCE(A.NettAmount,'0') AS NettAmount,A.PolRelated,A.PolicyNum,A.FormLocation,A.Subject, A.PaidBy,   
     D.SlfiBankAccountNum, E.Bank as SLFIBankCode, E.Bank as SLFIBankName, A.Taxable, F.RejectType,A.Budgeted,   
     coalesce(A.BeneficiaryTypeCd,'') as BeneficiaryTypeCd,   
     isnull(dbo.fnc_getLOVNAME('*','BNFTP',A.BeneficiaryTypeCd),'') as BeneficiaryTypeNm,   
     coalesce(A.BeneficiaryResidenStatusCd,'') as BeneficiaryResidentStatusCd,  
     isnull(dbo.fnc_getLOVNAME('*','BNFRECST',A.BeneficiaryResidenStatusCd),'') as BeneficiaryResidentStatusNm,   
     coalesce(A.BeneficiaryTranTypeCd,'') as BeneficiaryTranTypeCd,  
     isnull(dbo.fnc_getLOVNAME('*','BNFTRTP',A.BeneficiaryTranTypeCd),'') as BeneficiaryTranTypeNm ,ApplicationNo,  
     G.rejectreason, @skey5 as codeTypeTransaction, A.PaymentCategory, A.PONum, a.PayeeDOB  
     FROM fb_GER_info A   
     Inner join fb_TransactionType B   
     on A.TransactionCode = B.Code   
     left join fb_ListOfBeneficiaryBank C   
     on A.BeneficiaryBankCode = C.Code   
     left join fb_Payment_Info D   
     on A.FormNum =  D.FormNum   
     left join fb_ListVoucher E   
     on SlfiBankAccountNum = E.AccountNum   
     left join fb_ger_reject_info F on A.FormNum = F.CopiedTo   
     left outer join fb_ger_reject_info G  
     on A.FormNum=g.formnum  
     WHERE A.FormNum=@skey1  and A.companyid=@companyid  
     --And A.FromDept IN(" & sSelectDept & ")")  
  
 END  
  
 ELSE IF @table = 'key_GER_Detail'  
 BEGIN  
  
  select CompanyID as Codeid, CompanyName as DescriptionID,  
  '' as Others1,  
  '' as Others2,   
  '' as Others3,  
  '' as Others4,  
  '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
  from tcompany  
  
 END  
  
 ELSE IF @table = 'key_GER_Attachment'  
 BEGIN  
  
  select CompanyID as Codeid, CompanyName as DescriptionID,  
  '' as Others1,  
  '' as Others2,   
  '' as Others3,  
  '' as Others4,  
  '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
  from tcompany  
  
 END  
  
 ELSE IF @table = 'key_GER_History'  
 BEGIN  
  
  select CompanyID as Codeid, CompanyName as DescriptionID,  
  '' as Others1,  
  '' as Others2,   
  '' as Others3,  
  '' as Others4,  
  '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
  from tcompany  
  
 END  
  
 ELSE IF @table = 'key_GER_Policy_Detail'  
 BEGIN  
  
  select CompanyID as Codeid, CompanyName as DescriptionID,  
  '' as Others1,  
  '' as Others2,   
  '' as Others3,  
  '' as Others4,  
  '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
  from tcompany  
  
 END  
  
 ELSE IF @table = 'key_GER_Policy_Bulk'  
 BEGIN  
  
  select CompanyID as Codeid, CompanyName as DescriptionID,  
  '' as Others1,  
  '' as Others2,   
  '' as Others3,  
  '' as Others4,  
  '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
  from tcompany  
  
 END  
 ELSE IF @table = 'key_login'  
 BEGIN  
  
  INSERT INTO tcheck_login  
  (  
   userid,  
   createddate  
  )  
  select @userid,getdate()  
  
  select userid,UserName,DeptId,Roles,DomainName from fb_USER_info where UserId=@userid and companyid=@companyid  
  
 END  
 ELSE IF @table = 'get_Location_Attach'  
 BEGIN  
  
  --select filelocation,case when UPPER(attachmenttype) in ('JPG','JPEG','PNG') then 'IMAGE' else attachmenttype end as attachmenttype,  
  --case   
  --when UPPER(attachmenttype) = 'PDF' THEN 'application/pdf'  
  --when UPPER(attachmenttype) = 'JPG' THEN 'image/jpeg'  
  --when UPPER(attachmenttype) = 'JPEG' THEN 'image/jpeg'  
  --when UPPER(attachmenttype) = 'PNG' THEN 'image/png'  
  --else 'application/pdf' end as MMtype  
  --from SnAPS_GER_File_Attachment_Info where formnum=@skey1 and companyid=@CompanyID AND SeqNum=@skey2  
  
  select filelocation,case when UPPER(attachmenttype) in ('JPG','JPEG','PNG') then 'IMAGE' else attachmenttype end as attachmenttype,  
  case   
  when UPPER(attachmenttype) = 'PDF' THEN 'application/pdf'  
  when UPPER(attachmenttype) = 'JPG' THEN 'image/jpeg'  
  when UPPER(attachmenttype) = 'JPEG' THEN 'image/jpeg'  
  when UPPER(attachmenttype) = 'PNG' THEN 'image/png'  
  when UPPER(attachmenttype) = 'xls' THEN 'vnd.ms-excel'  
  when UPPER(attachmenttype) = 'xlsx' THEN 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'  
  when UPPER(attachmenttype) = 'doc' THEN 'application/msword'  
  when UPPER(attachmenttype) = 'docx' THEN 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'  
  else 'application/pdf' end as MMtype  
  from SnAPS_GER_File_Attachment_Info where formnum=@skey1 and companyid=@CompanyID AND SeqNum=@skey2  
  
 END  
  
 --ROBY  
 /*  
  
 Change : Add Validation Travel and Enter  
  
 Name : RS  
 Date : 11 July 2018  
  
 */  
 ELSE IF @table = 'get_Element_Rules'  
 BEGIN  
  
  
  select @skey5=dbo.fGetTypeCodeTransaction(@skey4)  
  print @skey5  
  select @skey6=CodeName from tdcode where CodeType='ELMNTRLS' and CodeID=LEFT(@skey4,3)  
  print @skey6  
  IF @skey5 = 'OTHER'  
   BEGIN  
  
    SELECT @skey5=dbo.fCheckBulkPolicy(@skey4,@CompanyID)  
  
   END  
  
  --OTHER CONDITIONAL  
  
  IF @skey2 = 'VWONLY'  
  BEGIN   
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NAUTH' and a.AttributeControl=@skey3  
  END  
  ELSE IF @skey1 = 'NEW' AND @skey2='UPREP' and @skey5 = 'OTHER'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NEW' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey1='MOFF' and @skey5 = 'OTHER' and @skey9 <> 'ABT'  
  BEGIN   
   IF @skey2 = 'GS'  
   BEGIN  
    SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
    coalesce(a.AttributeTag,'') as AttributeTag  
    FROM tElementForm a inner join telementrulesdetail b   
    on a.formtype=b.formtype and a.attributename=b.attributename  
    inner join telementrules c on b.rulesname=c.rulesname  
    where b.rulesname = @skey6+'_NAUTH' and a.AttributeControl=@skey3  
   END  
   ELSE  
   BEGIN  
    SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
    coalesce(a.AttributeTag,'') as AttributeTag  
    FROM tElementForm a inner join telementrulesdetail b   
    on a.formtype=b.formtype and a.attributename=b.attributename  
    inner join telementrules c on b.rulesname=c.rulesname  
    where b.rulesname = @skey6+'_MOFF' and a.AttributeControl=@skey3  
   END  
  
  END  
  ELSE IF @skey1 = 'PRN' and @skey5 = 'OTHER'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_ATT' and a.AttributeControl=@skey3  
  
  END  
  --Else IF @skey2 = 'GS' and @skey1 = 'MOFF'  
  --BEGIN  
  -- SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
  -- coalesce(a.AttributeTag,'') as AttributeTag  
  -- FROM tElementForm a inner join telementrulesdetail b   
  -- on a.formtype=b.formtype and a.attributename=b.attributename  
  -- inner join telementrules c on b.rulesname=c.rulesname  
  -- where b.rulesname = @skey6+'_NAUTH' and a.AttributeControl=@skey3  
  --END  
  
  --TRAVEL CONDITIONAL  
  
  IF @skey1 = 'NEW' AND @skey2='UPREP' and @skey5 = 'TRAVLE'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NEW_TRAVEL' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey1='MOFF' and @skey5 = 'TRAVLE' and @skey9 <> 'ABT'  
  BEGIN   
   IF @skey2 = 'GS'  
   BEGIN  
    SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
    coalesce(a.AttributeTag,'') as AttributeTag  
    FROM tElementForm a inner join telementrulesdetail b   
    on a.formtype=b.formtype and a.attributename=b.attributename  
    inner join telementrules c on b.rulesname=c.rulesname  
    where b.rulesname = @skey6+'_NAUTH' and a.AttributeControl=@skey3  
   END  
   ELSE  
   BEGIN  
    SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
    coalesce(a.AttributeTag,'') as AttributeTag  
    FROM tElementForm a inner join telementrulesdetail b   
    on a.formtype=b.formtype and a.attributename=b.attributename  
    inner join telementrules c on b.rulesname=c.rulesname  
    where b.rulesname = @skey6+'_MOFF_TRAVEL' and a.AttributeControl=@skey3  
   END  
  END  
  ELSE IF @skey1 = 'PRN' and @skey5 = 'TRAVLE'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_ATT_TRAVEL' and a.AttributeControl=@skey3  
  
  END  
  
  --ENTER CONDITIONAL  
  
  IF @skey1 = 'NEW' AND @skey2='UPREP' and @skey5 = 'ENTREE'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NEW_ENTRE' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey1='MOFF' and @skey5 = 'ENTREE' and @skey9 <> 'ABT'  
  BEGIN   
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_MOFF_ENTRE' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey1 = 'PRN' and @skey5 = 'ENTREE'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_ATT_ENTRE' and a.AttributeControl=@skey3  
  
  END  
  
  --BULK CONDITIONAL  
  
  IF @skey1 = 'NEW' AND @skey2='UPREP' and @skey5 = 'BULK'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NEW_BULK' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey1='MOFF' and @skey5 = 'BULK' and @skey9 <> 'ABT'  
  BEGIN   
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_MOFF_BULK' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey1 = 'PRN' and @skey5 = 'BULK'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_ATT_BULK' and a.AttributeControl=@skey3  
  
  END  
  
  --PARENT POLICY BULK CONDITIONAL  
  
  IF @skey1 = 'NEW' AND @skey2='UPREP' and @skey5 = 'parentBulk'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NEW_PPOLICY' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey1='MOFF' and @skey5 = 'parentBulk' and @skey9 <> 'ABT'  
  BEGIN   
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_MOFF_PPOLICY' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey1 = 'PRN' and @skey5 = 'parentBulk'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_ATT_PPOLICY' and a.AttributeControl=@skey3  
  
  END  
  -- CHILD POLICY BULK CONDITIONAL  
  
  IF @skey1 = 'NEW' AND @skey2='UPREP' and @skey5 = 'childBulk'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NEW_CPOLICY' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey1='MOFF' and @skey5 = 'childBulk' and @skey9 <> 'ABT'  
  BEGIN   
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_MOFF_CPOLICY' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey1 = 'PRN' and @skey5 = 'childBulk'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_ATT_CPOLICY' and a.AttributeControl=@skey3  
  
  END  
  
  -- SINGLE POLICY BULK CONDITIONAL  
  
  IF @skey1 = 'NEW' AND @skey2='UPREP' and @skey5 = 'singlePolicy'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NEW_SPOLICY' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey1='MOFF' and @skey5 = 'singlePolicy' and @skey9 <> 'ABT'  
  BEGIN   
   IF @skey2 = 'GS'  
   BEGIN  
    SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
    coalesce(a.AttributeTag,'') as AttributeTag  
    FROM tElementForm a inner join telementrulesdetail b   
    on a.formtype=b.formtype and a.attributename=b.attributename  
    inner join telementrules c on b.rulesname=c.rulesname  
    where b.rulesname = @skey6+'_NAUTH' and a.AttributeControl=@skey3  
   END  
   ELSE  
   BEGIN  
    SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
    coalesce(a.AttributeTag,'') as AttributeTag  
    FROM tElementForm a inner join telementrulesdetail b   
    on a.formtype=b.formtype and a.attributename=b.attributename  
    inner join telementrules c on b.rulesname=c.rulesname  
    where b.rulesname = @skey6+'_MOFF_SPOLICY' and a.AttributeControl=@skey3  
   END  
  END  
  ELSE IF @skey1 = 'PRN' and @skey5 = 'singlePolicy'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_ATT_SPOLICY' and a.AttributeControl=@skey3  
  
  END  
  
  --ABT  
  
  --MOFF  
  
  ELSE IF @skey5 = 'OTHER' AND @skey1='MOFF' AND @skey2 = 'CASHIER' AND @skey9 = 'ABT'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_MOFF_ABT' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey5 = 'TRAVLE' AND @skey1='MOFF' AND @skey2 = 'CASHIER' AND @skey9 = 'ABT'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_MOFF_ABT_TRAVEL' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey5 = 'ENTREE' AND @skey1='MOFF' AND @skey2 = 'CASHIER' AND @skey9 = 'ABT'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_MOFF_ABT_ENTRE' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey5 = 'singlePolicy' AND @skey1='MOFF' AND @skey2 = 'CASHIER' AND @skey9 = 'ABT'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_MOFF_ABT_SPOLICY' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey5 = 'childBulk' AND @skey1='MOFF' AND @skey2 = 'CASHIER' AND @skey9 = 'ABT'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_MOFF_ABT_CPOLICY' and a.AttributeControl=@skey3  
  
  END  
   ELSE IF @skey5 = 'parentBulk' AND @skey1='MOFF' AND @skey2 = 'CASHIER' AND @skey9 = 'ABT'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_MOFF_ABT_PPOLICY' and a.AttributeControl=@skey3  
  
  END  
  
  --PREP  
  Else IF @skey2 = 'GS' and @skey1 = 'MOFF'  
  BEGIN  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NAUTH' and a.AttributeControl=@skey3  
  END  
  ELSE IF @skey5 = 'OTHER' AND @skey1='MOFF' AND @skey2 = 'UPREP' AND @skey9 = 'ABT'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NAUTH' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey5 = 'TRAVLE' AND @skey1='MOFF' AND @skey2 = 'UPREP' AND @skey9 = 'ABT'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NAUTH' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey5 = 'ENTREE' AND @skey1='MOFF' AND @skey2 = 'UPREP' AND @skey9 = 'ABT'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NAUTH' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey5 = 'singlePolicy' AND @skey1='MOFF' AND @skey2 = 'UPREP' AND @skey9 = 'ABT'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NAUTH' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey5 = 'childBulk' AND @skey1='MOFF' AND @skey2 = 'UPREP' AND @skey9 = 'ABT'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NAUTH' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey5 = 'parentBulk' AND @skey1='MOFF' AND @skey2 = 'UPREP' AND @skey9 = 'ABT'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NAUTH' and a.AttributeControl=@skey3  
  
  END  
  
  --END MOFF  
  
  ELSE IF @skey5 = 'OTHER' AND @skey1='ABT' AND @skey2 = 'CASHIER'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_ABT' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey5 = 'TRAVLE' AND @skey1='ABT' AND @skey2 = 'CASHIER'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_ABT_TRAVEL' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey5 = 'ENTREE' AND @skey1='ABT' AND @skey2 = 'CASHIER'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_ABT_ENTRE' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey5 = 'singlePolicy' AND @skey1='ABT' AND @skey2 = 'CASHIER'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_ABT_SPOLICY' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey5 = 'childBulk' AND @skey1='ABT' AND @skey2 = 'CASHIER'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_ABT_CPOLICY' and a.AttributeControl=@skey3  
  
  END  
   ELSE IF @skey5 = 'parentBulk' AND @skey1='ABT' AND @skey2 = 'CASHIER'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_ABT_PPOLICY' and a.AttributeControl=@skey3  
  
  END  
  
  --END ABT  
  
  --ALL  
  ELSE IF @skey1 = 'NEW' AND @skey2<>'UPREP'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NAUTH' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey5 = 'OTHER' AND @skey1 NOT IN ('NEW','MOFF','PRN') --AND @skey2 <> 'UPREP'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NAUTH' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey5 = 'TRAVLE' AND @skey1 NOT IN ('NEW','MOFF','PRN') --AND @skey2 <> 'UPREP'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NAUTH_TRAVEL' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey5 = 'ENTREE' AND @skey1 NOT IN ('NEW','MOFF','PRN') --AND @skey2 <> 'UPREP'  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NAUTH_ENTRE' and a.AttributeControl=@skey3  
  
  END  
  ELSE IF @skey5 = 'parentBulk' AND @skey1 NOT IN ('NEW','MOFF','PRN')  
  BEGIN  
  
   SELECT b.rulesname,a.attributename,a.attributetype,case when b.rulesvalue = 'AC' THEN 'false' else 'true' end RulesValue,coalesce(c.RulesText,'') as RulesText,  
   coalesce(a.AttributeTag,'') as AttributeTag  
   FROM tElementForm a inner join telementrulesdetail b   
   on a.formtype=b.formtype and a.attributename=b.attributename  
   inner join telementrules c on b.rulesname=c.rulesname  
   where b.rulesname = @skey6+'_NAUTH' and a.AttributeControl=@skey3  
  
  END  
  
 END  
 ELSE IF @table = 'check_App_No'  
 BEGIN  
  
  IF EXISTS(select top 1 * from fb_ger_info where applicationno=@skey1  and companyid=@companyid )  
   select convert(bit,1) as resultFlag,'Application number already exists !!!' as ResultMessage  
  ELSE  
   select convert(bit,0) as resultFlag,'' as ResultMessage  
  
 END  
  
 ELSE IF @table = 'combo_ENTRE_title'  
  begin   
  
   select CodeID as Codeid, Codename as DescriptionID,'' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
    from tdcode where CodeType='TTLTP'  
  
  end  
 ELSE IF @table = 'combo_ENTRE_typeCompany'  
  begin   
  
   select CodeID as Codeid, Codename as DescriptionID,'' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
    from tdcode where CodeType='ENTYCP'  
  
  end  
 ELSE IF @table = 'Menu_List'  
  begin   
  
   select distinct a.CompanyId, a.Objectid, a.ObjectName, a.ObjectTitle,a.ObjectType,   
   a.ObjectParent, a.ObjectSequence, a.ObjectLink, a.ObjectImage, a.LinkChild, a.ObjectShortcut  
   from tobject a  
   inner join trole_detail b  
   on a.ObjectID=b.ObjectID  and a.CompanyID=b.CompanyID  
   inner join trole c  
   on b.RoleID=c.RoleID and b.CompanyID=c.CompanyID  
   inner join tuser_role d  
   on d.RoleID=c.RoleID and d.CompanyID=c.CompanyID  
   inner join fb_USER_info e  
   on e.userid=d.userid and e.companyid=d.companyid  
   where e.userid=@userid and a.CompanyID=@CompanyID  
   and isnull(e.logonstatus,'0')<>'DIS'   
  end  
 else if @table = 'TRXTYPEAPPR'  
 begin   
  select distinct B.Code as Codeid, B.[Description] as DescriptionID,'' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
    FROM dbo.fb_GER_info AS A INNER JOIN   
    dbo.fb_TransactionType AS B ON A.TransactionCode = B.Code LEFT OUTER JOIN   
    dbo.fb_ListOfBeneficiaryBank AS C ON A.BeneficiaryBankCode = C.Code LEFT OUTER JOIN   
    dbo.fb_Payment_Info AS D ON A.FormNum = D.FormNum LEFT OUTER JOIN   
    dbo.fb_ListVoucher AS E ON D.SLFIBankAccountNum = E.AccountNum LEFT OUTER JOIN   
    dbo.fb_GER_Reject_Info AS F ON A.FormNum = F.CopiedTo   
    WHERE A.FormLocation = @skey1 and left(A.FormStatus,2)='FA'  and A.companyid=@companyid  
  
    --SELECT    
    --distinct B.Code as TransactionCode, B.[Description]  as TransactionDescription  
    --FROM dbo.fb_GER_info AS A INNER JOIN   
    --dbo.fb_TransactionType AS B ON A.TransactionCode = B.Code LEFT OUTER JOIN   
    --dbo.fb_ListOfBeneficiaryBank AS C ON A.BeneficiaryBankCode = C.Code LEFT OUTER JOIN   
    --dbo.fb_Payment_Info AS D ON A.FormNum = D.FormNum LEFT OUTER JOIN   
    --dbo.fb_ListVoucher AS E ON D.SLFIBankAccountNum = E.AccountNum LEFT OUTER JOIN   
    --dbo.fb_GER_Reject_Info AS F ON A.FormNum = F.CopiedTo   
    --WHERE A.FormLocation = @skey1 and left(A.FormStatus,2)='FA'  
 end  
  
 /*  
 Name : RS  
 Date : 03 September 2018  
 Change : Get Policy GER List View  
 */  
  
 ELSE if @table='ger_policyNolist'  
 begin  
  
  IF @skey2<>'' AND @skey2 <> '-'   
   SET @stmt=' where coalesce(policyNumber,'''') LIKE ' + '''' + '%' + @skey2 + '%'+ ''''   
  ELSE  
   SET @stmt=''  
  
  --Get Total Rows matched with criteria  
  
  CREATE TABLE #trows1_policyListGER (TotalRows INT)  
  
  SELECT @TotalRows=0,  
    @stmt2='INSERT INTO #trows1_policyListGER(TotalRows) SELECT COUNT(1) from dbo.fTable_policyNoFilterGER('''+@CompanyID+''')'  
  --PRINT @stmt2  
  EXEC (@stmt2)  
  SELECT @TotalRows=COALESCE(TotalRows,0) FROM #trows1_policyListGER  
  
  delete from #trows1_policyListGER  
  
  SELECT @TotalRows2=0,  
    @stmt2='INSERT INTO #trows1_policyListGER(TotalRows) SELECT COUNT(1) from dbo.fTable_policyNoFilterGER('''+@CompanyID+''') ' + @stmt   
  --PRINT @stmt2  
  EXEC (@stmt2)  
  SELECT @TotalRows2=COALESCE(TotalRows,0) FROM #trows1_policyListGER  
  
  DROP TABLE #trows1_policyListGER  
  
  CREATE TABLE #temp_gerData_policyList (TotalRows INT,TotalFilter INT,SequenceNo INT,policyNumber [varchar](10), totalAmount float, paidAmount float, remainingAmount float)  
  
  --Select Rows matched with criteria  
  SET @stmt= 'INSERT INTO #temp_gerData_policyList SELECT ' + CAST(@TotalRows AS VARCHAR) + ' AS TotalRows,' + CAST(@TotalRows2 AS VARCHAR) + ' AS TotalFilter, ' +  
       'NULL,policyNumber, ' +  
       'totalAmount, ' +  
       'paidAmount, ' +  
       'remainingAmount FROM ' +  
       '(SELECT ' +  
       'policyNumber,totalAmount,paidAmount,remainingAmount ' +  
       'from dbo.fTable_policyNoFilterGER('''+@CompanyID+''') ' + @stmt + ') LST ORDER BY '+@skey10  
  PRINT @stmt  
  EXEC (@stmt)  
  
  UPDATE a SET a.SequenceNo = a.SQNumber  
  FROM (  
     SELECT SequenceNo, ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS SQNumber  
     FROM #temp_gerData_policyList  
     ) a  
  
  SELECT TotalRows,TotalFilter,SequenceNo,policyNumber,   
  convert(varchar(20),cast(totalAmount as money),1) AS totalAmount,convert(varchar(20),cast(paidAmount as money),1) AS paidAmount,  
  convert(varchar(20),cast(remainingAmount as money),1) AS remainingAmount  
  FROM #temp_gerData_policyList WHERE (SequenceNo BETWEEN ((@pageNum-1)*@pageSize)+1 AND (@pageNum*@pageSize) )  
  
  DROP TABLE #temp_gerData_policyList  
  
 end  
  
  
 /*  
 Name : RS  
 Date : 05 September 2018  
 Change : Get Beneficiary GER  
 */  
  
 ELSE if @table='ger_BeneficiaryListView'  
 begin  
  
  IF @skey2<>'' AND @skey2 <> '-'   
   SET @stmt=' where coalesce(BeneficiaryName,'''') LIKE ' + '''' + '%' + @skey2 + '%'+ ''''   
  ELSE  
   SET @stmt=''  
  
  --Get Total Rows matched with criteria  
  
  CREATE TABLE #trows1_beneficiaryListGER (TotalRows INT)  
  
  SELECT @TotalRows=0,  
    @stmt2='INSERT INTO #trows1_beneficiaryListGER(TotalRows) SELECT COUNT(1) from dbo.fTable_beneficiaryGERList('''+@CompanyID+''','''+@skey1+''')'  
  --PRINT @stmt2  
  EXEC (@stmt2)  
  SELECT @TotalRows=COALESCE(TotalRows,0) FROM #trows1_beneficiaryListGER  
  
  delete from #trows1_beneficiaryListGER  
  
  SELECT @TotalRows2=0,  
    @stmt2='INSERT INTO #trows1_beneficiaryListGER(TotalRows) SELECT COUNT(1) from dbo.fTable_beneficiaryGERList('''+@CompanyID+''','''+@skey1+''') ' + @stmt   
  --PRINT @stmt2  
  EXEC (@stmt2)  
  SELECT @TotalRows2=COALESCE(TotalRows,0) FROM #trows1_beneficiaryListGER  
  
  DROP TABLE #trows1_beneficiaryListGER  
  
  CREATE TABLE #temp_gerData_beneficiaryList   
  (  
     TotalRows INT,TotalFilter INT,SequenceNo INT,  
     BenID varchar(7) NULL,  
     BeneficiaryName varchar(50) NULL,  
     Beneficiary_Bank_Name varchar(50) NULL,  
     Beneficiary_Bank_Account varchar(50) NULL,  
     Beneficiary_Bank_Branch varchar(50) NULL,  
     Beneficiary_Bank_City varchar(50) NULL,  
     Beneficiary_Email varchar(50) NULL,  
     OnlyForDept varchar(50) NULL,  
     BeneficiaryTypeCd varchar(75) NULL,  
     BeneficiaryResidenStatusCd varchar(75) NULL,  
     BeneficiaryTranTypeCd varchar(75) NULL,  
     BeneficiaryTranfacilityTypeCd varchar(75) NULL,  
     Beneficiary_Bank_Code varchar(50) NULL,  
     BeneficiaryTypeCode varchar(50) NULL,  
     BeneficiaryTranTypeCode varchar(50) NULL,  
     BeneficiaryResidenStatusCode varchar(50) NULL,  
     BeneficiaryTranfacilityTypeCode varchar(50) NULL  
  )  
  
  --Select Rows matched with criteria  
  SET @stmt= 'INSERT INTO #temp_gerData_beneficiaryList SELECT ' + CAST(@TotalRows AS VARCHAR) + ' AS TotalRows,' + CAST(@TotalRows2 AS VARCHAR) + ' AS TotalFilter, ' +  
       'NULL,LST.* FROM ' +  
       '(SELECT ' +  
       'BenID,BeneficiaryName,Beneficiary_Bank_Name,Beneficiary_Bank_Account,Beneficiary_Bank_Branch,Beneficiary_Bank_City, ' +  
       'Beneficiary_Email,OnlyForDept,BeneficiaryTypeCd,BeneficiaryResidenStatusCd,BeneficiaryTranTypeCd,BeneficiaryTranfacilityTypeCd, ' +  
       'Beneficiary_Bank_Code,BeneficiaryTypeCode,BeneficiaryTranTypeCode,BeneficiaryResidenStatusCode,BeneficiaryTranfacilityTypeCode ' +  
       'from dbo.fTable_beneficiaryGERList('''+@CompanyID+''','''+@skey1+''') ' + @stmt + ') LST ORDER BY '+@skey10  
  PRINT @stmt  
  EXEC (@stmt)  
  
  UPDATE a SET a.SequenceNo = a.SQNumber  
  FROM (  
     SELECT SequenceNo, ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS SQNumber  
     FROM #temp_gerData_beneficiaryList  
     ) a  
  
  SELECT TotalRows,TotalFilter,SequenceNo,*  
  FROM #temp_gerData_beneficiaryList WHERE (SequenceNo BETWEEN ((@pageNum-1)*@pageSize)+1 AND (@pageNum*@pageSize) )  
  
  DROP TABLE #temp_gerData_beneficiaryList  
  
 end  
  
 /*  
 Name : RS  
 Date : 17 September 2018  
 Change : Get Filter CAR  
 */  
  
 ELSE if @table='ger_CARFilterListView'  
 begin  
  
  --IF @skey2<>'' AND @skey2 <> '-'   
  -- SET @stmt=' where coalesce(CARNumber,'''') LIKE ' + '''' + '%' + @skey2 + '%'+ ''''   
  --ELSE  
  -- SET @stmt=''  
  
  ----Get Total Rows matched with criteria  
  
  --CREATE TABLE #trows1_carFilterListGER (TotalRows INT)  
  
  --SELECT @TotalRows=0,  
  --  @stmt2='INSERT INTO #trows1_carFilterListGER(TotalRows) SELECT COUNT(1) from dbo.fTable_CARSelectedFilter('''+@CompanyID+''','''+@skey1+''')'  
  ----PRINT @stmt2  
  --EXEC (@stmt2)  
  --SELECT @TotalRows=COALESCE(TotalRows,0) FROM #trows1_carFilterListGER  
  
  --delete from #trows1_carFilterListGER  
  
  --SELECT @TotalRows2=0,  
  --  @stmt2='INSERT INTO #trows1_carFilterListGER(TotalRows) SELECT COUNT(1) from dbo.fTable_CARSelectedFilter('''+@CompanyID+''','''+@skey1+''') ' + @stmt   
  ----PRINT @stmt2  
  --EXEC (@stmt2)  
  --SELECT @TotalRows2=COALESCE(TotalRows,0) FROM #trows1_carFilterListGER  
  
  --DROP TABLE #trows1_carFilterListGER  
  
  --CREATE TABLE #temp_gerData_carFilterList   
  --(  
  --   TotalRows INT,TotalFilter INT,SequenceNo INT,  
  --   CARNumber varchar(20) NULL,  
  --   TotalAmount float NULL,  
  --   PaidAmount Float NULL  
  --)  
  
  ----Select Rows matched with criteria  
  --SET @stmt= 'INSERT INTO #temp_gerData_carFilterList SELECT ' + CAST(@TotalRows AS VARCHAR) + ' AS TotalRows,' + CAST(@TotalRows2 AS VARCHAR) + ' AS TotalFilter, ' +  
  --     'NULL,LST.* FROM ' +  
  --     '(SELECT ' +  
  --     'CARNumber,TotalAmount,PaidAmount ' +  
  --     'from dbo.fTable_CARSelectedFilter('''+@CompanyID+''','''+@skey1+''') ' + @stmt + ') LST ORDER BY '+@skey10  
  
  
  --PRINT @stmt  
  --EXEC (@stmt)  
  --insert into test2 values(GETDATE(), @stmt)  
  
  
  SELECT   
   @TotalRows = count(*) over()  
  FROM dbo.fb_ger_info AS A   
  INNER JOIN dbo.fb_Payment_Info AS C ON A.FormNum = C.FormNum AND A.CompanyID=C.CompanyID  
  LEFT OUTER JOIN dbo.fb_AdvanceAndSettlement_Info AS B ON A.FormNum = B.AdvanceFormNum AND A.COMPANYID=B.COMPANYID  
  WHERE   
   (A.FormType = 'CAR') AND (C.Status = 'PAID') AND (B.SettleStatus IS NULL) and   
   a.FormNum not in (select AdvanceFormNum from fb_ger_info where FormType = 'GER' and (AdvanceFormNum <> '' or AdvanceFormNum is null) and FormStatus <> 'REJ') and a.FormStatus <> 'REJ'  
   and FromDept = @skey1 and a.CompanyID = @CompanyID  
   and (A.FormNum like '%'+@skey2+'%' or @skey2 is Null or @skey2='')   
  
 SELECT   
  *   
 From (  
  SELECT top 1000  
   @TotalRows TotalRows,  
   @TotalRows TotalFilter,  
   ROW_NUMBER() OVER(order by A.CreateDt desc) SequenceNo,  
   --A.COMPANYID,  
   A.FormNum AS CARNumber,   
   --A.FromDept,   
   A.NettAmount as totalAmount,   
   C.PaidAmount as paidAmount  
  FROM dbo.fb_ger_info AS A   
  INNER JOIN dbo.fb_Payment_Info AS C ON A.FormNum = C.FormNum AND A.CompanyID=C.CompanyID  
  LEFT OUTER JOIN dbo.fb_AdvanceAndSettlement_Info AS B ON A.FormNum = B.AdvanceFormNum AND A.COMPANYID=B.COMPANYID  
  WHERE   
   (A.FormType = 'CAR') AND (C.Status = 'PAID') AND (B.SettleStatus IS NULL) and   
   a.FormNum not in (select AdvanceFormNum from fb_ger_info where FormType = 'GER' and (AdvanceFormNum <> '' or AdvanceFormNum is null) and FormStatus <> 'REJ') and a.FormStatus <> 'REJ'  
   and FromDept = @skey1 and a.CompanyID = @CompanyID  
   and (A.FormNum like '%'+@skey2+'%' or @skey2 is Null or @skey2='')   
   ) AS tbl  
 WHERE (SequenceNo BETWEEN ((@pageNum - 1)* @pagesize + 1) AND (@pageNum * @pagesize)  
  OR (@pageNum IS NULL OR @pagesize IS NULL))    
  ORDER BY SequenceNo   
  
  
  --UPDATE a SET a.SequenceNo = a.SQNumber  
  --FROM (  
  --   SELECT SequenceNo, ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS SQNumber  
  --   FROM #temp_gerData_carFilterList  
  --   ) a  
  
  --SELECT TotalRows,TotalFilter,SequenceNo,CARNumber,   
  --convert(varchar(20),cast(totalAmount as money),1) AS totalAmount,convert(varchar(20),cast(paidAmount as money),1) AS paidAmount  
  --FROM #temp_gerData_carFilterList WHERE (SequenceNo BETWEEN ((@pageNum-1)*@pageSize)+1 AND (@pageNum*@pageSize) )  
  
  --DROP TABLE #temp_gerData_carFilterList  
  
 end  
  
 /*  
 Name : RS  
 Date : 24 September 2018  
 Change : Policy Bulk Detail  
 */  
  
 /*  
  
 exec usp_get_records   
 @table='ger_policyBulkDetailList'  
 ,@skey2='',@PageSize='10'  
 ,@PageNum='1',@skey10='4 asc'  
 ,@skey1='GER317301',@CompanyID='SLF'  
  
 */  
  
  
 ELSE if @table='ger_policyBulkDetailList'  
 begin  
  
  IF dbo.fCheckBulkPolicy(@skey1,@CompanyID) = 'childBulk' AND @skey2<>'' AND @skey2 <> '-'   
  BEGIN  
   SET @stmt=' where SUBGER = ' + '''' + @skey1 + '''' + 'AND coalesce(policyNum,'''') LIKE ' + '''' + '%' + @skey2 + '%'+ ''''   
   select @skey3=MainFormNum from fb_ger_info where FormNum=@skey1 and CompanyID=@CompanyID  
  END  
  ELSE IF dbo.fCheckBulkPolicy(@skey1,@CompanyID) = 'childBulk' AND (@skey2='' or @skey2 = '-')  
  BEGIN  
   SET @stmt=' where SUBGER = ' + '''' + @skey1 + ''''  
   select @skey3=MainFormNum from fb_ger_info where FormNum=@skey1 and CompanyID=@CompanyID  
  END   
  else if dbo.fCheckBulkPolicy(@skey1,@CompanyID) = 'parentBulk' AND @skey2<>'' AND @skey2 <> '-'   
  BEGIN  
   select @skey3=MainFormNum from fb_ger_info where FormNum=@skey1 and CompanyID=@CompanyID  
   SET @stmt=' where coalesce(policyNum,'''') LIKE ' + '''' + '%' + @skey2 + '%'+ ''''   
  END  
  ELSE  
  BEGIN  
   select @skey3=MainFormNum from fb_ger_info where FormNum=@skey1 and CompanyID=@CompanyID  
   SET @stmt=''   
  END  
  
  
  --Get Total Rows matched with criteria  
  
  CREATE TABLE #trows1_policyBulkDetailList (TotalRows INT)  
  
  SELECT @TotalRows=0,  
    @stmt2='INSERT INTO #trows1_policyBulkDetailList(TotalRows) SELECT COUNT(1) from dbo.fTable_policyBulkDetail('''+@CompanyID+''','''+@skey3+''')'  
  --PRINT @stmt2  
  EXEC (@stmt2)  
  SELECT @TotalRows=COALESCE(TotalRows,0) FROM #trows1_policyBulkDetailList  
  
  delete from #trows1_policyBulkDetailList  
  
  SELECT @TotalRows2=0,  
    @stmt2='INSERT INTO #trows1_policyBulkDetailList(TotalRows) SELECT COUNT(1) from dbo.fTable_policyBulkDetail('''+@CompanyID+''','''+@skey3+''') ' + @stmt   
  --PRINT @stmt2  
  EXEC (@stmt2)  
  SELECT @TotalRows2=COALESCE(TotalRows,0) FROM #trows1_policyBulkDetailList  
  
  DROP TABLE #trows1_policyBulkDetailList  
  
  CREATE TABLE #temp_gerData_policyBulkDetailList  
  (  
     TotalRows INT,TotalFilter INT,SequenceNo INT,  
     subGER varchar(10) NULL,  
     mainGER varchar(10) NULL,  
     policyNum varchar(10) NULL,  
     beneficiaryName varchar(50) NULL,  
     beneficiary_Bank_Name varchar(50) NULL,  
     beneficiary_Bank_Account varchar(50) NULL,  
     TotalAmount float NULL  
  )  
  
  --Select Rows matched with criteria  
  SET @stmt= 'INSERT INTO #temp_gerData_policyBulkDetailList SELECT ' + CAST(@TotalRows AS VARCHAR) + ' AS TotalRows,' + CAST(@TotalRows2 AS VARCHAR) + ' AS TotalFilter, ' +  
       'NULL,LST.* FROM ' +  
       '(SELECT ' +  
       'subGER, mainGER, policyNum, beneficiaryName, beneficiaryBankName, beneficiaryBankAccount,TotalAmount ' +  
       'from dbo.fTable_policyBulkDetail('''+@CompanyID+''','''+@skey3+''') ' + @stmt + ') LST ORDER BY '+@skey10  
  PRINT @stmt  
  EXEC (@stmt)  
  
  UPDATE a SET a.SequenceNo = a.SQNumber  
  FROM (  
     SELECT SequenceNo, ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS SQNumber  
     FROM #temp_gerData_policyBulkDetailList  
     ) a  
  
  SELECT TotalRows,TotalFilter,SequenceNo, subGER, mainGER, policyNum, beneficiaryName, beneficiary_Bank_Name, beneficiary_Bank_Account,  
  convert(varchar(20),cast(totalAmount as money),1) AS totalAmount  
  FROM #temp_gerData_policyBulkDetailList WHERE (SequenceNo BETWEEN ((@pageNum-1)*@pageSize)+1 AND (@pageNum*@pageSize) )  
  
  DROP TABLE #temp_gerData_policyBulkDetailList  
  
 end  
 ELSE if @table='PaymentCategory'  
 begin  
  if @skey1 in (select distinct codedept from dbo.fb_payment_catagory where companyid = @CompanyID )  
  begin   
    select a.CodeID, b.CodeName as DescriptionID,'' as Others1, '' as Others2, '' as Others3,'' as Others4,'' as Others5, '' as Others6,  '' as Others7, '' as Others8    
   from fb_payment_catagory a inner join tcode b on a.CompanyID =  b.CompanyID and  a.CodeID=b.CodeID  
    where a.CompanyID=@COMPANYID and a.CodeDept=@skey1 and b.CodeType = 'PyCat' order by codesequence  
  end  
  else  
  begin  
   select CodeID, CodeName as DescriptionID, '' as Others1,  
   '' as Others2,   
   '' as Others3,  
   '' as Others4,  
   '' as Others5,  
      '' as Others6,  
      '' as Others7, '' as others8 from tcode where CodeType = 'PyCat' and CompanyID = @COMPANYID order by codesequence  
  end  
 end  
 -------------------AJI---------------------
 ELSE if @table='DetailExpenses'  
 begin  
   select CodeID, CodeName as DescriptionID, '' as Others1,  
   '' as Others2,   
   '' as Others3,  
   '' as Others4,  
   '' as Others5,  
      '' as Others6,  
      '' as Others7, '' as others8 from tcode where CodeType = 'DTLEX' and CompanyID = @COMPANYID order by codesequence   
 end  
 -----------------------------------------------------
 ELSE IF @table='OutstandingDays'  
 BEGIN  
  declare @dt1 datetime = @skey2  
  declare @dt2 datetime = @skey3  
  
  select distinct DATEDIFF(DAY,d.TransferedDt, GETDATE()) as CodeID, DATEDIFF(DAY,d.TransferedDt, GETDATE()) DescriptionID, '' as Others1,  
  '' as Others2,   
  '' as Others3,  
  '' as Others4,  
  '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
  from fb_ger_info a   
  left join fb_USER_info b on a.CompanyID =  b.CompanyID and a.CreateBy = b.UserId   
  LEFT JOIN  fb_ger_info c on a.CompanyID = b.CompanyID and c.FormType = 'GER' and a.FormNum = c.AdvanceFormNum and c.FormStatus not in ('REJ')  
  left join fb_Payment_Info d on a.CompanyID = d.CompanyID and a.FormNum = d.FormNum   
  where a.FormType= 'CAR' and a.FormStatus = 'PAID' and a.PaidBy !='Zero Payment' and a.FormStatus+isnull(c.FormStatus, '') != 'PAIDPAID' and DATEDIFF(DAY,d.TransferedDt, GETDATE()) is not null and   
  (convert(varchar(10),A.CreateDt,121)>=convert(varchar(10),@dt1,121) and convert(varchar(10),A.CreateDt,121)<=convert(varchar(10),@dt2,121))   
  order by DATEDIFF(DAY,d.TransferedDt, GETDATE()) desc  
 END  
 ELSE IF @table = 'combo_ENTRE_Reason'  
  begin   
  
   select CodeID as Codeid, Codename as DescriptionID,'' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
    from tdcode where CodeType='RSN' order by CodeSequence asc  
  
  end  
  ELSE IF @table = 'combo_ENTRE_typeOfEntertaiment'  
  begin   
  
   select CodeID as Codeid, Codename as DescriptionID,'' as Others1,  
    '' as Others2,   
    '' as Others3,  
    '' as Others4,  
    '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as others8  
    from tdcode where CodeType='CETOE' order by CodeSequence asc  
  
  end  
  else if @table = 'combo_ListNoId'  
 begin  
  SELECT ListNo as CodeID, ListNo as DescriptionID,ID as Others1,  
 TotalAmount as Others2,   
  ID as Others3,  
  '' as Others4,  
  '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as Others8  
 FROM NDARS02_DEV.dbo.ListNoIDforSNAPS  
 end  
 else if @table = 'ListNoId_detail'  
 begin  
  
 SELECT ListNo as CodeID, ListNo as DescriptionID,TotalAmount as Others1,  
 ID as Others2,   
  '' as Others3,  
  '' as Others4,  
  '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as Others8  
 FROM NDARS02_DEV.dbo.ListNoIDforSNAPS  
 where ListNo = @skey1 --group by ListNo  
  
 end  
 else if @table = 'get_ListNoID'  
 begin  
  --SELECT [CompanyID] as Others1  
  --  ,[Formnum] as CodeID  
  --  ,[ListNoID] as DescriptionID  
  --  ,Amount as Others2,  
  --  --,case when ListNoID like '%RF%' then case when sum([NettReinsPremium]) < 0 then sum([NettReinsPremium]) * -1 else sum([NettReinsPremium]) end else sum(NettReinsPremium) end as Others2,  
  --  ID as Others3,  
  --'' as Others4,  
  --'' as Others5,  
  --   '' as Others6,  
  --   '' as Others7, '' as Others8  
  --FROM [dbo].[fb_listNo_ger] where formnum = @skey1 --and DebitCredit = 'D'  
  --group by [CompanyID],[Formnum],[ListNoID], ID, Amount  
  
  
    
 SELECT a.[CompanyID] as Others1  
    ,a.[Formnum] as CodeID  
    ,a.[ListNoID] as DescriptionID  
    ,b.TotalAmount as Others2,  
    --,case when ListNoID like '%RF%' then case when sum([NettReinsPremium]) < 0 then sum([NettReinsPremium]) * -1 else sum([NettReinsPremium]) end else sum(NettReinsPremium) end as Others2,  
    b.ID as Others3,  
  '' as Others4,  
  '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as Others8  
  FROM [dbo].[fb_listNo_ger] a  
  left join NDARS02_DEV.dbo.ListNoIDforSNAPS b on  a.ListNoID = b.ListNo  
  where formnum = @skey1 --and DebitCredit = 'D'  
  group by a.[CompanyID],a.[Formnum],a.[ListNoID], b.ID,b.TotalAmount  
 end  
 else if @table = 'get_beneficiarylistreport'  
 begin  
  select distinct BeneficiaryName as CodeID, BeneficiaryName as DescriptionID,'' as Others1,   
     '' as Others2,   
  '' as Others3,  
  '' as Others4,  
  '' as Others5,  
     '' as Others6,  
     '' as Others7, '' as Others8 from fb_ger_info where convert(varchar(8), CreateDt, 112) between @skey1 and @skey2 and FormStatus = @skey3 and CompanyID = @CompanyID  
     --order by CreateDt desc  
  
 end  
 else if @table = 'get_ListMTF'  
 begin   
  select FormNum as CodeID, NomorRekening as DescriptionID, NamaPemilikRekening Others1, Bank Others2, Currency Others3, Keterangan Others4, Email Others5, Amount Others6, '' as Others7, '' as Others8 from fb_ger_mtf_detail where FormNum  = @skey1  
 end  
   
END  