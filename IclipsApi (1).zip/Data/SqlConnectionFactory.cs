
using System.Data;
using System.Data.SqlClient;

namespace IclipsApi.Data
{
    public class SqlConnectionFactory
    {
        private readonly IConfiguration _config;

        public SqlConnectionFactory(IConfiguration config)
        {
            _config = config;
        }

        public IDbConnection Create()
        {
            return new SqlConnection(_config.GetConnectionString("DefaultConnection"));
        }
    }
}
