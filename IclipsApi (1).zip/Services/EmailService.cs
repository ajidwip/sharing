
using IclipsApi.Repositories;

namespace IclipsApi.Services
{
    public class EmailService
    {
        private readonly EmailRepository _repo;

        public EmailService(EmailRepository repo)
        {
            _repo = repo;
        }

        public object Execute(string procedure, Dictionary<string, object> parameters)
        {
            return _repo.Execute(procedure, parameters);
        }
    }
