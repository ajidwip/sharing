
using IclipsApi.Repositories;

namespace IclipsApi.Services
{
    public class AgentService
    {
        private readonly AgentRepository _repo;

        public AgentService(AgentRepository repo)
        {
            _repo = repo;
        }

        public object Execute(string procedure, Dictionary<string, object> parameters)
        {
            return _repo.Execute(procedure, parameters);
        }
    }
