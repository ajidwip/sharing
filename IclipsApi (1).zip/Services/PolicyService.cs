
using IclipsApi.Repositories;

namespace IclipsApi.Services
{
    public class PolicyService
    {
        private readonly PolicyRepository _repo;

        public PolicyService(PolicyRepository repo)
        {
            _repo = repo;
        }

        public object Execute(string procedure, Dictionary<string, object> parameters)
        {
            return _repo.Execute(procedure, parameters);
        }
    }
