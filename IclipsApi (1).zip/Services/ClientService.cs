
using IclipsApi.Repositories;

namespace IclipsApi.Services
{
    public class ClientService
    {
        private readonly ClientRepository _repo;

        public ClientService(ClientRepository repo)
        {
            _repo = repo;
        }

        public object Execute(string procedure, Dictionary<string, object> parameters)
        {
            return _repo.Execute(procedure, parameters);
        }
    }
