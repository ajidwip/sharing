
namespace IclipsApi.Models
{
    public class ClientRequest
    {
        public Dictionary<string, object> Data { get; set; }
    }
}
