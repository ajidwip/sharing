
namespace IclipsApi.Models
{
    public class EmailRequest
    {
        public string CompanyId { get; set; }
        public string Recipients { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public string Attachment { get; set; }
        public string BodyFormat { get; set; }
    }
}
