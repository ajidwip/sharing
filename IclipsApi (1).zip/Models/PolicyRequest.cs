
namespace IclipsApi.Models
{
    public class PolicyRequest
    {
        public Dictionary<string, object> Data { get; set; }
    }
}
