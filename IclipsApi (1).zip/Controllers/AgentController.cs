
using Microsoft.AspNetCore.Mvc;
using IclipsApi.Services;

namespace IclipsApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AgentController : ControllerBase
    {
        private readonly AgentService _service;

        public AgentController(AgentService service)
        {
            _service = service;
        }

        [HttpPost("execute")]
        public IActionResult Execute([FromQuery] string procedure, [FromBody] Dictionary<string, object> parameters)
        {
            var result = _service.Execute(procedure, parameters);
            return Ok(result);
        }
    }
