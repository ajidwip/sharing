
using System.Data;

namespace IclipsApi.Helpers
{
    public static class DataReaderHelper
    {
        public static List<Dictionary<string, object>> ToList(IDataReader reader)
        {
            var list = new List<Dictionary<string, object>>();

            while (reader.Read())
            {
                var row = new Dictionary<string, object>();
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    row[reader.GetName(i)] = reader.GetValue(i);
                }
                list.Add(row);
            }

            return list;
        }
    }
}
