
using System.Data;
using IclipsApi.Data;
using IclipsApi.Helpers;

namespace IclipsApi.Repositories
{
    public class EmailRepository
    {
        private readonly SqlConnectionFactory _factory;

        public EmailRepository(SqlConnectionFactory factory)
        {
            _factory = factory;
        }

        public List<Dictionary<string, object>> Execute(string storedProcedure, Dictionary<string, object> parameters)
        {
            using var conn = _factory.Create();
            using var cmd = conn.CreateCommand();

            cmd.CommandText = storedProcedure;
            cmd.CommandType = CommandType.StoredProcedure;

            foreach (var p in parameters)
            {
                var param = cmd.CreateParameter();
                param.ParameterName = p.Key;
                param.Value = p.Value ?? DBNull.Value;
                cmd.Parameters.Add(param);
            }

            conn.Open();
            using var reader = cmd.ExecuteReader();
            return DataReaderHelper.ToList(reader);
        }
    }
